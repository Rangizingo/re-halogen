0000000000399500 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy>:
; _ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy():
	s_clause 0x2                                               // 000000399500: BF850002
	s_load_b32 s3, s[0:1], 0x138                               // 000000399504: F40000C0 F8000138
	s_load_b128 s[16:19], s[0:1], 0x128                        // 00000039950C: F4080400 F8000128
	s_load_b128 s[12:15], s[0:1], 0x160                        // 000000399514: F4080300 F8000160
	s_mov_b32 s6, -1                                           // 00000039951C: BE8600C1
	s_waitcnt lgkmcnt(0)                                       // 000000399520: BF89FC07
	s_cmp_ge_i32 s2, s3                                        // 000000399524: BF030302
	s_cbranch_scc0 3903                                        // 000000399528: BFA10F3F <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3d28>
	s_load_b256 s[4:11], s[0:1], 0x140                         // 00000039952C: F40C0100 F8000140
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000399534: 32020084
	v_bfe_u32 v2, v0, 4, 1                                     // 000000399538: D6100002 02050900
	v_and_b32_e32 v89, 15, v0                                  // 000000399540: 36B2008F
	s_sub_i32 s3, s2, s3                                       // 000000399544: 81830302
	s_delay_alu instid0(VALU_DEP_3)                            // 000000399548: BF870003
	v_and_b32_e32 v1, 14, v1                                   // 00000039954C: 3602028E
	s_lshl_b32 s3, s3, 4                                       // 000000399550: 84038403
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000399554: BF870481
	v_or3_b32 v80, s3, v1, v2                                  // 000000399558: D6580050 040A0203
	.long 0xd44c0003                                           // 000000399560: D44C0003
	v_cndmask_b32_e32 v1, 10, v89, vcc_lo                      // 000000399564: 0202B28A
	s_and_saveexec_b32 s20, s3                                 // 000000399568: BE942003
	s_cbranch_execz 99                                         // 00000039956C: BFA50063 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x1fc>
	s_waitcnt lgkmcnt(0)                                       // 000000399570: BF89FC07
	v_mad_i64_i32 v[1:2], null, 0x110, v80, s[4:5]             // 000000399574: D6FF7C01 0012A0FF 00000110
	v_lshlrev_b32_e32 v3, 1, v0                                // 000000399580: 30060081
	v_lshlrev_b32_e32 v4, 4, v89                               // 000000399584: 3008B284
	v_lshlrev_b32_e32 v5, 3, v89                               // 000000399588: 300AB283
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039958C: BF870193
	v_and_b32_e32 v7, 28, v3                                   // 000000399590: 360E069C
	.long 0xd7006a03                                           // 000000399594: D7006A03
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000399598: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039959C: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000003995A0: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000003995A8: D7006A05
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 0000003995AC: 02020B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003995B0: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000003995B4: D5207C06 01AA0480
	.long 0xd7006a01                                           // 0000003995BC: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 0000003995C0: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003995C4: D5207C02 01AA0480
	.long 0xd7006a07                                           // 0000003995CC: D7006A07
	v_cndmask_b32_e32 v1, 0xaa000, v3, vcc_lo                  // 0000003995D0: 020206FF 000AA000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003995D8: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v4, vcc_lo                // 0000003995DC: D5207C08 01AA0880
	.long 0xd7006a09                                           // 0000003995E4: D7006A09
	v_cndmask_b32_e32 v1, 0xaa000, v5, vcc_lo                  // 0000003995E8: 02020AFF 000AA000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000003995F0: D5207C0A 01AA0C80
	.long 0xd7006a0b                                           // 0000003995F8: D7006A0B
	v_cndmask_b32_e32 v1, 0xaa000, v1, vcc_lo                  // 0000003995FC: 020202FF 000AA000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000399604: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 000000399608: D5207C0C 01AA0480
	s_clause 0x5                                               // 000000399610: BF850005
	global_load_b128 v[76:79], v[3:4], off                     // 000000399614: DC5E0000 4C7C0003
	global_load_b64 v[87:88], v[5:6], off offset:160           // 00000039961C: DC5600A0 577C0005
	global_load_b32 v94, v[1:2], off offset:240                // 000000399624: DC5200F0 5E7C0001
	global_load_b128 v[25:28], v[7:8], off                     // 00000039962C: DC5E0000 197C0007
	global_load_b64 v[85:86], v[9:10], off offset:160          // 000000399634: DC5600A0 557C0009
	global_load_b32 v93, v[11:12], off offset:240              // 00000039963C: DC5200F0 5D7C000B
	.long 0xd7006a07                                           // 000000399644: D7006A07
	v_cndmask_b32_e32 v1, 0x154000, v3, vcc_lo                 // 000000399648: 020206FF 00154000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000399650: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v4, vcc_lo                // 000000399654: D5207C08 01AA0880
	.long 0xd7006a0d                                           // 00000039965C: D7006A0D
	v_cndmask_b32_e32 v1, 0x154000, v5, vcc_lo                 // 000000399660: 02020AFF 00154000
	v_add_co_ci_u32_e64 v14, null, 0, v6, vcc_lo               // 000000399668: D5207C0E 01AA0C80
	.long 0xd7006a0f                                           // 000000399670: D7006A0F
	v_cndmask_b32_e32 v1, 0x154000, v1, vcc_lo                 // 000000399674: 020202FF 00154000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039967C: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v2, vcc_lo               // 000000399680: D5207C10 01AA0480
	.long 0xd7006a03                                           // 000000399688: D7006A03
	v_cndmask_b32_e32 v1, 0x1fe000, v3, vcc_lo                 // 00000039968C: 020206FF 001FE000
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000399694: D5207C04 01AA0880
	.long 0xd7006a05                                           // 00000039969C: D7006A05
	v_cndmask_b32_e32 v1, 0x1fe000, v5, vcc_lo                 // 0000003996A0: 02020AFF 001FE000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003996A8: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 0000003996AC: D5207C06 01AA0C80
	.long 0xd7006a11                                           // 0000003996B4: D7006A11
	v_cndmask_b32_e32 v1, 0x1fe000, v1, vcc_lo                 // 0000003996B8: 020202FF 001FE000
	v_add_co_ci_u32_e64 v18, null, 0, v2, vcc_lo               // 0000003996C0: D5207C12 01AA0480
	s_clause 0x5                                               // 0000003996C8: BF850005
	global_load_b128 v[9:12], v[7:8], off                      // 0000003996CC: DC5E0000 097C0007
	global_load_b64 v[83:84], v[13:14], off offset:160         // 0000003996D4: DC5600A0 537C000D
	global_load_b32 v92, v[15:16], off offset:240              // 0000003996DC: DC5200F0 5C7C000F
	global_load_b128 v[1:4], v[3:4], off                       // 0000003996E4: DC5E0000 017C0003
	global_load_b64 v[81:82], v[5:6], off offset:160           // 0000003996EC: DC5600A0 517C0005
	global_load_b32 v90, v[17:18], off offset:240              // 0000003996F4: DC5200F0 5A7C0011
	s_or_b32 exec_lo, exec_lo, s20                             // 0000003996FC: 8C7E147E
	s_waitcnt lgkmcnt(0)                                       // 000000399700: BF89FC07
	s_mov_b32 s4, exec_lo                                      // 000000399704: BE84007E
	v_cmpx_eq_u32_e32 0, v0                                    // 000000399708: 7D940080
	s_cbranch_execz 20                                         // 00000039970C: BFA50014 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x260>
	v_mov_b32_e32 v5, 0                                        // 000000399710: 7E0A0280
	global_load_b64 v[6:7], v5, s[12:13] glc                   // 000000399714: DC564000 060C0005
	s_waitcnt vmcnt(0)                                         // 00000039971C: BF8903F7
	buffer_gl1_inv                                             // 000000399720: E0B00000 00000000
	buffer_gl0_inv                                             // 000000399728: E0AC0000 00000000
	v_cmp_le_u64_e32 vcc_lo, s[14:15], v[6:7]                  // 000000399730: 7CB60C0E
	s_cbranch_vccnz 10                                         // 000000399734: BFA4000A <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x260>
	s_sleep 1                                                  // 000000399738: BF830001
	global_load_b64 v[6:7], v5, s[12:13] glc                   // 00000039973C: DC564000 060C0005
	s_waitcnt vmcnt(0)                                         // 000000399744: BF8903F7
	buffer_gl1_inv                                             // 000000399748: E0B00000 00000000
	buffer_gl0_inv                                             // 000000399750: E0AC0000 00000000
	v_cmp_gt_u64_e32 vcc_lo, s[14:15], v[6:7]                  // 000000399758: 7CB80C0E
	s_cbranch_vccnz 65526                                      // 00000039975C: BFA4FFF6 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x238>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000399760: 8C7E047E
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v102, 0             // 000000399764: CA100080 05660080
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v104, 0           // 00000039976C: CA100080 69680080
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v100, 0           // 000000399774: CA100080 67640080
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v98, 0            // 00000039977C: CA100080 65620080
	v_dual_mov_b32 v99, 0 :: v_dual_mov_b32 v96, 0             // 000000399784: CA100080 63600080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v8, 0              // 00000039978C: CA100080 61080080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v6, 0              // 000000399794: CA100080 5F060080
	v_mov_b32_e32 v13, 0                                       // 00000039979C: 7E1A0280
	v_mov_b32_e32 v7, 0                                        // 0000003997A0: 7E0E0280
	s_waitcnt vmcnt(0)                                         // 0000003997A4: BF8903F7
	s_barrier                                                  // 0000003997A8: BFBD0000
	buffer_gl0_inv                                             // 0000003997AC: E0AC0000 00000000
	buffer_gl1_inv                                             // 0000003997B4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003997BC: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000003997C4: BE842003
	s_cbranch_execz 2471                                       // 0000003997C8: BFA509A7 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2968>
	v_lshlrev_b32_e32 v5, 4, v87                               // 0000003997CC: 300AAE84
	v_lshlrev_b32_e32 v6, 2, v87                               // 0000003997D0: 300CAE82
	v_lshrrev_b32_e32 v7, 4, v76                               // 0000003997D4: 320E9884
	v_lshrrev_b32_e32 v8, 8, v76                               // 0000003997D8: 32109888
	v_lshrrev_b32_e32 v13, 2, v87                              // 0000003997DC: 321AAE82
	v_and_b32_e32 v5, 48, v5                                   // 0000003997E0: 360A0AB0
	v_and_b32_e32 v6, 48, v6                                   // 0000003997E4: 360C0CB0
	v_and_b32_e32 v14, 48, v87                                 // 0000003997E8: 361CAEB0
	v_lshrrev_b32_e32 v15, 12, v76                             // 0000003997EC: 321E988C
	v_and_b32_e32 v13, 48, v13                                 // 0000003997F0: 361A1AB0
	v_and_or_b32 v5, v76, 15, v5                               // 0000003997F4: D6570005 04151F4C
	v_and_or_b32 v6, v7, 15, v6                                // 0000003997FC: D6570006 04191F07
	v_and_or_b32 v7, v8, 15, v14                               // 000000399804: D6570007 04391F08
	.long 0x7fb63880                                           // 00000039980C: 7FB63880
	v_and_or_b32 v8, v15, 15, v13                              // 000000399810: D6570008 04351F0F
	v_cvt_f32_ubyte0_e32 v5, v5                                // 000000399818: 7E0A2305
	v_cvt_f32_ubyte0_e32 v6, v6                                // 00000039981C: 7E0C2306
	v_cvt_f32_ubyte0_e32 v7, v7                                // 000000399820: 7E0E2307
	v_lshrrev_b32_e32 v16, 22, v87                             // 000000399824: 3220AE96
	v_cvt_f32_ubyte0_e32 v8, v8                                // 000000399828: 7E102308
	v_fma_mix_f32 v5, v5, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039982C: CC206005 157ABD05
	v_fma_mix_f32 v6, v6, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399834: CC206006 157ABD06
	v_fma_mix_f32 v7, v7, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039983C: CC206007 157ABD07
	v_and_b32_e32 v16, 48, v16                                 // 000000399844: 362020B0
	v_fma_mix_f32 v8, v8, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399848: CC206008 157ABD08
	v_bfe_u32 v13, v5, 16, 1                                   // 000000399850: D610000D 02052105
	v_bfe_u32 v14, v6, 16, 1                                   // 000000399858: D610000E 02052106
	v_lshrrev_b32_e32 v17, 28, v77                             // 000000399860: 32229A9C
	v_lshrrev_b32_e32 v18, 26, v87                             // 000000399864: 3224AE9A
	v_bfe_u32 v15, v8, 16, 1                                   // 000000399868: D610000F 02052108
	v_add3_u32 v5, v5, v13, 0x7fff                             // 000000399870: D6550005 03FE1B05 00007FFF
	v_bfe_u32 v13, v7, 16, 1                                   // 00000039987C: D610000D 02052107
	v_add3_u32 v6, v6, v14, 0x7fff                             // 000000399884: D6550006 03FE1D06 00007FFF
	v_lshrrev_b32_e32 v14, 28, v76                             // 000000399890: 321C989C
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000399894: D6550008 03FE1F08 00007FFF
	.long 0x7eb63985                                           // 0000003998A0: 7EB63985
	v_add3_u32 v5, v7, v13, 0x7fff                             // 0000003998A4: D6550005 03FE1B07 00007FFF
	v_lshrrev_b32_e32 v7, 4, v87                               // 0000003998B0: 320EAE84
	v_lshrrev_b32_e32 v13, 24, v76                             // 0000003998B4: 321A9898
	v_lshrrev_b32_e32 v15, 10, v87                             // 0000003998B8: 321EAE8A
	v_and_or_b32 v95, 0xffff0000, v6, v91                      // 0000003998BC: D657005F 056E0CFF FFFF0000
	.long 0x7eb63985                                           // 0000003998C8: 7EB63985
	v_lshrrev_b32_e32 v5, 6, v87                               // 0000003998CC: 320AAE86
	v_and_b32_e32 v6, 48, v7                                   // 0000003998D0: 360C0EB0
	v_lshrrev_b32_e32 v7, 8, v87                               // 0000003998D4: 320EAE88
	v_lshlrev_b32_e32 v20, 2, v88                              // 0000003998D8: 3028B082
	v_and_or_b32 v96, 0xffff0000, v8, v91                      // 0000003998DC: D6570060 056E10FF FFFF0000
	.long 0x7eb639cc                                           // 0000003998E8: 7EB639CC
	v_lshrrev_b32_e32 v8, 20, v76                              // 0000003998EC: 32109894
	v_and_b32_e32 v5, 48, v5                                   // 0000003998F0: 360A0AB0
	v_and_b32_e32 v7, 48, v7                                   // 0000003998F4: 360E0EB0
	v_lshrrev_b32_e32 v21, 8, v78                              // 0000003998F8: 322A9C88
	v_and_or_b32 v6, v91, 15, v6                               // 0000003998FC: D6570006 04191F5B
	v_and_b32_e32 v22, 48, v88                                 // 000000399904: 362CB0B0
	v_and_or_b32 v5, v8, 15, v5                                // 000000399908: D6570005 04151F08
	v_and_or_b32 v7, v13, 15, v7                               // 000000399910: D6570007 041D1F0D
	v_and_or_b32 v8, v15, 48, v14                              // 000000399918: D6570008 0439610F
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000399920: 7E0C2306
	v_and_or_b32 v17, v18, 48, v17                             // 000000399924: D6570011 04456112
	v_cvt_f32_ubyte0_e32 v5, v5                                // 00000039992C: 7E0A2305
	v_cvt_f32_ubyte0_e32 v7, v7                                // 000000399930: 7E0E2307
	v_cvt_f32_ubyte0_e32 v8, v8                                // 000000399934: 7E102308
	v_fma_mix_f32 v6, v6, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399938: CC206006 157ABD06
	v_lshrrev_b32_e32 v19, 4, v78                              // 000000399940: 32269C84
	v_fma_mix_f32 v5, v5, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399944: CC206005 157ABD05
	v_fma_mix_f32 v7, v7, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039994C: CC206007 157ABD07
	v_fma_mix_f32 v8, v8, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399954: CC206008 157ABD08
	v_bfe_u32 v13, v6, 16, 1                                   // 00000039995C: D610000D 02052106
	v_lshrrev_b32_e32 v29, 2, v88                              // 000000399964: 323AB082
	v_bfe_u32 v14, v5, 16, 1                                   // 000000399968: D610000E 02052105
	v_and_b32_e32 v20, 48, v20                                 // 000000399970: 362828B0
	v_bfe_u32 v15, v8, 16, 1                                   // 000000399974: D610000F 02052108
	v_add3_u32 v6, v6, v13, 0x7fff                             // 00000039997C: D6550006 03FE1B06 00007FFF
	v_bfe_u32 v13, v7, 16, 1                                   // 000000399988: D610000D 02052107
	v_add3_u32 v5, v5, v14, 0x7fff                             // 000000399990: D6550005 03FE1D05 00007FFF
	v_lshrrev_b32_e32 v14, 24, v87                             // 00000039999C: 321CAE98
	v_and_or_b32 v21, v21, 15, v22                             // 0000003999A0: D6570015 04591F15
	.long 0x7eb63986                                           // 0000003999A8: 7EB63986
	v_add3_u32 v6, v7, v13, 0x7fff                             // 0000003999AC: D6550006 03FE1B07 00007FFF
	v_add3_u32 v7, v8, v15, 0x7fff                             // 0000003999B8: D6550007 03FE1F08 00007FFF
	v_lshrrev_b32_e32 v8, 12, v77                              // 0000003999C4: 32109A8C
	v_lshrrev_b32_e32 v15, 20, v77                             // 0000003999C8: 321E9A94
	v_and_or_b32 v98, 0xffff0000, v5, v91                      // 0000003999CC: D6570062 056E0AFF FFFF0000
	.long 0x7eb63986                                           // 0000003999D8: 7EB63986
	v_lshrrev_b32_e32 v5, 8, v77                               // 0000003999DC: 320A9A88
	v_lshrrev_b32_e32 v6, 18, v87                              // 0000003999E0: 320CAE92
	v_and_b32_e32 v14, 48, v14                                 // 0000003999E4: 361C1CB0
	v_and_or_b32 v15, v15, 15, v16                             // 0000003999E8: D657000F 04411F0F
	v_and_or_b32 v97, 0xffff0000, v7, v91                      // 0000003999F0: D6570061 056E0EFF FFFF0000
	.long 0x7eb639d7                                           // 0000003999FC: 7EB639D7
	v_and_b32_e32 v6, 48, v6                                   // 000000399A00: 360C0CB0
	v_lshrrev_b32_e32 v7, 20, v87                              // 000000399A04: 320EAE94
	v_cvt_f32_ubyte0_e32 v15, v15                              // 000000399A08: 7E1E230F
	v_lshrrev_b32_e32 v23, 12, v78                             // 000000399A0C: 322E9C8C
	v_and_b32_e32 v13, 48, v91                                 // 000000399A10: 361AB6B0
	v_and_or_b32 v6, v8, 15, v6                                // 000000399A14: D6570006 04191F08
	v_and_b32_e32 v30, 48, v7                                  // 000000399A1C: 363C0EB0
	v_lshlrev_b32_e32 v8, 4, v88                               // 000000399A20: 3010B084
	v_and_b32_e32 v22, 48, v29                                 // 000000399A24: 362C3AB0
	v_and_or_b32 v5, v5, 15, v13                               // 000000399A28: D6570005 04351F05
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000399A30: 7E0C2306
	v_lshrrev_b32_e32 v13, 24, v77                             // 000000399A34: 321A9A98
	v_and_b32_e32 v18, 48, v8                                  // 000000399A38: 362410B0
	v_fma_mix_f32 v15, v15, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399A3C: CC20600F 157ABD0F
	v_cvt_f32_ubyte0_e32 v5, v5                                // 000000399A44: 7E0A2305
	v_fma_mix_f32 v6, v6, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399A48: CC206006 157ABD06
	v_and_or_b32 v13, v13, 15, v14                             // 000000399A50: D657000D 04391F0D
	v_cvt_f32_ubyte0_e32 v14, v17                              // 000000399A58: 7E1C2311
	v_and_or_b32 v17, v78, 15, v18                             // 000000399A5C: D6570011 04491F4E
	v_fma_mix_f32 v5, v5, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399A64: CC206005 157ABD05
	v_bfe_u32 v7, v6, 16, 1                                    // 000000399A6C: D6100007 02052106
	v_cvt_f32_ubyte0_e32 v13, v13                              // 000000399A74: 7E1A230D
	v_and_or_b32 v18, v19, 15, v20                             // 000000399A78: D6570012 04511F13
	v_cvt_f32_ubyte0_e32 v20, v21                              // 000000399A80: 7E282315
	v_bfe_u32 v24, v5, 16, 1                                   // 000000399A84: D6100018 02052105
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000399A8C: D6550006 03FE0F06 00007FFF
	v_cvt_f32_ubyte0_e32 v17, v17                              // 000000399A98: 7E222311
	v_fma_mix_f32 v13, v13, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399A9C: CC20600D 157ABD0D
	v_and_or_b32 v19, v23, 15, v22                             // 000000399AA4: D6570013 04591F17
	v_add3_u32 v5, v5, v24, 0x7fff                             // 000000399AAC: D6550005 03FE3105 00007FFF
	v_fma_mix_f32 v14, v14, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399AB8: CC20600E 157ABD0E
	v_cvt_f32_ubyte0_e32 v18, v18                              // 000000399AC0: 7E242312
	v_fma_mix_f32 v17, v17, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399AC4: CC206011 157ABD11
	v_bfe_u32 v23, v15, 16, 1                                  // 000000399ACC: D6100017 0205210F
	.long 0x7eb63985                                           // 000000399AD4: 7EB63985
	v_lshlrev_b32_e32 v73, 6, v89                              // 000000399AD8: 3092B286
	v_fma_mix_f32 v20, v20, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399ADC: CC206014 157ABD14
	v_cvt_f32_ubyte0_e32 v19, v19                              // 000000399AE4: 7E262313
	v_bfe_u32 v22, v14, 16, 1                                  // 000000399AE8: D6100016 0205210E
	v_and_or_b32 v99, 0xffff0000, v6, v91                      // 000000399AF0: D6570063 056E0CFF FFFF0000
	.long 0x7eb639cd                                           // 000000399AFC: 7EB639CD
	v_fma_mix_f32 v18, v18, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399B00: CC206012 157ABD12
	v_add3_u32 v15, v15, v23, 0x7fff                           // 000000399B08: D655000F 03FE2F0F 00007FFF
	global_load_b128 v[5:8], v73, s[6:7]                       // 000000399B14: DC5E0000 05060049
	v_fma_mix_f32 v19, v19, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399B1C: CC206013 157ABD13
	v_and_or_b32 v16, v91, 15, v30                             // 000000399B24: D6570010 04791F5B
	v_add3_u32 v14, v14, v22, 0x7fff                           // 000000399B2C: D655000E 03FE2D0E 00007FFF
	s_clause 0x1                                               // 000000399B38: BF850001
	global_load_b128 v[29:32], v73, s[6:7] offset:640          // 000000399B3C: DC5E0280 1D060049
	global_load_b128 v[33:36], v73, s[6:7] offset:656          // 000000399B44: DC5E0290 21060049
	v_lshrrev_b32_e32 v22, 28, v78                             // 000000399B4C: 322C9C9C
	v_cvt_f32_ubyte0_e32 v16, v16                              // 000000399B50: 7E202310
	v_lshrrev_b32_e32 v23, 10, v88                             // 000000399B54: 322EB08A
	s_clause 0x1                                               // 000000399B58: BF850001
	global_load_b128 v[45:48], v73, s[6:7] offset:1280         // 000000399B5C: DC5E0500 2D060049
	global_load_b128 v[49:52], v73, s[6:7] offset:1920         // 000000399B64: DC5E0780 31060049
	v_lshrrev_b32_e32 v41, 8, v79                              // 000000399B6C: 32529E88
	v_fma_mix_f32 v16, v16, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399B70: CC206010 157ABD10
	v_lshrrev_b32_e32 v42, 18, v88                             // 000000399B78: 3254B092
	v_lshrrev_b32_e32 v43, 12, v79                             // 000000399B7C: 32569E8C
	global_load_b128 v[53:56], v73, s[6:7] offset:1296         // 000000399B80: DC5E0510 35060049
	v_lshrrev_b32_e32 v57, 20, v88                             // 000000399B88: 3272B094
	v_bfe_u32 v21, v16, 16, 1                                  // 000000399B8C: D6100015 02052110
	v_and_b32_e32 v42, 48, v42                                 // 000000399B94: 365454B0
	v_lshrrev_b32_e32 v59, 22, v88                             // 000000399B98: 3276B096
	v_lshrrev_b32_e32 v60, 28, v79                             // 000000399B9C: 32789E9C
	v_lshrrev_b32_e32 v65, 26, v88                             // 000000399BA0: 3282B09A
	v_add3_u32 v16, v16, v21, 0x7fff                           // 000000399BA4: D6550010 03FE2B10 00007FFF
	v_bfe_u32 v21, v13, 16, 1                                  // 000000399BB0: D6100015 0205210D
	v_and_or_b32 v42, v43, 15, v42                             // 000000399BB8: D657002A 04A91F2B
	v_and_b32_e32 v105, 48, v57                                // 000000399BC0: 36D272B0
	v_and_b32_e32 v106, 48, v59                                // 000000399BC4: 36D476B0
	.long 0x7eb63990                                           // 000000399BC8: 7EB63990
	v_add3_u32 v13, v13, v21, 0x7fff                           // 000000399BCC: D655000D 03FE2B0D 00007FFF
	v_bfe_u32 v16, v17, 16, 1                                  // 000000399BD8: D6100010 02052111
	v_bfe_u32 v21, v18, 16, 1                                  // 000000399BE0: D6100015 02052112
	v_cvt_f32_ubyte0_e32 v74, v42                              // 000000399BE8: 7E94232A
	v_and_or_b32 v103, 0xffff0000, v15, v91                    // 000000399BEC: D6570067 056E1EFF FFFF0000
	.long 0x7eb6398d                                           // 000000399BF8: 7EB6398D
	v_add3_u32 v13, v17, v16, 0x7fff                           // 000000399BFC: D655000D 03FE2111 00007FFF
	v_bfe_u32 v15, v20, 16, 1                                  // 000000399C08: D610000F 02052114
	v_bfe_u32 v16, v19, 16, 1                                  // 000000399C10: D6100010 02052113
	v_add3_u32 v17, v18, v21, 0x7fff                           // 000000399C18: D6550011 03FE2B12 00007FFF
	v_and_or_b32 v101, 0xffff0000, v14, v91                    // 000000399C24: D6570065 056E1CFF FFFF0000
	.long 0x7eb6398d                                           // 000000399C30: 7EB6398D
	v_add3_u32 v13, v20, v15, 0x7fff                           // 000000399C34: D655000D 03FE1F14 00007FFF
	v_lshrrev_b32_e32 v15, 4, v88                              // 000000399C40: 321EB084
	v_add3_u32 v18, v19, v16, 0x7fff                           // 000000399C44: D6550012 03FE2113 00007FFF
	v_lshrrev_b32_e32 v16, 6, v88                              // 000000399C50: 3220B086
	v_and_or_b32 v102, 0xffff0000, v17, v91                    // 000000399C54: D6570066 056E22FF FFFF0000
	.long 0x7eb6398d                                           // 000000399C60: 7EB6398D
	v_lshrrev_b32_e32 v14, 8, v88                              // 000000399C64: 321CB088
	v_and_b32_e32 v21, 48, v15                                 // 000000399C68: 362A1EB0
	v_lshrrev_b32_e32 v13, 20, v78                             // 000000399C6C: 321A9C94
	v_lshrrev_b32_e32 v15, 24, v78                             // 000000399C70: 321E9C98
	v_and_or_b32 v100, 0xffff0000, v18, v91                    // 000000399C74: D6570064 056E24FF FFFF0000
	.long 0x7eb639ce                                           // 000000399C80: 7EB639CE
	global_load_b128 v[17:20], v73, s[6:7] offset:16           // 000000399C84: DC5E0010 11060049
	v_and_b32_e32 v16, 48, v16                                 // 000000399C8C: 362020B0
	v_and_b32_e32 v14, 48, v14                                 // 000000399C90: 361C1CB0
	v_fma_mix_f32 v74, v74, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399C94: CC20604A 157ABD4A
	v_and_or_b32 v21, v91, 15, v21                             // 000000399C9C: D6570015 04551F5B
	v_lshrrev_b32_e32 v58, 24, v88                             // 000000399CA4: 3274B098
	v_and_or_b32 v13, v13, 15, v16                             // 000000399CA8: D657000D 04411F0D
	v_and_or_b32 v14, v15, 15, v14                             // 000000399CB0: D657000E 04391F0F
	v_bfe_u32 v57, v74, 16, 1                                  // 000000399CB8: D6100039 0205214A
	v_cvt_f32_ubyte0_e32 v16, v21                              // 000000399CC0: 7E202315
	v_and_or_b32 v21, v23, 48, v22                             // 000000399CC4: D6570015 04596117
	v_cvt_f32_ubyte0_e32 v22, v13                              // 000000399CCC: 7E2C230D
	v_cvt_f32_ubyte0_e32 v24, v14                              // 000000399CD0: 7E30230E
	v_lshrrev_b32_e32 v70, 24, v79                             // 000000399CD4: 328C9E98
	v_fma_mix_f32 v23, v16, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399CD8: CC206017 157ABD10
	v_cvt_f32_ubyte0_e32 v21, v21                              // 000000399CE0: 7E2A2315
	v_fma_mix_f32 v22, v22, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399CE4: CC206016 157ABD16
	v_fma_mix_f32 v24, v24, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399CEC: CC206018 157ABD18
	global_load_b128 v[13:16], v73, s[6:7] offset:32           // 000000399CF4: DC5E0020 0D060049
	v_bfe_u32 v37, v23, 16, 1                                  // 000000399CFC: D6100025 02052117
	v_fma_mix_f32 v21, v21, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399D04: CC206015 157ABD15
	v_bfe_u32 v38, v22, 16, 1                                  // 000000399D0C: D6100026 02052116
	v_lshlrev_b32_e32 v67, 2, v85                              // 000000399D14: 3086AA82
	v_lshrrev_b32_e32 v104, 2, v85                             // 000000399D18: 32D0AA82
	v_add3_u32 v23, v23, v37, 0x7fff                           // 000000399D1C: D6550017 03FE4B17 00007FFF
	v_bfe_u32 v37, v24, 16, 1                                  // 000000399D28: D6100025 02052118
	v_bfe_u32 v39, v21, 16, 1                                  // 000000399D30: D6100027 02052115
	v_add3_u32 v22, v22, v38, 0x7fff                           // 000000399D38: D6550016 03FE4D16 00007FFF
	v_lshrrev_b32_e32 v69, 20, v79                             // 000000399D44: 328A9E94
	.long 0x7eb63997                                           // 000000399D48: 7EB63997
	v_add3_u32 v23, v24, v37, 0x7fff                           // 000000399D4C: D6550017 03FE4B18 00007FFF
	v_add3_u32 v37, v21, v39, 0x7fff                           // 000000399D58: D6550025 03FE4F15 00007FFF
	v_lshlrev_b32_e32 v66, 4, v85                              // 000000399D64: 3084AA84
	v_lshrrev_b32_e32 v71, 4, v25                              // 000000399D68: 328E3284
	v_and_or_b32 v115, 0xffff0000, v22, v91                    // 000000399D6C: D6570073 056E2CFF FFFF0000
	.long 0x7eb63997                                           // 000000399D78: 7EB63997
	global_load_b128 v[21:24], v73, s[6:7] offset:48           // 000000399D7C: DC5E0030 15060049
	v_lshrrev_b32_e32 v68, 8, v25                              // 000000399D84: 32883288
	v_and_b32_e32 v72, 48, v85                                 // 000000399D88: 3690AAB0
	v_lshrrev_b32_e32 v76, 12, v25                             // 000000399D8C: 3298328C
	v_and_or_b32 v112, 0xffff0000, v37, v91                    // 000000399D90: D6570070 056E4AFF FFFF0000
	.long 0x7eb639d8                                           // 000000399D9C: 7EB639D8
	global_load_b128 v[37:40], v73, s[6:7] offset:672          // 000000399DA0: DC5E02A0 25060049
	v_and_b32_e32 v104, 48, v104                               // 000000399DA8: 36D0D0B0
	v_and_b32_e32 v107, 48, v66                                // 000000399DAC: 36D684B0
	v_and_or_b32 v72, v68, 15, v72                             // 000000399DB0: D6570048 05211F44
	v_and_b32_e32 v44, 48, v91                                 // 000000399DB8: 3658B6B0
	v_and_or_b32 v69, v69, 15, v106                            // 000000399DBC: D6570045 05A91F45
	v_lshrrev_b32_e32 v117, 12, v88                            // 000000399DC4: 32EAB08C
	v_lshrrev_b32_e32 v119, 24, v85                            // 000000399DC8: 32EEAA98
	v_cvt_f32_ubyte0_e32 v72, v72                              // 000000399DCC: 7E902348
	v_and_or_b32 v41, v41, 15, v44                             // 000000399DD0: D6570029 04B11F29
	v_cvt_f32_ubyte0_e32 v69, v69                              // 000000399DD8: 7E8A2345
	v_lshrrev_b32_e32 v121, 22, v85                            // 000000399DDC: 32F2AA96
	v_lshrrev_b32_e32 v120, 20, v26                            // 000000399DE0: 32F03494
	v_fma_mix_f32 v72, v72, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399DE4: CC206048 1576BB48
	v_cvt_f32_ubyte0_e32 v41, v41                              // 000000399DEC: 7E522329
	v_fma_mix_f32 v69, v69, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399DF0: CC206045 157ABD45
	v_lshrrev_b32_e32 v123, 24, v26                            // 000000399DF8: 32F63498
	v_and_b32_e32 v128, 48, v86                                // 000000399DFC: 3700ACB0
	v_and_b32_e32 v121, 48, v121                               // 000000399E00: 36F2F2B0
	v_fma_mix_f32 v75, v41, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399E04: CC20604B 157ABD29
	s_clause 0x1                                               // 000000399E0C: BF850001
	global_load_b128 v[41:44], v73, s[6:7] offset:688          // 000000399E10: DC5E02B0 29060049
	global_load_b128 v[61:64], v73, s[6:7] offset:1936         // 000000399E18: DC5E0790 3D060049
	v_bfe_u32 v106, v69, 16, 1                                 // 000000399E20: D610006A 02052145
	v_and_b32_e32 v119, 48, v119                               // 000000399E28: 36EEEEB0
	v_lshrrev_b32_e32 v124, 28, v26                            // 000000399E2C: 32F8349C
	v_bfe_u32 v78, v75, 16, 1                                  // 000000399E30: D610004E 0205214B
	v_lshrrev_b32_e32 v125, 26, v85                            // 000000399E38: 32FAAA9A
	v_add3_u32 v69, v69, v106, 0x7fff                          // 000000399E3C: D6550045 03FED545 00007FFF
	v_lshlrev_b32_e32 v127, 2, v86                             // 000000399E48: 30FEAC82
	v_and_or_b32 v120, v120, 15, v121                          // 000000399E4C: D6570078 05E51F78
	v_add3_u32 v59, v75, v78, 0x7fff                           // 000000399E54: D655003B 03FE9D4B 00007FFF
	v_and_or_b32 v78, v65, 48, v60                             // 000000399E60: D657004E 04F16141
	v_add3_u32 v65, v74, v57, 0x7fff                           // 000000399E68: D6550041 03FE734A 00007FFF
	v_and_b32_e32 v75, 48, v58                                 // 000000399E74: 369674B0
	v_and_b32_e32 v74, 48, v67                                 // 000000399E78: 369486B0
	.long 0x7eb639bb                                           // 000000399E7C: 7EB639BB
	global_load_b128 v[57:60], v73, s[6:7] offset:1312         // 000000399E80: DC5E0520 39060049
	v_and_or_b32 v119, v123, 15, v119                          // 000000399E88: D6570077 05DD1F7B
	v_and_or_b32 v70, v70, 15, v75                             // 000000399E90: D6570046 052D1F46
	v_cvt_f32_ubyte0_e32 v75, v78                              // 000000399E98: 7E96234E
	v_and_or_b32 v116, 0xffff0000, v65, v91                    // 000000399E9C: D6570074 056E82FF FFFF0000
	.long 0x7eb639cf                                           // 000000399EA8: 7EB639CF
	global_load_b128 v[65:68], v73, s[6:7] offset:1952         // 000000399EAC: DC5E07A0 41060049
	v_and_or_b32 v71, v71, 15, v74                             // 000000399EB4: D6570047 05291F47
	v_and_or_b32 v74, v76, 15, v104                            // 000000399EBC: D657004A 05A11F4C
	v_cvt_f32_ubyte0_e32 v70, v70                              // 000000399EC4: 7E8C2346
	v_and_or_b32 v78, v91, 15, v105                            // 000000399EC8: D657004E 05A51F5B
	v_and_or_b32 v105, v25, 15, v107                           // 000000399ED0: D6570069 05AD1F19
	v_fma_mix_f32 v75, v75, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399ED8: CC20604B 157ABD4B
	v_cvt_f32_ubyte0_e32 v71, v71                              // 000000399EE0: 7E8E2347
	v_fma_mix_f32 v70, v70, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399EE4: CC206046 157ABD46
	v_cvt_f32_ubyte0_e32 v76, v78                              // 000000399EEC: 7E98234E
	v_cvt_f32_ubyte0_e32 v78, v105                             // 000000399EF0: 7E9C2369
	v_cvt_f32_ubyte0_e32 v74, v74                              // 000000399EF4: 7E94234A
	v_bfe_u32 v105, v75, 16, 1                                 // 000000399EF8: D6100069 0205214B
	v_fma_mix_f32 v71, v71, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399F00: CC206047 1576BB47
	v_fma_mix_f32 v76, v76, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399F08: CC20604C 157ABD4C
	v_fma_mix_f32 v78, v78, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399F10: CC20604E 1576BB4E
	v_fma_mix_f32 v74, v74, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000399F18: CC20604A 1576BB4A
	v_add3_u32 v75, v75, v105, 0x7fff                          // 000000399F20: D655004B 03FED34B 00007FFF
	v_lshrrev_b32_e32 v126, 4, v27                             // 000000399F2C: 32FC3684
	v_bfe_u32 v104, v76, 16, 1                                 // 000000399F30: D6100068 0205214C
	v_lshrrev_b32_e32 v130, 2, v86                             // 000000399F38: 3304AC82
	v_and_or_b32 v124, v125, 48, v124                          // 000000399F3C: D657007C 05F1617D
	v_and_b32_e32 v125, 48, v127                               // 000000399F44: 36FAFEB0
	v_cvt_f32_ubyte0_e32 v120, v120                            // 000000399F48: 7EF02378
	v_add3_u32 v76, v76, v104, 0x7fff                          // 000000399F4C: D655004C 03FED14C 00007FFF
	v_bfe_u32 v104, v70, 16, 1                                 // 000000399F58: D6100068 02052146
	v_cvt_f32_ubyte0_e32 v119, v119                            // 000000399F60: 7EEE2377
	v_lshrrev_b32_e32 v129, 12, v27                            // 000000399F64: 3302368C
	v_cvt_f32_ubyte0_e32 v121, v124                            // 000000399F68: 7EF2237C
	.long 0x7eb639cc                                           // 000000399F6C: 7EB639CC
	v_add3_u32 v70, v70, v104, 0x7fff                          // 000000399F70: D6550046 03FED146 00007FFF
	v_bfe_u32 v76, v78, 16, 1                                  // 000000399F7C: D610004C 0205214E
	v_bfe_u32 v104, v71, 16, 1                                 // 000000399F84: D6100068 02052147
	v_and_or_b32 v123, v126, 15, v125                          // 000000399F8C: D657007B 05F51F7E
	v_and_or_b32 v114, 0xffff0000, v69, v91                    // 000000399F94: D6570072 056E8AFF FFFF0000
	.long 0x7eb639c6                                           // 000000399FA0: 7EB639C6
	v_add3_u32 v69, v78, v76, 0x7fff                           // 000000399FA4: D6550045 03FE994E 00007FFF
	v_bfe_u32 v70, v72, 16, 1                                  // 000000399FB0: D6100046 02052148
	v_bfe_u32 v76, v74, 16, 1                                  // 000000399FB8: D610004C 0205214A
	v_add3_u32 v71, v71, v104, 0x7fff                          // 000000399FC0: D6550047 03FED147 00007FFF
	v_and_or_b32 v107, 0xffff0000, v75, v91                    // 000000399FCC: D657006B 056E96FF FFFF0000
	.long 0x7eb639c5                                           // 000000399FD8: 7EB639C5
	v_add3_u32 v69, v72, v70, 0x7fff                           // 000000399FDC: D6550045 03FE8D48 00007FFF
	v_lshrrev_b32_e32 v70, 4, v85                              // 000000399FE8: 328CAA84
	v_add3_u32 v72, v74, v76, 0x7fff                           // 000000399FEC: D6550048 03FE994A 00007FFF
	v_lshrrev_b32_e32 v74, 20, v25                             // 000000399FF8: 32943294
	v_and_or_b32 v78, 0xffff0000, v71, v91                     // 000000399FFC: D657004E 056E8EFF FFFF0000
	.long 0x7eb639c5                                           // 00000039A008: 7EB639C5
	v_lshrrev_b32_e32 v69, 6, v85                              // 00000039A00C: 328AAA86
	v_lshrrev_b32_e32 v71, 8, v85                              // 00000039A010: 328EAA88
	v_and_b32_e32 v70, 48, v70                                 // 00000039A014: 368C8CB0
	v_lshrrev_b32_e32 v75, 10, v85                             // 00000039A018: 3296AA8A
	v_and_or_b32 v104, 0xffff0000, v72, v91                    // 00000039A01C: D6570068 056E90FF FFFF0000
	.long 0x7eb63999                                           // 00000039A028: 7EB63999
	v_lshrrev_b32_e32 v72, 24, v25                             // 00000039A02C: 32903298
	v_lshrrev_b32_e32 v25, 28, v25                             // 00000039A030: 3232329C
	v_and_b32_e32 v69, 48, v69                                 // 00000039A034: 368A8AB0
	v_and_b32_e32 v71, 48, v71                                 // 00000039A038: 368E8EB0
	v_and_or_b32 v70, v91, 15, v70                             // 00000039A03C: D6570046 05191F5B
	v_fma_mix_f32 v119, v119, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A044: CC206077 1576BB77
	v_and_or_b32 v25, v75, 48, v25                             // 00000039A04C: D6570019 0465614B
	v_and_or_b32 v105, v74, 15, v69                            // 00000039A054: D6570069 05151F4A
	v_and_or_b32 v108, v72, 15, v71                            // 00000039A05C: D657006C 051D1F48
	v_cvt_f32_ubyte0_e32 v106, v70                             // 00000039A064: 7ED42346
	s_clause 0x1                                               // 00000039A068: BF850001
	global_load_b128 v[69:72], v73, s[6:7] offset:1328         // 00000039A06C: DC5E0530 45060049
	global_load_b128 v[73:76], v73, s[6:7] offset:1968         // 00000039A074: DC5E07B0 49060049
	v_cvt_f32_ubyte0_e32 v25, v25                              // 00000039A07C: 7E322319
	v_cvt_f32_ubyte0_e32 v105, v105                            // 00000039A080: 7ED22369
	v_cvt_f32_ubyte0_e32 v108, v108                            // 00000039A084: 7ED8236C
	v_fma_mix_f32 v106, v106, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A088: CC20606A 1576BB6A
	v_fma_mix_f32 v121, v121, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A090: CC206079 1576BB79
	v_fma_mix_f32 v25, v25, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A098: CC206019 1576BB19
	v_fma_mix_f32 v105, v105, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A0A0: CC206069 1576BB69
	v_fma_mix_f32 v108, v108, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A0A8: CC20606C 1576BB6C
	v_bfe_u32 v110, v106, 16, 1                                // 00000039A0B0: D610006E 0205216A
	v_cvt_f32_ubyte0_e32 v123, v123                            // 00000039A0B8: 7EF6237B
	v_bfe_u32 v118, v25, 16, 1                                 // 00000039A0BC: D6100076 02052119
	v_bfe_u32 v111, v105, 16, 1                                // 00000039A0C4: D610006F 02052169
	v_bfe_u32 v125, v121, 16, 1                                // 00000039A0CC: D610007D 02052179
	v_add3_u32 v106, v106, v110, 0x7fff                        // 00000039A0D4: D655006A 03FEDD6A 00007FFF
	v_bfe_u32 v110, v108, 16, 1                                // 00000039A0E0: D610006E 0205216C
	v_add3_u32 v25, v25, v118, 0x7fff                          // 00000039A0E8: D6550019 03FEED19 00007FFF
	v_add3_u32 v105, v105, v111, 0x7fff                        // 00000039A0F4: D6550069 03FEDF69 00007FFF
	v_lshrrev_b32_e32 v118, 14, v88                            // 00000039A100: 32ECB08E
	.long 0x7eb639ea                                           // 00000039A104: 7EB639EA
	v_add3_u32 v106, v108, v110, 0x7fff                        // 00000039A108: D655006A 03FEDD6C 00007FFF
	v_lshrrev_b32_e32 v111, 12, v26                            // 00000039A114: 32DE348C
	v_lshrrev_b32_e32 v108, 20, v85                            // 00000039A118: 32D8AA94
	v_fma_mix_f32 v123, v123, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A11C: CC20607B 1576BB7B
	v_and_or_b32 v105, 0xffff0000, v105, v91                   // 00000039A124: D6570069 056ED2FF FFFF0000
	.long 0x7eb639ea                                           // 00000039A130: 7EB639EA
	v_lshrrev_b32_e32 v106, 8, v26                             // 00000039A134: 32D43488
	v_and_b32_e32 v108, 48, v108                               // 00000039A138: 36D8D8B0
	v_lshrrev_b32_e32 v109, 12, v87                            // 00000039A13C: 32DAAE8C
	v_and_b32_e32 v110, 15, v79                                // 00000039A140: 36DC9E8F
	v_and_or_b32 v88, 0xffff0000, v25, v91                     // 00000039A144: D6570058 056E32FF FFFF0000
	.long 0x7eb639d5                                           // 00000039A150: 7EB639D5
	v_lshrrev_b32_e32 v25, 18, v85                             // 00000039A154: 3232AA92
	v_lshrrev_b32_e32 v132, 4, v86                             // 00000039A158: 3308AC84
	v_lshrrev_b32_e32 v113, 4, v77                             // 00000039A15C: 32E29A84
	v_lshrrev_b32_e32 v87, 14, v87                             // 00000039A160: 32AEAE8E
	v_and_b32_e32 v122, 48, v91                                // 00000039A164: 36F4B6B0
	v_and_b32_e32 v25, 48, v25                                 // 00000039A168: 363232B0
	v_and_or_b32 v117, v117, 48, v110                          // 00000039A16C: D6570075 05B96175
	v_lshrrev_b32_e32 v131, 8, v86                             // 00000039A174: 3306AC88
	v_lshrrev_b32_e32 v79, 4, v79                              // 00000039A178: 329E9E84
	v_and_or_b32 v106, v106, 15, v122                          // 00000039A17C: D657006A 05E91F6A
	v_and_or_b32 v25, v111, 15, v25                            // 00000039A184: D6570019 04651F6F
	v_lshlrev_b32_e32 v122, 4, v86                             // 00000039A18C: 30F4AC84
	v_lshrrev_b32_e32 v111, 8, v27                             // 00000039A190: 32DE3688
	v_lshrrev_b32_e32 v134, 20, v27                            // 00000039A194: 330C3694
	v_cvt_f32_ubyte0_e32 v106, v106                            // 00000039A198: 7ED4236A
	v_cvt_f32_ubyte0_e32 v25, v25                              // 00000039A19C: 7E322319
	v_and_b32_e32 v122, 48, v122                               // 00000039A1A0: 36F4F4B0
	v_and_or_b32 v111, v111, 15, v128                          // 00000039A1A4: D657006F 06011F6F
	v_lshrrev_b32_e32 v135, 6, v86                             // 00000039A1AC: 330EAC86
	v_fma_mix_f32 v106, v106, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A1B0: CC20606A 1576BB6A
	v_fma_mix_f32 v25, v25, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A1B8: CC206019 1576BB19
	v_and_or_b32 v122, v27, 15, v122                           // 00000039A1C0: D657007A 05E91F1B
	v_cvt_f32_ubyte0_e32 v111, v111                            // 00000039A1C8: 7EDE236F
	v_lshrrev_b32_e32 v136, 24, v27                            // 00000039A1CC: 33103698
	v_bfe_u32 v133, v106, 16, 1                                // 00000039A1D0: D6100085 0205216A
	v_bfe_u32 v137, v25, 16, 1                                 // 00000039A1D8: D6100089 02052119
	v_cvt_f32_ubyte0_e32 v122, v122                            // 00000039A1E0: 7EF4237A
	v_fma_mix_f32 v124, v111, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A1E4: CC20607C 1576BB6F
	v_fma_mix_f32 v111, v120, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A1EC: CC20606F 1576BB78
	v_add3_u32 v106, v106, v133, 0x7fff                        // 00000039A1F4: D655006A 03FF0B6A 00007FFF
	v_add3_u32 v25, v25, v137, 0x7fff                          // 00000039A200: D6550019 03FF1319 00007FFF
	v_fma_mix_f32 v122, v122, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A20C: CC20607A 1576BB7A
	v_lshrrev_b32_e32 v133, 28, v27                            // 00000039A214: 330A369C
	v_bfe_u32 v126, v111, 16, 1                                // 00000039A218: D610007E 0205216F
	.long 0x7eb639ea                                           // 00000039A220: 7EB639EA
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039A224: BF870112
	v_add3_u32 v111, v111, v126, 0x7fff                        // 00000039A228: D655006F 03FEFD6F 00007FFF
	v_and_or_b32 v106, 0xffff0000, v25, v91                    // 00000039A234: D657006A 056E32FF FFFF0000
	.long 0x7eb6399a                                           // 00000039A240: 7EB6399A
	v_and_b32_e32 v25, 48, v130                                // 00000039A244: 363304B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039A248: BF870112
	v_and_or_b32 v108, v91, 15, v108                           // 00000039A24C: D657006C 05B11F5B
	v_and_or_b32 v25, v129, 15, v25                            // 00000039A254: D6570019 04651F81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039A25C: BF870112
	v_cvt_f32_ubyte0_e32 v108, v108                            // 00000039A260: 7ED8236C
	v_cvt_f32_ubyte0_e32 v25, v25                              // 00000039A264: 7E322319
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039A268: BF870112
	v_fma_mix_f32 v108, v108, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A26C: CC20606C 1576BB6C
	v_fma_mix_f32 v25, v25, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A274: CC206019 1576BB19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039A27C: BF870092
	v_bfe_u32 v120, v108, 16, 1                                // 00000039A280: D6100078 0205216C
	v_add3_u32 v108, v108, v120, 0x7fff                        // 00000039A288: D655006C 03FEF16C 00007FFF
	v_bfe_u32 v120, v119, 16, 1                                // 00000039A294: D6100078 02052177
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039A29C: BF870112
	.long 0x7eb639ec                                           // 00000039A2A0: 7EB639EC
	v_add3_u32 v108, v119, v120, 0x7fff                        // 00000039A2A4: D655006C 03FEF177 00007FFF
	v_bfe_u32 v119, v122, 16, 1                                // 00000039A2B0: D6100077 0205217A
	v_add3_u32 v120, v121, v125, 0x7fff                        // 00000039A2B8: D6550078 03FEFB79 00007FFF
	v_bfe_u32 v121, v123, 16, 1                                // 00000039A2C4: D6100079 0205217B
	v_and_or_b32 v111, 0xffff0000, v111, v91                   // 00000039A2CC: D657006F 056EDEFF FFFF0000
	.long 0x7eb639ec                                           // 00000039A2D8: 7EB639EC
	v_add3_u32 v119, v122, v119, 0x7fff                        // 00000039A2DC: D6550077 03FEEF7A 00007FFF
	v_bfe_u32 v122, v124, 16, 1                                // 00000039A2E8: D610007A 0205217C
	v_bfe_u32 v125, v25, 16, 1                                 // 00000039A2F0: D610007D 02052119
	v_add3_u32 v121, v123, v121, 0x7fff                        // 00000039A2F8: D6550079 03FEF37B 00007FFF
	v_and_or_b32 v108, 0xffff0000, v120, v91                   // 00000039A304: D657006C 056EF0FF FFFF0000
	.long 0x7eb639f7                                           // 00000039A310: 7EB639F7
	v_add3_u32 v119, v124, v122, 0x7fff                        // 00000039A314: D6550077 03FEF57C 00007FFF
	v_lshrrev_b32_e32 v120, 10, v86                            // 00000039A320: 32F0AC8A
	v_and_b32_e32 v122, 48, v109                               // 00000039A324: 36F4DAB0
	v_add3_u32 v25, v25, v125, 0x7fff                          // 00000039A328: D6550019 03FEFB19 00007FFF
	v_and_or_b32 v109, 0xffff0000, v121, v91                   // 00000039A334: D657006D 056EF2FF FFFF0000
	.long 0x7eb639f7                                           // 00000039A340: 7EB639F7
	v_and_or_b32 v119, v120, 48, v133                          // 00000039A344: D6570077 06156178
	v_and_or_b32 v77, v77, 15, v122                            // 00000039A34C: D657004D 05E91F4D
	v_and_b32_e32 v120, 48, v132                               // 00000039A354: 36F108B0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000039A358: BF870004
	v_and_or_b32 v110, 0xffff0000, v25, v91                    // 00000039A35C: D657006E 056E32FF FFFF0000
	.long 0x7eb6399b                                           // 00000039A368: 7EB6399B
	v_and_b32_e32 v25, 48, v87                                 // 00000039A36C: 3632AEB0
	v_cvt_f32_ubyte0_e32 v77, v77                              // 00000039A370: 7E9A234D
	v_and_b32_e32 v27, 48, v118                                // 00000039A374: 3636ECB0
	v_and_b32_e32 v118, 48, v131                               // 00000039A378: 36ED06B0
	v_and_or_b32 v120, v91, 15, v120                           // 00000039A37C: D6570078 05E11F5B
	v_and_or_b32 v25, v113, 15, v25                            // 00000039A384: D6570019 04651F71
	v_fma_mix_f32 v77, v77, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A38C: CC20604D 157ABD4D
	v_and_b32_e32 v87, 48, v135                                // 00000039A394: 36AF0EB0
	v_and_or_b32 v27, v79, 15, v27                             // 00000039A398: D657001B 046D1F4F
	v_cvt_f32_ubyte0_e32 v113, v120                            // 00000039A3A0: 7EE22378
	v_cvt_f32_ubyte0_e32 v79, v117                             // 00000039A3A4: 7E9E2375
	v_and_or_b32 v117, v136, 15, v118                          // 00000039A3A8: D6570075 05D91F88
	v_cvt_f32_ubyte0_e32 v118, v119                            // 00000039A3B0: 7EEC2377
	v_cvt_f32_ubyte0_e32 v25, v25                              // 00000039A3B4: 7E322319
	v_fma_mix_f32 v113, v113, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A3B8: CC206071 1576BB71
	v_bfe_u32 v119, v77, 16, 1                                 // 00000039A3C0: D6100077 0205214D
	v_and_or_b32 v87, v134, 15, v87                            // 00000039A3C8: D6570057 055D1F86
	v_cvt_f32_ubyte0_e32 v117, v117                            // 00000039A3D0: 7EEA2375
	v_fma_mix_f32 v25, v25, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A3D4: CC206019 157ABD19
	v_bfe_u32 v120, v113, 16, 1                                // 00000039A3DC: D6100078 02052171
	v_add3_u32 v77, v77, v119, 0x7fff                          // 00000039A3E4: D655004D 03FEEF4D 00007FFF
	s_waitcnt vmcnt(15)                                        // 00000039A3F0: BF893FF7
	v_dot2_f32_bf16 v119, v5, v95, 0                           // 00000039A3F4: CC1A4077 1A02BF05
	v_cvt_f32_ubyte0_e32 v87, v87                              // 00000039A3FC: 7EAE2357
	v_bfe_u32 v122, v25, 16, 1                                 // 00000039A400: D610007A 02052119
	v_add3_u32 v113, v113, v120, 0x7fff                        // 00000039A408: D6550071 03FEF171 00007FFF
	v_fma_mix_f32 v117, v117, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A414: CC206075 1576BB75
	v_dot2_f32_bf16 v119, v6, v96, v119                        // 00000039A41C: CC1A4077 1DDEC106
	v_fma_mix_f32 v87, v87, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A424: CC206057 1576BB57
	.long 0x7e9a39cd                                           // 00000039A42C: 7E9A39CD
	.long 0x7eb639f1                                           // 00000039A430: 7EB639F1
	.long 0x7f9a39db                                           // 00000039A434: 7F9A39DB
	v_add3_u32 v25, v25, v122, 0x7fff                          // 00000039A438: D6550019 03FEF519 00007FFF
	v_dot2_f32_bf16 v113, v7, v98, v119                        // 00000039A444: CC1A4071 1DDEC507
	v_fma_mix_f32 v118, v118, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A44C: CC206076 1576BB76
	v_bfe_u32 v120, v87, 16, 1                                 // 00000039A454: D6100078 02052157
	v_bfe_u32 v121, v117, 16, 1                                // 00000039A45C: D6100079 02052175
	v_and_or_b32 v77, 0xffff0000, v25, v77                     // 00000039A464: D657004D 053632FF FFFF0000
	v_dot2_f32_bf16 v25, v8, v97, v113                         // 00000039A470: CC1A4019 1DC6C308
	v_bfe_u32 v119, v118, 16, 1                                // 00000039A478: D6100077 02052176
	v_add3_u32 v87, v87, v120, 0x7fff                          // 00000039A480: D6550057 03FEF157 00007FFF
	v_add3_u32 v117, v117, v121, 0x7fff                        // 00000039A48C: D6550075 03FEF375 00007FFF
	v_cvt_f32_ubyte0_e32 v27, v27                              // 00000039A498: 7E36231B
	v_fma_mix_f32 v79, v79, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A49C: CC20604F 157ABD4F
	v_lshrrev_b32_e32 v120, 18, v86                            // 00000039A4A4: 32F0AC92
	v_and_or_b32 v113, 0xffff0000, v87, v91                    // 00000039A4A8: D6570071 056EAEFF FFFF0000
	.long 0x7eb639f5                                           // 00000039A4B4: 7EB639F5
	s_waitcnt vmcnt(9)                                         // 00000039A4B8: BF8927F7
	v_dot2_f32_bf16 v25, v17, v77, v25                         // 00000039A4BC: CC1A4019 1C669B11
	v_add3_u32 v87, v118, v119, 0x7fff                         // 00000039A4C4: D6550057 03FEEF76 00007FFF
	v_dot2_f32_bf16 v118, v29, v95, 0                          // 00000039A4D0: CC1A4076 1A02BF1D
	v_fma_mix_f32 v27, v27, v94, v94 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A4D8: CC20601B 157ABD1B
	v_bfe_u32 v117, v79, 16, 1                                 // 00000039A4E0: D6100075 0205214F
	v_dot2_f32_bf16 v25, v18, v99, v25                         // 00000039A4E8: CC1A4019 1C66C712
	v_and_or_b32 v94, 0xffff0000, v87, v91                     // 00000039A4F0: D657005E 056EAEFF FFFF0000
	v_dot2_f32_bf16 v87, v30, v96, v118                        // 00000039A4FC: CC1A4057 1DDAC11E
	.long 0x7eb639d6                                           // 00000039A504: 7EB639D6
	v_add3_u32 v79, v79, v117, 0x7fff                          // 00000039A508: D655004F 03FEEB4F 00007FFF
	v_dot2_f32_bf16 v25, v19, v103, v25                        // 00000039A514: CC1A4019 1C66CF13
	v_bfe_u32 v117, v27, 16, 1                                 // 00000039A51C: D6100075 0205211B
	v_dot2_f32_bf16 v87, v31, v98, v87                         // 00000039A524: CC1A4057 1D5EC51F
	v_lshrrev_b32_e32 v118, 8, v28                             // 00000039A52C: 32EC3888
	v_and_b32_e32 v119, 48, v91                                // 00000039A530: 36EEB6B0
	v_dot2_f32_bf16 v25, v20, v101, v25                        // 00000039A534: CC1A4019 1C66CB14
	.long 0x7e9e39cf                                           // 00000039A53C: 7E9E39CF
	v_dot2_f32_bf16 v87, v32, v97, v87                         // 00000039A540: CC1A4057 1D5EC320
	.long 0x7f9e39db                                           // 00000039A548: 7F9E39DB
	v_add3_u32 v27, v27, v117, 0x7fff                          // 00000039A54C: D655001B 03FEEB1B 00007FFF
	s_waitcnt vmcnt(8)                                         // 00000039A558: BF8923F7
	v_dot2_f32_bf16 v25, v13, v102, v25                        // 00000039A55C: CC1A4019 1C66CD0D
	v_and_or_b32 v117, v118, 15, v119                          // 00000039A564: D6570075 05DD1F76
	v_lshrrev_b32_e32 v118, 12, v28                            // 00000039A56C: 32EC388C
	v_dot2_f32_bf16 v87, v33, v77, v87                         // 00000039A570: CC1A4057 1D5E9B21
	v_and_b32_e32 v119, 48, v120                               // 00000039A578: 36EEF0B0
	v_dot2_f32_bf16 v25, v14, v100, v25                        // 00000039A57C: CC1A4019 1C66C90E
	v_and_or_b32 v120, 0xffff0000, v27, v79                    // 00000039A584: D6570078 053E36FF FFFF0000
	v_cvt_f32_ubyte0_e32 v27, v117                             // 00000039A590: 7E362375
	v_dot2_f32_bf16 v79, v34, v99, v87                         // 00000039A594: CC1A404F 1D5EC722
	v_and_or_b32 v87, v118, 15, v119                           // 00000039A59C: D6570057 05DD1F76
	v_dot2_f32_bf16 v25, v15, v115, v25                        // 00000039A5A4: CC1A4019 1C66E70F
	v_dot2_f32_bf16 v117, v45, v95, 0                          // 00000039A5AC: CC1A4075 1A02BF2D
	v_fma_mix_f32 v27, v27, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A5B4: CC20601B 1576BB1B
	v_dot2_f32_bf16 v95, v49, v95, 0                           // 00000039A5BC: CC1A405F 1A02BF31
	v_cvt_f32_ubyte0_e32 v87, v87                              // 00000039A5C4: 7EAE2357
	v_dot2_f32_bf16 v25, v16, v112, v25                        // 00000039A5C8: CC1A4019 1C66E110
	v_dot2_f32_bf16 v79, v35, v103, v79                        // 00000039A5D0: CC1A404F 1D3ECF23
	v_dot2_f32_bf16 v117, v46, v96, v117                       // 00000039A5D8: CC1A4075 1DD6C12E
	v_bfe_u32 v118, v27, 16, 1                                 // 00000039A5E0: D6100076 0205211B
	v_fma_mix_f32 v87, v87, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A5E8: CC206057 1576BB57
	s_waitcnt vmcnt(7)                                         // 00000039A5F0: BF891FF7
	v_dot2_f32_bf16 v25, v21, v120, v25                        // 00000039A5F4: CC1A4019 1C66F115
	v_dot2_f32_bf16 v95, v50, v96, v95                         // 00000039A5FC: CC1A405F 1D7EC132
	v_dot2_f32_bf16 v79, v36, v101, v79                        // 00000039A604: CC1A404F 1D3ECB24
	v_add3_u32 v27, v27, v118, 0x7fff                          // 00000039A60C: D655001B 03FEED1B 00007FFF
	v_bfe_u32 v96, v87, 16, 1                                  // 00000039A618: D6100060 02052157
	v_dot2_f32_bf16 v25, v22, v116, v25                        // 00000039A620: CC1A4019 1C66E916
	v_dot2_f32_bf16 v117, v47, v98, v117                       // 00000039A628: CC1A4075 1DD6C52F
	v_dot2_f32_bf16 v95, v51, v98, v95                         // 00000039A630: CC1A405F 1D7EC533
	s_waitcnt vmcnt(6)                                         // 00000039A638: BF891BF7
	v_dot2_f32_bf16 v79, v37, v102, v79                        // 00000039A63C: CC1A404F 1D3ECD25
	.long 0x7eb6399b                                           // 00000039A644: 7EB6399B
	v_dot2_f32_bf16 v25, v23, v114, v25                        // 00000039A648: CC1A4019 1C66E517
	v_add3_u32 v27, v87, v96, 0x7fff                           // 00000039A650: D655001B 03FEC157 00007FFF
	v_dot2_f32_bf16 v87, v48, v97, v117                        // 00000039A65C: CC1A4057 1DD6C330
	v_dot2_f32_bf16 v95, v52, v97, v95                         // 00000039A664: CC1A405F 1D7EC334
	v_lshrrev_b32_e32 v97, 20, v86                             // 00000039A66C: 32C2AC94
	v_dot2_f32_bf16 v79, v38, v100, v79                        // 00000039A670: CC1A404F 1D3EC926
	v_dot2_f32_bf16 v96, v24, v107, v25                        // 00000039A678: CC1A4060 1C66D718
	v_dot2_f32_bf16 v87, v53, v77, v87                         // 00000039A680: CC1A4057 1D5E9B35
	v_and_or_b32 v25, 0xffff0000, v27, v91                     // 00000039A688: D6570019 056E36FF FFFF0000
	.long 0x7eb6399c                                           // 00000039A694: 7EB6399C
	v_and_b32_e32 v27, 48, v97                                 // 00000039A698: 3636C2B0
	v_dot2_f32_bf16 v79, v39, v115, v79                        // 00000039A69C: CC1A404F 1D3EE727
	s_waitcnt vmcnt(4)                                         // 00000039A6A4: BF8913F7
	v_dot2_f32_bf16 v77, v61, v77, v95                         // 00000039A6A8: CC1A404D 1D7E9B3D
	v_dot2_f32_bf16 v87, v54, v99, v87                         // 00000039A6B0: CC1A4057 1D5EC736
	v_lshrrev_b32_e32 v95, 22, v86                             // 00000039A6B8: 32BEAC96
	v_and_or_b32 v27, v91, 15, v27                             // 00000039A6BC: D657001B 046D1F5B
	v_dot2_f32_bf16 v79, v40, v112, v79                        // 00000039A6C4: CC1A404F 1D3EE128
	v_lshrrev_b32_e32 v97, 20, v28                             // 00000039A6CC: 32C23894
	v_dot2_f32_bf16 v87, v55, v103, v87                        // 00000039A6D0: CC1A4057 1D5ECF37
	v_and_b32_e32 v95, 48, v95                                 // 00000039A6D8: 36BEBEB0
	v_cvt_f32_ubyte0_e32 v27, v27                              // 00000039A6DC: 7E36231B
	v_lshrrev_b32_e32 v98, 24, v86                             // 00000039A6E0: 32C4AC98
	v_dot2_f32_bf16 v79, v41, v120, v79                        // 00000039A6E4: CC1A404F 1D3EF129
	v_dot2_f32_bf16 v77, v62, v99, v77                         // 00000039A6EC: CC1A404D 1D36C73E
	v_dot2_f32_bf16 v87, v56, v101, v87                        // 00000039A6F4: CC1A4057 1D5ECB38
	v_and_or_b32 v95, v97, 15, v95                             // 00000039A6FC: D657005F 057D1F61
	v_fma_mix_f32 v27, v27, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A704: CC20601B 1576BB1B
	v_lshrrev_b32_e32 v97, 24, v28                             // 00000039A70C: 32C23898
	v_and_b32_e32 v98, 48, v98                                 // 00000039A710: 36C4C4B0
	v_dot2_f32_bf16 v77, v63, v103, v77                        // 00000039A714: CC1A404D 1D36CF3F
	v_dot2_f32_bf16 v99, v42, v116, v79                        // 00000039A71C: CC1A4063 1D3EE92A
	s_waitcnt vmcnt(3)                                         // 00000039A724: BF890FF7
	v_dot2_f32_bf16 v79, v57, v102, v87                        // 00000039A728: CC1A404F 1D5ECD39
	v_bfe_u32 v87, v27, 16, 1                                  // 00000039A730: D6100057 0205211B
	v_and_or_b32 v97, v97, 15, v98                             // 00000039A738: D6570061 05891F61
	v_dot2_f32_bf16 v77, v64, v101, v77                        // 00000039A740: CC1A404D 1D36CB40
	v_cvt_f32_ubyte0_e32 v95, v95                              // 00000039A748: 7EBE235F
	v_dot2_f32_bf16 v79, v58, v100, v79                        // 00000039A74C: CC1A404F 1D3EC93A
	v_add3_u32 v27, v27, v87, 0x7fff                           // 00000039A754: D655001B 03FEAF1B 00007FFF
	v_cvt_f32_ubyte0_e32 v87, v97                              // 00000039A760: 7EAE2361
	s_waitcnt vmcnt(2)                                         // 00000039A764: BF890BF7
	v_dot2_f32_bf16 v77, v65, v102, v77                        // 00000039A768: CC1A404D 1D36CD41
	v_fma_mix_f32 v95, v95, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A770: CC20605F 1576BB5F
	v_dot2_f32_bf16 v97, v59, v115, v79                        // 00000039A778: CC1A4061 1D3EE73B
	.long 0x7eb6399b                                           // 00000039A780: 7EB6399B
	v_fma_mix_f32 v27, v87, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A784: CC20601B 1576BB57
	v_dot2_f32_bf16 v77, v66, v100, v77                        // 00000039A78C: CC1A404D 1D36C942
	v_bfe_u32 v79, v95, 16, 1                                  // 00000039A794: D610004F 0205215F
	v_lshrrev_b32_e32 v87, 28, v28                             // 00000039A79C: 32AE389C
	v_lshrrev_b32_e32 v98, 26, v86                             // 00000039A7A0: 32C4AC9A
	v_lshlrev_b32_e32 v100, 4, v83                             // 00000039A7A4: 30C8A684
	v_bfe_u32 v101, v27, 16, 1                                 // 00000039A7A8: D6100065 0205211B
	v_add3_u32 v79, v95, v79, 0x7fff                           // 00000039A7B0: D655004F 03FE9F5F 00007FFF
	v_dot2_f32_bf16 v77, v67, v115, v77                        // 00000039A7BC: CC1A404D 1D36E743
	v_and_or_b32 v87, v98, 48, v87                             // 00000039A7C4: D6570057 055D6162
	v_and_b32_e32 v95, 48, v100                                // 00000039A7CC: 36BEC8B0
	v_add3_u32 v27, v27, v101, 0x7fff                          // 00000039A7D0: D655001B 03FECB1B 00007FFF
	v_lshlrev_b32_e32 v98, 2, v83                              // 00000039A7DC: 30C4A682
	v_and_or_b32 v79, 0xffff0000, v79, v91                     // 00000039A7E0: D657004F 056E9EFF FFFF0000
	v_cvt_f32_ubyte0_e32 v87, v87                              // 00000039A7EC: 7EAE2357
	v_and_or_b32 v95, v9, 15, v95                              // 00000039A7F0: D657005F 057D1F09
	.long 0x7eb6399b                                           // 00000039A7F8: 7EB6399B
	v_lshrrev_b32_e32 v27, 4, v9                               // 00000039A7FC: 32361284
	v_and_b32_e32 v98, 48, v98                                 // 00000039A800: 36C4C4B0
	v_fma_mix_f32 v87, v87, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A804: CC206057 1576BB57
	v_cvt_f32_ubyte0_e32 v95, v95                              // 00000039A80C: 7EBE235F
	v_lshrrev_b32_e32 v100, 8, v9                              // 00000039A810: 32C81288
	v_and_b32_e32 v101, 48, v83                                // 00000039A814: 36CAA6B0
	v_and_or_b32 v27, v27, 15, v98                             // 00000039A818: D657001B 05891F1B
	v_lshrrev_b32_e32 v98, 2, v83                              // 00000039A820: 32C4A682
	v_bfe_u32 v102, v87, 16, 1                                 // 00000039A824: D6100066 02052157
	v_fma_mix_f32 v95, v95, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A82C: CC20605F 1572B95F
	v_and_or_b32 v100, v100, 15, v101                          // 00000039A834: D6570064 05951F64
	v_lshrrev_b32_e32 v101, 12, v9                             // 00000039A83C: 32CA128C
	v_and_b32_e32 v98, 48, v98                                 // 00000039A840: 36C4C4B0
	v_add3_u32 v87, v87, v102, 0x7fff                          // 00000039A844: D6550057 03FECD57 00007FFF
	v_bfe_u32 v102, v95, 16, 1                                 // 00000039A850: D6100066 0205215F
	v_cvt_f32_ubyte0_e32 v27, v27                              // 00000039A858: 7E36231B
	v_cvt_f32_ubyte0_e32 v100, v100                            // 00000039A85C: 7EC82364
	v_and_or_b32 v98, v101, 15, v98                            // 00000039A860: D6570062 05891F65
	v_lshrrev_b32_e32 v101, 12, v85                            // 00000039A868: 32CAAA8C
	v_add3_u32 v95, v95, v102, 0x7fff                          // 00000039A86C: D655005F 03FECD5F 00007FFF
	v_fma_mix_f32 v27, v27, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A878: CC20601B 1572B91B
	v_fma_mix_f32 v100, v100, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A880: CC206064 1572B964
	v_cvt_f32_ubyte0_e32 v98, v98                              // 00000039A888: 7EC42362
	v_and_or_b32 v87, 0xffff0000, v87, v91                     // 00000039A88C: D6570057 056EAEFF FFFF0000
	.long 0x7eb639df                                           // 00000039A898: 7EB639DF
	v_bfe_u32 v95, v27, 16, 1                                  // 00000039A89C: D610005F 0205211B
	v_bfe_u32 v102, v100, 16, 1                                // 00000039A8A4: D6100066 02052164
	v_fma_mix_f32 v98, v98, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A8AC: CC206062 1572B962
	v_and_b32_e32 v101, 48, v101                               // 00000039A8B4: 36CACAB0
	v_dot2_f32_bf16 v77, v68, v112, v77                        // 00000039A8B8: CC1A404D 1D36E144
	v_add3_u32 v27, v27, v95, 0x7fff                           // 00000039A8C0: D655001B 03FEBF1B 00007FFF
	v_add3_u32 v95, v100, v102, 0x7fff                         // 00000039A8CC: D655005F 03FECD64 00007FFF
	v_bfe_u32 v100, v98, 16, 1                                 // 00000039A8D8: D6100064 02052162
	v_and_or_b32 v101, v26, 15, v101                           // 00000039A8E0: D6570065 05951F1A
	v_lshrrev_b32_e32 v85, 14, v85                             // 00000039A8E8: 32AAAA8E
	v_and_or_b32 v27, 0xffff0000, v27, v91                     // 00000039A8EC: D657001B 056E36FF FFFF0000
	.long 0x7eb639df                                           // 00000039A8F8: 7EB639DF
	v_add3_u32 v95, v98, v100, 0x7fff                          // 00000039A8FC: D655005F 03FEC962 00007FFF
	v_lshrrev_b32_e32 v98, 4, v83                              // 00000039A908: 32C4A684
	s_waitcnt vmcnt(0)                                         // 00000039A90C: BF8903F7
	v_dot2_f32_bf16 v100, v73, v120, v77                       // 00000039A910: CC1A4064 1D36F149
	v_cvt_f32_ubyte0_e32 v101, v101                            // 00000039A918: 7ECA2365
	v_lshrrev_b32_e32 v26, 4, v26                              // 00000039A91C: 32343484
	v_and_or_b32 v77, 0xffff0000, v95, v91                     // 00000039A920: D657004D 056EBEFF FFFF0000
	.long 0x7eb63989                                           // 00000039A92C: 7EB63989
	v_and_b32_e32 v95, 48, v98                                 // 00000039A930: 36BEC4B0
	v_dot2_f32_bf16 v98, v74, v116, v100                       // 00000039A934: CC1A4062 1D92E94A
	v_fma_mix_f32 v100, v101, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A93C: CC206064 1576BB65
	v_lshrrev_b32_e32 v101, 6, v83                             // 00000039A944: 32CAA686
	v_and_b32_e32 v85, 48, v85                                 // 00000039A948: 36AAAAB0
	v_and_or_b32 v95, v91, 15, v95                             // 00000039A94C: D657005F 057D1F5B
	v_lshrrev_b32_e32 v103, 20, v9                             // 00000039A954: 32CE1294
	v_bfe_u32 v102, v100, 16, 1                                // 00000039A958: D6100066 02052164
	v_and_b32_e32 v101, 48, v101                               // 00000039A960: 36CACAB0
	v_and_or_b32 v26, v26, 15, v85                             // 00000039A964: D657001A 05551F1A
	v_lshrrev_b32_e32 v85, 8, v83                              // 00000039A96C: 32AAA688
	v_cvt_f32_ubyte0_e32 v95, v95                              // 00000039A970: 7EBE235F
	v_add3_u32 v100, v100, v102, 0x7fff                        // 00000039A974: D6550064 03FECD64 00007FFF
	v_and_or_b32 v101, v103, 15, v101                          // 00000039A980: D6570065 05951F67
	v_lshrrev_b32_e32 v102, 24, v9                             // 00000039A988: 32CC1298
	v_and_b32_e32 v85, 48, v85                                 // 00000039A98C: 36AAAAB0
	v_dot2_f32_bf16 v97, v60, v112, v97                        // 00000039A990: CC1A4061 1D86E13C
	v_fma_mix_f32 v112, v95, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A998: CC206070 1572B95F
	v_add_f32_e32 v95, 0, v96                                  // 00000039A9A0: 06BEC080
	v_dot2_f32_bf16 v96, v43, v114, v99                        // 00000039A9A4: CC1A4060 1D8EE52B
	v_cvt_f32_ubyte0_e32 v99, v101                             // 00000039A9AC: 7EC62365
	v_and_or_b32 v85, v102, 15, v85                            // 00000039A9B0: D6570055 05551F66
	v_lshrrev_b32_e32 v9, 28, v9                               // 00000039A9B8: 3212129C
	v_lshrrev_b32_e32 v102, 10, v83                            // 00000039A9BC: 32CCA68A
	v_bfe_u32 v103, v112, 16, 1                                // 00000039A9C0: D6100067 02052170
	v_fma_mix_f32 v99, v99, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A9C8: CC206063 1572B963
	v_cvt_f32_ubyte0_e32 v85, v85                              // 00000039A9D0: 7EAA2355
	v_cvt_f32_ubyte0_e32 v26, v26                              // 00000039A9D4: 7E34231A
	v_and_or_b32 v9, v102, 48, v9                              // 00000039A9D8: D6570009 04256166
	v_add3_u32 v101, v112, v103, 0x7fff                        // 00000039A9E0: D6550065 03FECF70 00007FFF
	v_bfe_u32 v102, v99, 16, 1                                 // 00000039A9EC: D6100066 02052163
	v_fma_mix_f32 v85, v85, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A9F4: CC206055 1572B955
	v_fma_mix_f32 v26, v26, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039A9FC: CC20601A 1576BB1A
	v_cvt_f32_ubyte0_e32 v9, v9                                // 00000039AA04: 7E122309
	.long 0x7eb639e5                                           // 00000039AA08: 7EB639E5
	v_add3_u32 v99, v99, v102, 0x7fff                          // 00000039AA0C: D6550063 03FECD63 00007FFF
	v_bfe_u32 v101, v85, 16, 1                                 // 00000039AA18: D6100065 02052155
	v_bfe_u32 v102, v26, 16, 1                                 // 00000039AA20: D6100066 0205211A
	v_fma_mix_f32 v103, v9, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AA28: CC206067 1572B909
	.long 0x7ec839e4                                           // 00000039AA30: 7EC839E4
	v_and_or_b32 v9, 0xffff0000, v99, v91                      // 00000039AA34: D6570009 056EC6FF FFFF0000
	v_add3_u32 v85, v85, v101, 0x7fff                          // 00000039AA40: D6550055 03FECB55 00007FFF
	v_add3_u32 v26, v26, v102, 0x7fff                          // 00000039AA4C: D655001A 03FECD1A 00007FFF
	v_bfe_u32 v102, v103, 16, 1                                // 00000039AA58: D6100066 02052167
	.long 0x7fc839db                                           // 00000039AA60: 7FC839DB
	v_lshrrev_b32_e32 v101, 12, v86                            // 00000039AA64: 32CAAC8C
	.long 0x7eb639d5                                           // 00000039AA68: 7EB639D5
	v_and_b32_e32 v85, 15, v28                                 // 00000039AA6C: 36AA388F
	v_add3_u32 v99, v103, v102, 0x7fff                         // 00000039AA70: D6550063 03FECD67 00007FFF
	v_and_or_b32 v100, 0xffff0000, v26, v100                   // 00000039AA7C: D6570064 059234FF FFFF0000
	v_lshrrev_b32_e32 v103, 18, v83                            // 00000039AA88: 32CEA692
	v_lshrrev_b32_e32 v86, 14, v86                             // 00000039AA8C: 32ACAC8E
	v_and_or_b32 v85, v101, 48, v85                            // 00000039AA90: D6570055 05556165
	v_and_or_b32 v26, 0xffff0000, v99, v91                     // 00000039AA98: D657001A 056EC6FF FFFF0000
	.long 0x7eb639d3                                           // 00000039AAA4: 7EB639D3
	v_dot2_f32_bf16 v99, v5, v78, 0                            // 00000039AAA8: CC1A4063 1A029D05
	v_lshrrev_b32_e32 v101, 8, v10                             // 00000039AAB0: 32CA1488
	v_and_b32_e32 v103, 48, v103                               // 00000039AAB4: 36CECEB0
	v_lshrrev_b32_e32 v28, 4, v28                              // 00000039AAB8: 32383884
	v_and_b32_e32 v102, 48, v91                                // 00000039AABC: 36CCB6B0
	v_dot2_f32_bf16 v99, v6, v104, v99                         // 00000039AAC0: CC1A4063 1D8ED106
	v_and_b32_e32 v86, 48, v86                                 // 00000039AAC8: 36ACACB0
	v_cvt_f32_ubyte0_e32 v85, v85                              // 00000039AACC: 7EAA2355
	v_dot2_f32_bf16 v97, v69, v120, v97                        // 00000039AAD0: CC1A4061 1D86F145
	v_and_or_b32 v101, v101, 15, v102                          // 00000039AAD8: D6570065 05991F65
	v_lshrrev_b32_e32 v102, 12, v10                            // 00000039AAE0: 32CC148C
	v_dot2_f32_bf16 v99, v7, v105, v99                         // 00000039AAE4: CC1A4063 1D8ED307
	v_and_or_b32 v28, v28, 15, v86                             // 00000039AAEC: D657001C 05591F1C
	v_fma_mix_f32 v85, v85, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AAF4: CC206055 1576BB55
	v_cvt_f32_ubyte0_e32 v101, v101                            // 00000039AAFC: 7ECA2365
	v_and_or_b32 v102, v102, 15, v103                          // 00000039AB00: D6570066 059D1F66
	v_dot2_f32_bf16 v86, v8, v88, v99                          // 00000039AB08: CC1A4056 1D8EB108
	v_cvt_f32_ubyte0_e32 v28, v28                              // 00000039AB10: 7E38231C
	v_bfe_u32 v112, v85, 16, 1                                 // 00000039AB14: D6100070 02052155
	v_fma_mix_f32 v99, v101, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AB1C: CC206063 1572B965
	v_cvt_f32_ubyte0_e32 v101, v102                            // 00000039AB24: 7ECA2366
	v_dot2_f32_bf16 v86, v17, v100, v86                        // 00000039AB28: CC1A4056 1D5AC911
	v_fma_mix_f32 v28, v28, v93, v93 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AB30: CC20601C 1576BB1C
	v_add3_u32 v85, v85, v112, 0x7fff                          // 00000039AB38: D6550055 03FEE155 00007FFF
	v_bfe_u32 v102, v99, 16, 1                                 // 00000039AB44: D6100066 02052163
	v_fma_mix_f32 v101, v101, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AB4C: CC206065 1572B965
	v_dot2_f32_bf16 v86, v18, v106, v86                        // 00000039AB54: CC1A4056 1D5AD512
	v_dot2_f32_bf16 v103, v29, v78, 0                          // 00000039AB5C: CC1A4067 1A029D1D
	.long 0x7eaa39d5                                           // 00000039AB64: 7EAA39D5
	v_add3_u32 v93, v99, v102, 0x7fff                          // 00000039AB68: D655005D 03FECD63 00007FFF
	v_bfe_u32 v99, v101, 16, 1                                 // 00000039AB74: D6100063 02052165
	v_bfe_u32 v102, v28, 16, 1                                 // 00000039AB7C: D6100066 0205211C
	v_dot2_f32_bf16 v86, v19, v111, v86                        // 00000039AB84: CC1A4056 1D5ADF13
	.long 0x7faa39db                                           // 00000039AB8C: 7FAA39DB
	.long 0x7eb639dd                                           // 00000039AB90: 7EB639DD
	v_add3_u32 v93, v101, v99, 0x7fff                          // 00000039AB94: D655005D 03FEC765 00007FFF
	v_lshrrev_b32_e32 v101, 20, v83                            // 00000039ABA0: 32CAA694
	v_add3_u32 v99, v28, v102, 0x7fff                          // 00000039ABA4: D6550063 03FECD1C 00007FFF
	v_dot2_f32_bf16 v86, v20, v108, v86                        // 00000039ABB0: CC1A4056 1D5AD914
	v_dot2_f32_bf16 v102, v30, v104, v103                      // 00000039ABB8: CC1A4066 1D9ED11E
	v_and_or_b32 v28, 0xffff0000, v93, v91                     // 00000039ABC0: D657001C 056EBAFF FFFF0000
	.long 0x7eb6398a                                           // 00000039ABCC: 7EB6398A
	v_and_b32_e32 v93, 48, v101                                // 00000039ABD0: 36BACAB0
	v_dot2_f32_bf16 v97, v70, v116, v97                        // 00000039ABD4: CC1A4061 1D86E946
	v_dot2_f32_bf16 v101, v31, v105, v102                      // 00000039ABDC: CC1A4065 1D9AD31F
	v_and_or_b32 v103, 0xffff0000, v99, v85                    // 00000039ABE4: D6570067 0556C6FF FFFF0000
	v_dot2_f32_bf16 v85, v13, v109, v86                        // 00000039ABF0: CC1A4055 1D5ADB0D
	v_and_or_b32 v86, v91, 15, v93                             // 00000039ABF8: D6570056 05751F5B
	v_lshrrev_b32_e32 v93, 22, v83                             // 00000039AC00: 32BAA696
	v_dot2_f32_bf16 v97, v71, v114, v97                        // 00000039AC04: CC1A4061 1D86E547
	v_dot2_f32_bf16 v98, v75, v114, v98                        // 00000039AC0C: CC1A4062 1D8AE54B
	v_dot2_f32_bf16 v99, v32, v88, v101                        // 00000039AC14: CC1A4063 1D96B120
	v_lshrrev_b32_e32 v101, 24, v83                            // 00000039AC1C: 32CAA698
	v_lshrrev_b32_e32 v102, 20, v10                            // 00000039AC20: 32CC1494
	v_and_b32_e32 v93, 48, v93                                 // 00000039AC24: 36BABAB0
	v_dot2_f32_bf16 v96, v44, v107, v96                        // 00000039AC28: CC1A4060 1D82D72C
	v_dot2_f32_bf16 v97, v72, v107, v97                        // 00000039AC30: CC1A4061 1D86D748
	v_dot2_f32_bf16 v98, v76, v107, v98                        // 00000039AC38: CC1A4062 1D8AD74C
	v_cvt_f32_ubyte0_e32 v86, v86                              // 00000039AC40: 7EAC2356
	v_lshrrev_b32_e32 v107, 24, v10                            // 00000039AC44: 32D61498
	v_and_b32_e32 v101, 48, v101                               // 00000039AC48: 36CACAB0
	v_and_or_b32 v93, v102, 15, v93                            // 00000039AC4C: D657005D 05751F66
	v_dot2_f32_bf16 v85, v14, v110, v85                        // 00000039AC54: CC1A4055 1D56DD0E
	v_fma_mix_f32 v86, v86, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AC5C: CC206056 1572B956
	v_lshrrev_b32_e32 v114, 8, v11                             // 00000039AC64: 32E41688
	v_and_or_b32 v101, v107, 15, v101                          // 00000039AC68: D6570065 05951F6B
	v_cvt_f32_ubyte0_e32 v93, v93                              // 00000039AC70: 7EBA235D
	v_dot2_f32_bf16 v107, v15, v113, v85                       // 00000039AC74: CC1A406B 1D56E30F
	v_bfe_u32 v102, v86, 16, 1                                 // 00000039AC7C: D6100066 02052156
	v_and_b32_e32 v116, 48, v84                                // 00000039AC84: 36E8A8B0
	v_cvt_f32_ubyte0_e32 v85, v101                             // 00000039AC88: 7EAA2365
	v_fma_mix_f32 v93, v93, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AC8C: CC20605D 1572B95D
	v_lshrrev_b32_e32 v101, 28, v10                            // 00000039AC94: 32CA149C
	v_add3_u32 v86, v86, v102, 0x7fff                          // 00000039AC98: D6550056 03FECD56 00007FFF
	v_lshrrev_b32_e32 v102, 26, v83                            // 00000039ACA4: 32CCA69A
	v_fma_mix_f32 v85, v85, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039ACA8: CC206055 1572B955
	v_bfe_u32 v112, v93, 16, 1                                 // 00000039ACB0: D6100070 0205215D
	v_lshrrev_b32_e32 v115, 2, v84                             // 00000039ACB8: 32E6A882
	.long 0x7eb639d6                                           // 00000039ACBC: 7EB639D6
	v_and_or_b32 v101, v102, 48, v101                          // 00000039ACC0: D6570065 05956166
	v_bfe_u32 v86, v85, 16, 1                                  // 00000039ACC8: D6100056 02052155
	v_lshlrev_b32_e32 v102, 4, v84                             // 00000039ACD0: 30CCA884
	v_add3_u32 v93, v93, v112, 0x7fff                          // 00000039ACD4: D655005D 03FEE15D 00007FFF
	v_and_or_b32 v114, v114, 15, v116                          // 00000039ACE0: D6570072 05D11F72
	v_cvt_f32_ubyte0_e32 v101, v101                            // 00000039ACE8: 7ECA2365
	v_add3_u32 v86, v85, v86, 0x7fff                           // 00000039ACEC: D6550056 03FEAD55 00007FFF
	v_and_b32_e32 v102, 48, v102                               // 00000039ACF8: 36CCCCB0
	v_and_or_b32 v85, 0xffff0000, v93, v91                     // 00000039ACFC: D6570055 056EBAFF FFFF0000
	v_lshlrev_b32_e32 v93, 2, v84                              // 00000039AD08: 30BAA882
	v_dot2_f32_bf16 v99, v33, v100, v99                        // 00000039AD0C: CC1A4063 1D8EC921
	.long 0x7eb639d6                                           // 00000039AD14: 7EB639D6
	v_fma_mix_f32 v86, v101, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AD18: CC206056 1572B965
	v_and_or_b32 v101, v11, 15, v102                           // 00000039AD20: D6570065 05991F0B
	v_lshrrev_b32_e32 v102, 4, v11                             // 00000039AD28: 32CC1684
	v_and_b32_e32 v93, 48, v93                                 // 00000039AD2C: 36BABAB0
	v_and_b32_e32 v115, 48, v115                               // 00000039AD30: 36E6E6B0
	v_cvt_f32_ubyte0_e32 v114, v114                            // 00000039AD34: 7EE42372
	v_cvt_f32_ubyte0_e32 v101, v101                            // 00000039AD38: 7ECA2365
	v_dot2_f32_bf16 v99, v34, v106, v99                        // 00000039AD3C: CC1A4063 1D8ED522
	v_and_or_b32 v93, v102, 15, v93                            // 00000039AD44: D657005D 05751F66
	v_lshrrev_b32_e32 v102, 12, v11                            // 00000039AD4C: 32CC168C
	v_bfe_u32 v116, v86, 16, 1                                 // 00000039AD50: D6100074 02052156
	v_fma_mix_f32 v101, v101, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AD58: CC206065 1572B965
	v_fma_mix_f32 v114, v114, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AD60: CC206072 1572B972
	v_cvt_f32_ubyte0_e32 v93, v93                              // 00000039AD68: 7EBA235D
	v_and_or_b32 v102, v102, 15, v115                          // 00000039AD6C: D6570066 05CD1F66
	v_dot2_f32_bf16 v99, v35, v111, v99                        // 00000039AD74: CC1A4063 1D8EDF23
	v_bfe_u32 v115, v101, 16, 1                                // 00000039AD7C: D6100073 02052165
	v_dot2_f32_bf16 v112, v45, v78, 0                          // 00000039AD84: CC1A4070 1A029D2D
	v_fma_mix_f32 v93, v93, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AD8C: CC20605D 1572B95D
	v_add3_u32 v86, v86, v116, 0x7fff                          // 00000039AD94: D6550056 03FEE956 00007FFF
	v_cvt_f32_ubyte0_e32 v102, v102                            // 00000039ADA0: 7ECC2366
	v_add3_u32 v101, v101, v115, 0x7fff                        // 00000039ADA4: D6550065 03FEE765 00007FFF
	v_bfe_u32 v116, v114, 16, 1                                // 00000039ADB0: D6100074 02052172
	v_bfe_u32 v115, v93, 16, 1                                 // 00000039ADB8: D6100073 0205215D
	v_dot2_f32_bf16 v99, v36, v108, v99                        // 00000039ADC0: CC1A4063 1D8ED924
	v_dot2_f32_bf16 v112, v46, v104, v112                      // 00000039ADC8: CC1A4070 1DC2D12E
	v_and_or_b32 v86, 0xffff0000, v86, v91                     // 00000039ADD0: D6570056 056EACFF FFFF0000
	.long 0x7eb639e5                                           // 00000039ADDC: 7EB639E5
	v_fma_mix_f32 v101, v102, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039ADE0: CC206065 1572B966
	v_add3_u32 v93, v93, v115, 0x7fff                          // 00000039ADE8: D655005D 03FEE75D 00007FFF
	v_add3_u32 v102, v114, v116, 0x7fff                        // 00000039ADF4: D6550066 03FEE972 00007FFF
	v_dot2_f32_bf16 v99, v37, v109, v99                        // 00000039AE00: CC1A4063 1D8EDB25
	v_dot2_f32_bf16 v112, v47, v105, v112                      // 00000039AE08: CC1A4070 1DC2D32F
	v_bfe_u32 v114, v101, 16, 1                                // 00000039AE10: D6100072 02052165
	v_and_or_b32 v93, 0xffff0000, v93, v91                     // 00000039AE18: D657005D 056EBAFF FFFF0000
	v_lshrrev_b32_e32 v115, 6, v84                             // 00000039AE24: 32E6A886
	.long 0x7eb639e6                                           // 00000039AE28: 7EB639E6
	v_lshrrev_b32_e32 v102, 8, v84                             // 00000039AE2C: 32CCA888
	v_add3_u32 v101, v101, v114, 0x7fff                        // 00000039AE30: D6550065 03FEE565 00007FFF
	v_lshrrev_b32_e32 v114, 20, v11                            // 00000039AE3C: 32E41694
	v_and_b32_e32 v115, 48, v115                               // 00000039AE40: 36E6E6B0
	v_lshrrev_b32_e32 v116, 24, v11                            // 00000039AE44: 32E81698
	v_and_b32_e32 v102, 48, v102                               // 00000039AE48: 36CCCCB0
	v_dot2_f32_bf16 v99, v38, v110, v99                        // 00000039AE4C: CC1A4063 1D8EDD26
	v_dot2_f32_bf16 v112, v48, v88, v112                       // 00000039AE54: CC1A4070 1DC2B130
	v_dot2_f32_bf16 v107, v16, v94, v107                       // 00000039AE5C: CC1A406B 1DAEBD10
	v_and_or_b32 v114, v114, 15, v115                          // 00000039AE64: D6570072 05CD1F72
	v_and_or_b32 v115, v116, 15, v102                          // 00000039AE6C: D6570073 05991F74
	v_lshrrev_b32_e32 v102, 28, v11                            // 00000039AE74: 32CC169C
	v_lshrrev_b32_e32 v116, 10, v84                            // 00000039AE78: 32E8A88A
	v_dot2_f32_bf16 v99, v39, v113, v99                        // 00000039AE7C: CC1A4063 1D8EE327
	v_dot2_f32_bf16 v112, v53, v100, v112                      // 00000039AE84: CC1A4070 1DC2C935
	v_lshrrev_b32_e32 v117, 4, v84                             // 00000039AE8C: 32EAA884
	v_dot2_f32_bf16 v107, v21, v103, v107                      // 00000039AE90: CC1A406B 1DAECF15
	v_and_or_b32 v116, v116, 48, v102                          // 00000039AE98: D6570074 05996174
	v_dot2_f32_bf16 v99, v40, v94, v99                         // 00000039AEA0: CC1A4063 1D8EBD28
	v_dot2_f32_bf16 v112, v54, v106, v112                      // 00000039AEA8: CC1A4070 1DC2D536
	v_and_or_b32 v102, 0xffff0000, v101, v91                   // 00000039AEB0: D6570066 056ECAFF FFFF0000
	.long 0x7eb6398b                                           // 00000039AEBC: 7EB6398B
	v_and_b32_e32 v11, 48, v117                                // 00000039AEC0: 3616EAB0
	v_dot2_f32_bf16 v101, v22, v25, v107                       // 00000039AEC4: CC1A4065 1DAE3316
	v_dot2_f32_bf16 v99, v41, v103, v99                        // 00000039AECC: CC1A4063 1D8ECF29
	v_dot2_f32_bf16 v107, v55, v111, v112                      // 00000039AED4: CC1A406B 1DC2DF37
	v_dot2_f32_bf16 v78, v49, v78, 0                           // 00000039AEDC: CC1A404E 1A029D31
	v_and_or_b32 v11, v91, 15, v11                             // 00000039AEE4: D657000B 042D1F5B
	v_dot2_f32_bf16 v101, v23, v79, v101                       // 00000039AEEC: CC1A4065 1D969F17
	v_dot2_f32_bf16 v99, v42, v25, v99                         // 00000039AEF4: CC1A4063 1D8E332A
	v_dot2_f32_bf16 v107, v56, v108, v107                      // 00000039AEFC: CC1A406B 1DAED938
	v_dot2_f32_bf16 v78, v50, v104, v78                        // 00000039AF04: CC1A404E 1D3AD132
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000039AF0C: 7E16230B
	v_dot2_f32_bf16 v101, v24, v87, v101                       // 00000039AF10: CC1A4065 1D96AF18
	v_dot2_f32_bf16 v112, v43, v79, v99                        // 00000039AF18: CC1A4070 1D8E9F2B
	v_dot2_f32_bf16 v99, v57, v109, v107                       // 00000039AF20: CC1A4063 1DAEDB39
	v_cvt_f32_ubyte0_e32 v107, v114                            // 00000039AF28: 7ED62372
	v_fma_mix_f32 v11, v11, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AF2C: CC20600B 1572B90B
	v_cvt_f32_ubyte0_e32 v114, v115                            // 00000039AF34: 7EE42373
	v_cvt_f32_ubyte0_e32 v115, v116                            // 00000039AF38: 7EE62374
	v_dot2_f32_bf16 v78, v51, v105, v78                        // 00000039AF3C: CC1A404E 1D3AD333
	v_fma_mix_f32 v107, v107, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AF44: CC20606B 1572B96B
	v_bfe_u32 v104, v11, 16, 1                                 // 00000039AF4C: D6100068 0205210B
	v_fma_mix_f32 v114, v114, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AF54: CC206072 1572B972
	v_fma_mix_f32 v115, v115, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039AF5C: CC206073 1572B973
	v_dot2_f32_bf16 v99, v58, v110, v99                        // 00000039AF64: CC1A4063 1D8EDD3A
	v_dot2_f32_bf16 v78, v52, v88, v78                         // 00000039AF6C: CC1A404E 1D3AB134
	v_add3_u32 v11, v11, v104, 0x7fff                          // 00000039AF74: D655000B 03FED10B 00007FFF
	v_bfe_u32 v104, v107, 16, 1                                // 00000039AF80: D6100068 0205216B
	v_bfe_u32 v105, v114, 16, 1                                // 00000039AF88: D6100069 02052172
	v_add_f32_e32 v96, 0, v96                                  // 00000039AF90: 06C0C080
	v_dot2_f32_bf16 v78, v61, v100, v78                        // 00000039AF94: CC1A404E 1D3AC93D
	.long 0x7eb6398b                                           // 00000039AF9C: 7EB6398B
	v_add3_u32 v11, v107, v104, 0x7fff                         // 00000039AFA0: D655000B 03FED16B 00007FFF
	v_add3_u32 v88, v114, v105, 0x7fff                         // 00000039AFAC: D6550058 03FED372 00007FFF
	v_bfe_u32 v104, v115, 16, 1                                // 00000039AFB8: D6100068 02052173
	v_dot2_f32_bf16 v105, v59, v113, v99                       // 00000039AFC0: CC1A4069 1D8EE33B
	v_add_f32_e32 v99, 0, v101                                 // 00000039AFC8: 06C6CA80
	v_and_or_b32 v11, 0xffff0000, v11, v91                     // 00000039AFCC: D657000B 056E16FF FFFF0000
	.long 0x7eb639d8                                           // 00000039AFD8: 7EB639D8
	v_add3_u32 v88, v115, v104, 0x7fff                         // 00000039AFDC: D6550058 03FED173 00007FFF
	v_dot2_f32_bf16 v100, v60, v94, v105                       // 00000039AFE8: CC1A4064 1DA6BD3C
	v_dot2_f32_bf16 v101, v44, v87, v112                       // 00000039AFF0: CC1A4065 1DC2AF2C
	v_dot2_f32_bf16 v104, v62, v106, v78                       // 00000039AFF8: CC1A4068 1D3AD53E
	v_lshrrev_b32_e32 v106, 18, v84                            // 00000039B000: 32D4A892
	v_and_or_b32 v78, 0xffff0000, v88, v91                     // 00000039B004: D657004E 056EB0FF FFFF0000
	.long 0x7eb639d4                                           // 00000039B010: 7EB639D4
	v_dot2_f32_bf16 v88, v69, v103, v100                       // 00000039B014: CC1A4058 1D92CF45
	v_add_f32_e32 v100, 0, v101                                // 00000039B01C: 06C8CA80
	v_dot2_f32_bf16 v101, v63, v111, v104                      // 00000039B020: CC1A4065 1DA2DF3F
	v_lshrrev_b32_e32 v104, 8, v12                             // 00000039B028: 32D01888
	v_and_b32_e32 v105, 48, v91                                // 00000039B02C: 36D2B6B0
	v_dot2_f32_bf16 v88, v70, v25, v88                         // 00000039B030: CC1A4058 1D623346
	v_lshrrev_b32_e32 v107, 12, v83                            // 00000039B038: 32D6A68C
	v_dot2_f32_bf16 v101, v64, v108, v101                      // 00000039B03C: CC1A4065 1D96D940
	v_and_b32_e32 v106, 48, v106                               // 00000039B044: 36D4D4B0
	v_and_or_b32 v104, v104, 15, v105                          // 00000039B048: D6570068 05A51F68
	v_lshrrev_b32_e32 v105, 12, v12                            // 00000039B050: 32D2188C
	v_dot2_f32_bf16 v88, v71, v79, v88                         // 00000039B054: CC1A4058 1D629F47
	v_dot2_f32_bf16 v101, v65, v109, v101                      // 00000039B05C: CC1A4065 1D96DB41
	v_and_b32_e32 v107, 48, v107                               // 00000039B064: 36D6D6B0
	v_cvt_f32_ubyte0_e32 v104, v104                            // 00000039B068: 7ED02368
	v_and_or_b32 v105, v105, 15, v106                          // 00000039B06C: D6570069 05A91F69
	v_dot2_f32_bf16 v88, v72, v87, v88                         // 00000039B074: CC1A4058 1D62AF48
	v_dot2_f32_bf16 v101, v66, v110, v101                      // 00000039B07C: CC1A4065 1D96DD42
	v_and_or_b32 v106, v10, 15, v107                           // 00000039B084: D657006A 05AD1F0A
	v_fma_mix_f32 v104, v104, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B08C: CC206068 1572B968
	v_cvt_f32_ubyte0_e32 v105, v105                            // 00000039B094: 7ED22369
	v_lshrrev_b32_e32 v83, 14, v83                             // 00000039B098: 32A6A68E
	v_dot2_f32_bf16 v107, v67, v113, v101                      // 00000039B09C: CC1A406B 1D96E343
	v_add_f32_e32 v101, 0, v88                                 // 00000039B0A4: 06CAB080
	v_cvt_f32_ubyte0_e32 v88, v106                             // 00000039B0A8: 7EB0236A
	v_bfe_u32 v106, v104, 16, 1                                // 00000039B0AC: D610006A 02052168
	v_fma_mix_f32 v105, v105, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B0B4: CC206069 1572B969
	v_dot2_f32_bf16 v94, v68, v94, v107                        // 00000039B0BC: CC1A405E 1DAEBD44
	v_lshrrev_b32_e32 v10, 4, v10                              // 00000039B0C4: 32141484
	v_fma_mix_f32 v88, v88, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B0C8: CC206058 1572B958
	v_add3_u32 v104, v104, v106, 0x7fff                        // 00000039B0D0: D6550068 03FED568 00007FFF
	v_bfe_u32 v106, v105, 16, 1                                // 00000039B0DC: D610006A 02052169
	v_and_b32_e32 v83, 48, v83                                 // 00000039B0E4: 36A6A6B0
	v_dot2_f32_bf16 v94, v73, v103, v94                        // 00000039B0E8: CC1A405E 1D7ACF49
	v_bfe_u32 v107, v88, 16, 1                                 // 00000039B0F0: D610006B 02052158
	.long 0x7eb639e8                                           // 00000039B0F8: 7EB639E8
	v_add3_u32 v104, v105, v106, 0x7fff                        // 00000039B0FC: D6550068 03FED569 00007FFF
	v_lshrrev_b32_e32 v103, 20, v84                            // 00000039B108: 32CEA894
	v_and_or_b32 v10, v10, 15, v83                             // 00000039B10C: D657000A 054D1F0A
	v_add3_u32 v88, v88, v107, 0x7fff                          // 00000039B114: D6550058 03FED758 00007FFF
	v_lshrrev_b32_e32 v105, 24, v84                            // 00000039B120: 32D2A898
	v_and_or_b32 v83, 0xffff0000, v104, v91                    // 00000039B124: D6570053 056ED0FF FFFF0000
	.long 0x7eb6398c                                           // 00000039B130: 7EB6398C
	v_and_b32_e32 v103, 48, v103                               // 00000039B134: 36CECEB0
	v_cvt_f32_ubyte0_e32 v10, v10                              // 00000039B138: 7E14230A
	.long 0x7ed039d8                                           // 00000039B13C: 7ED039D8
	v_lshrrev_b32_e32 v88, 22, v84                             // 00000039B140: 32B0A896
	v_lshrrev_b32_e32 v106, 20, v12                            // 00000039B144: 32D41894
	v_and_or_b32 v103, v91, 15, v103                           // 00000039B148: D6570067 059D1F5B
	v_fma_mix_f32 v10, v10, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B150: CC20600A 1572B90A
	v_lshrrev_b32_e32 v107, 24, v12                            // 00000039B158: 32D61898
	v_and_b32_e32 v88, 48, v88                                 // 00000039B15C: 36B0B0B0
	v_and_b32_e32 v105, 48, v105                               // 00000039B160: 36D2D2B0
	v_cvt_f32_ubyte0_e32 v103, v103                            // 00000039B164: 7ECE2367
	v_bfe_u32 v108, v10, 16, 1                                 // 00000039B168: D610006C 0205210A
	v_lshlrev_b32_e32 v110, 4, v81                             // 00000039B170: 30DCA284
	v_and_or_b32 v88, v106, 15, v88                            // 00000039B174: D6570058 05611F6A
	v_and_or_b32 v105, v107, 15, v105                          // 00000039B17C: D6570069 05A51F6B
	v_fma_mix_f32 v103, v103, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B184: CC206067 1572B967
	v_add3_u32 v108, v10, v108, 0x7fff                         // 00000039B18C: D655006C 03FED90A 00007FFF
	v_lshrrev_b32_e32 v106, 12, v84                            // 00000039B198: 32D4A88C
	v_cvt_f32_ubyte0_e32 v88, v88                              // 00000039B19C: 7EB02358
	v_cvt_f32_ubyte0_e32 v105, v105                            // 00000039B1A0: 7ED22369
	v_bfe_u32 v10, v103, 16, 1                                 // 00000039B1A4: D610000A 02052167
	v_and_b32_e32 v107, 15, v12                                // 00000039B1AC: 36D6188F
	v_lshrrev_b32_e32 v111, 2, v81                             // 00000039B1B0: 32DEA282
	v_fma_mix_f32 v88, v88, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B1B4: CC206058 1572B958
	.long 0x7fd039db                                           // 00000039B1BC: 7FD039DB
	v_add3_u32 v10, v103, v10, 0x7fff                          // 00000039B1C0: D655000A 03FE1567 00007FFF
	v_fma_mix_f32 v103, v105, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B1CC: CC206067 1572B969
	v_and_or_b32 v106, v106, 48, v107                          // 00000039B1D4: D657006A 05AD616A
	v_bfe_u32 v109, v88, 16, 1                                 // 00000039B1DC: D610006D 02052158
	v_lshrrev_b32_e32 v107, 4, v12                             // 00000039B1E4: 32D61884
	.long 0x7eb6398a                                           // 00000039B1E8: 7EB6398A
	v_bfe_u32 v10, v103, 16, 1                                 // 00000039B1EC: D610000A 02052167
	v_lshrrev_b32_e32 v105, 14, v84                            // 00000039B1F4: 32D2A88E
	v_add3_u32 v88, v88, v109, 0x7fff                          // 00000039B1F8: D6550058 03FEDB58 00007FFF
	v_lshrrev_b32_e32 v12, 28, v12                             // 00000039B204: 3218189C
	v_lshrrev_b32_e32 v84, 26, v84                             // 00000039B208: 32A8A89A
	v_add3_u32 v10, v103, v10, 0x7fff                          // 00000039B20C: D655000A 03FE1567 00007FFF
	v_and_b32_e32 v103, 48, v110                               // 00000039B218: 36CEDCB0
	v_lshlrev_b32_e32 v109, 2, v81                             // 00000039B21C: 30DAA282
	v_and_or_b32 v88, 0xffff0000, v88, v91                     // 00000039B220: D6570058 056EB0FF FFFF0000
	v_and_or_b32 v12, v84, 48, v12                             // 00000039B22C: D657000C 04316154
	.long 0x7eb6398a                                           // 00000039B234: 7EB6398A
	v_and_or_b32 v10, v1, 15, v103                             // 00000039B238: D657000A 059D1F01
	v_lshrrev_b32_e32 v84, 4, v1                               // 00000039B240: 32A80284
	v_and_b32_e32 v103, 48, v109                               // 00000039B244: 36CEDAB0
	v_lshrrev_b32_e32 v109, 8, v1                              // 00000039B248: 32DA0288
	v_and_b32_e32 v110, 48, v81                                // 00000039B24C: 36DCA2B0
	v_cvt_f32_ubyte0_e32 v12, v12                              // 00000039B250: 7E18230C
	v_cvt_f32_ubyte0_e32 v10, v10                              // 00000039B254: 7E14230A
	v_and_or_b32 v84, v84, 15, v103                            // 00000039B258: D6570054 059D1F54
	v_cvt_f32_ubyte0_e32 v106, v106                            // 00000039B260: 7ED4236A
	v_and_or_b32 v103, v109, 15, v110                          // 00000039B264: D6570067 05B91F6D
	v_lshrrev_b32_e32 v109, 12, v1                             // 00000039B26C: 32DA028C
	v_and_b32_e32 v110, 48, v111                               // 00000039B270: 36DCDEB0
	v_fma_mix_f32 v12, v12, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B274: CC20600C 1572B90C
	v_fma_mix_f32 v10, v10, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B27C: CC20600A 156AB50A
	v_cvt_f32_ubyte0_e32 v84, v84                              // 00000039B284: 7EA82354
	v_cvt_f32_ubyte0_e32 v103, v103                            // 00000039B288: 7ECE2367
	v_and_or_b32 v109, v109, 15, v110                          // 00000039B28C: D657006D 05B91F6D
	v_bfe_u32 v110, v12, 16, 1                                 // 00000039B294: D610006E 0205210C
	v_bfe_u32 v111, v10, 16, 1                                 // 00000039B29C: D610006F 0205210A
	v_fma_mix_f32 v84, v84, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B2A4: CC206054 156AB554
	v_fma_mix_f32 v103, v103, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B2AC: CC206067 156AB567
	v_cvt_f32_ubyte0_e32 v109, v109                            // 00000039B2B4: 7EDA236D
	v_add3_u32 v12, v12, v110, 0x7fff                          // 00000039B2B8: D655000C 03FEDD0C 00007FFF
	v_add3_u32 v110, v10, v111, 0x7fff                         // 00000039B2C4: D655006E 03FEDF0A 00007FFF
	v_bfe_u32 v111, v84, 16, 1                                 // 00000039B2D0: D610006F 02052154
	v_bfe_u32 v112, v103, 16, 1                                // 00000039B2D8: D6100070 02052167
	v_fma_mix_f32 v109, v109, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B2E0: CC20606D 156AB56D
	v_and_or_b32 v10, 0xffff0000, v12, v91                     // 00000039B2E8: D657000A 056E18FF FFFF0000
	.long 0x7eb639ee                                           // 00000039B2F4: 7EB639EE
	v_add3_u32 v12, v84, v111, 0x7fff                          // 00000039B2F8: D655000C 03FEDF54 00007FFF
	v_add3_u32 v84, v103, v112, 0x7fff                         // 00000039B304: D6550054 03FEE167 00007FFF
	v_bfe_u32 v103, v109, 16, 1                                // 00000039B310: D6100067 0205216D
	v_fma_mix_f32 v106, v106, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B318: CC20606A 1572B96A
	v_and_or_b32 v108, 0xffff0000, v108, v104                  // 00000039B320: D657006C 05A2D8FF FFFF0000
	v_and_or_b32 v12, 0xffff0000, v12, v91                     // 00000039B32C: D657000C 056E18FF FFFF0000
	.long 0x7eb639d4                                           // 00000039B338: 7EB639D4
	v_add3_u32 v84, v109, v103, 0x7fff                         // 00000039B33C: D6550054 03FECF6D 00007FFF
	v_lshrrev_b32_e32 v103, 4, v81                             // 00000039B348: 32CEA284
	v_bfe_u32 v104, v106, 16, 1                                // 00000039B34C: D6100068 0205216A
	v_and_b32_e32 v105, 48, v105                               // 00000039B354: 36D2D2B0
	v_lshrrev_b32_e32 v109, 8, v81                             // 00000039B358: 32DAA288
	v_and_or_b32 v84, 0xffff0000, v84, v91                     // 00000039B35C: D6570054 056EA8FF FFFF0000
	.long 0x7eb63981                                           // 00000039B368: 7EB63981
	v_and_b32_e32 v103, 48, v103                               // 00000039B36C: 36CECEB0
	v_add3_u32 v104, v106, v104, 0x7fff                        // 00000039B370: D6550068 03FED16A 00007FFF
	v_lshrrev_b32_e32 v106, 6, v81                             // 00000039B37C: 32D4A286
	v_and_or_b32 v105, v107, 15, v105                          // 00000039B380: D6570069 05A51F6B
	v_dot2_f32_bf16 v107, v5, v27, 0                           // 00000039B388: CC1A406B 1A023705
	v_and_or_b32 v103, v91, 15, v103                           // 00000039B390: D6570067 059D1F5B
	v_lshrrev_b32_e32 v110, 20, v1                             // 00000039B398: 32DC0294
	v_and_b32_e32 v106, 48, v106                               // 00000039B39C: 36D4D4B0
	v_lshrrev_b32_e32 v111, 24, v1                             // 00000039B3A0: 32DE0298
	v_and_b32_e32 v109, 48, v109                               // 00000039B3A4: 36DADAB0
	v_dot2_f32_bf16 v107, v6, v77, v107                        // 00000039B3A8: CC1A406B 1DAE9B06
	v_cvt_f32_ubyte0_e32 v103, v103                            // 00000039B3B0: 7ECE2367
	v_and_or_b32 v106, v110, 15, v106                          // 00000039B3B4: D657006A 05A91F6E
	v_lshrrev_b32_e32 v1, 28, v1                               // 00000039B3BC: 3202029C
	v_and_or_b32 v109, v111, 15, v109                          // 00000039B3C0: D657006D 05B51F6F
	v_lshrrev_b32_e32 v110, 10, v81                            // 00000039B3C8: 32DCA28A
	v_dot2_f32_bf16 v107, v7, v9, v107                         // 00000039B3CC: CC1A406B 1DAE1307
	v_fma_mix_f32 v103, v103, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B3D4: CC206067 156AB567
	v_cvt_f32_ubyte0_e32 v106, v106                            // 00000039B3DC: 7ED4236A
	v_cvt_f32_ubyte0_e32 v109, v109                            // 00000039B3E0: 7EDA236D
	v_and_or_b32 v1, v110, 48, v1                              // 00000039B3E4: D6570001 0405616E
	v_dot2_f32_bf16 v107, v8, v26, v107                        // 00000039B3EC: CC1A406B 1DAE3508
	v_bfe_u32 v110, v103, 16, 1                                // 00000039B3F4: D610006E 02052167
	v_fma_mix_f32 v106, v106, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B3FC: CC20606A 156AB56A
	v_fma_mix_f32 v109, v109, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B404: CC20606D 156AB56D
	v_cvt_f32_ubyte0_e32 v1, v1                                // 00000039B40C: 7E022301
	v_dot2_f32_bf16 v107, v17, v108, v107                      // 00000039B410: CC1A406B 1DAED911
	v_add3_u32 v103, v103, v110, 0x7fff                        // 00000039B418: D6550067 03FEDD67 00007FFF
	v_bfe_u32 v110, v106, 16, 1                                // 00000039B424: D610006E 0205216A
	v_bfe_u32 v111, v109, 16, 1                                // 00000039B42C: D610006F 0205216D
	v_fma_mix_f32 v1, v1, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B434: CC206001 156AB501
	v_dot2_f32_bf16 v107, v18, v28, v107                       // 00000039B43C: CC1A406B 1DAE3912
	.long 0x7eb639e7                                           // 00000039B444: 7EB639E7
	v_add3_u32 v103, v106, v110, 0x7fff                        // 00000039B448: D6550067 03FEDD6A 00007FFF
	v_add3_u32 v106, v109, v111, 0x7fff                        // 00000039B454: D655006A 03FEDF6D 00007FFF
	v_bfe_u32 v109, v1, 16, 1                                  // 00000039B460: D610006D 02052101
	v_cvt_f32_ubyte0_e32 v105, v105                            // 00000039B468: 7ED22369
	v_dot2_f32_bf16 v107, v19, v85, v107                       // 00000039B46C: CC1A406B 1DAEAB13
	v_and_or_b32 v110, 0xffff0000, v103, v91                   // 00000039B474: D657006E 056ECEFF FFFF0000
	.long 0x7eb639ea                                           // 00000039B480: 7EB639EA
	v_add3_u32 v1, v1, v109, 0x7fff                            // 00000039B484: D6550001 03FEDB01 00007FFF
	v_fma_mix_f32 v92, v105, v92, v92 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B490: CC20605C 1572B969
	v_dot2_f32_bf16 v103, v20, v86, v107                       // 00000039B498: CC1A4067 1DAEAD14
	v_dot2_f32_bf16 v105, v29, v27, 0                          // 00000039B4A0: CC1A4069 1A02371D
	v_lshrrev_b32_e32 v107, 8, v2                              // 00000039B4A8: 32D60488
	v_and_or_b32 v1, 0xffff0000, v1, v91                       // 00000039B4AC: D6570001 056E02FF FFFF0000
	.long 0x7eb639d1                                           // 00000039B4B8: 7EB639D1
	v_bfe_u32 v106, v92, 16, 1                                 // 00000039B4BC: D610006A 0205215C
	v_dot2_f32_bf16 v103, v13, v93, v103                       // 00000039B4C4: CC1A4067 1D9EBB0D
	v_dot2_f32_bf16 v105, v30, v77, v105                       // 00000039B4CC: CC1A4069 1DA69B1E
	.long 0x7ed039e8                                           // 00000039B4D4: 7ED039E8
	v_and_b32_e32 v109, 48, v91                                // 00000039B4D8: 36DAB6B0
	v_add3_u32 v92, v92, v106, 0x7fff                          // 00000039B4DC: D655005C 03FED55C 00007FFF
	v_lshrrev_b32_e32 v106, 18, v81                            // 00000039B4E8: 32D4A292
	.long 0x7fd039db                                           // 00000039B4EC: 7FD039DB
	v_dot2_f32_bf16 v103, v14, v102, v103                      // 00000039B4F0: CC1A4067 1D9ECD0E
	v_dot2_f32_bf16 v105, v31, v9, v105                        // 00000039B4F8: CC1A4069 1DA6131F
	v_and_or_b32 v107, v107, 15, v109                          // 00000039B500: D657006B 05B51F6B
	v_lshrrev_b32_e32 v109, 12, v2                             // 00000039B508: 32DA048C
	v_and_b32_e32 v106, 48, v106                               // 00000039B50C: 36D4D4B0
	v_dot2_f32_bf16 v103, v15, v11, v103                       // 00000039B510: CC1A4067 1D9E170F
	v_and_or_b32 v92, 0xffff0000, v92, v104                    // 00000039B518: D657005C 05A2B8FF FFFF0000
	v_dot2_f32_bf16 v104, v32, v26, v105                       // 00000039B524: CC1A4068 1DA63520
	v_cvt_f32_ubyte0_e32 v105, v107                            // 00000039B52C: 7ED2236B
	v_and_or_b32 v106, v109, 15, v106                          // 00000039B530: D657006A 05A91F6D
	v_dot2_f32_bf16 v103, v16, v78, v103                       // 00000039B538: CC1A4067 1D9E9D10
	v_dot2_f32_bf16 v25, v74, v25, v94                         // 00000039B540: CC1A4019 1D7A334A
	v_dot2_f32_bf16 v94, v33, v108, v104                       // 00000039B548: CC1A405E 1DA2D921
	v_fma_mix_f32 v104, v105, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B550: CC206068 156AB569
	v_cvt_f32_ubyte0_e32 v105, v106                            // 00000039B558: 7ED2236A
	v_dot2_f32_bf16 v103, v21, v92, v103                       // 00000039B55C: CC1A4067 1D9EB915
	v_dot2_f32_bf16 v25, v75, v79, v25                         // 00000039B564: CC1A4019 1C669F4B
	v_dot2_f32_bf16 v79, v34, v28, v94                         // 00000039B56C: CC1A404F 1D7A3922
	v_bfe_u32 v94, v104, 16, 1                                 // 00000039B574: D610005E 02052168
	v_fma_mix_f32 v105, v105, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B57C: CC206069 156AB569
	v_dot2_f32_bf16 v103, v22, v83, v103                       // 00000039B584: CC1A4067 1D9EA716
	v_dot2_f32_bf16 v25, v76, v87, v25                         // 00000039B58C: CC1A4019 1C66AF4C
	v_dot2_f32_bf16 v79, v35, v85, v79                         // 00000039B594: CC1A404F 1D3EAB23
	v_add3_u32 v87, v104, v94, 0x7fff                          // 00000039B59C: D6550057 03FEBD68 00007FFF
	v_bfe_u32 v94, v105, 16, 1                                 // 00000039B5A8: D610005E 02052169
	v_dot2_f32_bf16 v104, v23, v88, v103                       // 00000039B5B0: CC1A4068 1D9EB117
	v_add_f32_e32 v103, 0, v25                                 // 00000039B5B8: 06CE3280
	v_dot2_f32_bf16 v25, v36, v86, v79                         // 00000039B5BC: CC1A4019 1D3EAD24
	.long 0x7eb639d7                                           // 00000039B5C4: 7EB639D7
	v_add3_u32 v79, v105, v94, 0x7fff                          // 00000039B5C8: D655004F 03FEBD69 00007FFF
	v_lshrrev_b32_e32 v94, 20, v81                             // 00000039B5D4: 32BCA294
	v_dot2_f32_bf16 v87, v24, v10, v104                        // 00000039B5D8: CC1A4057 1DA21518
	v_dot2_f32_bf16 v104, v45, v27, 0                          // 00000039B5E0: CC1A4068 1A02372D
	v_lshrrev_b32_e32 v106, 24, v81                            // 00000039B5E8: 32D4A298
	v_and_or_b32 v79, 0xffff0000, v79, v91                     // 00000039B5EC: D657004F 056E9EFF FFFF0000
	.long 0x7eb63982                                           // 00000039B5F8: 7EB63982
	v_and_b32_e32 v94, 48, v94                                 // 00000039B5FC: 36BCBCB0
	v_dot2_f32_bf16 v105, v46, v77, v104                       // 00000039B600: CC1A4069 1DA29B2E
	v_add_f32_e32 v104, 0, v87                                 // 00000039B608: 06D0AE80
	v_lshrrev_b32_e32 v87, 22, v81                             // 00000039B60C: 32AEA296
	v_lshrrev_b32_e32 v107, 20, v2                             // 00000039B610: 32D60494
	v_and_or_b32 v94, v91, 15, v94                             // 00000039B614: D657005E 05791F5B
	v_lshrrev_b32_e32 v109, 24, v2                             // 00000039B61C: 32DA0498
	v_and_b32_e32 v106, 48, v106                               // 00000039B620: 36D4D4B0
	v_and_b32_e32 v87, 48, v87                                 // 00000039B624: 36AEAEB0
	v_lshrrev_b32_e32 v111, 26, v81                            // 00000039B628: 32DEA29A
	v_cvt_f32_ubyte0_e32 v94, v94                              // 00000039B62C: 7EBC235E
	v_and_b32_e32 v112, 48, v82                                // 00000039B630: 36E0A4B0
	v_and_or_b32 v106, v109, 15, v106                          // 00000039B634: D657006A 05A91F6D
	v_and_or_b32 v87, v107, 15, v87                            // 00000039B63C: D6570057 055D1F6B
	v_lshlrev_b32_e32 v109, 4, v82                             // 00000039B644: 30DAA484
	v_fma_mix_f32 v94, v94, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B648: CC20605E 156AB55E
	v_lshrrev_b32_e32 v113, 2, v82                             // 00000039B650: 32E2A482
	v_cvt_f32_ubyte0_e32 v106, v106                            // 00000039B654: 7ED4236A
	v_cvt_f32_ubyte0_e32 v87, v87                              // 00000039B658: 7EAE2357
	v_dot2_f32_bf16 v105, v47, v9, v105                        // 00000039B65C: CC1A4069 1DA6132F
	v_bfe_u32 v107, v94, 16, 1                                 // 00000039B664: D610006B 0205215E
	v_dot2_f32_bf16 v27, v49, v27, 0                           // 00000039B66C: CC1A401B 1A023731
	v_fma_mix_f32 v106, v106, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B674: CC20606A 156AB56A
	v_fma_mix_f32 v87, v87, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B67C: CC206057 156AB557
	v_dot2_f32_bf16 v105, v48, v26, v105                       // 00000039B684: CC1A4069 1DA63530
	v_add3_u32 v94, v94, v107, 0x7fff                          // 00000039B68C: D655005E 03FED75E 00007FFF
	v_dot2_f32_bf16 v25, v37, v93, v25                         // 00000039B698: CC1A4019 1C66BB25
	v_dot2_f32_bf16 v27, v50, v77, v27                         // 00000039B6A0: CC1A401B 1C6E9B32
	v_bfe_u32 v107, v87, 16, 1                                 // 00000039B6A8: D610006B 02052157
	v_dot2_f32_bf16 v105, v53, v108, v105                      // 00000039B6B0: CC1A4069 1DA6D935
	.long 0x7eb639de                                           // 00000039B6B8: 7EB639DE
	v_bfe_u32 v94, v106, 16, 1                                 // 00000039B6BC: D610005E 0205216A
	v_lshrrev_b32_e32 v77, 8, v82                              // 00000039B6C4: 329AA488
	v_add3_u32 v87, v87, v107, 0x7fff                          // 00000039B6C8: D6550057 03FED757 00007FFF
	v_lshrrev_b32_e32 v107, 28, v2                             // 00000039B6D4: 32D6049C
	v_dot2_f32_bf16 v25, v38, v102, v25                        // 00000039B6D8: CC1A4019 1C66CD26
	v_add3_u32 v94, v106, v94, 0x7fff                          // 00000039B6E0: D655005E 03FEBD6A 00007FFF
	v_and_b32_e32 v106, 48, v109                               // 00000039B6EC: 36D4DAB0
	v_lshlrev_b32_e32 v109, 2, v82                             // 00000039B6F0: 30DAA482
	v_and_or_b32 v87, 0xffff0000, v87, v91                     // 00000039B6F4: D6570057 056EAEFF FFFF0000
	v_and_or_b32 v107, v111, 48, v107                          // 00000039B700: D657006B 05AD616F
	.long 0x7eb639de                                           // 00000039B708: 7EB639DE
	v_and_or_b32 v94, v3, 15, v106                             // 00000039B70C: D657005E 05A91F03
	v_lshrrev_b32_e32 v106, 4, v3                              // 00000039B714: 32D40684
	v_and_b32_e32 v109, 48, v109                               // 00000039B718: 36DADAB0
	v_lshrrev_b32_e32 v111, 8, v3                              // 00000039B71C: 32DE0688
	v_cvt_f32_ubyte0_e32 v107, v107                            // 00000039B720: 7ED6236B
	v_cvt_f32_ubyte0_e32 v94, v94                              // 00000039B724: 7EBC235E
	v_dot2_f32_bf16 v105, v54, v28, v105                       // 00000039B728: CC1A4069 1DA63936
	v_and_or_b32 v106, v106, 15, v109                          // 00000039B730: D657006A 05B51F6A
	v_and_or_b32 v109, v111, 15, v112                          // 00000039B738: D657006D 05C11F6F
	v_lshrrev_b32_e32 v111, 12, v3                             // 00000039B740: 32DE068C
	v_and_b32_e32 v112, 48, v113                               // 00000039B744: 36E0E2B0
	v_fma_mix_f32 v107, v107, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B748: CC20606B 156AB56B
	v_fma_mix_f32 v94, v94, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B750: CC20605E 156AB55E
	v_cvt_f32_ubyte0_e32 v106, v106                            // 00000039B758: 7ED4236A
	v_cvt_f32_ubyte0_e32 v109, v109                            // 00000039B75C: 7EDA236D
	v_and_or_b32 v111, v111, 15, v112                          // 00000039B760: D657006F 05C11F6F
	v_bfe_u32 v112, v107, 16, 1                                // 00000039B768: D6100070 0205216B
	v_bfe_u32 v113, v94, 16, 1                                 // 00000039B770: D6100071 0205215E
	v_fma_mix_f32 v106, v106, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B778: CC20606A 156AB56A
	v_fma_mix_f32 v109, v109, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B780: CC20606D 156AB56D
	v_cvt_f32_ubyte0_e32 v111, v111                            // 00000039B788: 7EDE236F
	v_add3_u32 v107, v107, v112, 0x7fff                        // 00000039B78C: D655006B 03FEE16B 00007FFF
	v_add3_u32 v94, v94, v113, 0x7fff                          // 00000039B798: D655005E 03FEE35E 00007FFF
	v_bfe_u32 v112, v106, 16, 1                                // 00000039B7A4: D6100070 0205216A
	v_bfe_u32 v113, v109, 16, 1                                // 00000039B7AC: D6100071 0205216D
	v_fma_mix_f32 v111, v111, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B7B4: CC20606F 156AB56F
	v_and_or_b32 v107, 0xffff0000, v107, v91                   // 00000039B7BC: D657006B 056ED6FF FFFF0000
	.long 0x7eb639de                                           // 00000039B7C8: 7EB639DE
	v_add3_u32 v94, v106, v112, 0x7fff                         // 00000039B7CC: D655005E 03FEE16A 00007FFF
	v_add3_u32 v106, v109, v113, 0x7fff                        // 00000039B7D8: D655006A 03FEE36D 00007FFF
	v_bfe_u32 v109, v111, 16, 1                                // 00000039B7E4: D610006D 0205216F
	v_lshrrev_b32_e32 v112, 20, v3                             // 00000039B7EC: 32E00694
	v_lshrrev_b32_e32 v113, 24, v3                             // 00000039B7F0: 32E20698
	v_and_or_b32 v94, 0xffff0000, v94, v91                     // 00000039B7F4: D657005E 056EBCFF FFFF0000
	.long 0x7eb639ea                                           // 00000039B800: 7EB639EA
	v_add3_u32 v106, v111, v109, 0x7fff                        // 00000039B804: D655006A 03FEDB6F 00007FFF
	v_lshrrev_b32_e32 v109, 4, v82                             // 00000039B810: 32DAA484
	v_lshrrev_b32_e32 v111, 6, v82                             // 00000039B814: 32DEA486
	v_and_b32_e32 v77, 48, v77                                 // 00000039B818: 369A9AB0
	v_dot2_f32_bf16 v25, v39, v11, v25                         // 00000039B81C: CC1A4019 1C661727
	v_and_or_b32 v106, 0xffff0000, v106, v91                   // 00000039B824: D657006A 056ED4FF FFFF0000
	.long 0x7eb63983                                           // 00000039B830: 7EB63983
	v_and_b32_e32 v109, 48, v109                               // 00000039B834: 36DADAB0
	v_and_b32_e32 v111, 48, v111                               // 00000039B838: 36DEDEB0
	v_dot2_f32_bf16 v105, v55, v85, v105                       // 00000039B83C: CC1A4069 1DA6AB37
	v_dot2_f32_bf16 v9, v51, v9, v27                           // 00000039B844: CC1A4009 1C6E1333
	v_and_or_b32 v77, v113, 15, v77                            // 00000039B84C: D657004D 05351F71
	v_and_or_b32 v109, v91, 15, v109                           // 00000039B854: D657006D 05B51F5B
	v_and_or_b32 v27, v112, 15, v111                           // 00000039B85C: D657001B 05BD1F70
	v_lshrrev_b32_e32 v3, 28, v3                               // 00000039B864: 3206069C
	v_lshrrev_b32_e32 v111, 10, v82                            // 00000039B868: 32DEA48A
	v_dot2_f32_bf16 v25, v40, v78, v25                         // 00000039B86C: CC1A4019 1C669D28
	v_cvt_f32_ubyte0_e32 v109, v109                            // 00000039B874: 7EDA236D
	v_dot2_f32_bf16 v105, v56, v86, v105                       // 00000039B878: CC1A4069 1DA6AD38
	v_dot2_f32_bf16 v9, v52, v26, v9                           // 00000039B880: CC1A4009 1C263534
	v_cvt_f32_ubyte0_e32 v27, v27                              // 00000039B888: 7E36231B
	v_cvt_f32_ubyte0_e32 v77, v77                              // 00000039B88C: 7E9A234D
	v_fma_mix_f32 v26, v109, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B890: CC20601A 156AB56D
	v_and_or_b32 v3, v111, 48, v3                              // 00000039B898: D6570003 040D616F
	v_dot2_f32_bf16 v25, v41, v92, v25                         // 00000039B8A0: CC1A4019 1C66B929
	v_dot2_f32_bf16 v105, v57, v93, v105                       // 00000039B8A8: CC1A4069 1DA6BB39
	v_dot2_f32_bf16 v9, v61, v108, v9                          // 00000039B8B0: CC1A4009 1C26D93D
	v_bfe_u32 v108, v26, 16, 1                                 // 00000039B8B8: D610006C 0205211A
	v_fma_mix_f32 v27, v27, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B8C0: CC20601B 156AB51B
	v_fma_mix_f32 v77, v77, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B8C8: CC20604D 156AB54D
	v_cvt_f32_ubyte0_e32 v3, v3                                // 00000039B8D0: 7E062303
	v_dot2_f32_bf16 v25, v42, v83, v25                         // 00000039B8D4: CC1A4019 1C66A72A
	v_dot2_f32_bf16 v105, v58, v102, v105                      // 00000039B8DC: CC1A4069 1DA6CD3A
	v_dot2_f32_bf16 v9, v62, v28, v9                           // 00000039B8E4: CC1A4009 1C26393E
	v_add3_u32 v26, v26, v108, 0x7fff                          // 00000039B8EC: D655001A 03FED91A 00007FFF
	v_bfe_u32 v28, v27, 16, 1                                  // 00000039B8F8: D610001C 0205211B
	v_bfe_u32 v108, v77, 16, 1                                 // 00000039B900: D610006C 0205214D
	v_fma_mix_f32 v3, v3, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039B908: CC206003 156AB503
	v_dot2_f32_bf16 v25, v43, v88, v25                         // 00000039B910: CC1A4019 1C66B12B
	v_dot2_f32_bf16 v105, v59, v11, v105                       // 00000039B918: CC1A4069 1DA6173B
	v_dot2_f32_bf16 v9, v63, v85, v9                           // 00000039B920: CC1A4009 1C26AB3F
	.long 0x7eb6399a                                           // 00000039B928: 7EB6399A
	v_add3_u32 v26, v27, v28, 0x7fff                           // 00000039B92C: D655001A 03FE391B 00007FFF
	v_add3_u32 v27, v77, v108, 0x7fff                          // 00000039B938: D655001B 03FED94D 00007FFF
	v_bfe_u32 v28, v3, 16, 1                                   // 00000039B944: D610001C 02052103
	v_dot2_f32_bf16 v25, v44, v10, v25                         // 00000039B94C: CC1A4019 1C66152C
	v_dot2_f32_bf16 v77, v60, v78, v105                        // 00000039B954: CC1A404D 1DA69D3C
	v_dot2_f32_bf16 v9, v64, v86, v9                           // 00000039B95C: CC1A4009 1C26AD40
	v_and_or_b32 v26, 0xffff0000, v26, v91                     // 00000039B964: D657001A 056E34FF FFFF0000
	.long 0x7eb6399b                                           // 00000039B970: 7EB6399B
	v_add3_u32 v3, v3, v28, 0x7fff                             // 00000039B974: D6550003 03FE3903 00007FFF
	v_add_f32_e32 v105, 0, v25                                 // 00000039B980: 06D23280
	v_dot2_f32_bf16 v25, v69, v92, v77                         // 00000039B984: CC1A4019 1D36B945
	v_dot2_f32_bf16 v9, v65, v93, v9                           // 00000039B98C: CC1A4009 1C26BB41
	v_lshrrev_b32_e32 v27, 12, v81                             // 00000039B994: 3236A28C
	v_and_or_b32 v3, 0xffff0000, v3, v91                       // 00000039B998: D6570003 056E06FF FFFF0000
	.long 0x7eb639d2                                           // 00000039B9A4: 7EB639D2
	v_dot2_f32_bf16 v25, v70, v83, v25                         // 00000039B9A8: CC1A4019 1C66A746
	v_dot2_f32_bf16 v9, v66, v102, v9                          // 00000039B9B0: CC1A4009 1C26CD42
	v_and_b32_e32 v27, 48, v27                                 // 00000039B9B8: 363636B0
	v_lshrrev_b32_e32 v28, 8, v4                               // 00000039B9BC: 32380888
	v_and_b32_e32 v77, 48, v91                                 // 00000039B9C0: 369AB6B0
	v_lshrrev_b32_e32 v85, 18, v82                             // 00000039B9C4: 32AAA492
	v_dot2_f32_bf16 v25, v71, v88, v25                         // 00000039B9C8: CC1A4019 1C66B147
	v_dot2_f32_bf16 v9, v67, v11, v9                           // 00000039B9D0: CC1A4009 1C261743
	v_and_or_b32 v11, v2, 15, v27                              // 00000039B9D8: D657000B 046D1F02
	v_and_or_b32 v27, v28, 15, v77                             // 00000039B9E0: D657001B 05351F1C
	v_lshrrev_b32_e32 v28, 12, v4                              // 00000039B9E8: 3238088C
	v_and_b32_e32 v77, 48, v85                                 // 00000039B9EC: 369AAAB0
	v_dot2_f32_bf16 v25, v72, v10, v25                         // 00000039B9F0: CC1A4019 1C661548
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000039B9F8: 7E16230B
	v_cvt_f32_ubyte0_e32 v27, v27                              // 00000039B9FC: 7E36231B
	v_dot2_f32_bf16 v9, v68, v78, v9                           // 00000039BA00: CC1A4009 1C269D44
	v_and_or_b32 v28, v28, 15, v77                             // 00000039BA08: D657001C 05351F1C
	v_add_f32_e32 v102, 0, v25                                 // 00000039BA10: 06CC3280
	v_fma_mix_f32 v11, v11, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039BA14: CC20600B 156AB50B
	v_fma_mix_f32 v25, v27, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039BA1C: CC206019 156AB51B
	v_lshrrev_b32_e32 v2, 4, v2                                // 00000039BA24: 32040484
	v_cvt_f32_ubyte0_e32 v27, v28                              // 00000039BA28: 7E36231C
	v_lshrrev_b32_e32 v28, 14, v81                             // 00000039BA2C: 3238A28E
	v_bfe_u32 v77, v11, 16, 1                                  // 00000039BA30: D610004D 0205210B
	v_bfe_u32 v78, v25, 16, 1                                  // 00000039BA38: D610004E 02052119
	v_dot2_f32_bf16 v9, v73, v92, v9                           // 00000039BA40: CC1A4009 1C26B949
	v_fma_mix_f32 v27, v27, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039BA48: CC20601B 156AB51B
	v_and_b32_e32 v28, 48, v28                                 // 00000039BA50: 363838B0
	v_add3_u32 v11, v11, v77, 0x7fff                           // 00000039BA54: D655000B 03FE9B0B 00007FFF
	v_add3_u32 v25, v25, v78, 0x7fff                           // 00000039BA60: D6550019 03FE9D19 00007FFF
	v_lshrrev_b32_e32 v78, 14, v82                             // 00000039BA6C: 329CA48E
	v_bfe_u32 v77, v27, 16, 1                                  // 00000039BA70: D610004D 0205211B
	v_and_or_b32 v2, v2, 15, v28                               // 00000039BA78: D6570002 04711F02
	v_lshrrev_b32_e32 v28, 20, v82                             // 00000039BA80: 3238A494
	.long 0x7eb63999                                           // 00000039BA84: 7EB63999
	v_dot2_f32_bf16 v9, v74, v83, v9                           // 00000039BA88: CC1A4009 1C26A74A
	v_add3_u32 v25, v27, v77, 0x7fff                           // 00000039BA90: D6550019 03FE9B1B 00007FFF
	v_lshrrev_b32_e32 v27, 12, v82                             // 00000039BA9C: 3236A48C
	v_and_b32_e32 v77, 15, v4                                  // 00000039BAA0: 369A088F
	v_and_b32_e32 v28, 48, v28                                 // 00000039BAA4: 363838B0
	v_lshrrev_b32_e32 v81, 4, v4                               // 00000039BAA8: 32A20884
	v_and_or_b32 v25, 0xffff0000, v25, v91                     // 00000039BAAC: D6570019 056E32FF FFFF0000
	.long 0x7eb63984                                           // 00000039BAB8: 7EB63984
	v_and_or_b32 v27, v27, 48, v77                             // 00000039BABC: D657001B 0535611B
	v_lshrrev_b32_e32 v77, 22, v82                             // 00000039BAC4: 329AA496
	v_and_b32_e32 v78, 48, v78                                 // 00000039BAC8: 369C9CB0
	v_lshrrev_b32_e32 v83, 20, v4                              // 00000039BACC: 32A60894
	v_and_or_b32 v28, v91, 15, v28                             // 00000039BAD0: D657001C 04711F5B
	v_cvt_f32_ubyte0_e32 v27, v27                              // 00000039BAD8: 7E36231B
	v_and_b32_e32 v77, 48, v77                                 // 00000039BADC: 369A9AB0
	v_cvt_f32_ubyte0_e32 v2, v2                                // 00000039BAE0: 7E042302
	v_and_or_b32 v78, v81, 15, v78                             // 00000039BAE4: D657004E 05391F51
	v_cvt_f32_ubyte0_e32 v28, v28                              // 00000039BAEC: 7E38231C
	v_fma_mix_f32 v27, v27, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039BAF0: CC20601B 156AB51B
	v_and_or_b32 v77, v83, 15, v77                             // 00000039BAF8: D657004D 05351F53
	v_fma_mix_f32 v2, v2, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039BB00: CC206002 156AB502
	v_cvt_f32_ubyte0_e32 v78, v78                              // 00000039BB08: 7E9C234E
	v_fma_mix_f32 v28, v28, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039BB0C: CC20601C 156AB51C
	v_bfe_u32 v81, v27, 16, 1                                  // 00000039BB14: D6100051 0205211B
	v_cvt_f32_ubyte0_e32 v77, v77                              // 00000039BB1C: 7E9A234D
	v_bfe_u32 v83, v2, 16, 1                                   // 00000039BB20: D6100053 02052102
	v_fma_mix_f32 v78, v78, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039BB28: CC20604E 156AB54E
	v_bfe_u32 v85, v28, 16, 1                                  // 00000039BB30: D6100055 0205211C
	v_dot2_f32_bf16 v5, v5, v12, 0                             // 00000039BB38: CC1A4005 1A021905
	v_fma_mix_f32 v77, v77, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039BB40: CC20604D 156AB54D
	v_dot2_f32_bf16 v29, v29, v12, 0                           // 00000039BB48: CC1A401D 1A02191D
	v_dot2_f32_bf16 v45, v45, v12, 0                           // 00000039BB50: CC1A402D 1A02192D
	v_dot2_f32_bf16 v12, v49, v12, 0                           // 00000039BB58: CC1A400C 1A021931
	v_add3_u32 v27, v27, v81, 0x7fff                           // 00000039BB60: D655001B 03FEA31B 00007FFF
	v_add3_u32 v2, v2, v83, 0x7fff                             // 00000039BB6C: D6550002 03FEA702 00007FFF
	v_bfe_u32 v81, v78, 16, 1                                  // 00000039BB78: D6100051 0205214E
	v_add3_u32 v28, v28, v85, 0x7fff                           // 00000039BB80: D655001C 03FEAB1C 00007FFF
	v_bfe_u32 v83, v77, 16, 1                                  // 00000039BB8C: D6100053 0205214D
	v_dot2_f32_bf16 v5, v6, v84, v5                            // 00000039BB94: CC1A4005 1C16A906
	v_dot2_f32_bf16 v6, v30, v84, v29                          // 00000039BB9C: CC1A4006 1C76A91E
	v_dot2_f32_bf16 v29, v46, v84, v45                         // 00000039BBA4: CC1A401D 1CB6A92E
	v_dot2_f32_bf16 v12, v50, v84, v12                         // 00000039BBAC: CC1A400C 1C32A932
	.long 0x7e16398b                                           // 00000039BBB4: 7E16398B
	.long 0x7f1639db                                           // 00000039BBB8: 7F1639DB
	.long 0x7e36399b                                           // 00000039BBBC: 7E36399B
	.long 0x7f3639db                                           // 00000039BBC0: 7F3639DB
	v_add3_u32 v78, v78, v81, 0x7fff                           // 00000039BBC4: D655004E 03FEA34E 00007FFF
	.long 0x7eb6399c                                           // 00000039BBD0: 7EB6399C
	v_add3_u32 v28, v77, v83, 0x7fff                           // 00000039BBD4: D655001C 03FEA74D 00007FFF
	v_lshrrev_b32_e32 v77, 24, v82                             // 00000039BBE0: 329AA498
	v_dot2_f32_bf16 v5, v7, v110, v5                           // 00000039BBE4: CC1A4005 1C16DD07
	v_dot2_f32_bf16 v6, v31, v110, v6                          // 00000039BBEC: CC1A4006 1C1ADD1F
	v_dot2_f32_bf16 v7, v47, v110, v29                         // 00000039BBF4: CC1A4007 1C76DD2F
	v_dot2_f32_bf16 v12, v51, v110, v12                        // 00000039BBFC: CC1A400C 1C32DD33
	v_and_or_b32 v2, 0xffff0000, v2, v11                       // 00000039BC04: D6570002 042E04FF FFFF0000
	v_and_or_b32 v11, 0xffff0000, v78, v27                     // 00000039BC10: D657000B 046E9CFF FFFF0000
	v_and_or_b32 v27, 0xffff0000, v28, v91                     // 00000039BC1C: D657001B 056E38FF FFFF0000
	v_lshrrev_b32_e32 v28, 24, v4                              // 00000039BC28: 32380898
	v_and_b32_e32 v77, 48, v77                                 // 00000039BC2C: 369A9AB0
	v_dot2_f32_bf16 v5, v8, v1, v5                             // 00000039BC30: CC1A4005 1C160308
	v_dot2_f32_bf16 v6, v32, v1, v6                            // 00000039BC38: CC1A4006 1C1A0320
	v_dot2_f32_bf16 v7, v48, v1, v7                            // 00000039BC40: CC1A4007 1C1E0330
	v_dot2_f32_bf16 v1, v52, v1, v12                           // 00000039BC48: CC1A4001 1C320334
	v_and_or_b32 v28, v28, 15, v77                             // 00000039BC50: D657001C 05351F1C
	v_dot2_f32_bf16 v5, v17, v2, v5                            // 00000039BC58: CC1A4005 1C160511
	v_dot2_f32_bf16 v6, v33, v2, v6                            // 00000039BC60: CC1A4006 1C1A0521
	v_dot2_f32_bf16 v7, v53, v2, v7                            // 00000039BC68: CC1A4007 1C1E0535
	v_dot2_f32_bf16 v1, v61, v2, v1                            // 00000039BC70: CC1A4001 1C06053D
	v_cvt_f32_ubyte0_e32 v2, v28                               // 00000039BC78: 7E04231C
	v_dot2_f32_bf16 v5, v18, v79, v5                           // 00000039BC7C: CC1A4005 1C169F12
	v_dot2_f32_bf16 v6, v34, v79, v6                           // 00000039BC84: CC1A4006 1C1A9F22
	v_dot2_f32_bf16 v7, v54, v79, v7                           // 00000039BC8C: CC1A4007 1C1E9F36
	v_dot2_f32_bf16 v1, v62, v79, v1                           // 00000039BC94: CC1A4001 1C069F3E
	v_fma_mix_f32 v2, v2, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039BC9C: CC206002 156AB502
	v_dot2_f32_bf16 v5, v19, v87, v5                           // 00000039BCA4: CC1A4005 1C16AF13
	v_dot2_f32_bf16 v6, v35, v87, v6                           // 00000039BCAC: CC1A4006 1C1AAF23
	v_dot2_f32_bf16 v7, v55, v87, v7                           // 00000039BCB4: CC1A4007 1C1EAF37
	v_dot2_f32_bf16 v1, v63, v87, v1                           // 00000039BCBC: CC1A4001 1C06AF3F
	v_bfe_u32 v8, v2, 16, 1                                    // 00000039BCC4: D6100008 02052102
	v_dot2_f32_bf16 v5, v20, v107, v5                          // 00000039BCCC: CC1A4005 1C16D714
	v_dot2_f32_bf16 v6, v36, v107, v6                          // 00000039BCD4: CC1A4006 1C1AD724
	v_dot2_f32_bf16 v7, v56, v107, v7                          // 00000039BCDC: CC1A4007 1C1ED738
	v_dot2_f32_bf16 v1, v64, v107, v1                          // 00000039BCE4: CC1A4001 1C06D740
	v_lshrrev_b32_e32 v4, 28, v4                               // 00000039BCEC: 3208089C
	v_lshrrev_b32_e32 v29, 26, v82                             // 00000039BCF0: 323AA49A
	v_add3_u32 v2, v2, v8, 0x7fff                              // 00000039BCF4: D6550002 03FE1102 00007FFF
	v_dot2_f32_bf16 v5, v13, v94, v5                           // 00000039BD00: CC1A4005 1C16BD0D
	v_dot2_f32_bf16 v6, v37, v94, v6                           // 00000039BD08: CC1A4006 1C1ABD25
	v_dot2_f32_bf16 v7, v57, v94, v7                           // 00000039BD10: CC1A4007 1C1EBD39
	v_dot2_f32_bf16 v1, v65, v94, v1                           // 00000039BD18: CC1A4001 1C06BD41
	v_and_or_b32 v4, v29, 48, v4                               // 00000039BD20: D6570004 0411611D
	.long 0x7eb63982                                           // 00000039BD28: 7EB63982
	v_dot2_f32_bf16 v2, v14, v106, v5                          // 00000039BD2C: CC1A4002 1C16D50E
	v_dot2_f32_bf16 v5, v38, v106, v6                          // 00000039BD34: CC1A4005 1C1AD526
	v_dot2_f32_bf16 v6, v58, v106, v7                          // 00000039BD3C: CC1A4006 1C1ED53A
	v_dot2_f32_bf16 v1, v66, v106, v1                          // 00000039BD44: CC1A4001 1C06D542
	v_cvt_f32_ubyte0_e32 v4, v4                                // 00000039BD4C: 7E082304
	v_dot2_f32_bf16 v2, v15, v26, v2                           // 00000039BD50: CC1A4002 1C0A350F
	v_dot2_f32_bf16 v5, v39, v26, v5                           // 00000039BD58: CC1A4005 1C163527
	v_dot2_f32_bf16 v6, v59, v26, v6                           // 00000039BD60: CC1A4006 1C1A353B
	v_dot2_f32_bf16 v1, v67, v26, v1                           // 00000039BD68: CC1A4001 1C063543
	v_fma_mix_f32 v4, v4, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039BD70: CC206004 156AB504
	v_dot2_f32_bf16 v2, v16, v3, v2                            // 00000039BD78: CC1A4002 1C0A0710
	v_dot2_f32_bf16 v5, v40, v3, v5                            // 00000039BD80: CC1A4005 1C160728
	v_dot2_f32_bf16 v6, v60, v3, v6                            // 00000039BD88: CC1A4006 1C1A073C
	v_dot2_f32_bf16 v1, v68, v3, v1                            // 00000039BD90: CC1A4001 1C060744
	v_bfe_u32 v3, v4, 16, 1                                    // 00000039BD98: D6100003 02052104
	v_dot2_f32_bf16 v2, v21, v11, v2                           // 00000039BDA0: CC1A4002 1C0A1715
	v_dot2_f32_bf16 v5, v41, v11, v5                           // 00000039BDA8: CC1A4005 1C161729
	v_dot2_f32_bf16 v6, v69, v11, v6                           // 00000039BDB0: CC1A4006 1C1A1745
	v_dot2_f32_bf16 v1, v73, v11, v1                           // 00000039BDB8: CC1A4001 1C061749
	v_add3_u32 v3, v4, v3, 0x7fff                              // 00000039BDC0: D6550003 03FE0704 00007FFF
	v_dot2_f32_bf16 v2, v22, v25, v2                           // 00000039BDCC: CC1A4002 1C0A3316
	v_dot2_f32_bf16 v4, v42, v25, v5                           // 00000039BDD4: CC1A4004 1C16332A
	v_dot2_f32_bf16 v5, v70, v25, v6                           // 00000039BDDC: CC1A4005 1C1A3346
	v_dot2_f32_bf16 v1, v74, v25, v1                           // 00000039BDE4: CC1A4001 1C06334A
	v_dot2_f32_bf16 v9, v75, v88, v9                           // 00000039BDEC: CC1A4009 1C26B14B
	v_and_or_b32 v3, 0xffff0000, v3, v91                       // 00000039BDF4: D6570003 056E06FF FFFF0000
	v_dot2_f32_bf16 v2, v23, v27, v2                           // 00000039BE00: CC1A4002 1C0A3717
	v_dot2_f32_bf16 v4, v43, v27, v4                           // 00000039BE08: CC1A4004 1C12372B
	v_dot2_f32_bf16 v5, v71, v27, v5                           // 00000039BE10: CC1A4005 1C163747
	v_dot2_f32_bf16 v1, v75, v27, v1                           // 00000039BE18: CC1A4001 1C06374B
	v_dot2_f32_bf16 v6, v76, v10, v9                           // 00000039BE20: CC1A4006 1C26154C
	v_dot2_f32_bf16 v2, v24, v3, v2                            // 00000039BE28: CC1A4002 1C0A0718
	v_dot2_f32_bf16 v4, v44, v3, v4                            // 00000039BE30: CC1A4004 1C12072C
	v_dot2_f32_bf16 v7, v72, v3, v5                            // 00000039BE38: CC1A4007 1C160748
	v_dot2_f32_bf16 v1, v76, v3, v1                            // 00000039BE40: CC1A4001 1C06074C
	v_dual_add_f32 v97, 0, v97 :: v_dual_add_f32 v98, 0, v98   // 00000039BE48: C908C280 6162C480
	v_add_f32_e32 v5, 0, v6                                    // 00000039BE50: 060A0C80
	v_dual_add_f32 v8, 0, v2 :: v_dual_add_f32 v13, 0, v4      // 00000039BE54: C9080480 080C0880
	s_delay_alu instid0(VALU_DEP_4)                            // 00000039BE5C: BF870004
	v_dual_add_f32 v7, 0, v7 :: v_dual_add_f32 v6, 0, v1       // 00000039BE60: C9080E80 07060280
	s_or_b32 exec_lo, exec_lo, s4                              // 00000039BE68: 8C7E047E
	.long 0xd71f0001                                           // 00000039BE6C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000039BE70: 020100C1
	s_mov_b32 s6, 0                                            // 00000039BE74: BE860080
	s_mov_b32 s7, exec_lo                                      // 00000039BE78: BE87007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000039BE7C: BF8701B1
	v_xor_b32_e32 v2, 8, v1                                    // 00000039BE80: 3A040288
	v_xor_b32_e32 v3, 4, v1                                    // 00000039BE84: 3A060284
	v_xor_b32_e32 v23, 2, v1                                   // 00000039BE88: 3A2E0282
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000039BE8C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000039BE90: 02040501
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000039BE94: BF870134
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 00000039BE98: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 00000039BE9C: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v23                           // 00000039BEA0: 7C982EA0
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000039BEA4: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000039BEA8: 30040482
	ds_bpermute_b32 v9, v2, v96                                // 00000039BEAC: DACC0000 09006002
	s_waitcnt lgkmcnt(0)                                       // 00000039BEB4: BF89FC07
	v_add_f32_e32 v9, v96, v9                                  // 00000039BEB8: 06121360
	ds_bpermute_b32 v4, v2, v95                                // 00000039BEBC: DACC0000 04005F02
	ds_bpermute_b32 v10, v2, v97                               // 00000039BEC4: DACC0000 0A006102
	ds_bpermute_b32 v11, v2, v98                               // 00000039BECC: DACC0000 0B006202
	ds_bpermute_b32 v16, v2, v103                              // 00000039BED4: DACC0000 10006702
	ds_bpermute_b32 v20, v2, v5                                // 00000039BEDC: DACC0000 14000502
	ds_bpermute_b32 v17, v2, v104                              // 00000039BEE4: DACC0000 11006802
	ds_bpermute_b32 v21, v2, v8                                // 00000039BEEC: DACC0000 15000802
	ds_bpermute_b32 v22, v2, v13                               // 00000039BEF4: DACC0000 16000D02
	ds_bpermute_b32 v12, v2, v99                               // 00000039BEFC: DACC0000 0C006302
	ds_bpermute_b32 v14, v2, v100                              // 00000039BF04: DACC0000 0E006402
	ds_bpermute_b32 v15, v2, v101                              // 00000039BF0C: DACC0000 0F006502
	ds_bpermute_b32 v18, v2, v105                              // 00000039BF14: DACC0000 12006902
	ds_bpermute_b32 v19, v2, v102                              // 00000039BF1C: DACC0000 13006602
	ds_bpermute_b32 v24, v2, v7                                // 00000039BF24: DACC0000 18000702
	ds_bpermute_b32 v2, v2, v6                                 // 00000039BF2C: DACC0000 02000602
	s_waitcnt lgkmcnt(14)                                      // 00000039BF34: BF89FCE7
	v_add_f32_e32 v4, v95, v4                                  // 00000039BF38: 0608095F
	s_waitcnt lgkmcnt(12)                                      // 00000039BF3C: BF89FCC7
	v_dual_add_f32 v10, v97, v10 :: v_dual_add_f32 v11, v98, v11// 00000039BF40: C9081561 0A0A1762
	s_waitcnt lgkmcnt(11)                                      // 00000039BF48: BF89FCB7
	v_add_f32_e32 v16, v103, v16                               // 00000039BF4C: 06202167
	s_waitcnt lgkmcnt(10)                                      // 00000039BF50: BF89FCA7
	v_add_f32_e32 v5, v5, v20                                  // 00000039BF54: 060A2905
	ds_bpermute_b32 v20, v3, v4                                // 00000039BF58: DACC0000 14000403
	s_waitcnt lgkmcnt(10)                                      // 00000039BF60: BF89FCA7
	v_add_f32_e32 v17, v104, v17                               // 00000039BF64: 06222368
	ds_bpermute_b32 v25, v3, v11                               // 00000039BF68: DACC0000 19000B03
	s_waitcnt lgkmcnt(9)                                       // 00000039BF70: BF89FC97
	v_dual_add_f32 v8, v8, v21 :: v_dual_add_f32 v13, v13, v22 // 00000039BF74: C9082B08 080C2D0D
	ds_bpermute_b32 v21, v3, v9                                // 00000039BF7C: DACC0000 15000903
	ds_bpermute_b32 v22, v3, v10                               // 00000039BF84: DACC0000 16000A03
	ds_bpermute_b32 v29, v3, v16                               // 00000039BF8C: DACC0000 1D001003
	ds_bpermute_b32 v32, v3, v5                                // 00000039BF94: DACC0000 20000503
	s_waitcnt lgkmcnt(6)                                       // 00000039BF9C: BF89FC67
	v_add_f32_e32 v2, v6, v2                                   // 00000039BFA0: 06040506
	v_cndmask_b32_e32 v6, v1, v23, vcc_lo                      // 00000039BFA4: 020C2F01
	v_dual_add_f32 v12, v99, v12 :: v_dual_add_f32 v15, v101, v15// 00000039BFA8: C9081963 0C0E1F65
	v_dual_add_f32 v14, v100, v14 :: v_dual_add_f32 v19, v102, v19// 00000039BFB0: C9081D64 0E122766
	v_dual_add_f32 v18, v105, v18 :: v_dual_add_f32 v7, v7, v24// 00000039BFB8: C9082569 12063107
	ds_bpermute_b32 v26, v3, v12                               // 00000039BFC0: DACC0000 1A000C03
	ds_bpermute_b32 v27, v3, v14                               // 00000039BFC8: DACC0000 1B000E03
	ds_bpermute_b32 v28, v3, v15                               // 00000039BFD0: DACC0000 1C000F03
	s_waitcnt lgkmcnt(8)                                       // 00000039BFD8: BF89FC87
	v_add_f32_e32 v4, v4, v20                                  // 00000039BFDC: 06082904
	ds_bpermute_b32 v30, v3, v17                               // 00000039BFE0: DACC0000 1E001103
	s_waitcnt lgkmcnt(8)                                       // 00000039BFE8: BF89FC87
	v_dual_add_f32 v11, v11, v25 :: v_dual_lshlrev_b32 v6, 2, v6// 00000039BFEC: C922330B 0B060C82
	ds_bpermute_b32 v24, v3, v18                               // 00000039BFF4: DACC0000 18001203
	ds_bpermute_b32 v31, v3, v19                               // 00000039BFFC: DACC0000 1F001303
	ds_bpermute_b32 v33, v3, v8                                // 00000039C004: DACC0000 21000803
	ds_bpermute_b32 v23, v3, v13                               // 00000039C00C: DACC0000 17000D03
	ds_bpermute_b32 v34, v3, v7                                // 00000039C014: DACC0000 22000703
	s_waitcnt lgkmcnt(12)                                      // 00000039C01C: BF89FCC7
	v_add_f32_e32 v9, v9, v21                                  // 00000039C020: 06122B09
	ds_bpermute_b32 v3, v3, v2                                 // 00000039C024: DACC0000 03000203
	s_waitcnt lgkmcnt(11)                                      // 00000039C02C: BF89FCB7
	v_dual_add_f32 v10, v10, v22 :: v_dual_add_f32 v21, v16, v29// 00000039C030: C9082D0A 0A143B10
	s_waitcnt lgkmcnt(10)                                      // 00000039C038: BF89FCA7
	v_add_f32_e32 v22, v5, v32                                 // 00000039C03C: 062C4105
	ds_bpermute_b32 v5, v6, v4                                 // 00000039C040: DACC0000 05000406
	s_waitcnt lgkmcnt(10)                                      // 00000039C048: BF89FCA7
	v_add_f32_e32 v12, v12, v26                                // 00000039C04C: 0618350C
	s_waitcnt lgkmcnt(9)                                       // 00000039C050: BF89FC97
	v_add_f32_e32 v14, v14, v27                                // 00000039C054: 061C370E
	s_waitcnt lgkmcnt(7)                                       // 00000039C058: BF89FC77
	v_dual_add_f32 v20, v15, v28 :: v_dual_add_f32 v17, v17, v30// 00000039C05C: C908390F 14103D11
	s_waitcnt lgkmcnt(5)                                       // 00000039C064: BF89FC57
	v_dual_add_f32 v18, v18, v24 :: v_dual_add_f32 v19, v19, v31// 00000039C068: C9083112 12123F13
	s_waitcnt lgkmcnt(3)                                       // 00000039C070: BF89FC37
	v_dual_add_f32 v26, v8, v33 :: v_dual_add_f32 v13, v13, v23// 00000039C074: C9084308 1A0C2F0D
	s_waitcnt lgkmcnt(1)                                       // 00000039C07C: BF89FC17
	v_dual_add_f32 v29, v7, v34 :: v_dual_add_f32 v2, v2, v3   // 00000039C080: C9084507 1D020702
	s_waitcnt lgkmcnt(0)                                       // 00000039C088: BF89FC07
	v_add_f32_e32 v3, v4, v5                                   // 00000039C08C: 06060B04
	ds_bpermute_b32 v8, v6, v9                                 // 00000039C090: DACC0000 08000906
	ds_bpermute_b32 v15, v6, v10                               // 00000039C098: DACC0000 0F000A06
	ds_bpermute_b32 v16, v6, v11                               // 00000039C0A0: DACC0000 10000B06
	ds_bpermute_b32 v24, v6, v12                               // 00000039C0A8: DACC0000 18000C06
	ds_bpermute_b32 v25, v6, v14                               // 00000039C0B0: DACC0000 19000E06
	ds_bpermute_b32 v27, v6, v20                               // 00000039C0B8: DACC0000 1B001406
	ds_bpermute_b32 v28, v6, v21                               // 00000039C0C0: DACC0000 1C001506
	ds_bpermute_b32 v30, v6, v17                               // 00000039C0C8: DACC0000 1E001106
	ds_bpermute_b32 v31, v6, v18                               // 00000039C0D0: DACC0000 1F001206
	ds_bpermute_b32 v32, v6, v19                               // 00000039C0D8: DACC0000 20001306
	ds_bpermute_b32 v35, v6, v13                               // 00000039C0E0: DACC0000 23000D06
	ds_bpermute_b32 v36, v6, v29                               // 00000039C0E8: DACC0000 24001D06
	v_xor_b32_e32 v5, 1, v1                                    // 00000039C0F0: 3A0A0281
	s_delay_alu instid0(VALU_DEP_1)                            // 00000039C0F4: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 00000039C0F8: 7C980AA0
	s_waitcnt lgkmcnt(11)                                      // 00000039C0FC: BF89FCB7
	v_add_f32_e32 v23, v9, v8                                  // 00000039C100: 062E1109
	ds_bpermute_b32 v34, v6, v26                               // 00000039C104: DACC0000 22001A06
	s_waitcnt lgkmcnt(11)                                      // 00000039C10C: BF89FCB7
	v_add_f32_e32 v15, v10, v15                                // 00000039C110: 061E1F0A
	ds_bpermute_b32 v33, v6, v22                               // 00000039C114: DACC0000 21001606
	s_waitcnt lgkmcnt(11)                                      // 00000039C11C: BF89FCB7
	v_add_f32_e32 v7, v11, v16                                 // 00000039C120: 060E210B
	ds_bpermute_b32 v37, v6, v2                                // 00000039C124: DACC0000 25000206
	s_waitcnt lgkmcnt(11)                                      // 00000039C12C: BF89FCB7
	v_dual_add_f32 v4, v12, v24 :: v_dual_cndmask_b32 v1, v1, v5// 00000039C130: C912310C 04000B01
	s_waitcnt lgkmcnt(7)                                       // 00000039C138: BF89FC77
	v_dual_add_f32 v24, v14, v25 :: v_dual_add_f32 v5, v17, v30// 00000039C13C: C908330E 18043D11
	s_waitcnt lgkmcnt(5)                                       // 00000039C144: BF89FC57
	v_dual_add_f32 v16, v20, v27 :: v_dual_add_f32 v17, v19, v32// 00000039C148: C9083714 10104113
	v_dual_add_f32 v8, v21, v28 :: v_dual_add_f32 v25, v18, v31// 00000039C150: C9083915 08183F12
	s_waitcnt lgkmcnt(3)                                       // 00000039C158: BF89FC37
	v_dual_add_f32 v18, v29, v36 :: v_dual_lshlrev_b32 v1, 2, v1// 00000039C15C: C922491D 12000282
	s_waitcnt lgkmcnt(2)                                       // 00000039C164: BF89FC27
	v_add_f32_e32 v6, v26, v34                                 // 00000039C168: 060C451A
	s_waitcnt lgkmcnt(1)                                       // 00000039C16C: BF89FC17
	v_dual_add_f32 v26, v13, v35 :: v_dual_add_f32 v9, v22, v33// 00000039C170: C908470D 1A084316
	ds_bpermute_b32 v31, v1, v3                                // 00000039C178: DACC0000 1F000301
	s_waitcnt lgkmcnt(1)                                       // 00000039C180: BF89FC17
	v_add_f32_e32 v10, v2, v37                                 // 00000039C184: 06144B02
	ds_bpermute_b32 v27, v1, v23                               // 00000039C188: DACC0000 1B001701
	ds_bpermute_b32 v19, v1, v15                               // 00000039C190: DACC0000 13000F01
	ds_bpermute_b32 v11, v1, v7                                // 00000039C198: DACC0000 0B000701
	ds_bpermute_b32 v32, v1, v4                                // 00000039C1A0: DACC0000 20000401
	ds_bpermute_b32 v28, v1, v24                               // 00000039C1A8: DACC0000 1C001801
	ds_bpermute_b32 v20, v1, v16                               // 00000039C1B0: DACC0000 14001001
	ds_bpermute_b32 v12, v1, v8                                // 00000039C1B8: DACC0000 0C000801
	ds_bpermute_b32 v33, v1, v5                                // 00000039C1C0: DACC0000 21000501
	ds_bpermute_b32 v29, v1, v25                               // 00000039C1C8: DACC0000 1D001901
	ds_bpermute_b32 v21, v1, v17                               // 00000039C1D0: DACC0000 15001101
	ds_bpermute_b32 v13, v1, v9                                // 00000039C1D8: DACC0000 0D000901
	ds_bpermute_b32 v34, v1, v6                                // 00000039C1E0: DACC0000 22000601
	ds_bpermute_b32 v30, v1, v26                               // 00000039C1E8: DACC0000 1E001A01
	ds_bpermute_b32 v22, v1, v18                               // 00000039C1F0: DACC0000 16001201
	ds_bpermute_b32 v14, v1, v10                               // 00000039C1F8: DACC0000 0E000A01
	v_cmpx_eq_u32_e32 0, v89                                   // 00000039C200: 7D94B280
	s_cbranch_execz 1031                                       // 00000039C204: BFA50407 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3d24>
	v_ashrrev_i32_e32 v81, 31, v80                             // 00000039C208: 34A2A09F
	s_waitcnt lgkmcnt(11)                                      // 00000039C20C: BF89FCB7
	v_dual_add_f32 v3, v3, v31 :: v_dual_add_f32 v4, v4, v32   // 00000039C210: C9083F03 03044104
	s_waitcnt lgkmcnt(3)                                       // 00000039C218: BF89FC37
	v_dual_add_f32 v5, v5, v33 :: v_dual_add_f32 v6, v6, v34   // 00000039C21C: C9084305 05064506
	.long 0xd73c0023                                           // 00000039C224: D73C0023
	v_cndmask_b32_e32 v1, 1, v80, vcc_lo                       // 00000039C228: 0202A081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000039C22C: BF870223
	v_bfe_u32 v31, v3, 16, 1                                   // 00000039C230: D610001F 02052103
	v_bfe_u32 v32, v4, 16, 1                                   // 00000039C238: D6100020 02052104
	v_bfe_u32 v33, v5, 16, 1                                   // 00000039C240: D6100021 02052105
	v_bfe_u32 v34, v6, 16, 1                                   // 00000039C248: D6100022 02052106
	s_cmp_lg_u64 s[10:11], 0                                   // 00000039C250: BF11800A
	.long 0xd7006a01                                           // 00000039C254: D7006A01
	v_cndmask_b32_e32 v1, s16, v35, vcc_lo                     // 00000039C258: 02024610
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000039C25C: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s17, v36, vcc_lo             // 00000039C260: D5207C02 01AA4811
	v_add3_u32 v4, v4, v32, 0x7fff                             // 00000039C268: D6550004 03FE4104 00007FFF
	.long 0xd7006a25                                           // 00000039C274: D7006A25
	v_cndmask_b32_e32 v1, 0x2000, v1, vcc_lo                   // 00000039C278: 020202FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039C280: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v2, vcc_lo               // 00000039C284: D5207C26 01AA0480
	.long 0xd7006a27                                           // 00000039C28C: D7006A27
	v_cndmask_b32_e32 v1, 0x3000, v1, vcc_lo                   // 00000039C290: 020202FF 00003000
	v_add_co_ci_u32_e64 v40, null, 0, v2, vcc_lo               // 00000039C298: D5207C28 01AA0480
	.long 0xd7006a29                                           // 00000039C2A0: D7006A29
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 00000039C2A4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000039C2AC: BF870001
	v_add_co_ci_u32_e64 v42, null, 0, v2, vcc_lo               // 00000039C2B0: D5207C2A 01AA0480
	s_clause 0x3                                               // 00000039C2B8: BF850003
	global_load_u16 v37, v[37:38], off offset:2048             // 00000039C2BC: DC4A0800 257C0025
	global_load_u16 v38, v[39:40], off offset:3072             // 00000039C2C4: DC4A0C00 267C0027
	global_load_u16 v39, v[1:2], off                           // 00000039C2CC: DC4A0000 277C0001
	global_load_u16 v40, v[41:42], off offset:1024             // 00000039C2D4: DC4A0400 287C0029
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000039C2DC: 360808FF FFFF0000
	v_add3_u32 v3, v3, v31, 0x7fff                             // 00000039C2E4: D6550003 03FE3F03 00007FFF
	v_add3_u32 v6, v6, v34, 0x7fff                             // 00000039C2F0: D6550006 03FE4506 00007FFF
	v_add3_u32 v5, v5, v33, 0x7fff                             // 00000039C2FC: D6550005 03FE4305 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039C308: BF870194
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 00000039C30C: 100808FF BFB8AA3B
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000039C314: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000039C31C: BF870122
	v_exp_f32_e32 v4, v4                                       // 00000039C320: 7E084B04
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000039C324: 360606FF FFFF0000
	v_mul_f32_e32 v6, 0xbfb8aa3b, v6                           // 00000039C32C: 100C0CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000039C334: BF870311
	v_exp_f32_e32 v6, v6                                       // 00000039C338: 7E0C4B06
	v_dual_add_f32 v4, 1.0, v4 :: v_dual_and_b32 v5, 0xffff0000, v5// 00000039C33C: C92408F2 04040AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039C348: BF870113
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 00000039C34C: 100606FF BFB8AA3B
	v_div_scale_f32 v32, null, v4, v4, 1.0                     // 00000039C354: D6FC7C20 03CA0904
	s_delay_alu instid0(VALU_DEP_2)                            // 00000039C35C: BF870002
	v_exp_f32_e32 v3, v3                                       // 00000039C360: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 00000039C364: BF870186
	v_dual_add_f32 v6, 1.0, v6 :: v_dual_mul_f32 v5, 0xbfb8aa3b, v5// 00000039C368: C9060CF2 06040AFF BFB8AA3B
	v_div_scale_f32 v46, s3, 1.0, v4, 1.0                      // 00000039C374: D6FC032E 03CA08F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039C37C: BF870113
	v_rcp_f32_e32 v42, v32                                     // 00000039C380: 7E545520
	v_div_scale_f32 v34, null, v6, v6, 1.0                     // 00000039C384: D6FC7C22 03CA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 00000039C38C: BF870393
	v_exp_f32_e32 v5, v5                                       // 00000039C390: 7E0A4B05
	v_add_f32_e32 v3, 1.0, v3                                  // 00000039C394: 060606F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 00000039C398: BF870392
	v_rcp_f32_e32 v44, v34                                     // 00000039C39C: 7E585522
	v_fma_f32 v48, -v32, v42, 1.0                              // 00000039C3A0: D6130030 23CA5520
	s_delay_alu instid0(VALU_DEP_2)                            // 00000039C3A8: BF870002
	v_div_scale_f32 v31, null, v3, v3, 1.0                     // 00000039C3AC: D6FC7C1F 03CA0703
	v_div_scale_f32 v45, vcc_lo, 1.0, v3, 1.0                  // 00000039C3B4: D6FC6A2D 03CA06F2
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 00000039C3BC: BF870186
	v_dual_add_f32 v5, 1.0, v5 :: v_dual_fmac_f32 v42, v48, v42// 00000039C3C0: C9000AF2 052A5530
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000039C3C8: BF870313
	v_rcp_f32_e32 v41, v31                                     // 00000039C3CC: 7E52551F
	v_fma_f32 v51, -v34, v44, 1.0                              // 00000039C3D0: D6130033 23CA5922
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000039C3D8: BF8701A2
	v_div_scale_f32 v33, null, v5, v5, 1.0                     // 00000039C3DC: D6FC7C21 03CA0B05
	v_div_scale_f32 v50, s4, 1.0, v5, 1.0                      // 00000039C3E4: D6FC0432 03CA0AF2
	v_fmac_f32_e32 v44, v51, v44                               // 00000039C3EC: 56585933
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000039C3F0: BF870313
	v_rcp_f32_e32 v43, v33                                     // 00000039C3F4: 7E565521
	v_fma_f32 v47, -v31, v41, 1.0                              // 00000039C3F8: D613002F 23CA531F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000039C400: BF8702A1
	v_fmac_f32_e32 v41, v47, v41                               // 00000039C404: 5652532F
	v_div_scale_f32 v47, s5, 1.0, v6, 1.0                      // 00000039C408: D6FC052F 03CA0CF2
	v_fma_f32 v49, -v33, v43, 1.0                              // 00000039C410: D6130031 23CA5721
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039C418: BF870113
	v_mul_f32_e32 v48, v45, v41                                // 00000039C41C: 1060532D
	v_dual_mul_f32 v52, v47, v44 :: v_dual_fmac_f32 v43, v49, v43// 00000039C420: C8C0592F 342A5731
	v_mul_f32_e32 v49, v46, v42                                // 00000039C428: 1062552E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039C42C: BF870193
	v_fma_f32 v53, -v31, v48, v45                              // 00000039C430: D6130035 24B6611F
	v_fma_f32 v56, -v34, v52, v47                              // 00000039C438: D6130038 24BE6922
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C440: BF870214
	v_mul_f32_e32 v51, v50, v43                                // 00000039C444: 10665732
	v_fma_f32 v54, -v32, v49, v46                              // 00000039C448: D6130036 24BA6320
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C450: BF870214
	v_fmac_f32_e32 v48, v53, v41                               // 00000039C454: 56605335
	v_fmac_f32_e32 v52, v56, v44                               // 00000039C458: 56685938
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C45C: BF870214
	v_fma_f32 v55, -v33, v51, v50                              // 00000039C460: D6130037 24CA6721
	v_fmac_f32_e32 v49, v54, v42                               // 00000039C468: 56625536
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C46C: BF870214
	v_fma_f32 v31, -v31, v48, v45                              // 00000039C470: D613001F 24B6611F
	v_fma_f32 v34, -v34, v52, v47                              // 00000039C478: D6130022 24BE6922
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C480: BF870214
	v_fmac_f32_e32 v51, v55, v43                               // 00000039C484: 56665737
	v_fma_f32 v32, -v32, v49, v46                              // 00000039C488: D6130020 24BA6320
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000039C490: BF8701A4
	v_div_fmas_f32 v31, v31, v41, v48                          // 00000039C494: D637001F 04C2531F
	s_mov_b32 vcc_lo, s3                                       // 00000039C49C: BEEA0003
	v_fma_f32 v33, -v33, v51, v50                              // 00000039C4A0: D6130021 24CA6721
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000039C4A8: BF8701B3
	v_div_fmas_f32 v32, v32, v42, v49                          // 00000039C4AC: D6370020 04C65520
	s_mov_b32 vcc_lo, s4                                       // 00000039C4B4: BEEA0004
	v_div_fixup_f32 v3, v31, v3, 1.0                           // 00000039C4B8: D6270003 03CA071F
	v_div_fmas_f32 v31, v33, v43, v51                          // 00000039C4C0: D637001F 04CE5721
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000039C4C8: BF8701A3
	v_div_fixup_f32 v4, v32, v4, 1.0                           // 00000039C4CC: D6270004 03CA0920
	s_mov_b32 vcc_lo, s5                                       // 00000039C4D4: BEEA0005
	v_bfe_u32 v32, v3, 16, 1                                   // 00000039C4D8: D6100020 02052103
	v_div_fmas_f32 v33, v34, v44, v52                          // 00000039C4E0: D6370021 04D25922
	v_div_fixup_f32 v5, v31, v5, 1.0                           // 00000039C4E8: D6270005 03CA0B1F
	v_bfe_u32 v31, v4, 16, 1                                   // 00000039C4F0: D610001F 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C4F8: BF870214
	v_add3_u32 v3, v3, v32, 0x7fff                             // 00000039C4FC: D6550003 03FE4103 00007FFF
	v_div_fixup_f32 v6, v33, v6, 1.0                           // 00000039C508: D6270006 03CA0D21
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C510: BF870214
	v_bfe_u32 v32, v5, 16, 1                                   // 00000039C514: D6100020 02052105
	v_add3_u32 v4, v4, v31, 0x7fff                             // 00000039C51C: D6550004 03FE3F04 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C528: BF870214
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000039C52C: 360606FF FFFF0000
	v_bfe_u32 v33, v6, 16, 1                                   // 00000039C534: D6100021 02052106
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039C53C: BF870114
	v_add3_u32 v5, v5, v32, 0x7fff                             // 00000039C540: D6550005 03FE4105 00007FFF
	v_add3_u32 v6, v6, v33, 0x7fff                             // 00000039C54C: D6550006 03FE4306 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000039C558: BF870152
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000039C55C: 360A0AFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 00000039C564: BF8907F7
	v_lshlrev_b32_e32 v31, 16, v39                             // 00000039C568: 303E4E90
	s_waitcnt vmcnt(0)                                         // 00000039C56C: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v40                             // 00000039C570: 30405090
	v_fma_f32 v3, v3, v31, 0                                   // 00000039C574: D6130003 02023F03
	v_lshlrev_b32_e32 v31, 16, v37                             // 00000039C57C: 303E4A90
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000039C580: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039C588: BF870091
	v_dual_fmac_f32 v3, v4, v32 :: v_dual_and_b32 v4, 0xffff0000, v6// 00000039C58C: C8244104 03040CFF FFFF0000
	v_dual_fmac_f32 v3, v5, v31 :: v_dual_lshlrev_b32 v6, 16, v38// 00000039C598: C8223F05 03064C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039C5A0: BF870091
	v_fmac_f32_e32 v3, v4, v6                                  // 00000039C5A4: 56060D04
	v_mul_f32_e32 v31, 0x3e800000, v3                          // 00000039C5A8: 103E06FF 3E800000
	.long 0xd7006a03                                           // 00000039C5B0: D7006A03
	v_cndmask_b32_e32 v1, s8, v35, vcc_lo                      // 00000039C5B4: 02024608
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039C5B8: BF870191
	v_add_co_ci_u32_e64 v4, null, s9, v36, vcc_lo              // 00000039C5BC: D5207C04 01AA4809
	v_bfe_u32 v5, v31, 16, 1                                   // 00000039C5C4: D6100005 0205211F
	s_cselect_b32 s8, -1, 0                                    // 00000039C5CC: 980880C1
	s_cmp_eq_u64 s[10:11], 0                                   // 00000039C5D0: BF10800A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000039C5D4: BF870001
	v_add3_u32 v32, v31, v5, 0x7fff                            // 00000039C5D8: D6550020 03FE0B1F 00007FFF
	.long 0xd73c0005                                           // 00000039C5E4: D73C0005
	v_cndmask_b32_e32 v1, 2, v80, vcc_lo                       // 00000039C5E8: 0202A082
	global_store_d16_hi_b16 v[3:4], v32, off                   // 00000039C5EC: DC960000 007C2003
	s_cbranch_scc1 7                                           // 00000039C5F4: BFA20007 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3114>
	.long 0xd7006a20                                           // 00000039C5F8: D7006A20
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000039C5FC: 02020A0A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000039C600: BF870001
	v_add_co_ci_u32_e64 v33, null, s11, v6, vcc_lo             // 00000039C604: D5207C21 01AA0C0B
	global_store_b32 v[32:33], v31, off                        // 00000039C60C: DC6A0000 007C1F20
	.long 0xd7006a1f                                           // 00000039C614: D7006A1F
	v_cndmask_b32_e32 v1, 0x5000, v1, vcc_lo                   // 00000039C618: 020202FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039C620: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v2, vcc_lo               // 00000039C624: D5207C20 01AA0480
	.long 0xd7006a21                                           // 00000039C62C: D7006A21
	v_cndmask_b32_e32 v1, 0x6000, v1, vcc_lo                   // 00000039C630: 020202FF 00006000
	v_add_co_ci_u32_e64 v34, null, 0, v2, vcc_lo               // 00000039C638: D5207C22 01AA0480
	s_clause 0x1                                               // 00000039C640: BF850001
	global_load_u16 v35, v[31:32], off                         // 00000039C644: DC4A0000 237C001F
	global_load_u16 v36, v[33:34], off offset:1024             // 00000039C64C: DC4A0400 247C0021
	.long 0xd7006a1f                                           // 00000039C654: D7006A1F
	v_cndmask_b32_e32 v1, 0x7000, v1, vcc_lo                   // 00000039C658: 020202FF 00007000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039C660: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v2, vcc_lo               // 00000039C664: D5207C20 01AA0480
	.long 0xd7006a21                                           // 00000039C66C: D7006A21
	v_cndmask_b32_e32 v1, 0x8000, v1, vcc_lo                   // 00000039C670: 020202FF 00008000
	v_add_co_ci_u32_e64 v34, null, 0, v2, vcc_lo               // 00000039C678: D5207C22 01AA0480
	s_clause 0x1                                               // 00000039C680: BF850001
	global_load_u16 v31, v[31:32], off offset:2048             // 00000039C684: DC4A0800 1F7C001F
	global_load_u16 v32, v[33:34], off offset:3072             // 00000039C68C: DC4A0C00 207C0021
	v_dual_add_f32 v23, v23, v27 :: v_dual_add_f32 v24, v24, v28// 00000039C694: C9083717 17183918
	s_waitcnt lgkmcnt(2)                                       // 00000039C69C: BF89FC27
	v_dual_add_f32 v25, v25, v29 :: v_dual_add_f32 v26, v26, v30// 00000039C6A0: C9083B19 191A3D1A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039C6A8: BF870192
	v_bfe_u32 v27, v23, 16, 1                                  // 00000039C6AC: D610001B 02052117
	v_bfe_u32 v28, v24, 16, 1                                  // 00000039C6B4: D610001C 02052118
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C6BC: BF870213
	v_bfe_u32 v29, v25, 16, 1                                  // 00000039C6C0: D610001D 02052119
	v_bfe_u32 v30, v26, 16, 1                                  // 00000039C6C8: D610001E 0205211A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C6D0: BF870214
	v_add3_u32 v23, v23, v27, 0x7fff                           // 00000039C6D4: D6550017 03FE3717 00007FFF
	v_add3_u32 v24, v24, v28, 0x7fff                           // 00000039C6E0: D6550018 03FE3918 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C6EC: BF870214
	v_add3_u32 v25, v25, v29, 0x7fff                           // 00000039C6F0: D6550019 03FE3B19 00007FFF
	v_add3_u32 v26, v26, v30, 0x7fff                           // 00000039C6FC: D655001A 03FE3D1A 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039C708: BF870113
	v_and_b32_e32 v24, 0xffff0000, v24                         // 00000039C70C: 363030FF FFFF0000
	v_and_b32_e32 v26, 0xffff0000, v26                         // 00000039C714: 363434FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039C71C: BF870112
	v_mul_f32_e32 v24, 0xbfb8aa3b, v24                         // 00000039C720: 103030FF BFB8AA3B
	v_mul_f32_e32 v26, 0xbfb8aa3b, v26                         // 00000039C728: 103434FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000039C730: BF870122
	v_exp_f32_e32 v24, v24                                     // 00000039C734: 7E304B18
	v_and_b32_e32 v23, 0xffff0000, v23                         // 00000039C738: 362E2EFF FFFF0000
	v_exp_f32_e32 v26, v26                                     // 00000039C740: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000039C744: BF870296
	v_dual_add_f32 v24, 1.0, v24 :: v_dual_and_b32 v25, 0xffff0000, v25// 00000039C748: C92430F2 181832FF FFFF0000
	v_dual_mul_f32 v23, 0xbfb8aa3b, v23 :: v_dual_add_f32 v26, 1.0, v26// 00000039C754: C8C82EFF 171A34F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039C760: BF870192
	v_mul_f32_e32 v25, 0xbfb8aa3b, v25                         // 00000039C764: 103232FF BFB8AA3B
	v_div_scale_f32 v28, null, v24, v24, 1.0                   // 00000039C76C: D6FC7C1C 03CA3118
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039C774: BF870193
	v_exp_f32_e32 v23, v23                                     // 00000039C778: 7E2E4B17
	v_div_scale_f32 v30, null, v26, v26, 1.0                   // 00000039C77C: D6FC7C1E 03CA351A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000039C784: BF870133
	v_exp_f32_e32 v25, v25                                     // 00000039C788: 7E324B19
	v_div_scale_f32 v40, s3, 1.0, v24, 1.0                     // 00000039C78C: D6FC0328 03CA30F2
	v_rcp_f32_e32 v34, v28                                     // 00000039C794: 7E44551C
	v_rcp_f32_e32 v38, v30                                     // 00000039C798: 7E4C551E
	v_add_f32_e32 v23, 1.0, v23                                // 00000039C79C: 062E2EF2
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000039C7A0: BF870317
	v_add_f32_e32 v25, 1.0, v25                                // 00000039C7A4: 063232F2
	v_fma_f32 v42, -v28, v34, 1.0                              // 00000039C7A8: D613002A 23CA451C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000039C7B0: BF870223
	v_div_scale_f32 v27, null, v23, v23, 1.0                   // 00000039C7B4: D6FC7C1B 03CA2F17
	v_div_scale_f32 v39, vcc_lo, 1.0, v23, 1.0                 // 00000039C7BC: D6FC6A27 03CA2EF2
	v_div_scale_f32 v29, null, v25, v25, 1.0                   // 00000039C7C4: D6FC7C1D 03CA3319
	v_div_scale_f32 v44, s4, 1.0, v25, 1.0                     // 00000039C7CC: D6FC042C 03CA32F2
	v_fmac_f32_e32 v34, v42, v34                               // 00000039C7D4: 5644452A
	v_rcp_f32_e32 v33, v27                                     // 00000039C7D8: 7E42551B
	v_fma_f32 v45, -v30, v38, 1.0                              // 00000039C7DC: D613002D 23CA4D1E
	v_rcp_f32_e32 v37, v29                                     // 00000039C7E4: 7E4A551D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000039C7E8: BF870311
	v_fmac_f32_e32 v38, v45, v38                               // 00000039C7EC: 564C4D2D
	v_fma_f32 v41, -v27, v33, 1.0                              // 00000039C7F0: D6130029 23CA431B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039C7F8: BF870115
	v_fma_f32 v43, -v29, v37, 1.0                              // 00000039C7FC: D613002B 23CA4B1D
	v_fmac_f32_e32 v33, v41, v33                               // 00000039C804: 56424329
	v_div_scale_f32 v41, s5, 1.0, v26, 1.0                     // 00000039C808: D6FC0529 03CA34F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039C810: BF870193
	v_fmac_f32_e32 v37, v43, v37                               // 00000039C814: 564A4B2B
	v_dual_mul_f32 v43, v40, v34 :: v_dual_mul_f32 v42, v39, v33// 00000039C818: C8C64528 2B2A4327
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039C820: BF870112
	v_dual_mul_f32 v46, v41, v38 :: v_dual_mul_f32 v45, v44, v37// 00000039C824: C8C64D29 2E2C4B2C
	v_fma_f32 v48, -v28, v43, v40                              // 00000039C82C: D6130030 24A2571C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039C834: BF870193
	v_fma_f32 v47, -v27, v42, v39                              // 00000039C838: D613002F 249E551B
	v_fma_f32 v50, -v30, v46, v41                              // 00000039C840: D6130032 24A65D1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039C848: BF870194
	v_fma_f32 v49, -v29, v45, v44                              // 00000039C84C: D6130031 24B25B1D
	v_dual_fmac_f32 v43, v48, v34 :: v_dual_fmac_f32 v42, v47, v33// 00000039C854: C8004530 2B2A432F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039C85C: BF870112
	v_dual_fmac_f32 v46, v50, v38 :: v_dual_fmac_f32 v45, v49, v37// 00000039C860: C8004D32 2E2C4B31
	v_fma_f32 v28, -v28, v43, v40                              // 00000039C868: D613001C 24A2571C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039C870: BF870193
	v_fma_f32 v27, -v27, v42, v39                              // 00000039C874: D613001B 249E551B
	v_fma_f32 v30, -v30, v46, v41                              // 00000039C87C: D613001E 24A65D1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039C884: BF870194
	v_fma_f32 v29, -v29, v45, v44                              // 00000039C888: D613001D 24B25B1D
	v_div_fmas_f32 v27, v27, v33, v42                          // 00000039C890: D637001B 04AA431B
	s_mov_b32 vcc_lo, s3                                       // 00000039C898: BEEA0003
	v_div_fmas_f32 v28, v28, v34, v43                          // 00000039C89C: D637001C 04AE451C
	s_mov_b32 vcc_lo, s4                                       // 00000039C8A4: BEEA0004
	s_delay_alu instid0(VALU_DEP_2)                            // 00000039C8A8: BF870002
	v_div_fixup_f32 v23, v27, v23, 1.0                         // 00000039C8AC: D6270017 03CA2F1B
	v_div_fmas_f32 v27, v29, v37, v45                          // 00000039C8B4: D637001B 04B64B1D
	s_mov_b32 vcc_lo, s5                                       // 00000039C8BC: BEEA0005
	v_div_fixup_f32 v24, v28, v24, 1.0                         // 00000039C8C0: D6270018 03CA311C
	v_div_fmas_f32 v29, v30, v38, v46                          // 00000039C8C8: D637001D 04BA4D1E
	v_bfe_u32 v28, v23, 16, 1                                  // 00000039C8D0: D610001C 02052117
	v_div_fixup_f32 v25, v27, v25, 1.0                         // 00000039C8D8: D6270019 03CA331B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C8E0: BF870214
	v_bfe_u32 v27, v24, 16, 1                                  // 00000039C8E4: D610001B 02052118
	v_div_fixup_f32 v26, v29, v26, 1.0                         // 00000039C8EC: D627001A 03CA351D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C8F4: BF870214
	v_add3_u32 v23, v23, v28, 0x7fff                           // 00000039C8F8: D6550017 03FE3917 00007FFF
	v_bfe_u32 v28, v25, 16, 1                                  // 00000039C904: D610001C 02052119
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C90C: BF870214
	v_add3_u32 v24, v24, v27, 0x7fff                           // 00000039C910: D6550018 03FE3718 00007FFF
	v_bfe_u32 v29, v26, 16, 1                                  // 00000039C91C: D610001D 0205211A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039C924: BF870214
	v_and_b32_e32 v23, 0xffff0000, v23                         // 00000039C928: 362E2EFF FFFF0000
	v_add3_u32 v25, v25, v28, 0x7fff                           // 00000039C930: D6550019 03FE3919 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039C93C: BF870113
	v_add3_u32 v26, v26, v29, 0x7fff                           // 00000039C940: D655001A 03FE3B1A 00007FFF
	v_and_b32_e32 v25, 0xffff0000, v25                         // 00000039C94C: 363232FF FFFF0000
	s_waitcnt vmcnt(3)                                         // 00000039C954: BF890FF7
	v_lshlrev_b32_e32 v27, 16, v35                             // 00000039C958: 30364690
	s_waitcnt vmcnt(2)                                         // 00000039C95C: BF890BF7
	v_lshlrev_b32_e32 v28, 16, v36                             // 00000039C960: 30384890
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000039C964: BF8700C2
	v_fma_f32 v23, v23, v27, 0                                 // 00000039C968: D6130017 02023717
	s_waitcnt vmcnt(1)                                         // 00000039C970: BF8907F7
	v_lshlrev_b32_e32 v27, 16, v31                             // 00000039C974: 30363E90
	v_and_b32_e32 v24, 0xffff0000, v24                         // 00000039C978: 363030FF FFFF0000
	v_dual_fmac_f32 v23, v24, v28 :: v_dual_and_b32 v24, 0xffff0000, v26// 00000039C980: C8243918 171834FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 00000039C98C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039C990: BF870091
	v_dual_fmac_f32 v23, v25, v27 :: v_dual_lshlrev_b32 v26, 16, v32// 00000039C994: C8223719 171A4090
	v_fmac_f32_e32 v23, v24, v26                               // 00000039C99C: 562E3518
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000039C9A0: BF870121
	v_mul_f32_e32 v24, 0x3e800000, v23                         // 00000039C9A4: 10302EFF 3E800000
	v_cndmask_b32_e64 v23, 0, 1, s8                            // 00000039C9AC: D5010017 00210280
	v_bfe_u32 v25, v24, 16, 1                                  // 00000039C9B4: D6100019 02052118
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039C9BC: BF8700A1
	v_add3_u32 v27, v24, v25, 0x7fff                           // 00000039C9C0: D655001B 03FE3318 00007FFF
	.long 0xd7006a19                                           // 00000039C9CC: D7006A19
	v_cndmask_b32_e32 v1, 0x1000, v3, vcc_lo                   // 00000039C9D0: 020206FF 00001000
	v_add_co_ci_u32_e64 v26, null, 0, v4, vcc_lo               // 00000039C9D8: D5207C1A 01AA0880
	s_and_not1_b32 vcc_lo, exec_lo, s8                         // 00000039C9E0: 916A087E
	global_store_d16_hi_b16 v[25:26], v27, off offset:1024     // 00000039C9E4: DC960400 007C1B19
	s_cbranch_vccnz 13                                         // 00000039C9EC: BFA4000D <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3524>
	.long 0xd7006a19                                           // 00000039C9F0: D7006A19
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000039C9F4: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039C9F8: BF870111
	v_add_co_ci_u32_e64 v26, null, s11, v6, vcc_lo             // 00000039C9FC: D5207C1A 01AA0C0B
	.long 0xd7006a19                                           // 00000039CA04: D7006A19
	v_cndmask_b32_e32 v1, 0x2000, v25, vcc_lo                  // 00000039CA08: 020232FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000039CA10: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v26, vcc_lo              // 00000039CA14: D5207C1A 01AA3480
	global_store_b32 v[25:26], v24, off offset:2048            // 00000039CA1C: DC6A0800 007C1819
	.long 0xd7006a18                                           // 00000039CA24: D7006A18
	v_cndmask_b32_e32 v1, 0xa000, v1, vcc_lo                   // 00000039CA28: 020202FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039CA30: BF8700A1
	v_add_co_ci_u32_e64 v25, null, 0, v2, vcc_lo               // 00000039CA34: D5207C19 01AA0480
	.long 0xd7006a1a                                           // 00000039CA3C: D7006A1A
	v_cndmask_b32_e32 v1, 0xb000, v1, vcc_lo                   // 00000039CA40: 020202FF 0000B000
	v_add_co_ci_u32_e64 v27, null, 0, v2, vcc_lo               // 00000039CA48: D5207C1B 01AA0480
	s_clause 0x1                                               // 00000039CA50: BF850001
	global_load_u16 v28, v[24:25], off                         // 00000039CA54: DC4A0000 1C7C0018
	global_load_u16 v29, v[26:27], off offset:1024             // 00000039CA5C: DC4A0400 1D7C001A
	.long 0xd7006a18                                           // 00000039CA64: D7006A18
	v_cndmask_b32_e32 v1, 0xc000, v1, vcc_lo                   // 00000039CA68: 020202FF 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039CA70: BF8700A1
	v_add_co_ci_u32_e64 v25, null, 0, v2, vcc_lo               // 00000039CA74: D5207C19 01AA0480
	.long 0xd7006a1a                                           // 00000039CA7C: D7006A1A
	v_cndmask_b32_e32 v1, 0xd000, v1, vcc_lo                   // 00000039CA80: 020202FF 0000D000
	v_add_co_ci_u32_e64 v27, null, 0, v2, vcc_lo               // 00000039CA88: D5207C1B 01AA0480
	s_clause 0x1                                               // 00000039CA90: BF850001
	global_load_u16 v24, v[24:25], off offset:2048             // 00000039CA94: DC4A0800 187C0018
	global_load_u16 v25, v[26:27], off offset:3072             // 00000039CA9C: DC4A0C00 197C001A
	v_dual_add_f32 v15, v15, v19 :: v_dual_add_f32 v16, v16, v20// 00000039CAA4: C908270F 0F102910
	s_waitcnt lgkmcnt(1)                                       // 00000039CAAC: BF89FC17
	v_dual_add_f32 v17, v17, v21 :: v_dual_add_f32 v18, v18, v22// 00000039CAB0: C9082B11 11122D12
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039CAB8: BF870192
	v_bfe_u32 v19, v15, 16, 1                                  // 00000039CABC: D6100013 0205210F
	v_bfe_u32 v20, v16, 16, 1                                  // 00000039CAC4: D6100014 02052110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039CACC: BF870213
	v_bfe_u32 v21, v17, 16, 1                                  // 00000039CAD0: D6100015 02052111
	v_bfe_u32 v22, v18, 16, 1                                  // 00000039CAD8: D6100016 02052112
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039CAE0: BF870214
	v_add3_u32 v15, v15, v19, 0x7fff                           // 00000039CAE4: D655000F 03FE270F 00007FFF
	v_add3_u32 v16, v16, v20, 0x7fff                           // 00000039CAF0: D6550010 03FE2910 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039CAFC: BF870214
	v_add3_u32 v17, v17, v21, 0x7fff                           // 00000039CB00: D6550011 03FE2B11 00007FFF
	v_add3_u32 v18, v18, v22, 0x7fff                           // 00000039CB0C: D6550012 03FE2D12 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039CB18: BF870113
	v_and_b32_e32 v16, 0xffff0000, v16                         // 00000039CB1C: 362020FF FFFF0000
	v_and_b32_e32 v18, 0xffff0000, v18                         // 00000039CB24: 362424FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039CB2C: BF870112
	v_mul_f32_e32 v16, 0xbfb8aa3b, v16                         // 00000039CB30: 102020FF BFB8AA3B
	v_mul_f32_e32 v18, 0xbfb8aa3b, v18                         // 00000039CB38: 102424FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000039CB40: BF870122
	v_exp_f32_e32 v16, v16                                     // 00000039CB44: 7E204B10
	v_and_b32_e32 v15, 0xffff0000, v15                         // 00000039CB48: 361E1EFF FFFF0000
	v_exp_f32_e32 v18, v18                                     // 00000039CB50: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000039CB54: BF870296
	v_dual_add_f32 v16, 1.0, v16 :: v_dual_and_b32 v17, 0xffff0000, v17// 00000039CB58: C92420F2 101022FF FFFF0000
	v_dual_mul_f32 v15, 0xbfb8aa3b, v15 :: v_dual_add_f32 v18, 1.0, v18// 00000039CB64: C8C81EFF 0F1224F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039CB70: BF870192
	v_mul_f32_e32 v17, 0xbfb8aa3b, v17                         // 00000039CB74: 102222FF BFB8AA3B
	v_div_scale_f32 v20, null, v16, v16, 1.0                   // 00000039CB7C: D6FC7C14 03CA2110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039CB84: BF870193
	v_exp_f32_e32 v15, v15                                     // 00000039CB88: 7E1E4B0F
	v_div_scale_f32 v22, null, v18, v18, 1.0                   // 00000039CB8C: D6FC7C16 03CA2512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000039CB94: BF870133
	v_exp_f32_e32 v17, v17                                     // 00000039CB98: 7E224B11
	v_div_scale_f32 v33, s3, 1.0, v16, 1.0                     // 00000039CB9C: D6FC0321 03CA20F2
	v_rcp_f32_e32 v27, v20                                     // 00000039CBA4: 7E365514
	v_rcp_f32_e32 v31, v22                                     // 00000039CBA8: 7E3E5516
	v_add_f32_e32 v15, 1.0, v15                                // 00000039CBAC: 061E1EF2
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000039CBB0: BF870317
	v_add_f32_e32 v17, 1.0, v17                                // 00000039CBB4: 062222F2
	v_fma_f32 v35, -v20, v27, 1.0                              // 00000039CBB8: D6130023 23CA3714
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000039CBC0: BF870223
	v_div_scale_f32 v19, null, v15, v15, 1.0                   // 00000039CBC4: D6FC7C13 03CA1F0F
	v_div_scale_f32 v32, vcc_lo, 1.0, v15, 1.0                 // 00000039CBCC: D6FC6A20 03CA1EF2
	v_div_scale_f32 v21, null, v17, v17, 1.0                   // 00000039CBD4: D6FC7C15 03CA2311
	v_div_scale_f32 v37, s4, 1.0, v17, 1.0                     // 00000039CBDC: D6FC0425 03CA22F2
	v_fmac_f32_e32 v27, v35, v27                               // 00000039CBE4: 56363723
	v_rcp_f32_e32 v26, v19                                     // 00000039CBE8: 7E345513
	v_fma_f32 v38, -v22, v31, 1.0                              // 00000039CBEC: D6130026 23CA3F16
	v_rcp_f32_e32 v30, v21                                     // 00000039CBF4: 7E3C5515
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000039CBF8: BF870311
	v_fmac_f32_e32 v31, v38, v31                               // 00000039CBFC: 563E3F26
	v_fma_f32 v34, -v19, v26, 1.0                              // 00000039CC00: D6130022 23CA3513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039CC08: BF870115
	v_fma_f32 v36, -v21, v30, 1.0                              // 00000039CC0C: D6130024 23CA3D15
	v_fmac_f32_e32 v26, v34, v26                               // 00000039CC14: 56343522
	v_div_scale_f32 v34, s5, 1.0, v18, 1.0                     // 00000039CC18: D6FC0522 03CA24F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039CC20: BF870193
	v_fmac_f32_e32 v30, v36, v30                               // 00000039CC24: 563C3D24
	v_dual_mul_f32 v36, v33, v27 :: v_dual_mul_f32 v35, v32, v26// 00000039CC28: C8C63721 24223520
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039CC30: BF870112
	v_dual_mul_f32 v39, v34, v31 :: v_dual_mul_f32 v38, v37, v30// 00000039CC34: C8C63F22 27263D25
	v_fma_f32 v41, -v20, v36, v33                              // 00000039CC3C: D6130029 24864914
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039CC44: BF870193
	v_fma_f32 v40, -v19, v35, v32                              // 00000039CC48: D6130028 24824713
	v_fma_f32 v43, -v22, v39, v34                              // 00000039CC50: D613002B 248A4F16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039CC58: BF870194
	v_fma_f32 v42, -v21, v38, v37                              // 00000039CC5C: D613002A 24964D15
	v_dual_fmac_f32 v36, v41, v27 :: v_dual_fmac_f32 v35, v40, v26// 00000039CC64: C8003729 24223528
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039CC6C: BF870112
	v_dual_fmac_f32 v39, v43, v31 :: v_dual_fmac_f32 v38, v42, v30// 00000039CC70: C8003F2B 27263D2A
	v_fma_f32 v20, -v20, v36, v33                              // 00000039CC78: D6130014 24864914
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039CC80: BF870193
	v_fma_f32 v19, -v19, v35, v32                              // 00000039CC84: D6130013 24824713
	v_fma_f32 v22, -v22, v39, v34                              // 00000039CC8C: D6130016 248A4F16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039CC94: BF870194
	v_fma_f32 v21, -v21, v38, v37                              // 00000039CC98: D6130015 24964D15
	v_div_fmas_f32 v19, v19, v26, v35                          // 00000039CCA0: D6370013 048E3513
	s_mov_b32 vcc_lo, s3                                       // 00000039CCA8: BEEA0003
	v_div_fmas_f32 v20, v20, v27, v36                          // 00000039CCAC: D6370014 04923714
	s_mov_b32 vcc_lo, s4                                       // 00000039CCB4: BEEA0004
	s_delay_alu instid0(VALU_DEP_2)                            // 00000039CCB8: BF870002
	v_div_fixup_f32 v15, v19, v15, 1.0                         // 00000039CCBC: D627000F 03CA1F13
	v_div_fmas_f32 v19, v21, v30, v38                          // 00000039CCC4: D6370013 049A3D15
	s_mov_b32 vcc_lo, s5                                       // 00000039CCCC: BEEA0005
	v_div_fixup_f32 v16, v20, v16, 1.0                         // 00000039CCD0: D6270010 03CA2114
	v_div_fmas_f32 v21, v22, v31, v39                          // 00000039CCD8: D6370015 049E3F16
	v_bfe_u32 v20, v15, 16, 1                                  // 00000039CCE0: D6100014 0205210F
	v_div_fixup_f32 v17, v19, v17, 1.0                         // 00000039CCE8: D6270011 03CA2313
	v_cmp_ne_u32_e32 vcc_lo, 1, v23                            // 00000039CCF0: 7C9A2E81
	v_bfe_u32 v19, v16, 16, 1                                  // 00000039CCF4: D6100013 02052110
	v_div_fixup_f32 v18, v21, v18, 1.0                         // 00000039CCFC: D6270012 03CA2515
	v_add3_u32 v15, v15, v20, 0x7fff                           // 00000039CD04: D655000F 03FE290F 00007FFF
	v_bfe_u32 v20, v17, 16, 1                                  // 00000039CD10: D6100014 02052111
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000039CD18: 8B6A6A7E
	v_add3_u32 v16, v16, v19, 0x7fff                           // 00000039CD1C: D6550010 03FE2710 00007FFF
	v_bfe_u32 v21, v18, 16, 1                                  // 00000039CD28: D6100015 02052112
	v_and_b32_e32 v15, 0xffff0000, v15                         // 00000039CD30: 361E1EFF FFFF0000
	v_add3_u32 v17, v17, v20, 0x7fff                           // 00000039CD38: D6550011 03FE2911 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039CD44: BF870113
	v_add3_u32 v18, v18, v21, 0x7fff                           // 00000039CD48: D6550012 03FE2B12 00007FFF
	v_and_b32_e32 v17, 0xffff0000, v17                         // 00000039CD54: 362222FF FFFF0000
	s_waitcnt vmcnt(3)                                         // 00000039CD5C: BF890FF7
	v_lshlrev_b32_e32 v19, 16, v28                             // 00000039CD60: 30263890
	s_waitcnt vmcnt(2)                                         // 00000039CD64: BF890BF7
	v_lshlrev_b32_e32 v20, 16, v29                             // 00000039CD68: 30283A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000039CD6C: BF8700C2
	v_fma_f32 v15, v15, v19, 0                                 // 00000039CD70: D613000F 0202270F
	s_waitcnt vmcnt(1)                                         // 00000039CD78: BF8907F7
	v_lshlrev_b32_e32 v19, 16, v24                             // 00000039CD7C: 30263090
	v_and_b32_e32 v16, 0xffff0000, v16                         // 00000039CD80: 362020FF FFFF0000
	v_dual_fmac_f32 v15, v16, v20 :: v_dual_and_b32 v16, 0xffff0000, v18// 00000039CD88: C8242910 0F1024FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 00000039CD94: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039CD98: BF870091
	v_dual_fmac_f32 v15, v17, v19 :: v_dual_lshlrev_b32 v18, 16, v25// 00000039CD9C: C8222711 0F123290
	v_fmac_f32_e32 v15, v16, v18                               // 00000039CDA4: 561E2510
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039CDA8: BF870091
	v_mul_f32_e32 v15, 0x3e800000, v15                         // 00000039CDAC: 101E1EFF 3E800000
	v_bfe_u32 v16, v15, 16, 1                                  // 00000039CDB4: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039CDBC: BF8700A1
	v_add3_u32 v18, v15, v16, 0x7fff                           // 00000039CDC0: D6550012 03FE210F 00007FFF
	.long 0xd7000310                                           // 00000039CDCC: D7000310
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 00000039CDD0: 020206FF 00002000
	v_add_co_ci_u32_e64 v17, null, 0, v4, s3                   // 00000039CDD8: D5207C11 000E0880
	global_store_d16_hi_b16 v[16:17], v18, off offset:2048     // 00000039CDE0: DC960800 007C1210
	s_cbranch_vccnz 13                                         // 00000039CDE8: BFA4000D <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3920>
	.long 0xd7006a10                                           // 00000039CDEC: D7006A10
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000039CDF0: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039CDF4: BF870111
	v_add_co_ci_u32_e64 v17, null, s11, v6, vcc_lo             // 00000039CDF8: D5207C11 01AA0C0B
	.long 0xd7006a10                                           // 00000039CE00: D7006A10
	v_cndmask_b32_e32 v1, 0x5000, v16, vcc_lo                  // 00000039CE04: 020220FF 00005000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000039CE0C: BF870001
	v_add_co_ci_u32_e64 v17, null, 0, v17, vcc_lo              // 00000039CE10: D5207C11 01AA2280
	global_store_b32 v[16:17], v15, off                        // 00000039CE18: DC6A0000 007C0F10
	.long 0xd7006a0f                                           // 00000039CE20: D7006A0F
	v_cndmask_b32_e32 v1, 0xf000, v1, vcc_lo                   // 00000039CE24: 020202FF 0000F000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039CE2C: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v2, vcc_lo               // 00000039CE30: D5207C10 01AA0480
	.long 0xd7006a11                                           // 00000039CE38: D7006A11
	v_cndmask_b32_e32 v1, 0x10000, v1, vcc_lo                  // 00000039CE3C: 020202FF 00010000
	v_add_co_ci_u32_e64 v18, null, 0, v2, vcc_lo               // 00000039CE44: D5207C12 01AA0480
	s_clause 0x1                                               // 00000039CE4C: BF850001
	global_load_u16 v19, v[15:16], off                         // 00000039CE50: DC4A0000 137C000F
	global_load_u16 v17, v[17:18], off offset:1024             // 00000039CE58: DC4A0400 117C0011
	.long 0xd7006a0f                                           // 00000039CE60: D7006A0F
	v_cndmask_b32_e32 v1, 0x11000, v1, vcc_lo                  // 00000039CE64: 020202FF 00011000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039CE6C: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v2, vcc_lo               // 00000039CE70: D5207C10 01AA0480
	.long 0xd7006a01                                           // 00000039CE78: D7006A01
	v_cndmask_b32_e32 v1, 0x12000, v1, vcc_lo                  // 00000039CE7C: 020202FF 00012000
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000039CE84: D5207C02 01AA0480
	s_clause 0x1                                               // 00000039CE8C: BF850001
	global_load_u16 v15, v[15:16], off offset:2048             // 00000039CE90: DC4A0800 0F7C000F
	global_load_u16 v1, v[1:2], off offset:3072                // 00000039CE98: DC4A0C00 017C0001
	v_dual_add_f32 v2, v7, v11 :: v_dual_add_f32 v7, v8, v12   // 00000039CEA0: C9081707 02061908
	s_waitcnt lgkmcnt(0)                                       // 00000039CEA8: BF89FC07
	v_dual_add_f32 v8, v9, v13 :: v_dual_add_f32 v9, v10, v14  // 00000039CEAC: C9081B09 08081D0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039CEB4: BF870192
	v_bfe_u32 v10, v2, 16, 1                                   // 00000039CEB8: D610000A 02052102
	v_bfe_u32 v11, v7, 16, 1                                   // 00000039CEC0: D610000B 02052107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039CEC8: BF870213
	v_bfe_u32 v12, v8, 16, 1                                   // 00000039CECC: D610000C 02052108
	v_bfe_u32 v13, v9, 16, 1                                   // 00000039CED4: D610000D 02052109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039CEDC: BF870214
	v_add3_u32 v2, v2, v10, 0x7fff                             // 00000039CEE0: D6550002 03FE1502 00007FFF
	v_add3_u32 v7, v7, v11, 0x7fff                             // 00000039CEEC: D6550007 03FE1707 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039CEF8: BF870214
	v_add3_u32 v8, v8, v12, 0x7fff                             // 00000039CEFC: D6550008 03FE1908 00007FFF
	v_add3_u32 v9, v9, v13, 0x7fff                             // 00000039CF08: D6550009 03FE1B09 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039CF14: BF870113
	v_and_b32_e32 v7, 0xffff0000, v7                           // 00000039CF18: 360E0EFF FFFF0000
	v_and_b32_e32 v9, 0xffff0000, v9                           // 00000039CF20: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039CF28: BF870112
	v_mul_f32_e32 v7, 0xbfb8aa3b, v7                           // 00000039CF2C: 100E0EFF BFB8AA3B
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 00000039CF34: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000039CF3C: BF870122
	v_exp_f32_e32 v7, v7                                       // 00000039CF40: 7E0E4B07
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000039CF44: 360404FF FFFF0000
	v_exp_f32_e32 v9, v9                                       // 00000039CF4C: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000039CF50: BF870296
	v_dual_add_f32 v7, 1.0, v7 :: v_dual_and_b32 v8, 0xffff0000, v8// 00000039CF54: C9240EF2 070810FF FFFF0000
	v_dual_mul_f32 v2, 0xbfb8aa3b, v2 :: v_dual_add_f32 v9, 1.0, v9// 00000039CF60: C8C804FF 020812F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039CF6C: BF870192
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 00000039CF70: 101010FF BFB8AA3B
	v_div_scale_f32 v11, null, v7, v7, 1.0                     // 00000039CF78: D6FC7C0B 03CA0F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000039CF80: BF8701A3
	v_exp_f32_e32 v2, v2                                       // 00000039CF84: 7E044B02
	v_div_scale_f32 v22, s3, 1.0, v7, 1.0                      // 00000039CF88: D6FC0316 03CA0EF2
	v_exp_f32_e32 v8, v8                                       // 00000039CF90: 7E104B08
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 00000039CF94: D6FC7C0D 03CA1309
	v_rcp_f32_e32 v16, v11                                     // 00000039CF9C: 7E20550B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 00000039CFA0: BF8703A1
	v_rcp_f32_e32 v20, v13                                     // 00000039CFA4: 7E28550D
	v_add_f32_e32 v2, 1.0, v2                                  // 00000039CFA8: 060404F2
	v_add_f32_e32 v8, 1.0, v8                                  // 00000039CFAC: 061010F2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039CFB0: BF870196
	v_fma_f32 v25, -v11, v16, 1.0                              // 00000039CFB4: D6130019 23CA210B
	v_div_scale_f32 v10, null, v2, v2, 1.0                     // 00000039CFBC: D6FC7C0A 03CA0502
	v_div_scale_f32 v21, vcc_lo, 1.0, v2, 1.0                  // 00000039CFC4: D6FC6A15 03CA04F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000039CFCC: BF870294
	v_div_scale_f32 v12, null, v8, v8, 1.0                     // 00000039CFD0: D6FC7C0C 03CA1108
	v_fma_f32 v28, -v13, v20, 1.0                              // 00000039CFD8: D613001C 23CA290D
	v_div_scale_f32 v27, s4, 1.0, v8, 1.0                      // 00000039CFE0: D6FC041B 03CA10F2
	v_rcp_f32_e32 v14, v10                                     // 00000039CFE8: 7E1C550A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039CFEC: BF870113
	v_rcp_f32_e32 v18, v12                                     // 00000039CFF0: 7E24550C
	v_fmac_f32_e32 v20, v28, v20                               // 00000039CFF4: 5628291C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000039CFF8: BF870296
	v_fma_f32 v24, -v10, v14, 1.0                              // 00000039CFFC: D6130018 23CA1D0A
	v_fma_f32 v26, -v12, v18, 1.0                              // 00000039D004: D613001A 23CA250C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039D00C: BF8700A2
	v_fmac_f32_e32 v14, v24, v14                               // 00000039D010: 561C1D18
	v_div_scale_f32 v24, s5, 1.0, v9, 1.0                      // 00000039D014: D6FC0518 03CA12F2
	v_dual_fmac_f32 v18, v26, v18 :: v_dual_mul_f32 v29, v24, v20// 00000039D01C: C806251A 121C2918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039D024: BF870111
	v_mul_f32_e32 v28, v27, v18                                // 00000039D028: 1038251B
	v_fma_f32 v33, -v13, v29, v24                              // 00000039D02C: D6130021 24623B0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039D034: BF870112
	v_fma_f32 v32, -v12, v28, v27                              // 00000039D038: D6130020 246E390C
	v_fmac_f32_e32 v29, v33, v20                               // 00000039D040: 563A2921
	v_fmac_f32_e32 v16, v25, v16                               // 00000039D044: 56202119
	v_mul_f32_e32 v25, v21, v14                                // 00000039D048: 10321D15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039D04C: BF870214
	v_fmac_f32_e32 v28, v32, v18                               // 00000039D050: 56382520
	v_fma_f32 v13, -v13, v29, v24                              // 00000039D054: D613000D 24623B0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039D05C: BF870093
	v_fma_f32 v30, -v10, v25, v21                              // 00000039D060: D613001E 2456330A
	v_fmac_f32_e32 v25, v30, v14                               // 00000039D068: 56321D1E
	v_mul_f32_e32 v26, v22, v16                                // 00000039D06C: 10342116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039D070: BF870112
	v_fma_f32 v10, -v10, v25, v21                              // 00000039D074: D613000A 2456330A
	v_fma_f32 v31, -v11, v26, v22                              // 00000039D07C: D613001F 245A350B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039D084: BF870112
	v_div_fmas_f32 v10, v10, v14, v25                          // 00000039D088: D637000A 04661D0A
	v_fmac_f32_e32 v26, v31, v16                               // 00000039D090: 5634211F
	s_mov_b32 vcc_lo, s3                                       // 00000039D094: BEEA0003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039D098: BF870112
	v_div_fixup_f32 v2, v10, v2, 1.0                           // 00000039D09C: D6270002 03CA050A
	v_fma_f32 v11, -v11, v26, v22                              // 00000039D0A4: D613000B 245A350B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039D0AC: BF8700A1
	v_div_fmas_f32 v11, v11, v16, v26                          // 00000039D0B0: D637000B 046A210B
	s_mov_b32 vcc_lo, s4                                       // 00000039D0B8: BEEA0004
	v_div_fixup_f32 v7, v11, v7, 1.0                           // 00000039D0BC: D6270007 03CA0F0B
	v_bfe_u32 v11, v2, 16, 1                                   // 00000039D0C4: D610000B 02052102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039D0CC: BF870091
	v_add3_u32 v2, v2, v11, 0x7fff                             // 00000039D0D0: D6550002 03FE1702 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000039D0DC: 360404FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 00000039D0E4: BF8903F7
	v_lshlrev_b32_e32 v1, 16, v1                               // 00000039D0E8: 30020290
	v_fma_f32 v12, -v12, v28, v27                              // 00000039D0EC: D613000C 246E390C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000039D0F4: BF8701C1
	v_div_fmas_f32 v10, v12, v18, v28                          // 00000039D0F8: D637000A 0472250C
	s_mov_b32 vcc_lo, s5                                       // 00000039D100: BEEA0005
	v_div_fmas_f32 v12, v13, v20, v29                          // 00000039D104: D637000C 0476290D
	v_cmp_ne_u32_e32 vcc_lo, 1, v23                            // 00000039D10C: 7C9A2E81
	v_div_fixup_f32 v8, v10, v8, 1.0                           // 00000039D110: D6270008 03CA110A
	v_bfe_u32 v10, v7, 16, 1                                   // 00000039D118: D610000A 02052107
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000039D120: BF8701A4
	v_div_fixup_f32 v9, v12, v9, 1.0                           // 00000039D124: D6270009 03CA130C
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000039D12C: 8B6A6A7E
	v_bfe_u32 v11, v8, 16, 1                                   // 00000039D130: D610000B 02052108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000039D138: BF870233
	v_add3_u32 v7, v7, v10, 0x7fff                             // 00000039D13C: D6550007 03FE1507 00007FFF
	v_lshlrev_b32_e32 v10, 16, v19                             // 00000039D148: 30142690
	v_bfe_u32 v12, v9, 16, 1                                   // 00000039D14C: D610000C 02052109
	v_add3_u32 v8, v8, v11, 0x7fff                             // 00000039D154: D6550008 03FE1708 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000039D160: BF870004
	v_and_b32_e32 v7, 0xffff0000, v7                           // 00000039D164: 360E0EFF FFFF0000
	v_lshlrev_b32_e32 v11, 16, v17                             // 00000039D16C: 30162290
	v_fma_f32 v2, v2, v10, 0                                   // 00000039D170: D6130002 02021502
	v_add3_u32 v9, v9, v12, 0x7fff                             // 00000039D178: D6550009 03FE1909 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 00000039D184: 361010FF FFFF0000
	v_lshlrev_b32_e32 v10, 16, v15                             // 00000039D18C: 30141E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039D190: BF870093
	v_dual_fmac_f32 v2, v7, v11 :: v_dual_and_b32 v7, 0xffff0000, v9// 00000039D194: C8241707 020612FF FFFF0000
	v_fmac_f32_e32 v2, v8, v10                                 // 00000039D1A0: 56041508
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039D1A4: BF870091
	v_fmac_f32_e32 v2, v7, v1                                  // 00000039D1A8: 56040307
	v_mul_f32_e32 v1, 0x3e800000, v2                           // 00000039D1AC: 100204FF 3E800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039D1B4: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 00000039D1B8: D6100002 02052101
	v_add3_u32 v7, v1, v2, 0x7fff                              // 00000039D1C0: D6550007 03FE0501 00007FFF
	.long 0xd7000302                                           // 00000039D1CC: D7000302
	v_cndmask_b32_e32 v1, 0x3000, v3, vcc_lo                   // 00000039D1D0: 020206FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000039D1D8: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v4, s3                    // 00000039D1DC: D5207C03 000E0880
	global_store_d16_hi_b16 v[2:3], v7, off offset:3072        // 00000039D1E4: DC960C00 007C0702
	s_cbranch_vccnz 13                                         // 00000039D1EC: BFA4000D <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3d24>
	.long 0xd7006a02                                           // 00000039D1F0: D7006A02
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000039D1F4: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039D1F8: BF870111
	v_add_co_ci_u32_e64 v3, null, s11, v6, vcc_lo              // 00000039D1FC: D5207C03 01AA0C0B
	.long 0xd7006a02                                           // 00000039D204: D7006A02
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 00000039D208: 020204FF 00007000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000039D210: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000039D214: D5207C03 01AA0680
	global_store_b32 v[2:3], v1, off offset:2048               // 00000039D21C: DC6A0800 007C0102
	s_or_b32 exec_lo, exec_lo, s7                              // 00000039D224: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039D228: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000039D22C: 8B6A067E
	s_cbranch_vccz 1526                                        // 00000039D230: BFA305F6 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x550c>
	s_clause 0x3                                               // 00000039D234: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 00000039D238: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000039D240: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 00000039D248: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000039D250: F4000180 F8000118
	v_lshrrev_b32_e32 v5, 5, v0                                // 00000039D258: 320A0085
	v_dual_mov_b32 v42, 0 :: v_dual_and_b32 v41, 31, v0        // 00000039D25C: CA240080 2A28009F
	s_waitcnt lgkmcnt(0)                                       // 00000039D264: BF89FC07
	v_mov_b32_e32 v28, 0                                       // 00000039D268: 7E380280
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v27, 0             // 00000039D26C: CA100080 361A0080
	s_cmp_gt_i32 s3, 1                                         // 00000039D274: BF028103
	s_cselect_b32 s7, -1, 0                                    // 00000039D278: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000039D27C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 00000039D280: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039D284: BF870009
	s_and_b32 s4, s7, s4                                       // 00000039D288: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000039D28C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 00000039D290: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 00000039D298: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000039D29C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 00000039D2A0: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039D2A4: BF870009
	s_and_b32 s4, s7, s5                                       // 00000039D2A8: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000039D2AC: BF028303
	v_readfirstlane_b32 s5, v1                                 // 00000039D2B0: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 00000039D2B4: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000039D2B8: BF030602
	s_cselect_b32 s6, -1, 0                                    // 00000039D2BC: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000039D2C0: BF8704D9
	s_and_b32 s3, s3, s6                                       // 00000039D2C4: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000039D2C8: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000039D2CC: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 00000039D2D0: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000039D2D4: 98030483
	s_mulk_i32 s3, 0x48                                        // 00000039D2D8: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039D2DC: BF870009
	s_add_u32 s6, s0, s3                                       // 00000039D2E0: 80060300
	s_addc_u32 s7, s1, 0                                       // 00000039D2E4: 82078001
	s_clause 0x1                                               // 00000039D2E8: BF850001
	s_load_b64 s[4:5], s[6:7], 0x30                            // 00000039D2EC: F4040103 F8000030
	s_load_b32 s8, s[6:7], 0x40                                // 00000039D2F4: F4000203 F8000040
	s_waitcnt lgkmcnt(0)                                       // 00000039D2FC: BF89FC07
	.long 0xd451000e                                           // 00000039D300: D451000E
	v_cndmask_b32_e32 v0, s4, v137, vcc_lo                     // 00000039D304: 02011204
	s_and_b32 s0, s14, exec_lo                                 // 00000039D308: 8B007E0E
	s_cselect_b32 s3, 8, 2                                     // 00000039D30C: 98038288
	s_cselect_b32 s15, 3, 1                                    // 00000039D310: 980F8183
	v_cvt_f32_ubyte0_e32 v1, s3                                // 00000039D314: 7E022203
	s_sub_i32 s8, s2, s8                                       // 00000039D318: 81880802
	s_add_i32 s21, s3, -1                                      // 00000039D31C: 8115C103
	s_ashr_i32 s9, s8, 31                                      // 00000039D320: 86099F08
	s_and_b32 s11, s14, exec_lo                                // 00000039D324: 8B0B7E0E
	v_rcp_iflag_f32_e32 v2, v1                                 // 00000039D328: 7E045701
	s_cselect_b32 s20, 0, 2                                    // 00000039D32C: 98148280
	s_ashr_i32 s24, s19, 31                                    // 00000039D330: 86189F13
	s_lshl_b64 s[8:9], s[8:9], s20                             // 00000039D334: 84881408
	v_lshrrev_b32_e32 v43, s15, v5                             // 00000039D338: 32560A0F
	s_load_b64 s[0:1], s[6:7], null                            // 00000039D33C: F4040003 F8000000
	v_mov_b32_e32 v1, 0                                        // 00000039D344: 7E020280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000039D348: BF870292
	.long 0xd7000803                                           // 00000039D34C: D7000803
	v_cndmask_b32_e32 v1, s8, v43, vcc_lo                      // 00000039D350: 02025608
	v_readfirstlane_b32 s10, v2                                // 00000039D354: 7E140502
	v_add_co_ci_u32_e64 v4, null, s9, 0, s8                    // 00000039D358: D5207C04 00210009
	v_mov_b32_e32 v2, 0                                        // 00000039D360: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000039D364: BF870123
	s_mul_f32 s11, s10, 0x4f7ffffe                             // 00000039D368: A20BFF0A 4F7FFFFE
	s_lshr_b32 s10, s24, 27                                    // 00000039D370: 850A9B18
	v_cmp_gt_i64_e32 vcc_lo, s[4:5], v[3:4]                    // 00000039D374: 7CA80604
	s_add_u32 s10, s18, s10                                    // 00000039D378: 800A0A12
	s_cvt_u32_f32 s25, s11                                     // 00000039D37C: BE99670B
	s_addc_u32 s11, s19, 0                                     // 00000039D380: 820B8013
	s_sub_i32 s26, 0, s3                                       // 00000039D384: 819A0380
	s_lshr_b64 s[22:23], s[10:11], 5                           // 00000039D388: 8596850A
	s_mul_i32 s26, s26, s25                                    // 00000039D38C: 961A191A
	s_add_i32 s10, s21, s22                                    // 00000039D390: 810A1615
	s_mul_hi_u32 s11, s25, s26                                 // 00000039D394: 968B1A19
	s_abs_i32 s23, s10                                         // 00000039D398: BE97150A
	s_add_i32 s25, s25, s11                                    // 00000039D39C: 81190B19
	s_ashr_i32 s10, s10, 31                                    // 00000039D3A0: 860A9F0A
	s_mul_hi_u32 s11, s23, s25                                 // 00000039D3A4: 968B1917
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_and_b32 v44, s21, v5// 00000039D3A8: CA640680 032C0A15
	s_mul_i32 s25, s11, s3                                     // 00000039D3B0: 9619030B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039D3B4: BF870009
	s_sub_i32 s23, s23, s25                                    // 00000039D3B8: 81971917
	s_add_i32 s25, s11, 1                                      // 00000039D3BC: 8119810B
	s_sub_i32 s26, s23, s3                                     // 00000039D3C0: 819A0317
	s_cmp_ge_u32 s23, s3                                       // 00000039D3C4: BF090317
	s_cselect_b32 s8, s25, s11                                 // 00000039D3C8: 98080B19
	s_cselect_b32 s9, s26, s23                                 // 00000039D3CC: 9809171A
	s_add_i32 s11, s8, 1                                       // 00000039D3D0: 810B8108
	s_cmp_ge_u32 s9, s3                                        // 00000039D3D4: BF090309
	s_cselect_b32 s8, s11, s8                                  // 00000039D3D8: 9808080B
	s_lshr_b32 s9, s19, 31                                     // 00000039D3DC: 85099F13
	s_xor_b32 s8, s8, s10                                      // 00000039D3E0: 8D080A08
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039D3E4: BF870009
	s_sub_i32 s21, s8, s10                                     // 00000039D3E8: 81950A08
	s_add_u32 s8, s18, s9                                      // 00000039D3EC: 80080912
	s_addc_u32 s9, s19, 0                                      // 00000039D3F0: 82098013
	s_lshr_b32 s10, s24, 30                                    // 00000039D3F4: 850A9E18
	s_ashr_i64 s[8:9], s[8:9], 1                               // 00000039D3F8: 86888108
	s_add_u32 s10, s18, s10                                    // 00000039D3FC: 800A0A12
	s_addc_u32 s11, s19, 0                                     // 00000039D400: 820B8013
	s_lshr_b32 s23, s24, 28                                    // 00000039D404: 85179C18
	s_ashr_i64 s[10:11], s[10:11], 2                           // 00000039D408: 868A820A
	s_add_u32 s24, s18, s23                                    // 00000039D40C: 80181712
	s_addc_u32 s25, s19, 0                                     // 00000039D410: 82198013
	.long 0xd72c0005                                           // 00000039D414: D72C0005
	v_cndmask_b32_e32 v0, v44, v21, vcc_lo                     // 00000039D418: 02002B2C
	s_ashr_i64 s[24:25], s[24:25], 4                           // 00000039D41C: 86988418
	s_add_u32 s23, s10, s8                                     // 00000039D420: 8017080A
	s_addc_u32 s26, s11, s9                                    // 00000039D424: 821A090B
	s_add_u32 s23, s23, s24                                    // 00000039D428: 80171817
	s_addc_u32 s24, s26, s25                                   // 00000039D42C: 8218191A
	s_add_u32 s23, s23, 15                                     // 00000039D430: 80178F17
	s_addc_u32 s24, s24, 0                                     // 00000039D434: 82188018
	v_dual_cndmask_b32 v4, 0, v4 :: v_dual_add_nc_u32 v45, v5, v41// 00000039D438: CA600880 042C5305
	s_ashr_i32 s25, s24, 31                                    // 00000039D440: 86199F18
	v_add_nc_u32_e32 v6, s21, v5                               // 00000039D444: 4A0C0A15
	s_lshr_b32 s25, s25, 28                                    // 00000039D448: 85199C19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039D44C: BF870009
	s_add_u32 s21, s23, s25                                    // 00000039D450: 80151917
	s_addc_u32 s23, s24, 0                                     // 00000039D454: 82178018
	s_and_b32 s21, s21, -16                                    // 00000039D458: 8B15D015
	.long 0xd72c0007                                           // 00000039D45C: D72C0007
	v_cndmask_b32_e32 v1, s23, v3, vcc_lo                      // 00000039D460: 02020617
	.long 0xd72c0008                                           // 00000039D464: D72C0008
	v_cndmask_b32_e32 v1, s21, v4, vcc_lo                      // 00000039D468: 02020815
	s_waitcnt lgkmcnt(0)                                       // 00000039D46C: BF89FC07
	v_mad_u64_u32 v[25:26], null, s21, v3, s[0:1]              // 00000039D470: D6FE7C19 00020615
	v_mov_b32_e32 v3, 0                                        // 00000039D478: 7E060280
	v_min_i32_e32 v46, s22, v6                                 // 00000039D47C: 225C0C16
	v_mov_b32_e32 v4, 0                                        // 00000039D480: 7E080280
	s_delay_alu instid0(VALU_DEP_2)                            // 00000039D484: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v45, v46                          // 00000039D488: 7C825D2D
	v_add3_u32 v26, v7, v26, v8                                // 00000039D48C: D655001A 04223507
	s_and_saveexec_b32 s1, vcc_lo                              // 00000039D494: BE81206A
	s_cbranch_execz 39                                         // 00000039D498: BFA50027 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x4038>
	v_lshlrev_b32_e32 v1, 4, v45                               // 00000039D49C: 30025A84
	v_lshlrev_b32_e32 v4, 1, v45                               // 00000039D4A0: 30085A81
	v_lshlrev_b32_e32 v3, 3, v45                               // 00000039D4A4: 30065A83
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000039D4A8: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000039D4AC: 3404029F
	.long 0xd7000001                                           // 00000039D4B0: D7000001
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 00000039D4B4: 02020319
	v_and_b32_e32 v4, -4, v4                                   // 00000039D4B8: 360808C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039D4BC: BF870214
	v_ashrrev_i32_e32 v8, 31, v3                               // 00000039D4C0: 3410069F
	v_add_co_ci_u32_e64 v2, null, v26, v2, s0                  // 00000039D4C4: D5207C02 0002051A
	.long 0xd7000006                                           // 00000039D4CC: D7000006
	v_cndmask_b32_e32 v0, v25, v8, vcc_lo                      // 00000039D4D0: 02001119
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000039D4D4: BF8701A1
	v_add_co_ci_u32_e64 v7, null, s9, v26, s0                  // 00000039D4D8: D5207C07 00023409
	v_ashrrev_i32_e32 v11, 31, v4                              // 00000039D4E0: 3416089F
	.long 0xd7000009                                           // 00000039D4E4: D7000009
	v_cndmask_b32_e32 v0, v6, v10, vcc_lo                      // 00000039D4E8: 02001506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039D4EC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s11, v7, s0                 // 00000039D4F0: D5207C0A 00020E0B
	.long 0xd7000006                                           // 00000039D4F8: D7000006
	v_cndmask_b32_e32 v1, v6, v3, vcc_lo                       // 00000039D4FC: 02020706
	v_add_co_ci_u32_e64 v7, null, v7, v8, s0                   // 00000039D500: D5207C07 00021107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039D508: BF870094
	.long 0xd7000008                                           // 00000039D50C: D7000008
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 00000039D510: 02020909
	v_add_co_ci_u32_e64 v9, null, v10, v11, s0                 // 00000039D514: D5207C09 0002170A
	s_clause 0x2                                               // 00000039D51C: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 00000039D520: DC5E0000 017C0001
	global_load_b64 v[27:28], v[6:7], off                      // 00000039D528: DC560000 1B7C0006
	global_load_b32 v54, v[8:9], off                           // 00000039D530: DC520000 367C0008
	s_or_b32 exec_lo, exec_lo, s1                              // 00000039D538: 8C7E017E
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v48, 0             // 00000039D53C: CA100080 2F300080
	v_mov_b32_e32 v49, 0                                       // 00000039D544: 7E620280
	s_and_saveexec_b32 s1, vcc_lo                              // 00000039D548: BE81206A
	s_cbranch_execz 772                                        // 00000039D54C: BFA50304 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x4c60>
	.long 0xd7006a32                                           // 00000039D550: D7006A32
	v_cndmask_b32_e32 v0, v25, v8, vcc_lo                      // 00000039D554: 02001119
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000039D558: BF870231
	v_add_co_ci_u32_e64 v51, null, s9, v26, vcc_lo             // 00000039D55C: D5207C33 01AA3409
	v_dual_mov_b32 v47, 0 :: v_dual_lshlrev_b32 v6, 5, v41     // 00000039D564: CA220080 2F065285
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v7, 32, v45     // 00000039D56C: CA200080 2A065AA0
	.long 0xd7006a34                                           // 00000039D574: D7006A34
	v_cndmask_b32_e32 v0, v50, v10, vcc_lo                     // 00000039D578: 02001532
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039D57C: BF870211
	v_add_co_ci_u32_e64 v53, null, s11, v51, vcc_lo            // 00000039D580: D5207C35 01AA660B
	v_lshl_add_u32 v29, v5, 5, v6                              // 00000039D588: D646001D 04190B05
	s_delay_alu instid0(VALU_DEP_4)                            // 00000039D590: BF870004
	v_dual_mov_b32 v48, 0 :: v_dual_lshlrev_b32 v55, 4, v7     // 00000039D594: CA220080 30360E84
	v_dual_mov_b32 v49, 0 :: v_dual_lshlrev_b32 v56, 3, v7     // 00000039D59C: CA220080 31380E83
	s_waitcnt vmcnt(0)                                         // 00000039D5A4: BF8903F7
	v_dual_mov_b32 v58, v54 :: v_dual_lshlrev_b32 v57, 1, v7   // 00000039D5A8: CA220136 3A380E81
	s_mul_i32 s0, s19, 6                                       // 00000039D5B0: 96008613
	s_mul_hi_u32 s10, s18, 6                                   // 00000039D5B4: 968A8612
	s_lshl_b64 s[8:9], s[18:19], 2                             // 00000039D5B8: 84888212
	s_add_i32 s21, s10, s0                                     // 00000039D5BC: 8115000A
	s_mul_i32 s23, s18, 6                                      // 00000039D5C0: 96178612
	s_mov_b32 s22, 0                                           // 00000039D5C4: BE960080
	s_lshl_b64 s[10:11], s[18:19], 1                           // 00000039D5C8: 848A8112
	s_branch 700                                               // 00000039D5CC: BFA002BC <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x4bc0>
	s_or_b32 exec_lo, exec_lo, s18                             // 00000039D5D0: 8C7E127E
	v_ashrrev_i32_e32 v30, 31, v29                             // 00000039D5D4: 343C3A9F
	v_lshlrev_b32_e32 v91, 2, v27                              // 00000039D5D8: 30B63682
	v_lshrrev_b32_e32 v99, 4, v1                               // 00000039D5DC: 32C60284
	v_lshrrev_b32_e32 v100, 8, v1                              // 00000039D5E0: 32C80288
	v_lshrrev_b32_e32 v101, 2, v27                             // 00000039D5E4: 32CA3682
	.long 0xd73c0009                                           // 00000039D5E8: D73C0009
	v_cndmask_b32_e32 v1, 1, v29, vcc_lo                       // 00000039D5EC: 02023A81
	v_and_b32_e32 v114, 48, v91                                // 00000039D5F0: 36E4B6B0
	v_lshlrev_b32_e32 v30, 4, v27                              // 00000039D5F4: 303C3684
	v_and_b32_e32 v102, 48, v27                                // 00000039D5F8: 36CC36B0
	v_lshrrev_b32_e32 v103, 12, v1                             // 00000039D5FC: 32CE028C
	v_and_b32_e32 v101, 48, v101                               // 00000039D600: 36CACAB0
	.long 0xd7000021                                           // 00000039D604: D7000021
	v_cndmask_b32_e32 v1, s16, v9, vcc_lo                      // 00000039D608: 02021210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000039D60C: BF8701A1
	v_add_co_ci_u32_e64 v34, null, s17, v10, s0                // 00000039D610: D5207C22 00021411
	v_and_b32_e32 v30, 48, v30                                 // 00000039D618: 363C3CB0
	.long 0xd7000023                                           // 00000039D61C: D7000023
	v_cndmask_b32_e32 v0, v33, v10, vcc_lo                     // 00000039D620: 02001521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039D624: BF8700A1
	v_add_co_ci_u32_e64 v36, null, s11, v34, s0                // 00000039D628: D5207C24 0002440B
	.long 0xd7000027                                           // 00000039D630: D7000027
	v_cndmask_b32_e32 v0, v33, v8, vcc_lo                      // 00000039D634: 02001121
	v_add_co_ci_u32_e64 v40, null, s9, v34, s0                 // 00000039D638: D5207C28 00024409
	.long 0xd7000025                                           // 00000039D640: D7000025
	v_cndmask_b32_e32 v0, v33, v23, vcc_lo                     // 00000039D644: 02002F21
	s_delay_alu instid0(VALU_DEP_1)                            // 00000039D648: BF870001
	v_add_co_ci_u32_e64 v38, null, s21, v34, s0                // 00000039D64C: D5207C26 00024415
	s_clause 0xf                                               // 00000039D654: BF85000F
	global_load_b128 v[9:12], v[33:34], off                    // 00000039D658: DC5E0000 097C0021
	global_load_b128 v[13:16], v[35:36], off                   // 00000039D660: DC5E0000 0D7C0023
	global_load_b128 v[17:20], v[39:40], off                   // 00000039D668: DC5E0000 117C0027
	global_load_b128 v[21:24], v[37:38], off                   // 00000039D670: DC5E0000 157C0025
	global_load_b128 v[59:62], v[33:34], off offset:16         // 00000039D678: DC5E0010 3B7C0021
	global_load_b128 v[63:66], v[35:36], off offset:16         // 00000039D680: DC5E0010 3F7C0023
	global_load_b128 v[67:70], v[39:40], off offset:16         // 00000039D688: DC5E0010 437C0027
	global_load_b128 v[71:74], v[37:38], off offset:16         // 00000039D690: DC5E0010 477C0025
	global_load_b128 v[75:78], v[33:34], off offset:32         // 00000039D698: DC5E0020 4B7C0021
	global_load_b128 v[79:82], v[35:36], off offset:32         // 00000039D6A0: DC5E0020 4F7C0023
	global_load_b128 v[83:86], v[39:40], off offset:32         // 00000039D6A8: DC5E0020 537C0027
	global_load_b128 v[87:90], v[37:38], off offset:32         // 00000039D6B0: DC5E0020 577C0025
	global_load_b128 v[91:94], v[33:34], off offset:48         // 00000039D6B8: DC5E0030 5B7C0021
	global_load_b128 v[33:36], v[35:36], off offset:48         // 00000039D6C0: DC5E0030 217C0023
	global_load_b128 v[95:98], v[39:40], off offset:48         // 00000039D6C8: DC5E0030 5F7C0027
	global_load_b128 v[37:40], v[37:38], off offset:48         // 00000039D6D0: DC5E0030 257C0025
	v_and_or_b32 v30, v1, 15, v30                              // 00000039D6D8: D657001E 04791F01
	v_and_or_b32 v99, v99, 15, v114                            // 00000039D6E0: D6570063 05C91F63
	v_and_or_b32 v100, v100, 15, v102                          // 00000039D6E8: D6570064 05991F64
	v_and_or_b32 v101, v103, 15, v101                          // 00000039D6F0: D6570065 05951F67
	.long 0x7fd03880                                           // 00000039D6F8: 7FD03880
	v_cvt_f32_ubyte0_e32 v30, v30                              // 00000039D6FC: 7E3C231E
	v_cvt_f32_ubyte0_e32 v99, v99                              // 00000039D700: 7EC62363
	v_cvt_f32_ubyte0_e32 v100, v100                            // 00000039D704: 7EC82364
	v_cvt_f32_ubyte0_e32 v101, v101                            // 00000039D708: 7ECA2365
	v_lshrrev_b32_e32 v105, 4, v27                             // 00000039D70C: 32D23684
	v_fma_mix_f32 v30, v30, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039D710: CC20601E 14DA6D1E
	v_fma_mix_f32 v99, v99, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039D718: CC206063 14DA6D63
	v_fma_mix_f32 v100, v100, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039D720: CC206064 14DA6D64
	v_fma_mix_f32 v101, v101, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039D728: CC206065 14DA6D65
	v_lshrrev_b32_e32 v106, 6, v27                             // 00000039D730: 32D43686
	v_bfe_u32 v114, v30, 16, 1                                 // 00000039D734: D6100072 0205211E
	v_bfe_u32 v116, v99, 16, 1                                 // 00000039D73C: D6100074 02052163
	v_lshrrev_b32_e32 v107, 8, v27                             // 00000039D744: 32D63688
	v_bfe_u32 v118, v101, 16, 1                                // 00000039D748: D6100076 02052165
	v_and_b32_e32 v105, 48, v105                               // 00000039D750: 36D2D2B0
	v_add3_u32 v30, v30, v114, 0x7fff                          // 00000039D754: D655001E 03FEE51E 00007FFF
	v_bfe_u32 v114, v100, 16, 1                                // 00000039D760: D6100072 02052164
	v_add3_u32 v99, v99, v116, 0x7fff                          // 00000039D768: D6550063 03FEE963 00007FFF
	v_add3_u32 v101, v101, v118, 0x7fff                        // 00000039D774: D6550065 03FEED65 00007FFF
	v_lshrrev_b32_e32 v108, 20, v1                             // 00000039D780: 32D80294
	.long 0x7ed0399e                                           // 00000039D784: 7ED0399E
	v_add3_u32 v30, v100, v114, 0x7fff                         // 00000039D788: D655001E 03FEE564 00007FFF
	v_lshrrev_b32_e32 v109, 24, v1                             // 00000039D794: 32DA0298
	v_and_b32_e32 v106, 48, v106                               // 00000039D798: 36D4D4B0
	v_and_b32_e32 v107, 48, v107                               // 00000039D79C: 36D6D6B0
	v_and_or_b32 v99, 0xffff0000, v99, v104                    // 00000039D7A0: D6570063 05A2C6FF FFFF0000
	.long 0x7ed0399e                                           // 00000039D7AC: 7ED0399E
	v_lshrrev_b32_e32 v110, 28, v1                             // 00000039D7B0: 32DC029C
	v_lshrrev_b32_e32 v111, 10, v27                            // 00000039D7B4: 32DE368A
	v_and_or_b32 v106, v108, 15, v106                          // 00000039D7B8: D657006A 05A91F6C
	v_and_or_b32 v107, v109, 15, v107                          // 00000039D7C0: D657006B 05AD1F6D
	v_and_or_b32 v101, 0xffff0000, v101, v104                  // 00000039D7C8: D6570065 05A2CAFF FFFF0000
	.long 0x7ed03981                                           // 00000039D7D4: 7ED03981
	v_and_or_b32 v109, v111, 48, v110                          // 00000039D7D8: D657006D 05B9616F
	v_cvt_f32_ubyte0_e32 v106, v106                            // 00000039D7E0: 7ED4236A
	v_cvt_f32_ubyte0_e32 v107, v107                            // 00000039D7E4: 7ED6236B
	v_lshrrev_b32_e32 v102, 8, v2                              // 00000039D7E8: 32CC0488
	v_and_or_b32 v105, v104, 15, v105                          // 00000039D7EC: D6570069 05A51F68
	v_cvt_f32_ubyte0_e32 v109, v109                            // 00000039D7F4: 7EDA236D
	v_fma_mix_f32 v106, v106, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039D7F8: CC20606A 14DA6D6A
	v_fma_mix_f32 v107, v107, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039D800: CC20606B 14DA6D6B
	v_lshrrev_b32_e32 v117, 18, v27                            // 00000039D808: 32EA3692
	v_cvt_f32_ubyte0_e32 v105, v105                            // 00000039D80C: 7ED22369
	v_fma_mix_f32 v109, v109, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039D810: CC20606D 14DA6D6D
	v_bfe_u32 v124, v106, 16, 1                                // 00000039D818: D610007C 0205216A
	v_bfe_u32 v125, v107, 16, 1                                // 00000039D820: D610007D 0205216B
	v_lshrrev_b32_e32 v115, 12, v2                             // 00000039D828: 32E6048C
	v_fma_mix_f32 v105, v105, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039D82C: CC206069 14DA6D69
	v_and_b32_e32 v117, 48, v117                               // 00000039D834: 36EAEAB0
	v_add3_u32 v106, v106, v124, 0x7fff                        // 00000039D838: D655006A 03FEF96A 00007FFF
	v_bfe_u32 v124, v109, 16, 1                                // 00000039D844: D610007C 0205216D
	v_add3_u32 v107, v107, v125, 0x7fff                        // 00000039D84C: D655006B 03FEFB6B 00007FFF
	v_bfe_u32 v111, v105, 16, 1                                // 00000039D858: D610006F 02052169
	v_lshrrev_b32_e32 v100, 24, v27                            // 00000039D860: 32C83698
	v_lshlrev_b32_e32 v121, 2, v28                             // 00000039D864: 30F23882
	v_add3_u32 v109, v109, v124, 0x7fff                        // 00000039D868: D655006D 03FEF96D 00007FFF
	v_and_or_b32 v115, v115, 15, v117                          // 00000039D874: D6570073 05D51F73
	v_add3_u32 v105, v105, v111, 0x7fff                        // 00000039D87C: D6550069 03FEDF69 00007FFF
	v_lshrrev_b32_e32 v116, 24, v2                             // 00000039D888: 32E80498
	v_lshrrev_b32_e32 v120, 4, v3                              // 00000039D88C: 32F00684
	v_lshrrev_b32_e32 v123, 2, v28                             // 00000039D890: 32F63882
	v_and_b32_e32 v100, 48, v100                               // 00000039D894: 36C8C8B0
	.long 0x7ed039e9                                           // 00000039D898: 7ED039E9
	v_lshrrev_b32_e32 v105, 12, v28                            // 00000039D89C: 32D2388C
	v_and_b32_e32 v121, 48, v121                               // 00000039D8A0: 36F2F2B0
	v_cvt_f32_ubyte0_e32 v115, v115                            // 00000039D8A4: 7EE62373
	v_lshrrev_b32_e32 v110, 12, v3                             // 00000039D8A8: 32DC068C
	v_and_or_b32 v106, 0xffff0000, v106, v104                  // 00000039D8AC: D657006A 05A2D4FF FFFF0000
	.long 0x7ed039eb                                           // 00000039D8B8: 7ED039EB
	v_and_b32_e32 v107, 15, v4                                 // 00000039D8BC: 36D6088F
	v_and_b32_e32 v123, 48, v123                               // 00000039D8C0: 36F6F6B0
	v_and_or_b32 v100, v116, 15, v100                          // 00000039D8C4: D6570064 05911F74
	v_and_or_b32 v116, v120, 15, v121                          // 00000039D8CC: D6570074 05E51F78
	v_and_or_b32 v109, 0xffff0000, v109, v104                  // 00000039D8D4: D657006D 05A2DAFF FFFF0000
	.long 0x7ed0399b                                           // 00000039D8E0: 7ED0399B
	v_and_or_b32 v105, v105, 48, v107                          // 00000039D8E4: D6570069 05AD6169
	v_fma_mix_f32 v115, v115, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039D8EC: CC206073 14DA6D73
	v_and_or_b32 v110, v110, 15, v123                          // 00000039D8F4: D657006E 05ED1F6E
	v_lshrrev_b32_e32 v103, 20, v27                            // 00000039D8FC: 32CE3694
	v_and_b32_e32 v107, 48, v104                               // 00000039D900: 36D6D0B0
	v_lshrrev_b32_e32 v118, 28, v2                             // 00000039D904: 32EC049C
	v_bfe_u32 v123, v115, 16, 1                                // 00000039D908: D610007B 02052173
	v_lshrrev_b32_e32 v1, 26, v27                              // 00000039D910: 3202369A
	v_lshrrev_b32_e32 v30, 22, v27                             // 00000039D914: 323C3696
	v_and_or_b32 v102, v102, 15, v107                          // 00000039D918: D6570066 05AD1F66
	v_lshrrev_b32_e32 v108, 8, v3                              // 00000039D920: 32D80688
	v_add3_u32 v115, v115, v123, 0x7fff                        // 00000039D924: D6550073 03FEF773 00007FFF
	v_and_b32_e32 v122, 48, v28                                // 00000039D930: 36F438B0
	v_and_or_b32 v1, v1, 48, v118                              // 00000039D934: D6570001 05D96101
	v_cvt_f32_ubyte0_e32 v102, v102                            // 00000039D93C: 7ECC2366
	v_and_b32_e32 v103, 48, v103                               // 00000039D940: 36CECEB0
	v_lshrrev_b32_e32 v114, 20, v2                             // 00000039D944: 32E40494
	v_lshlrev_b32_e32 v119, 4, v28                             // 00000039D948: 30EE3884
	v_lshrrev_b32_e32 v111, 8, v28                             // 00000039D94C: 32DE3888
	v_fma_mix_f32 v102, v102, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039D950: CC206066 14DA6D66
	v_and_or_b32 v108, v108, 15, v122                          // 00000039D958: D657006C 05E91F6C
	v_and_b32_e32 v30, 48, v30                                 // 00000039D960: 363C3CB0
	v_cvt_f32_ubyte0_e32 v1, v1                                // 00000039D964: 7E022301
	v_lshrrev_b32_e32 v113, 14, v27                            // 00000039D968: 32E2368E
	v_bfe_u32 v120, v102, 16, 1                                // 00000039D96C: D6100078 02052166
	v_lshrrev_b32_e32 v117, 24, v3                             // 00000039D974: 32EA0698
	v_and_or_b32 v30, v114, 15, v30                            // 00000039D978: D657001E 04791F72
	v_lshrrev_b32_e32 v121, 14, v28                            // 00000039D980: 32F2388E
	v_and_b32_e32 v119, 48, v119                               // 00000039D984: 36EEEEB0
	v_add3_u32 v102, v102, v120, 0x7fff                        // 00000039D988: D6550066 03FEF166 00007FFF
	v_and_b32_e32 v111, 48, v111                               // 00000039D994: 36DEDEB0
	v_cvt_f32_ubyte0_e32 v108, v108                            // 00000039D998: 7ED8236C
	v_fma_mix_f32 v1, v1, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039D99C: CC206001 14DA6D01
	v_lshrrev_b32_e32 v112, 4, v2                              // 00000039D9A4: 32E00484
	.long 0x7ed039e6                                           // 00000039D9A8: 7ED039E6
	v_lshrrev_b32_e32 v114, 4, v4                              // 00000039D9AC: 32E40884
	v_and_b32_e32 v113, 48, v113                               // 00000039D9B0: 36E2E2B0
	v_and_b32_e32 v121, 48, v121                               // 00000039D9B4: 36F2F2B0
	v_and_or_b32 v119, v3, 15, v119                            // 00000039D9B8: D6570077 05DD1F03
	v_and_or_b32 v115, 0xffff0000, v115, v104                  // 00000039D9C0: D6570073 05A2E6FF FFFF0000
	.long 0x7ed03982                                           // 00000039D9CC: 7ED03982
	v_and_or_b32 v111, v117, 15, v111                          // 00000039D9D0: D657006F 05BD1F75
	v_cvt_f32_ubyte0_e32 v30, v30                              // 00000039D9D8: 7E3C231E
	v_cvt_f32_ubyte0_e32 v100, v100                            // 00000039D9DC: 7EC82364
	v_fma_mix_f32 v108, v108, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039D9E0: CC20606C 14DA6D6C
	v_and_or_b32 v103, v104, 15, v103                          // 00000039D9E8: D6570067 059D1F68
	v_bfe_u32 v117, v1, 16, 1                                  // 00000039D9F0: D6100075 02052101
	v_and_or_b32 v112, v112, 15, v113                          // 00000039D9F8: D6570070 05C51F70
	v_and_or_b32 v113, v114, 15, v121                          // 00000039DA00: D6570071 05E51F72
	v_cvt_f32_ubyte0_e32 v114, v119                            // 00000039DA08: 7EE42377
	v_cvt_f32_ubyte0_e32 v103, v103                            // 00000039DA0C: 7ECE2367
	v_fma_mix_f32 v30, v30, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DA10: CC20601E 14DA6D1E
	v_fma_mix_f32 v100, v100, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DA18: CC206064 14DA6D64
	v_bfe_u32 v119, v108, 16, 1                                // 00000039DA20: D6100077 0205216C
	v_add3_u32 v1, v1, v117, 0x7fff                            // 00000039DA28: D6550001 03FEEB01 00007FFF
	v_fma_mix_f32 v103, v103, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DA34: CC206067 14DA6D67
	v_cvt_f32_ubyte0_e32 v116, v116                            // 00000039DA3C: 7EE82374
	v_fma_mix_f32 v114, v114, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DA40: CC206072 14DA6D72
	v_bfe_u32 v121, v30, 16, 1                                 // 00000039DA48: D6100079 0205211E
	v_add3_u32 v108, v108, v119, 0x7fff                        // 00000039DA50: D655006C 03FEEF6C 00007FFF
	v_bfe_u32 v117, v103, 16, 1                                // 00000039DA5C: D6100075 02052167
	v_bfe_u32 v119, v100, 16, 1                                // 00000039DA64: D6100077 02052164
	v_fma_mix_f32 v116, v116, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DA6C: CC206074 14DA6D74
	v_add3_u32 v30, v30, v121, 0x7fff                          // 00000039DA74: D655001E 03FEF31E 00007FFF
	v_bfe_u32 v121, v114, 16, 1                                // 00000039DA80: D6100079 02052172
	v_add3_u32 v103, v103, v117, 0x7fff                        // 00000039DA88: D6550067 03FEEB67 00007FFF
	v_add3_u32 v100, v100, v119, 0x7fff                        // 00000039DA94: D6550064 03FEEF64 00007FFF
	v_cvt_f32_ubyte0_e32 v110, v110                            // 00000039DAA0: 7EDC236E
	v_bfe_u32 v119, v116, 16, 1                                // 00000039DAA4: D6100077 02052174
	v_add3_u32 v114, v114, v121, 0x7fff                        // 00000039DAAC: D6550072 03FEF372 00007FFF
	.long 0x7ed039e7                                           // 00000039DAB8: 7ED039E7
	v_lshrrev_b32_e32 v125, 28, v3                             // 00000039DABC: 32FA069C
	v_fma_mix_f32 v110, v110, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DAC0: CC20606E 14DA6D6E
	v_lshrrev_b32_e32 v124, 10, v28                            // 00000039DAC8: 32F8388A
	v_add3_u32 v103, v116, v119, 0x7fff                        // 00000039DACC: D6550067 03FEEF74 00007FFF
	v_and_or_b32 v30, 0xffff0000, v30, v104                    // 00000039DAD8: D657001E 05A23CFF FFFF0000
	.long 0x7ed039e4                                           // 00000039DAE4: 7ED039E4
	v_lshrrev_b32_e32 v118, 28, v4                             // 00000039DAE8: 32EC089C
	v_lshrrev_b32_e32 v122, 26, v28                            // 00000039DAEC: 32F4389A
	v_and_or_b32 v124, v124, 48, v125                          // 00000039DAF0: D657007C 05F5617C
	v_lshrrev_b32_e32 v125, 4, v28                             // 00000039DAF8: 32FA3884
	v_and_or_b32 v1, 0xffff0000, v1, v104                      // 00000039DAFC: D6570001 05A202FF FFFF0000
	.long 0x7ed039f2                                           // 00000039DB08: 7ED039F2
	v_bfe_u32 v114, v110, 16, 1                                // 00000039DB0C: D6100072 0205216E
	v_lshrrev_b32_e32 v107, 6, v28                             // 00000039DB14: 32D63886
	v_lshrrev_b32_e32 v117, 22, v28                            // 00000039DB18: 32EA3896
	v_and_or_b32 v118, v122, 48, v118                          // 00000039DB1C: D6570076 05D9617A
	v_and_or_b32 v103, 0xffff0000, v103, v104                  // 00000039DB24: D6570067 05A2CEFF FFFF0000
	v_add3_u32 v110, v110, v114, 0x7fff                        // 00000039DB30: D655006E 03FEE56E 00007FFF
	.long 0x7ed039ec                                           // 00000039DB3C: 7ED039EC
	v_lshrrev_b32_e32 v122, 20, v3                             // 00000039DB40: 32F40694
	v_and_b32_e32 v107, 48, v107                               // 00000039DB44: 36D6D6B0
	v_lshrrev_b32_e32 v102, 20, v4                             // 00000039DB48: 32CC0894
	v_and_b32_e32 v119, 48, v125                               // 00000039DB4C: 36EEFAB0
	v_and_b32_e32 v117, 48, v117                               // 00000039DB50: 36EAEAB0
	v_and_or_b32 v110, 0xffff0000, v110, v104                  // 00000039DB54: D657006E 05A2DCFF FFFF0000
	.long 0x7ed03983                                           // 00000039DB60: 7ED03983
	v_and_or_b32 v107, v122, 15, v107                          // 00000039DB64: D657006B 05AD1F7A
	v_lshrrev_b32_e32 v122, 18, v28                            // 00000039DB6C: 32F43892
	v_and_or_b32 v102, v102, 15, v117                          // 00000039DB70: D6570066 05D51F66
	v_lshrrev_b32_e32 v120, 12, v4                             // 00000039DB78: 32F0088C
	v_and_or_b32 v117, v104, 15, v119                          // 00000039DB7C: D6570075 05DD1F68
	v_lshrrev_b32_e32 v27, 12, v27                             // 00000039DB84: 3236368C
	v_and_b32_e32 v122, 48, v122                               // 00000039DB88: 36F4F4B0
	v_cvt_f32_ubyte0_e32 v107, v107                            // 00000039DB8C: 7ED6236B
	v_cvt_f32_ubyte0_e32 v111, v111                            // 00000039DB90: 7EDE236F
	v_cvt_f32_ubyte0_e32 v117, v117                            // 00000039DB94: 7EEA2375
	v_lshrrev_b32_e32 v123, 24, v28                            // 00000039DB98: 32F63898
	v_and_or_b32 v120, v120, 15, v122                          // 00000039DB9C: D6570078 05E91F78
	v_and_b32_e32 v27, 48, v27                                 // 00000039DBA4: 363636B0
	v_cvt_f32_ubyte0_e32 v124, v124                            // 00000039DBA8: 7EF8237C
	v_fma_mix_f32 v117, v117, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DBAC: CC206075 14DA6D75
	v_fma_mix_f32 v107, v107, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DBB4: CC20606B 14DA6D6B
	v_cvt_f32_ubyte0_e32 v119, v120                            // 00000039DBBC: 7EEE2378
	v_fma_mix_f32 v111, v111, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DBC0: CC20606F 14DA6D6F
	v_lshrrev_b32_e32 v121, 24, v4                             // 00000039DBC8: 32F20898
	v_bfe_u32 v120, v117, 16, 1                                // 00000039DBCC: D6100078 02052175
	v_and_b32_e32 v123, 48, v123                               // 00000039DBD4: 36F6F6B0
	v_and_or_b32 v2, v2, 15, v27                               // 00000039DBD8: D6570002 046D1F02
	v_cvt_f32_ubyte0_e32 v27, v105                             // 00000039DBE0: 7E362369
	v_cvt_f32_ubyte0_e32 v105, v118                            // 00000039DBE4: 7ED22376
	v_add3_u32 v117, v117, v120, 0x7fff                        // 00000039DBE8: D6550075 03FEF175 00007FFF
	v_fma_mix_f32 v118, v124, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DBF4: CC206076 14DA6D7C
	v_bfe_u32 v122, v107, 16, 1                                // 00000039DBFC: D610007A 0205216B
	v_and_or_b32 v3, v121, 15, v123                            // 00000039DC04: D6570003 05ED1F79
	v_cvt_f32_ubyte0_e32 v2, v2                                // 00000039DC0C: 7E042302
	.long 0x7ed039f5                                           // 00000039DC10: 7ED039F5
	v_bfe_u32 v117, v111, 16, 1                                // 00000039DC14: D6100075 0205216F
	v_bfe_u32 v121, v118, 16, 1                                // 00000039DC1C: D6100079 02052176
	v_add3_u32 v107, v107, v122, 0x7fff                        // 00000039DC24: D655006B 03FEF56B 00007FFF
	v_fma_mix_f32 v27, v27, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DC30: CC20601B 14DA6D1B
	v_cvt_f32_ubyte0_e32 v112, v112                            // 00000039DC38: 7EE02370
	v_add3_u32 v111, v111, v117, 0x7fff                        // 00000039DC3C: D655006F 03FEEB6F 00007FFF
	v_cvt_f32_ubyte0_e32 v113, v113                            // 00000039DC48: 7EE22371
	v_fma_mix_f32 v119, v119, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DC4C: CC206077 14DA6D77
	v_fma_mix_f32 v2, v2, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DC54: CC206002 14DA6D02
	v_add3_u32 v117, v118, v121, 0x7fff                        // 00000039DC5C: D6550075 03FEF376 00007FFF
	v_and_or_b32 v107, 0xffff0000, v107, v104                  // 00000039DC68: D657006B 05A2D6FF FFFF0000
	.long 0x7ed039ef                                           // 00000039DC74: 7ED039EF
	v_bfe_u32 v120, v27, 16, 1                                 // 00000039DC78: D6100078 0205211B
	v_fma_mix_f32 v112, v112, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DC80: CC206070 14DA6D70
	v_fma_mix_f32 v113, v113, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DC88: CC206071 14DA6D71
	v_bfe_u32 v118, v119, 16, 1                                // 00000039DC90: D6100076 02052177
	v_bfe_u32 v121, v2, 16, 1                                  // 00000039DC98: D6100079 02052102
	v_and_or_b32 v117, 0xffff0000, v117, v104                  // 00000039DCA0: D6570075 05A2EAFF FFFF0000
	.long 0x7ed0399c                                           // 00000039DCAC: 7ED0399C
	v_lshrrev_b32_e32 v100, 8, v4                              // 00000039DCB0: 32C80888
	v_fma_mix_f32 v105, v105, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DCB4: CC206069 14DA6D69
	v_cvt_f32_ubyte0_e32 v102, v102                            // 00000039DCBC: 7ECC2366
	v_cvt_f32_ubyte0_e32 v3, v3                                // 00000039DCC0: 7E062303
	v_add3_u32 v27, v27, v120, 0x7fff                          // 00000039DCC4: D655001B 03FEF11B 00007FFF
	v_bfe_u32 v111, v112, 16, 1                                // 00000039DCD0: D610006F 02052170
	v_bfe_u32 v120, v113, 16, 1                                // 00000039DCD8: D6100078 02052171
	v_add3_u32 v118, v119, v118, 0x7fff                        // 00000039DCE0: D6550076 03FEED77 00007FFF
	v_add3_u32 v2, v2, v121, 0x7fff                            // 00000039DCEC: D6550002 03FEF302 00007FFF
	v_and_b32_e32 v119, 48, v104                               // 00000039DCF8: 36EED0B0
	.long 0x7fd839e8                                           // 00000039DCFC: 7FD839E8
	v_bfe_u32 v122, v105, 16, 1                                // 00000039DD00: D610007A 02052169
	v_fma_mix_f32 v102, v102, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DD08: CC206066 14DA6D66
	v_fma_mix_f32 v3, v3, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DD10: CC206003 14DA6D03
	v_add3_u32 v111, v112, v111, 0x7fff                        // 00000039DD18: D655006F 03FEDF70 00007FFF
	v_add3_u32 v112, v113, v120, 0x7fff                        // 00000039DD24: D6550070 03FEF171 00007FFF
	.long 0x7ed8399b                                           // 00000039DD30: 7ED8399B
	.long 0x7ee43982                                           // 00000039DD34: 7EE43982
	v_and_or_b32 v2, v100, 15, v119                            // 00000039DD38: D6570002 05DD1F64
	v_lshrrev_b32_e32 v116, 20, v28                            // 00000039DD40: 32E83894
	v_add3_u32 v105, v105, v122, 0x7fff                        // 00000039DD44: D6550069 03FEF569 00007FFF
	v_bfe_u32 v28, v102, 16, 1                                 // 00000039DD50: D610001C 02052166
	v_bfe_u32 v122, v3, 16, 1                                  // 00000039DD58: D610007A 02052103
	v_and_or_b32 v108, 0xffff0000, v112, v108                  // 00000039DD60: D657006C 05B2E0FF FFFF0000
	v_cvt_f32_ubyte0_e32 v112, v2                              // 00000039DD6C: 7EE02302
	s_waitcnt vmcnt(18)                                        // 00000039DD70: BF894BF7
	v_mov_b32_e32 v2, v6                                       // 00000039DD74: 7E040306
	v_add3_u32 v100, v102, v28, 0x7fff                         // 00000039DD78: D6550064 03FE3966 00007FFF
	v_add3_u32 v102, v3, v122, 0x7fff                          // 00000039DD84: D6550066 03FEF503 00007FFF
	v_mov_b32_e32 v3, v7                                       // 00000039DD90: 7E060307
	v_fma_mix_f32 v6, v112, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DD94: CC206006 14DA6D70
	.long 0x7fe439e8                                           // 00000039DD9C: 7FE439E8
	v_and_b32_e32 v116, 48, v116                               // 00000039DDA0: 36E8E8B0
	v_add_nc_u32_e32 v55, 0x200, v55                           // 00000039DDA4: 4A6E6EFF 00000200
	v_add_nc_u32_e32 v56, 0x100, v56                           // 00000039DDAC: 4A7070FF 00000100
	v_add_nc_u32_e32 v57, 64, v57                              // 00000039DDB4: 4A7272C0
	v_and_or_b32 v111, 0xffff0000, v111, v114                  // 00000039DDB8: D657006F 05CADEFF FFFF0000
	v_add_nc_u32_e32 v29, 0x400, v29                           // 00000039DDC4: 4A3A3AFF 00000400
	s_waitcnt vmcnt(17)                                        // 00000039DDCC: BF8947F7
	v_dual_mov_b32 v27, v31 :: v_dual_mov_b32 v28, v32         // 00000039DDD0: CA10011F 1B1C0120
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000039DDD8: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039DDDC: BF870009
	s_or_b32 s22, s0, s22                                      // 00000039DDE0: 8C161600
	s_waitcnt vmcnt(15)                                        // 00000039DDE4: BF893FF7
	v_dot2_f32_bf16 v7, v9, v99, 0                             // 00000039DDE8: CC1A4007 1A02C709
	s_waitcnt vmcnt(14)                                        // 00000039DDF0: BF893BF7
	v_dot2_f32_bf16 v9, v13, v99, 0                            // 00000039DDF4: CC1A4009 1A02C70D
	s_waitcnt vmcnt(13)                                        // 00000039DDFC: BF8937F7
	v_dot2_f32_bf16 v13, v17, v99, 0                           // 00000039DE00: CC1A400D 1A02C711
	s_waitcnt vmcnt(12)                                        // 00000039DE08: BF8933F7
	v_dot2_f32_bf16 v17, v21, v99, 0                           // 00000039DE0C: CC1A4011 1A02C715
	v_bfe_u32 v21, v6, 16, 1                                   // 00000039DE14: D6100015 02052106
	v_dot2_f32_bf16 v7, v10, v101, v7                          // 00000039DE1C: CC1A4007 1C1ECB0A
	v_dot2_f32_bf16 v9, v14, v101, v9                          // 00000039DE24: CC1A4009 1C26CB0E
	v_dot2_f32_bf16 v10, v18, v101, v13                        // 00000039DE2C: CC1A400A 1C36CB12
	v_dot2_f32_bf16 v13, v22, v101, v17                        // 00000039DE34: CC1A400D 1C46CB16
	v_add3_u32 v6, v6, v21, 0x7fff                             // 00000039DE3C: D6550006 03FE2B06 00007FFF
	v_dot2_f32_bf16 v7, v11, v106, v7                          // 00000039DE48: CC1A4007 1C1ED50B
	v_dot2_f32_bf16 v9, v15, v106, v9                          // 00000039DE50: CC1A4009 1C26D50F
	v_dot2_f32_bf16 v10, v19, v106, v10                        // 00000039DE58: CC1A400A 1C2AD513
	v_dot2_f32_bf16 v11, v23, v106, v13                        // 00000039DE60: CC1A400B 1C36D517
	.long 0x7ed03986                                           // 00000039DE68: 7ED03986
	v_dot2_f32_bf16 v6, v12, v109, v7                          // 00000039DE6C: CC1A4006 1C1EDB0C
	v_dot2_f32_bf16 v7, v16, v109, v9                          // 00000039DE74: CC1A4007 1C26DB10
	v_dot2_f32_bf16 v9, v20, v109, v10                         // 00000039DE7C: CC1A4009 1C2ADB14
	v_dot2_f32_bf16 v10, v24, v109, v11                        // 00000039DE84: CC1A400A 1C2EDB18
	v_and_or_b32 v11, 0xffff0000, v118, v104                   // 00000039DE8C: D657000B 05A2ECFF FFFF0000
	s_waitcnt vmcnt(11)                                        // 00000039DE98: BF892FF7
	v_dot2_f32_bf16 v6, v59, v111, v6                          // 00000039DE9C: CC1A4006 1C1ADF3B
	s_waitcnt vmcnt(10)                                        // 00000039DEA4: BF892BF7
	v_dot2_f32_bf16 v7, v63, v111, v7                          // 00000039DEA8: CC1A4007 1C1EDF3F
	s_waitcnt vmcnt(9)                                         // 00000039DEB0: BF8927F7
	v_dot2_f32_bf16 v9, v67, v111, v9                          // 00000039DEB4: CC1A4009 1C26DF43
	s_waitcnt vmcnt(8)                                         // 00000039DEBC: BF8923F7
	v_dot2_f32_bf16 v10, v71, v111, v10                        // 00000039DEC0: CC1A400A 1C2ADF47
	.long 0x7ed03984                                           // 00000039DEC8: 7ED03984
	v_dot2_f32_bf16 v4, v60, v115, v6                          // 00000039DECC: CC1A4004 1C1AE73C
	v_dot2_f32_bf16 v6, v64, v115, v7                          // 00000039DED4: CC1A4006 1C1EE740
	v_dot2_f32_bf16 v7, v68, v115, v9                          // 00000039DEDC: CC1A4007 1C26E744
	v_dot2_f32_bf16 v9, v72, v115, v10                         // 00000039DEE4: CC1A4009 1C2AE748
	v_and_or_b32 v10, v104, 15, v116                           // 00000039DEEC: D657000A 05D11F68
	v_dot2_f32_bf16 v4, v61, v30, v4                           // 00000039DEF4: CC1A4004 1C123D3D
	v_dot2_f32_bf16 v6, v65, v30, v6                           // 00000039DEFC: CC1A4006 1C1A3D41
	v_dot2_f32_bf16 v7, v69, v30, v7                           // 00000039DF04: CC1A4007 1C1E3D45
	v_dot2_f32_bf16 v9, v73, v30, v9                           // 00000039DF0C: CC1A4009 1C263D49
	v_cvt_f32_ubyte0_e32 v10, v10                              // 00000039DF14: 7E14230A
	v_dot2_f32_bf16 v4, v62, v1, v4                            // 00000039DF18: CC1A4004 1C12033E
	v_dot2_f32_bf16 v6, v66, v1, v6                            // 00000039DF20: CC1A4006 1C1A0342
	v_dot2_f32_bf16 v7, v70, v1, v7                            // 00000039DF28: CC1A4007 1C1E0346
	v_dot2_f32_bf16 v1, v74, v1, v9                            // 00000039DF30: CC1A4001 1C26034A
	v_fma_mix_f32 v9, v10, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000039DF38: CC206009 14DA6D0A
	s_waitcnt vmcnt(7)                                         // 00000039DF40: BF891FF7
	v_dot2_f32_bf16 v4, v75, v103, v4                          // 00000039DF44: CC1A4004 1C12CF4B
	s_waitcnt vmcnt(6)                                         // 00000039DF4C: BF891BF7
	v_dot2_f32_bf16 v6, v79, v103, v6                          // 00000039DF50: CC1A4006 1C1ACF4F
	s_waitcnt vmcnt(5)                                         // 00000039DF58: BF8917F7
	v_dot2_f32_bf16 v7, v83, v103, v7                          // 00000039DF5C: CC1A4007 1C1ECF53
	s_waitcnt vmcnt(4)                                         // 00000039DF64: BF8913F7
	v_dot2_f32_bf16 v1, v87, v103, v1                          // 00000039DF68: CC1A4001 1C06CF57
	v_bfe_u32 v10, v9, 16, 1                                   // 00000039DF70: D610000A 02052109
	v_dot2_f32_bf16 v4, v76, v110, v4                          // 00000039DF78: CC1A4004 1C12DD4C
	v_dot2_f32_bf16 v6, v80, v110, v6                          // 00000039DF80: CC1A4006 1C1ADD50
	v_dot2_f32_bf16 v7, v84, v110, v7                          // 00000039DF88: CC1A4007 1C1EDD54
	v_dot2_f32_bf16 v1, v88, v110, v1                          // 00000039DF90: CC1A4001 1C06DD58
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000039DF98: D6550009 03FE1509 00007FFF
	v_dot2_f32_bf16 v4, v77, v107, v4                          // 00000039DFA4: CC1A4004 1C12D74D
	v_dot2_f32_bf16 v6, v81, v107, v6                          // 00000039DFAC: CC1A4006 1C1AD751
	v_dot2_f32_bf16 v7, v85, v107, v7                          // 00000039DFB4: CC1A4007 1C1ED755
	v_dot2_f32_bf16 v1, v89, v107, v1                          // 00000039DFBC: CC1A4001 1C06D759
	.long 0x7ed03989                                           // 00000039DFC4: 7ED03989
	v_dot2_f32_bf16 v4, v78, v117, v4                          // 00000039DFC8: CC1A4004 1C12EB4E
	v_dot2_f32_bf16 v6, v82, v117, v6                          // 00000039DFD0: CC1A4006 1C1AEB52
	v_dot2_f32_bf16 v7, v86, v117, v7                          // 00000039DFD8: CC1A4007 1C1EEB56
	v_dot2_f32_bf16 v1, v90, v117, v1                          // 00000039DFE0: CC1A4001 1C06EB5A
	v_and_or_b32 v9, 0xffff0000, v100, v104                    // 00000039DFE8: D6570009 05A2C8FF FFFF0000
	s_waitcnt vmcnt(3)                                         // 00000039DFF4: BF890FF7
	v_dot2_f32_bf16 v4, v91, v108, v4                          // 00000039DFF8: CC1A4004 1C12D95B
	s_waitcnt vmcnt(2)                                         // 00000039E000: BF890BF7
	v_dot2_f32_bf16 v6, v33, v108, v6                          // 00000039E004: CC1A4006 1C1AD921
	s_waitcnt vmcnt(1)                                         // 00000039E00C: BF8907F7
	v_dot2_f32_bf16 v7, v95, v108, v7                          // 00000039E010: CC1A4007 1C1ED95F
	s_waitcnt vmcnt(0)                                         // 00000039E018: BF8903F7
	v_dot2_f32_bf16 v1, v37, v108, v1                          // 00000039E01C: CC1A4001 1C06D925
	.long 0x7ed039e6                                           // 00000039E024: 7ED039E6
	v_dot2_f32_bf16 v4, v92, v11, v4                           // 00000039E028: CC1A4004 1C12175C
	v_dot2_f32_bf16 v6, v34, v11, v6                           // 00000039E030: CC1A4006 1C1A1722
	v_dot2_f32_bf16 v7, v96, v11, v7                           // 00000039E038: CC1A4007 1C1E1760
	v_dot2_f32_bf16 v1, v38, v11, v1                           // 00000039E040: CC1A4001 1C061726
	v_and_or_b32 v10, 0xffff0000, v105, v104                   // 00000039E048: D657000A 05A2D2FF FFFF0000
	v_dot2_f32_bf16 v11, v93, v9, v4                           // 00000039E054: CC1A400B 1C12135D
	v_dot2_f32_bf16 v6, v35, v9, v6                            // 00000039E05C: CC1A4006 1C1A1323
	v_dot2_f32_bf16 v7, v97, v9, v7                            // 00000039E064: CC1A4007 1C1E1361
	v_dot2_f32_bf16 v1, v39, v9, v1                            // 00000039E06C: CC1A4001 1C061327
	v_mov_b32_e32 v4, v8                                       // 00000039E074: 7E080308
	v_dot2_f32_bf16 v8, v94, v10, v11                          // 00000039E078: CC1A4008 1C2E155E
	v_dot2_f32_bf16 v6, v36, v10, v6                           // 00000039E080: CC1A4006 1C1A1524
	v_dot2_f32_bf16 v7, v98, v10, v7                           // 00000039E088: CC1A4007 1C1E1562
	v_dot2_f32_bf16 v1, v40, v10, v1                           // 00000039E090: CC1A4001 1C061528
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039E098: BF870194
	v_dual_mov_b32 v54, v58 :: v_dual_add_f32 v49, v49, v8     // 00000039E09C: CA08013A 36301131
	v_dual_add_f32 v48, v48, v6 :: v_dual_add_f32 v47, v47, v7 // 00000039E0A4: C9080D30 302E0F2F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000039E0AC: BF870003
	v_dual_add_f32 v42, v42, v1 :: v_dual_mov_b32 v1, v5       // 00000039E0B0: C910032A 2A000105
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 00000039E0B8: 917E167E
	s_cbranch_execz 39                                         // 00000039E0BC: BFA50027 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x4c5c>
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v45, 32, v45    // 00000039E0C0: CA200102 062C5AA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000039E0C8: BF870002
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 00000039E0CC: CA100101 05080104
	v_dual_mov_b32 v7, v3 :: v_dual_mov_b32 v32, v28           // 00000039E0D4: CA100103 0720011C
	v_mov_b32_e32 v31, v27                                     // 00000039E0DC: 7E3E031B
	s_mov_b32 s18, exec_lo                                     // 00000039E0E0: BE92007E
	v_cmp_ge_i32_e32 vcc_lo, v45, v46                          // 00000039E0E4: 7C8C5D2D
	.long 0xd4c1007e                                           // 00000039E0E8: D4C1007E
	v_cndmask_b32_e32 v1, v45, v46, vcc_lo                     // 00000039E0EC: 02025D2D
	s_cbranch_execz 64823                                      // 00000039E0F0: BFA5FD37 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x40d0>
	v_and_b32_e32 v7, -4, v57                                  // 00000039E0F4: 360E72C4
	v_ashrrev_i32_e32 v6, 31, v55                              // 00000039E0F8: 340C6E9F
	v_ashrrev_i32_e32 v8, 31, v56                              // 00000039E0FC: 3410709F
	.long 0xd7000005                                           // 00000039E100: D7000005
	v_cndmask_b32_e32 v1, v25, v55, vcc_lo                     // 00000039E104: 02026F19
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039E108: BF870214
	v_ashrrev_i32_e32 v12, 31, v7                              // 00000039E10C: 34180E9F
	v_add_co_ci_u32_e64 v6, null, v26, v6, s0                  // 00000039E110: D5207C06 00020D1A
	.long 0xd7000009                                           // 00000039E118: D7000009
	v_cndmask_b32_e32 v1, v50, v56, vcc_lo                     // 00000039E11C: 02027132
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000039E120: BF8700A1
	v_add_co_ci_u32_e64 v10, null, v51, v8, s0                 // 00000039E124: D5207C0A 00021133
	.long 0xd700000b                                           // 00000039E12C: D700000B
	v_cndmask_b32_e32 v1, v52, v7, vcc_lo                      // 00000039E130: 02020F34
	v_add_co_ci_u32_e64 v12, null, v53, v12, s0                // 00000039E134: D5207C0C 00021935
	s_clause 0x2                                               // 00000039E13C: BF850002
	global_load_b128 v[5:8], v[5:6], off                       // 00000039E140: DC5E0000 057C0005
	global_load_b64 v[31:32], v[9:10], off                     // 00000039E148: DC560000 1F7C0009
	global_load_b32 v58, v[11:12], off                         // 00000039E150: DC520000 3A7C000B
	s_branch 64797                                             // 00000039E158: BFA0FD1D <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x40d0>
	s_or_b32 exec_lo, exec_lo, s22                             // 00000039E15C: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000039E160: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000039E164: 8C7E017E
	s_waitcnt vmcnt(2)                                         // 00000039E168: BF890BF7
	.long 0xd71f0001                                           // 00000039E16C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000039E170: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000039E174: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000039E178: 3A040290
	v_xor_b32_e32 v6, 8, v1                                    // 00000039E17C: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 00000039E180: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000039E184: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000039E188: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000039E18C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000039E190: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000039E194: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000039E198: 30040482
	ds_bpermute_b32 v3, v2, v49                                // 00000039E19C: DACC0000 03003102
	s_waitcnt lgkmcnt(0)                                       // 00000039E1A4: BF89FC07
	v_add_f32_e32 v3, v49, v3                                  // 00000039E1A8: 06060731
	ds_bpermute_b32 v5, v2, v47                                // 00000039E1AC: DACC0000 05002F02
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 00000039E1B4: 020C0D01
	ds_bpermute_b32 v4, v2, v48                                // 00000039E1B8: DACC0000 04003002
	ds_bpermute_b32 v2, v2, v42                                // 00000039E1C0: DACC0000 02002A02
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000039E1C8: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000039E1CC: 02141501
	s_waitcnt lgkmcnt(2)                                       // 00000039E1D0: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000039E1D4: BF870001
	v_dual_add_f32 v5, v47, v5 :: v_dual_lshlrev_b32 v10, 2, v10// 00000039E1D8: C9220B2F 050A1482
	v_lshlrev_b32_e32 v6, 2, v6                                // 00000039E1E0: 300C0C82
	ds_bpermute_b32 v9, v6, v5                                 // 00000039E1E4: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 00000039E1EC: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 00000039E1F0: 060A1305
	ds_bpermute_b32 v7, v6, v3                                 // 00000039E1F4: DACC0000 07000306
	s_waitcnt lgkmcnt(0)                                       // 00000039E1FC: BF89FC07
	v_dual_add_f32 v2, v42, v2 :: v_dual_add_f32 v3, v3, v7    // 00000039E200: C908052A 02020F03
	v_add_f32_e32 v4, v48, v4                                  // 00000039E208: 06080930
	ds_bpermute_b32 v8, v6, v4                                 // 00000039E20C: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 00000039E214: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 00000039E21C: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 00000039E220: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 00000039E224: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 00000039E22C: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 00000039E234: BF89FC17
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 00000039E238: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 00000039E240: DACC0000 0800050A
	s_waitcnt lgkmcnt(1)                                       // 00000039E248: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 00000039E24C: 060C1302
	ds_bpermute_b32 v7, v10, v4                                // 00000039E250: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 00000039E258: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000039E25C: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000039E260: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000039E264: 02141501
	s_waitcnt lgkmcnt(1)                                       // 00000039E268: BF89FC17
	v_dual_add_f32 v5, v5, v8 :: v_dual_lshlrev_b32 v10, 2, v10// 00000039E26C: C9221105 050A1482
	ds_bpermute_b32 v2, v10, v3                                // 00000039E274: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 00000039E27C: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 00000039E280: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 00000039E284: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 00000039E28C: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 00000039E294: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 00000039E29C: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000039E2A0: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000039E2A4: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 00000039E2A8: 02021501
	s_waitcnt lgkmcnt(3)                                       // 00000039E2AC: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 00000039E2B0: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 00000039E2B8: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 00000039E2BC: 06061105
	s_waitcnt lgkmcnt(0)                                       // 00000039E2C0: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 00000039E2C4: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 00000039E2CC: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 00000039E2D4: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 00000039E2DC: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 00000039E2E4: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v41                                   // 00000039E2EC: 7D945280
	s_cbranch_execz 12                                         // 00000039E2F0: BFA5000C <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x4e24>
	s_waitcnt lgkmcnt(1)                                       // 00000039E2F4: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_lshlrev_b32 v9, s15, v43// 00000039E2F8: C9221105 0808560F
	s_waitcnt lgkmcnt(0)                                       // 00000039E300: BF89FC07
	v_dual_add_f32 v7, v3, v7 :: v_dual_add_f32 v6, v2, v6     // 00000039E304: C9080F03 07060D02
	v_add_f32_e32 v5, v1, v4                                   // 00000039E30C: 060A0901
	s_delay_alu instid0(VALU_DEP_3)                            // 00000039E310: BF870003
	v_add_lshl_u32 v1, v9, v44, 4                              // 00000039E314: D6470001 02125909
	ds_store_b128 v1, v[5:8]                                   // 00000039E31C: DB7C0000 00000501
	s_or_b32 exec_lo, exec_lo, s0                              // 00000039E324: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039E328: BF870009
	s_and_b32 s0, s14, exec_lo                                 // 00000039E32C: 8B007E0E
	s_cselect_b32 s0, 4, 16                                    // 00000039E330: 98009084
	s_mov_b32 s1, exec_lo                                      // 00000039E334: BE81007E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000039E338: BF890007
	s_waitcnt_vscnt null, 0x0                                  // 00000039E33C: BC7C0000
	s_barrier                                                  // 00000039E340: BFBD0000
	buffer_gl0_inv                                             // 00000039E344: E0AC0000 00000000
	.long 0xd4cc007e                                           // 00000039E34C: D4CC007E
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000039E350: 02020000
	s_cbranch_execz 403                                        // 00000039E354: BFA50193 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x54a4>
	s_load_b32 s0, s[6:7], 0x40                                // 00000039E358: F4000003 F8000040
	v_lshrrev_b32_e32 v5, 2, v0                                // 00000039E360: 320A0082
	v_mov_b32_e32 v4, 0                                        // 00000039E364: 7E080280
	s_waitcnt lgkmcnt(0)                                       // 00000039E368: BF89FC07
	s_sub_i32 s8, s2, s0                                       // 00000039E36C: 81880002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000039E370: BF870499
	s_ashr_i32 s9, s8, 31                                      // 00000039E374: 86099F08
	s_lshl_b64 s[8:9], s[8:9], s20                             // 00000039E378: 84881408
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E37C: BF870099
	.long 0xd7000001                                           // 00000039E380: D7000001
	v_cndmask_b32_e32 v1, s8, v5, vcc_lo                       // 00000039E384: 02020A08
	v_add_co_ci_u32_e64 v2, null, s9, 0, s0                    // 00000039E388: D5207C02 00010009
	s_delay_alu instid0(VALU_DEP_1)                            // 00000039E390: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[4:5], v[1:2]                    // 00000039E394: 7CA80204
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 00000039E398: 8B7E6A7E
	s_cbranch_execz 385                                        // 00000039E39C: BFA50181 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x54a4>
	v_and_b32_e32 v3, 3, v0                                    // 00000039E3A0: 36060083
	v_lshlrev_b32_e32 v5, s15, v5                              // 00000039E3A4: 300A0A0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E3A8: BF870092
	v_lshlrev_b32_e32 v6, 2, v3                                // 00000039E3AC: 300C0682
	v_lshl_or_b32 v5, v5, 4, v6                                // 00000039E3B0: D6560005 04190905
	ds_load_b32 v6, v5                                         // 00000039E3B8: D8D80000 06000005
	v_add_nc_u32_e32 v5, 16, v5                                // 00000039E3C0: 4A0A0A90
	s_add_i32 s3, s3, -1                                       // 00000039E3C4: 8103C103
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039E3C8: BF870009
	s_cmp_eq_u32 s3, 0                                         // 00000039E3CC: BF068003
	s_waitcnt lgkmcnt(0)                                       // 00000039E3D0: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 00000039E3D4: 06080D04
	s_cbranch_scc0 65527                                       // 00000039E3D8: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x4eb8>
	s_clause 0x1                                               // 00000039E3DC: BF850001
	s_load_b64 s[8:9], s[6:7], 0x38                            // 00000039E3E0: F4040203 F8000038
	s_load_b64 s[2:3], s[6:7], 0x8                             // 00000039E3E8: F4040083 F8000008
	s_mov_b32 s11, -1                                          // 00000039E3F0: BE8B00C1
	s_mov_b32 s10, 0                                           // 00000039E3F4: BE8A0080
	s_mov_b32 s0, 0                                            // 00000039E3F8: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000039E3FC: BF89FC07
	s_cmp_lt_i32 s9, 3                                         // 00000039E400: BF048309
	s_cbranch_scc1 195                                         // 00000039E404: BFA200C3 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x5214>
	s_cmp_gt_i32 s9, 3                                         // 00000039E408: BF028309
	s_cbranch_scc0 73                                          // 00000039E40C: BFA10049 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x5034>
	s_cmp_gt_i32 s9, 4                                         // 00000039E410: BF028409
	s_cbranch_scc0 73                                          // 00000039E414: BFA10049 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x503c>
	s_cmp_eq_u32 s9, 5                                         // 00000039E418: BF068509
	s_mov_b32 s0, -1                                           // 00000039E41C: BE8000C1
	s_cbranch_scc0 66                                          // 00000039E420: BFA10042 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x502c>
	v_lshrrev_b32_e32 v5, 23, v2                               // 00000039E424: 320A0497
	s_lshr_b32 s0, s5, 31                                      // 00000039E428: 85009F05
	s_load_b64 s[6:7], s[6:7], 0x10                            // 00000039E42C: F4040183 F8000010
	s_add_u32 s14, s4, s0                                      // 00000039E434: 800E0004
	s_addc_u32 s15, s5, 0                                      // 00000039E438: 820F8005
	.long 0xd7006a05                                           // 00000039E43C: D7006A05
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 00000039E440: 02020B01
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000039E444: 868E810E
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 00000039E448: D5207C0A 01AA0480
	v_dual_mov_b32 v12, s3 :: v_dual_and_b32 v11, 0xfffffe00, v5// 00000039E450: CA240003 0C0A0AFF FFFFFE00
	v_mad_u64_u32 v[5:6], null, s14, v3, 0                     // 00000039E45C: D6FE7C05 0202060E
	v_bfe_u32 v15, v4, 16, 1                                   // 00000039E464: D610000F 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E46C: BF870093
	.long 0xd7016a08                                           // 00000039E470: D7016A08
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 00000039E474: 02021701
	v_sub_co_ci_u32_e64 v9, null, v2, v10, vcc_lo              // 00000039E478: D5217C09 01AA1502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039E480: BF870194
	v_mad_u64_u32 v[6:7], null, s15, v3, v[6:7]                // 00000039E484: D6FE7C06 041A060F
	.long 0xd700000d                                           // 00000039E48C: D700000D
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 00000039E490: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3)                            // 00000039E498: BF870003
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 00000039E49C: 7CA810FF 00000100
	v_mov_b32_e32 v7, s2                                       // 00000039E4A4: 7E0E0202
	v_add_co_ci_u32_e64 v14, null, -1, v9, s0                  // 00000039E4A8: D5207C0E 000212C1
	s_mov_b32 s0, 0                                            // 00000039E4B0: BE800080
	.long 0xd73c0005                                           // 00000039E4B4: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000039E4B8: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 00000039E4BC: BF89FC07
	v_dual_cndmask_b32 v8, v13, v8 :: v_dual_cndmask_b32 v7, s6, v7// 00000039E4C0: CA52110D 08060E06
	v_dual_cndmask_b32 v12, s7, v12 :: v_dual_cndmask_b32 v9, v14, v9// 00000039E4C8: CA521807 0C08130E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E4D0: BF870092
	.long 0xd7006a07                                           // 00000039E4D4: D7006A07
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 00000039E4D8: 02020B07
	v_add_co_ci_u32_e64 v12, null, v12, v6, vcc_lo             // 00000039E4DC: D5207C0C 01AA0D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039E4E4: BF870193
	.long 0xd73c0005                                           // 00000039E4E8: D73C0005
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000039E4EC: 02021081
	.long 0xd7006a07                                           // 00000039E4F0: D7006A07
	v_cndmask_b32_e32 v1, v7, v11, vcc_lo                      // 00000039E4F4: 02021707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000039E4F8: BF8701A1
	v_add_co_ci_u32_e64 v8, null, v12, v10, vcc_lo             // 00000039E4FC: D5207C08 01AA150C
	v_add3_u32 v9, v4, v15, 0x7fff                             // 00000039E504: D6550009 03FE1F04 00007FFF
	.long 0xd7006a05                                           // 00000039E510: D7006A05
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 00000039E514: 02020B07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000039E518: BF870001
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 00000039E51C: D5207C06 01AA0D08
	global_store_d16_hi_b16 v[5:6], v9, off                    // 00000039E524: DC960000 007C0905
	s_mov_b32 s6, 0                                            // 00000039E52C: BE860080
	s_branch 3                                                 // 00000039E530: BFA00003 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x5040>
	s_mov_b32 s6, -1                                           // 00000039E534: BE8600C1
	s_branch 54                                                // 00000039E538: BFA00036 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x5114>
	s_mov_b32 s6, -1                                           // 00000039E53C: BE8600C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039E540: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000039E544: 8B6A067E
	s_cbranch_vccz 49                                          // 00000039E548: BFA30031 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x5110>
	v_mul_f32_e32 v5, 0xbfb8aa3b, v4                           // 00000039E54C: 100A08FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000039E554: BF870291
	v_exp_f32_e32 v5, v5                                       // 00000039E558: 7E0A4B05
	v_add_f32_e32 v9, 1.0, v5                                  // 00000039E55C: 06120AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E560: BF870091
	v_div_scale_f32 v8, null, v9, v9, 1.0                      // 00000039E564: D6FC7C08 03CA1309
	v_rcp_f32_e32 v10, v8                                      // 00000039E56C: 7E145508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E570: BF870095
	v_fma_f32 v5, -v8, v10, 1.0                                // 00000039E574: D6130005 23CA1508
	v_fmac_f32_e32 v10, v5, v10                                // 00000039E57C: 56141505
	v_div_scale_f32 v11, vcc_lo, 1.0, v9, 1.0                  // 00000039E580: D6FC6A0B 03CA12F2
	v_mad_u64_u32 v[5:6], null, s4, v3, 0                      // 00000039E588: D6FE7C05 02020604
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039E590: BF870112
	v_mul_f32_e32 v12, v11, v10                                // 00000039E594: 1018150B
	v_mad_u64_u32 v[6:7], null, s5, v3, v[6:7]                 // 00000039E598: D6FE7C06 041A0605
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E5A0: BF870092
	v_fma_f32 v13, -v8, v12, v11                               // 00000039E5A4: D613000D 242E1908
	v_fmac_f32_e32 v12, v13, v10                               // 00000039E5AC: 5618150D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039E5B0: BF870113
	.long 0xd73c0005                                           // 00000039E5B4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000039E5B8: 02020A82
	v_fma_f32 v11, -v8, v12, v11                               // 00000039E5BC: D613000B 242E1908
	.long 0xd73c0007                                           // 00000039E5C4: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000039E5C8: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039E5CC: BF870212
	v_div_fmas_f32 v10, v11, v10, v12                          // 00000039E5D0: D637000A 0432150B
	.long 0xd7006a05                                           // 00000039E5D8: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000039E5DC: 02020A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039E5E0: BF870191
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 00000039E5E4: D5207C06 01AA0C03
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 00000039E5EC: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E5F4: BF870093
	.long 0xd7006a05                                           // 00000039E5F8: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000039E5FC: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000039E600: D5207C06 01AA1106
	global_store_b32 v[5:6], v9, off                           // 00000039E608: DC6A0000 007C0905
	s_mov_b32 s6, 0                                            // 00000039E610: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039E614: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000039E618: 8B6A067E
	s_cbranch_vccz 60                                          // 00000039E61C: BFA3003C <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x5210>
	v_bfe_u32 v5, v4, 16, 1                                    // 00000039E620: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E628: BF870091
	v_add3_u32 v5, v4, v5, 0x7fff                              // 00000039E62C: D6550005 03FE0B04 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000039E638: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E640: BF870091
	v_mul_f32_e32 v5, s8, v5                                   // 00000039E644: 100A0A08
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 00000039E648: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000039E650: BF870291
	v_exp_f32_e32 v5, v5                                       // 00000039E654: 7E0A4B05
	v_add_f32_e32 v9, 1.0, v5                                  // 00000039E658: 06120AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E65C: BF870091
	v_div_scale_f32 v8, null, v9, v9, 1.0                      // 00000039E660: D6FC7C08 03CA1309
	v_rcp_f32_e32 v10, v8                                      // 00000039E668: 7E145508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E66C: BF870095
	v_fma_f32 v5, -v8, v10, 1.0                                // 00000039E670: D6130005 23CA1508
	v_fmac_f32_e32 v10, v5, v10                                // 00000039E678: 56141505
	v_div_scale_f32 v11, vcc_lo, 1.0, v9, 1.0                  // 00000039E67C: D6FC6A0B 03CA12F2
	v_mad_u64_u32 v[5:6], null, s4, v3, 0                      // 00000039E684: D6FE7C05 02020604
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E68C: BF870092
	v_mul_f32_e32 v12, v11, v10                                // 00000039E690: 1018150B
	v_fma_f32 v7, -v8, v12, v11                                // 00000039E694: D6130007 242E1908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000039E69C: BF870211
	v_fmac_f32_e32 v12, v7, v10                                // 00000039E6A0: 56181507
	v_mad_u64_u32 v[6:7], null, s5, v3, v[6:7]                 // 00000039E6A4: D6FE7C06 041A0605
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039E6AC: BF870112
	v_fma_f32 v7, -v8, v12, v11                                // 00000039E6B0: D6130007 242E1908
	.long 0xd73c0005                                           // 00000039E6B8: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000039E6BC: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000039E6C0: BF8701A2
	v_div_fmas_f32 v10, v7, v10, v12                           // 00000039E6C4: D637000A 04321507
	.long 0xd73c0007                                           // 00000039E6CC: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000039E6D0: 02020282
	.long 0xd7006a05                                           // 00000039E6D4: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000039E6D8: 02020A02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000039E6DC: BF8701A3
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 00000039E6E0: D6270009 03CA130A
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 00000039E6E8: D5207C06 01AA0C03
	.long 0xd7006a05                                           // 00000039E6F0: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000039E6F4: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039E6F8: BF870193
	v_add_f32_e32 v9, v9, v9                                   // 00000039E6FC: 06121309
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000039E700: D5207C06 01AA1106
	global_store_b32 v[5:6], v9, off                           // 00000039E708: DC6A0000 007C0905
	s_mov_b32 s11, 0                                           // 00000039E710: BE8B0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039E714: BF870009
	s_and_b32 vcc_lo, exec_lo, s11                             // 00000039E718: 8B6A0B7E
	s_cbranch_vccz 72                                          // 00000039E71C: BFA30048 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x5340>
	s_cmp_gt_i32 s9, 1                                         // 00000039E720: BF028109
	s_mov_b32 s6, -1                                           // 00000039E724: BE8600C1
	s_cbranch_scc0 64                                          // 00000039E728: BFA10040 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x532c>
	v_bfe_u32 v5, v4, 16, 1                                    // 00000039E72C: D6100005 02052104
	s_mov_b32 s6, 0                                            // 00000039E734: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E738: BF870091
	v_add3_u32 v5, v4, v5, 0x7fff                              // 00000039E73C: D6550005 03FE0B04 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000039E748: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E750: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 00000039E754: 100A0AFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 00000039E75C: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E760: BF870095
	v_add_f32_e32 v8, 1.0, v5                                  // 00000039E764: 06100AF2
	v_div_scale_f32 v7, null, v8, v8, 1.0                      // 00000039E768: D6FC7C07 03CA1108
	v_div_scale_f32 v10, vcc_lo, 1.0, v8, 1.0                  // 00000039E770: D6FC6A0A 03CA10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000039E778: BF870292
	v_rcp_f32_e32 v9, v7                                       // 00000039E77C: 7E125507
	v_fma_f32 v5, -v7, v9, 1.0                                 // 00000039E780: D6130005 23CA1307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000039E788: BF870121
	v_fmac_f32_e32 v9, v5, v9                                  // 00000039E78C: 56121305
	v_mad_u64_u32 v[5:6], null, s4, v3, 0                      // 00000039E790: D6FE7C05 02020604
	v_mul_f32_e32 v11, v10, v9                                 // 00000039E798: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E79C: BF870091
	v_fma_f32 v12, -v7, v11, v10                               // 00000039E7A0: D613000C 242A1707
	v_fmac_f32_e32 v11, v12, v9                                // 00000039E7A8: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000039E7AC: BF870121
	v_fma_f32 v10, -v7, v11, v10                               // 00000039E7B0: D613000A 242A1707
	v_mad_u64_u32 v[6:7], null, s5, v3, v[6:7]                 // 00000039E7B8: D6FE7C06 041A0605
	v_div_fmas_f32 v7, v10, v9, v11                            // 00000039E7C0: D6370007 042E130A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039E7C8: BF870112
	.long 0xd73c0005                                           // 00000039E7CC: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000039E7D0: 02020A81
	v_div_fixup_f32 v9, v7, v8, 1.0                            // 00000039E7D4: D6270009 03CA1107
	.long 0xd73c0007                                           // 00000039E7DC: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000039E7E0: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039E7E4: BF870193
	.long 0xd7006a05                                           // 00000039E7E8: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000039E7EC: 02020A02
	v_bfe_u32 v10, v9, 16, 1                                   // 00000039E7F0: D610000A 02052109
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 00000039E7F8: D5207C06 01AA0C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039E800: BF870193
	.long 0xd7006a05                                           // 00000039E804: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000039E808: 02020F05
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000039E80C: D6550009 03FE1509 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000039E818: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000039E81C: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v9, off                    // 00000039E824: DC960000 007C0905
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 00000039E82C: 916A067E
	s_cbranch_vccnz 3                                          // 00000039E830: BFA40003 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x5340>
	s_cmp_lg_u32 s9, 1                                         // 00000039E834: BF078109
	s_mov_b32 s10, -1                                          // 00000039E838: BE8A00C1
	s_cselect_b32 s0, -1, 0                                    // 00000039E83C: 980080C1
	v_bfe_u32 v5, v4, 16, 1                                    // 00000039E840: D6100005 02052104
	.long 0xd73c0001                                           // 00000039E848: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000039E84C: 02020281
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000039E850: 8B6A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000039E854: BF870002
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000039E858: D6550004 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 00000039E864: BFA30014 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x53b8>
	v_mad_u64_u32 v[5:6], null, s4, v3, 0                      // 00000039E868: D6FE7C05 02020604
	s_mov_b32 s10, 0                                           // 00000039E870: BE8A0080
	v_mad_u64_u32 v[6:7], null, s5, v3, v[6:7]                 // 00000039E874: D6FE7C06 041A0605
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E87C: BF870091
	.long 0xd73c0005                                           // 00000039E880: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000039E884: 02020A81
	.long 0xd7006a05                                           // 00000039E888: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000039E88C: 02020A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039E890: BF870111
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 00000039E894: D5207C06 01AA0C03
	.long 0xd7006a05                                           // 00000039E89C: D7006A05
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                       // 00000039E8A0: 02020305
	s_delay_alu instid0(VALU_DEP_1)                            // 00000039E8A4: BF870001
	v_add_co_ci_u32_e64 v6, null, v6, v2, vcc_lo               // 00000039E8A8: D5207C06 01AA0506
	global_store_d16_hi_b16 v[5:6], v4, off                    // 00000039E8B0: DC960000 007C0405
	s_and_not1_b32 vcc_lo, exec_lo, s10                        // 00000039E8B8: 916A0A7E
	s_cbranch_vccnz 57                                         // 00000039E8BC: BFA40039 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x54a4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E8C0: BF870091
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000039E8C4: 360808FF FFFF0000
	v_mul_f32_e32 v7, s8, v4                                   // 00000039E8CC: 100E0808
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E8D0: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v7                           // 00000039E8D4: 10080EFF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 00000039E8DC: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E8E0: BF870095
	v_add_f32_e32 v8, 1.0, v4                                  // 00000039E8E4: 061008F2
	v_div_scale_f32 v6, null, v8, v8, v7                       // 00000039E8E8: D6FC7C06 041E1108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000039E8F0: BF870291
	v_rcp_f32_e32 v9, v6                                       // 00000039E8F4: 7E125506
	v_fma_f32 v4, -v6, v9, 1.0                                 // 00000039E8F8: D6130004 23CA1306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000039E900: BF870131
	v_fmac_f32_e32 v9, v4, v9                                  // 00000039E904: 56121304
	v_div_scale_f32 v10, vcc_lo, v7, v8, v7                    // 00000039E908: D6FC6A0A 041E1107
	v_mad_u64_u32 v[4:5], null, s4, v3, 0                      // 00000039E910: D6FE7C04 02020604
	v_mul_f32_e32 v11, v10, v9                                 // 00000039E918: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E91C: BF870091
	v_fma_f32 v12, -v6, v11, v10                               // 00000039E920: D613000C 242A1706
	v_fmac_f32_e32 v11, v12, v9                                // 00000039E928: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000039E92C: BF870121
	v_fma_f32 v10, -v6, v11, v10                               // 00000039E930: D613000A 242A1706
	v_mad_u64_u32 v[5:6], null, s5, v3, v[5:6]                 // 00000039E938: D6FE7C05 04160605
	v_div_fmas_f32 v3, v10, v9, v11                            // 00000039E940: D6370003 042E130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039E948: BF870191
	v_div_fixup_f32 v6, v3, v8, v7                             // 00000039E94C: D6270006 041E1103
	.long 0xd73c0003                                           // 00000039E954: D73C0003
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000039E958: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000039E95C: BF870112
	v_bfe_u32 v5, v6, 16, 1                                    // 00000039E960: D6100005 02052106
	.long 0xd7006a03                                           // 00000039E968: D7006A03
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 00000039E96C: 02020602
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000039E970: BF870191
	v_add_co_ci_u32_e64 v4, null, s3, v4, vcc_lo               // 00000039E974: D5207C04 01AA0803
	v_add3_u32 v5, v6, v5, 0x7fff                              // 00000039E97C: D6550005 03FE0B06 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039E988: BF870093
	.long 0xd7006a01                                           // 00000039E98C: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 00000039E990: 02020303
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 00000039E994: D5207C02 01AA0504
	global_store_d16_hi_b16 v[1:2], v5, off                    // 00000039E99C: DC960000 007C0501
	s_or_b32 exec_lo, exec_lo, s1                              // 00000039E9A4: 8C7E017E
	s_waitcnt_vscnt null, 0x0                                  // 00000039E9A8: BC7C0000
	s_barrier                                                  // 00000039E9AC: BFBD0000
	buffer_gl0_inv                                             // 00000039E9B0: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 00000039E9B8: BE80007E
	v_cmpx_eq_u32_e32 0, v0                                    // 00000039E9BC: 7D940080
	s_cbranch_execz 18                                         // 00000039E9C0: BFA50012 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x550c>
	s_mov_b32 s0, exec_lo                                      // 00000039E9C4: BE80007E
	buffer_gl1_inv                                             // 00000039E9C8: E0B00000 00000000
	buffer_gl0_inv                                             // 00000039E9D0: E0AC0000 00000000
	.long 0xd71f0000                                           // 00000039E9D8: D71F0000
	v_cndmask_b32_e32 v0, s0, v128, vcc_lo                     // 00000039E9DC: 02010000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000039E9E0: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 00000039E9E4: 7C940080
	s_and_b32 s1, exec_lo, vcc_lo                              // 00000039E9E8: 8B016A7E
	s_mov_b32 exec_lo, s1                                      // 00000039E9EC: BEFE0001
	s_cbranch_execz 6                                          // 00000039E9F0: BFA50006 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi4EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x550c>
	s_bcnt1_i32_b32 s0, s0                                     // 00000039E9F4: BE801800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039E9F8: BF870009
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, s0              // 00000039E9FC: CA100080 01000000
	global_atomic_add_u64 v1, v[0:1], s[12:13]                 // 00000039EA04: DD0E0000 000C0001
	s_nop 0                                                    // 00000039EA0C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000039EA10: BFB60003
	s_endpgm                                                   // 00000039EA14: BFB00000
		...

