0000000000daf900 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt>:
; _ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt():
	s_load_b256 s[4:11], s[0:1], null                          // 000000DAF900: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000DAF908: BE830080
	v_and_b32_e32 v76, 31, v0                                  // 000000DAF90C: 3698009F
	s_lshl_b64 s[2:3], s[2:3], 4                               // 000000DAF910: 84828402
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v0                          // 000000DAF914: 7C9200FF 000000FF
	v_lshlrev_b32_e32 v1, 4, v0                                // 000000DAF91C: 30020084
	v_and_b32_e32 v79, 0xe0, v0                                // 000000DAF920: 369E00FF 000000E0
	v_lshlrev_b32_e32 v2, 5, v76                               // 000000DAF928: 30049885
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DAF92C: BF870091
	v_add_nc_u32_e32 v3, 0x3f0, v2                             // 000000DAF930: 4A0604FF 000003F0
	v_lshrrev_b32_e32 v4, 5, v3                                // 000000DAF938: 32080685
	v_and_b32_e32 v5, 0x7e0, v3                                // 000000DAF93C: 360A06FF 000007E0
	s_waitcnt lgkmcnt(0)                                       // 000000DAF944: BF89FC07
	s_add_u32 s2, s8, s2                                       // 000000DAF948: 80020208
	s_addc_u32 s3, s9, s3                                      // 000000DAF94C: 82030309
	s_load_b64 s[8:9], s[0:1], 0x20                            // 000000DAF950: F4040200 F8000020
	s_load_b128 s[12:15], s[2:3], null                         // 000000DAF958: F4080301 F8000000
	v_add_nc_u32_e32 v6, 1, v4                                 // 000000DAF960: 4A0C0881
	v_sub_nc_u32_e32 v2, v5, v2                                // 000000DAF964: 4C040505
	v_lshrrev_b32_e32 v4, 1, v0                                // 000000DAF968: 32080081
	v_bfe_u32 v5, v3, 5, 5                                     // 000000DAF96C: D6100005 02150B03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DAF974: BF870214
	v_and_b32_e32 v6, 31, v6                                   // 000000DAF978: 360C0C9F
	v_add_nc_u32_e32 v80, 0xfffffc3c, v2                       // 000000DAF97C: 4AA004FF FFFFFC3C
	v_add_nc_u32_e32 v81, 0xfffffc38, v2                       // 000000DAF984: 4AA204FF FFFFFC38
	v_add_nc_u32_e32 v82, 0xfffffc34, v2                       // 000000DAF98C: 4AA404FF FFFFFC34
	v_add_nc_u32_e32 v83, 0xfffffc30, v2                       // 000000DAF994: 4AA604FF FFFFFC30
	s_waitcnt lgkmcnt(0)                                       // 000000DAF99C: BF89FC07
	s_mul_i32 s1, s12, 0xc8000                                 // 000000DAF9A0: 9601FF0C 000C8000
	s_mul_hi_i32 s0, s12, 0xc8000                              // 000000DAF9A8: 9700FF0C 000C8000
	s_mul_i32 s2, s13, 0xa000                                  // 000000DAF9B0: 9602FF0D 0000A000
	s_add_u32 s1, s4, s1                                       // 000000DAF9B8: 80010104
	s_addc_u32 s0, s5, s0                                      // 000000DAF9BC: 82000005
	s_mul_hi_i32 s3, s13, 0xa000                               // 000000DAF9C0: 9703FF0D 0000A000
	s_add_u32 s2, s1, s2                                       // 000000DAF9C8: 80020201
	s_addc_u32 s3, s0, s3                                      // 000000DAF9CC: 82030300
	s_and_saveexec_b32 s0, vcc_lo                              // 000000DAF9D0: BE80206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DAF9D4: BF870009
	s_xor_b32 s0, exec_lo, s0                                  // 000000DAF9D8: 8D00007E
	v_and_b32_e32 v3, 8, v4                                    // 000000DAF9DC: 36060888
	v_and_b32_e32 v79, 0xe0, v0                                // 000000DAF9E0: 369E00FF 000000E0
	s_or_saveexec_b32 s0, s0                                   // 000000DAF9E8: BE802200
	v_and_b32_e32 v1, 0xf0, v1                                 // 000000DAF9EC: 360202FF 000000F0
	v_lshrrev_b32_e32 v2, 5, v0                                // 000000DAF9F4: 32040085
	v_lshlrev_b32_e32 v84, 2, v5                               // 000000DAF9F8: 30A80A82
	v_lshlrev_b32_e32 v85, 2, v6                               // 000000DAF9FC: 30AA0C82
	v_lshlrev_b32_e32 v86, 2, v76                              // 000000DAFA00: 30AC9882
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000DAFA04: 30020281
	v_lshlrev_b32_e32 v10, 9, v2                               // 000000DAFA08: 30140489
	s_xor_b32 exec_lo, exec_lo, s0                             // 000000DAFA0C: 8D7E007E
	s_cbranch_execz 137                                        // 000000DAFA10: BFA50089 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x338>
	v_lshlrev_b32_e32 v3, 2, v79                               // 000000DAFA14: 30069E82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DAFA18: BF870091
	.long 0xd7000103                                           // 000000DAFA1C: D7000103
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000DAFA20: 02020602
	v_add_co_ci_u32_e64 v9, null, s3, 0, s1                    // 000000DAFA24: D5207C09 00050003
	s_movk_i32 s1, 0x1eee                                      // 000000DAFA2C: B0011EEE
	.long 0xd7006a05                                           // 000000DAFA30: D7006A05
	v_cndmask_b32_e32 v1, v3, v84, vcc_lo                      // 000000DAFA34: 0202A903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DAFA38: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 000000DAFA3C: D5207C06 01AA1280
	.long 0xd7006a07                                           // 000000DAFA44: D7006A07
	v_cndmask_b32_e32 v1, v3, v85, vcc_lo                      // 000000DAFA48: 0202AB03
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo                // 000000DAFA4C: D5207C08 01AA1280
	.long 0xd7006a0b                                           // 000000DAFA54: D7006A0B
	v_cndmask_b32_e32 v1, v3, v86, vcc_lo                      // 000000DAFA58: 0202AD03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DAFA5C: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v9, vcc_lo               // 000000DAFA60: D5207C0C 01AA1280
	s_clause 0x2                                               // 000000DAFA68: BF850002
	global_load_b32 v6, v[5:6], off                            // 000000DAFA6C: DC520000 067C0005
	global_load_b32 v5, v[7:8], off                            // 000000DAFA74: DC520000 057C0007
	global_load_b32 v13, v[11:12], off                         // 000000DAFA7C: DC520000 0D7C000B
	v_and_b32_e32 v3, 8, v4                                    // 000000DAFA84: 36060888
	s_waitcnt vmcnt(1)                                         // 000000DAFA88: BF8907F7
	.long 0xd73d0007                                           // 000000DAFA8C: D73D0007
	v_cndmask_b32_e32 v1, v80, v5, vcc_lo                      // 000000DAFA90: 02020B50
	.long 0xd73d000b                                           // 000000DAFA94: D73D000B
	v_cndmask_b32_e32 v1, v82, v5, vcc_lo                      // 000000DAFA98: 02020B52
	.long 0xd73d0008                                           // 000000DAFA9C: D73D0008
	v_cndmask_b32_e32 v1, v81, v5, vcc_lo                      // 000000DAFAA0: 02020B51
	.long 0xd73d0004                                           // 000000DAFAA4: D73D0004
	v_cndmask_b32_e32 v1, v83, v5, vcc_lo                      // 000000DAFAA8: 02020B53
	s_waitcnt vmcnt(0)                                         // 000000DAFAAC: BF8903F7
	v_bfe_u32 v9, v13, 12, 16                                  // 000000DAFAB0: D6100009 0241190D
	v_and_b32_e32 v5, 0xffff, v13                              // 000000DAFAB8: 360A1AFF 0000FFFF
	v_and_b32_e32 v7, 0xffff, v7                               // 000000DAFAC0: 360E0EFF 0000FFFF
	v_and_b32_e32 v11, 0xffff, v11                             // 000000DAFAC8: 361616FF 0000FFFF
	v_bfe_u32 v12, v13, 8, 16                                  // 000000DAFAD0: D610000C 0241110D
	v_bfe_u32 v14, v13, 4, 16                                  // 000000DAFAD8: D610000E 0241090D
	.long 0xd72c0006                                           // 000000DAFAE0: D72C0006
	v_cndmask_b32_e32 v1, 0x83dcd12d, v9, vcc_lo               // 000000DAFAE4: 020212FF 83DCD12D
	v_and_b32_e32 v8, 0xffff, v8                               // 000000DAFAEC: 361010FF 0000FFFF
	.long 0xd72c0005                                           // 000000DAFAF4: D72C0005
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000DAFAF8: 02020AFF 83DCD12D
	v_and_b32_e32 v4, 0xffff, v4                               // 000000DAFB00: 360808FF 0000FFFF
	.long 0xd72c0007                                           // 000000DAFB08: D72C0007
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 000000DAFB0C: 02020EFF 83DCD12D
	.long 0xd72c000b                                           // 000000DAFB14: D72C000B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v11, vcc_lo              // 000000DAFB18: 020216FF 83DCD12D
	.long 0xd72c0009                                           // 000000DAFB20: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v12, vcc_lo              // 000000DAFB24: 020218FF 83DCD12D
	.long 0xd72c000c                                           // 000000DAFB2C: D72C000C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 000000DAFB30: 02021CFF 83DCD12D
	.long 0xd72c0008                                           // 000000DAFB38: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 000000DAFB3C: 020210FF 83DCD12D
	.long 0xd72c0004                                           // 000000DAFB44: D72C0004
	v_cndmask_b32_e32 v1, 0x83dcd12d, v4, vcc_lo               // 000000DAFB48: 020208FF 83DCD12D
	v_sad_u8 v6, v6, 0, 0x6400                                 // 000000DAFB50: D6220006 03FD0106 00006400
	v_sad_u8 v5, v5, 0, 0x6400                                 // 000000DAFB5C: D6220005 03FD0105 00006400
	v_sad_u8 v7, v7, 0, 0x6400                                 // 000000DAFB68: D6220007 03FD0107 00006400
	v_sad_u8 v11, v11, 0, 0x6400                               // 000000DAFB74: D622000B 03FD010B 00006400
	v_sad_u8 v9, v9, 0, 0x6400                                 // 000000DAFB80: D6220009 03FD0109 00006400
	v_sad_u8 v12, v12, 0, 0x6400                               // 000000DAFB8C: D622000C 03FD010C 00006400
	v_and_b32_e32 v6, 0xffff, v6                               // 000000DAFB98: 360C0CFF 0000FFFF
	v_lshlrev_b32_e32 v5, 16, v5                               // 000000DAFBA0: 300A0A90
	v_sad_u8 v8, v8, 0, 0x6400                                 // 000000DAFBA4: D6220008 03FD0108 00006400
	v_sad_u8 v4, v4, 0, 0x6400                                 // 000000DAFBB0: D6220004 03FD0104 00006400
	v_and_b32_e32 v7, 0xffff, v7                               // 000000DAFBBC: 360E0EFF 0000FFFF
	v_and_b32_e32 v11, 0xffff, v11                             // 000000DAFBC4: 361616FF 0000FFFF
	v_lshl_or_b32 v6, v9, 16, v6                               // 000000DAFBCC: D6560006 04192109
	v_and_or_b32 v5, 0xffff, v12, v5                           // 000000DAFBD4: D6570005 041618FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DAFBE0: BF870214
	v_lshl_or_b32 v8, v8, 16, v7                               // 000000DAFBE4: D6560008 041D2108
	v_lshl_or_b32 v9, v4, 16, v11                              // 000000DAFBEC: D6560009 042D2104
	v_lshlrev_b32_e32 v11, 1, v3                               // 000000DAFBF4: 30160681
	v_pk_fma_f16 v6, v6, s1, 0xc931 op_sel_hi:[1,0,0]          // 000000DAFBF8: CC0E0006 0BFC0306 0000C931
	v_pk_fma_f16 v7, v5, s1, 0xc931 op_sel_hi:[1,0,0]          // 000000DAFC04: CC0E0007 0BFC0305 0000C931
	v_pk_fma_f16 v4, v8, s1, 0xc931 op_sel_hi:[1,0,0]          // 000000DAFC10: CC0E0004 0BFC0308 0000C931
	v_pk_fma_f16 v5, v9, s1, 0xc931 op_sel_hi:[1,0,0]          // 000000DAFC1C: CC0E0005 0BFC0309 0000C931
	v_add3_u32 v8, v1, v11, v10                                // 000000DAFC28: D6550008 042A1701
	ds_store_b128 v8, v[4:7]                                   // 000000DAFC30: DB7C0000 00000408
	s_or_b32 exec_lo, exec_lo, s0                              // 000000DAFC38: 8C7E007E
	v_lshl_add_u32 v77, v2, 4, s14                             // 000000DAFC3C: D646004D 00390902
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v11, 1, v3      // 000000DAFC44: CA220080 020A0681
	v_and_b32_e32 v78, 15, v0                                  // 000000DAFC4C: 369C008F
	s_add_i32 s0, s15, -1                                      // 000000DAFC50: 8100C10F
	s_movk_i32 s4, 0x1eee                                      // 000000DAFC54: B0041EEE
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DAFC58: BF870112
	v_mov_b32_e32 v3, v2                                       // 000000DAFC5C: 7E060302
	v_dual_mov_b32 v5, v2 :: v_dual_add_nc_u32 v6, v77, v78    // 000000DAFC60: CA200102 05069D4D
	v_mov_b32_e32 v9, v2                                       // 000000DAFC68: 7E120302
	v_dual_mov_b32 v4, v2 :: v_dual_lshlrev_b32 v87, 5, v78    // 000000DAFC6C: CA220102 04569C85
	v_mov_b32_e32 v7, v2                                       // 000000DAFC74: 7E0E0302
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DAFC78: BF870004
	v_min_i32_e32 v12, s0, v6                                  // 000000DAFC7C: 22180C00
	v_mov_b32_e32 v6, v2                                       // 000000DAFC80: 7E0C0302
	v_mov_b32_e32 v8, v2                                       // 000000DAFC84: 7E100302
	v_add3_u32 v88, v1, v11, v10                               // 000000DAFC88: D6550058 042A1701
	v_mov_b32_e32 v25, v9                                      // 000000DAFC90: 7E320309
	v_mad_i64_i32 v[74:75], null, 0x500, v12, s[6:7]           // 000000DAFC94: D6FF7C4A 001A18FF 00000500
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DAFCA0: BF870004
	v_dual_mov_b32 v17, v9 :: v_dual_mov_b32 v16, v8           // 000000DAFCA4: CA100109 11100108
	v_dual_mov_b32 v33, v9 :: v_dual_mov_b32 v32, v8           // 000000DAFCAC: CA100109 21200108
	v_dual_mov_b32 v41, v9 :: v_dual_mov_b32 v40, v8           // 000000DAFCB4: CA100109 29280108
	v_dual_mov_b32 v49, v9 :: v_dual_mov_b32 v48, v8           // 000000DAFCBC: CA100109 31300108
	v_dual_mov_b32 v57, v9 :: v_dual_mov_b32 v56, v8           // 000000DAFCC4: CA100109 39380108
	v_dual_mov_b32 v65, v9 :: v_dual_mov_b32 v64, v8           // 000000DAFCCC: CA100109 41400108
	v_dual_mov_b32 v73, v9 :: v_dual_mov_b32 v72, v8           // 000000DAFCD4: CA100109 49480108
	.long 0xd44c0000                                           // 000000DAFCDC: D44C0000
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000DAFCE0: 020200FF 00000100
	v_dual_mov_b32 v15, v7 :: v_dual_mov_b32 v14, v6           // 000000DAFCE8: CA100107 0F0E0106
	v_dual_mov_b32 v13, v5 :: v_dual_mov_b32 v12, v4           // 000000DAFCF0: CA100105 0D0C0104
	v_dual_mov_b32 v11, v3 :: v_dual_mov_b32 v10, v2           // 000000DAFCF8: CA100103 0B0A0102
	v_dual_mov_b32 v24, v8 :: v_dual_mov_b32 v23, v7           // 000000DAFD00: CA100108 18160107
	v_dual_mov_b32 v22, v6 :: v_dual_mov_b32 v21, v5           // 000000DAFD08: CA100106 16140105
	v_dual_mov_b32 v20, v4 :: v_dual_mov_b32 v19, v3           // 000000DAFD10: CA100104 14120103
	v_dual_mov_b32 v18, v2 :: v_dual_mov_b32 v31, v7           // 000000DAFD18: CA100102 121E0107
	v_dual_mov_b32 v30, v6 :: v_dual_mov_b32 v29, v5           // 000000DAFD20: CA100106 1E1C0105
	v_dual_mov_b32 v28, v4 :: v_dual_mov_b32 v27, v3           // 000000DAFD28: CA100104 1C1A0103
	v_dual_mov_b32 v26, v2 :: v_dual_mov_b32 v39, v7           // 000000DAFD30: CA100102 1A260107
	v_dual_mov_b32 v38, v6 :: v_dual_mov_b32 v37, v5           // 000000DAFD38: CA100106 26240105
	v_dual_mov_b32 v36, v4 :: v_dual_mov_b32 v35, v3           // 000000DAFD40: CA100104 24220103
	v_dual_mov_b32 v34, v2 :: v_dual_mov_b32 v47, v7           // 000000DAFD48: CA100102 222E0107
	v_dual_mov_b32 v46, v6 :: v_dual_mov_b32 v45, v5           // 000000DAFD50: CA100106 2E2C0105
	v_dual_mov_b32 v44, v4 :: v_dual_mov_b32 v43, v3           // 000000DAFD58: CA100104 2C2A0103
	v_dual_mov_b32 v42, v2 :: v_dual_mov_b32 v55, v7           // 000000DAFD60: CA100102 2A360107
	v_dual_mov_b32 v54, v6 :: v_dual_mov_b32 v53, v5           // 000000DAFD68: CA100106 36340105
	v_dual_mov_b32 v52, v4 :: v_dual_mov_b32 v51, v3           // 000000DAFD70: CA100104 34320103
	v_dual_mov_b32 v50, v2 :: v_dual_mov_b32 v63, v7           // 000000DAFD78: CA100102 323E0107
	v_dual_mov_b32 v62, v6 :: v_dual_mov_b32 v61, v5           // 000000DAFD80: CA100106 3E3C0105
	v_dual_mov_b32 v60, v4 :: v_dual_mov_b32 v59, v3           // 000000DAFD88: CA100104 3C3A0103
	v_dual_mov_b32 v58, v2 :: v_dual_mov_b32 v71, v7           // 000000DAFD90: CA100102 3A460107
	v_dual_mov_b32 v70, v6 :: v_dual_mov_b32 v69, v5           // 000000DAFD98: CA100106 46440105
	v_dual_mov_b32 v68, v4 :: v_dual_mov_b32 v67, v3           // 000000DAFDA0: CA100104 44420103
	v_mov_b32_e32 v66, v2                                      // 000000DAFDA8: 7E840302
	s_mov_b32 s7, 0                                            // 000000DAFDAC: BE870080
	v_cmp_gt_i32_e32 vcc_lo, s15, v77                          // 000000DAFDB0: 7C889A0F
	s_branch 4                                                 // 000000DAFDB4: BFA00004 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x4c8>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DAFDB8: 8C7E067E
	s_cmp_eq_u32 s5, 39                                        // 000000DAFDBC: BF06A705
	s_mov_b32 s7, s5                                           // 000000DAFDC0: BE870005
	s_cbranch_scc1 225                                         // 000000DAFDC4: BFA200E1 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x84c>
	s_and_b32 s14, s7, 1                                       // 000000DAFDC8: 8B0E8107
	s_add_i32 s5, s7, 1                                        // 000000DAFDCC: 81058107
	s_waitcnt lgkmcnt(0)                                       // 000000DAFDD0: BF89FC07
	s_barrier                                                  // 000000DAFDD4: BFBD0000
	buffer_gl0_inv                                             // 000000DAFDD8: E0AC0000 00000000
	s_and_saveexec_b32 s6, s0                                  // 000000DAFDE0: BE862000
	s_cbranch_execnz 4                                         // 000000DAFDE4: BFA60004 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x4f8>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DAFDE8: 8C7E067E
	s_and_saveexec_b32 s6, vcc_lo                              // 000000DAFDEC: BE86206A
	s_cbranch_execz 65521                                      // 000000DAFDF0: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x4b8>
	s_branch 143                                               // 000000DAFDF4: BFA0008F <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x734>
	v_lshl_or_b32 v1, s5, 8, v79                               // 000000DAFDF8: D6560001 053D1005
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DAFE00: BF870091
	.long 0xd73c0003                                           // 000000DAFE04: D73C0003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000DAFE08: 02020282
	.long 0xd7000101                                           // 000000DAFE0C: D7000101
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000DAFE10: 02020602
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DAFE14: BF870111
	v_add_co_ci_u32_e64 v8, null, s3, v4, s1                   // 000000DAFE18: D5207C08 00060803
	.long 0xd7000103                                           // 000000DAFE20: D7000103
	v_cndmask_b32_e32 v1, v1, v84, vcc_lo                      // 000000DAFE24: 0202A901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DAFE28: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v8, s1                    // 000000DAFE2C: D5207C04 00061080
	.long 0xd7000105                                           // 000000DAFE34: D7000105
	v_cndmask_b32_e32 v1, v1, v85, vcc_lo                      // 000000DAFE38: 0202AB01
	v_add_co_ci_u32_e64 v6, null, 0, v8, s1                    // 000000DAFE3C: D5207C06 00061080
	.long 0xd7000107                                           // 000000DAFE44: D7000107
	v_cndmask_b32_e32 v1, v1, v86, vcc_lo                      // 000000DAFE48: 0202AD01
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DAFE4C: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 000000DAFE50: D5207C08 00061080
	s_clause 0x2                                               // 000000DAFE58: BF850002
	global_load_b32 v4, v[3:4], off                            // 000000DAFE5C: DC520000 047C0003
	global_load_b32 v3, v[5:6], off                            // 000000DAFE64: DC520000 037C0005
	global_load_b32 v1, v[7:8], off                            // 000000DAFE6C: DC520000 017C0007
	s_xor_b32 s1, s14, 1                                       // 000000DAFE74: 8D01810E
	s_waitcnt vmcnt(1)                                         // 000000DAFE78: BF8907F7
	.long 0xd73d0005                                           // 000000DAFE7C: D73D0005
	v_cndmask_b32_e32 v1, v80, v3, vcc_lo                      // 000000DAFE80: 02020750
	.long 0xd73d0006                                           // 000000DAFE84: D73D0006
	v_cndmask_b32_e32 v1, v81, v3, vcc_lo                      // 000000DAFE88: 02020751
	.long 0xd73d0007                                           // 000000DAFE8C: D73D0007
	v_cndmask_b32_e32 v1, v82, v3, vcc_lo                      // 000000DAFE90: 02020752
	.long 0xd73d0003                                           // 000000DAFE94: D73D0003
	v_cndmask_b32_e32 v1, v83, v3, vcc_lo                      // 000000DAFE98: 02020753
	s_waitcnt vmcnt(0)                                         // 000000DAFE9C: BF8903F7
	v_bfe_u32 v8, v1, 12, 16                                   // 000000DAFEA0: D6100008 02411901
	v_bfe_u32 v9, v1, 8, 16                                    // 000000DAFEA8: D6100009 02411101
	v_bfe_u32 v89, v1, 4, 16                                   // 000000DAFEB0: D6100059 02410901
	v_and_b32_e32 v1, 0xffff, v1                               // 000000DAFEB8: 360202FF 0000FFFF
	v_and_b32_e32 v5, 0xffff, v5                               // 000000DAFEC0: 360A0AFF 0000FFFF
	v_and_b32_e32 v7, 0xffff, v7                               // 000000DAFEC8: 360E0EFF 0000FFFF
	.long 0xd72c0004                                           // 000000DAFED0: D72C0004
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 000000DAFED4: 020210FF 83DCD12D
	v_and_b32_e32 v6, 0xffff, v6                               // 000000DAFEDC: 360C0CFF 0000FFFF
	.long 0xd72c0001                                           // 000000DAFEE4: D72C0001
	v_cndmask_b32_e32 v1, 0x83dcd12d, v1, vcc_lo               // 000000DAFEE8: 020202FF 83DCD12D
	v_and_b32_e32 v3, 0xffff, v3                               // 000000DAFEF0: 360606FF 0000FFFF
	.long 0xd72c0005                                           // 000000DAFEF8: D72C0005
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000DAFEFC: 02020AFF 83DCD12D
	.long 0xd72c0007                                           // 000000DAFF04: D72C0007
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 000000DAFF08: 02020EFF 83DCD12D
	.long 0xd72c0008                                           // 000000DAFF10: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v9, vcc_lo               // 000000DAFF14: 020212FF 83DCD12D
	.long 0xd72c0009                                           // 000000DAFF1C: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000DAFF20: 0202B2FF 83DCD12D
	.long 0xd72c0006                                           // 000000DAFF28: D72C0006
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 000000DAFF2C: 02020CFF 83DCD12D
	.long 0xd72c0003                                           // 000000DAFF34: D72C0003
	v_cndmask_b32_e32 v1, 0x83dcd12d, v3, vcc_lo               // 000000DAFF38: 020206FF 83DCD12D
	v_sad_u8 v4, v4, 0, 0x6400                                 // 000000DAFF40: D6220004 03FD0104 00006400
	v_sad_u8 v1, v1, 0, 0x6400                                 // 000000DAFF4C: D6220001 03FD0101 00006400
	v_sad_u8 v5, v5, 0, 0x6400                                 // 000000DAFF58: D6220005 03FD0105 00006400
	v_sad_u8 v7, v7, 0, 0x6400                                 // 000000DAFF64: D6220007 03FD0107 00006400
	v_sad_u8 v8, v8, 0, 0x6400                                 // 000000DAFF70: D6220008 03FD0108 00006400
	v_sad_u8 v9, v9, 0, 0x6400                                 // 000000DAFF7C: D6220009 03FD0109 00006400
	v_and_b32_e32 v4, 0xffff, v4                               // 000000DAFF88: 360808FF 0000FFFF
	v_lshlrev_b32_e32 v1, 16, v1                               // 000000DAFF90: 30020290
	v_sad_u8 v6, v6, 0, 0x6400                                 // 000000DAFF94: D6220006 03FD0106 00006400
	v_sad_u8 v3, v3, 0, 0x6400                                 // 000000DAFFA0: D6220003 03FD0103 00006400
	v_and_b32_e32 v5, 0xffff, v5                               // 000000DAFFAC: 360A0AFF 0000FFFF
	v_and_b32_e32 v7, 0xffff, v7                               // 000000DAFFB4: 360E0EFF 0000FFFF
	v_lshl_or_b32 v4, v8, 16, v4                               // 000000DAFFBC: D6560004 04112108
	v_and_or_b32 v1, 0xffff, v9, v1                            // 000000DAFFC4: D6570001 040612FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DAFFD0: BF870214
	v_lshl_or_b32 v8, v6, 16, v5                               // 000000DAFFD4: D6560008 04152106
	v_lshl_or_b32 v7, v3, 16, v7                               // 000000DAFFDC: D6560007 041D2103
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DAFFE4: BF870214
	v_pk_fma_f16 v5, v4, s4, 0xc931 op_sel_hi:[1,0,0]          // 000000DAFFE8: CC0E0005 0BFC0904 0000C931
	v_pk_fma_f16 v6, v1, s4, 0xc931 op_sel_hi:[1,0,0]          // 000000DAFFF4: CC0E0006 0BFC0901 0000C931
	v_lshl_add_u32 v1, s1, 12, v88                             // 000000DB0000: D6460001 05611801
	v_pk_fma_f16 v3, v8, s4, 0xc931 op_sel_hi:[1,0,0]          // 000000DB0008: CC0E0003 0BFC0908 0000C931
	v_pk_fma_f16 v4, v7, s4, 0xc931 op_sel_hi:[1,0,0]          // 000000DB0014: CC0E0004 0BFC0907 0000C931
	ds_store_b128 v1, v[3:6]                                   // 000000DB0020: DB7C0000 00000301
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DB0028: 8C7E067E
	s_and_saveexec_b32 s6, vcc_lo                              // 000000DB002C: BE86206A
	s_cbranch_execz 65377                                      // 000000DB0030: BFA5FF61 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x4b8>
	s_lshl_b32 s1, s7, 5                                       // 000000DB0034: 84018507
	v_lshl_or_b32 v1, s14, 12, v87                             // 000000DB0038: D6560001 055D180E
	.long 0xd7000103                                           // 000000DB0040: D7000103
	v_cndmask_b32_e32 v0, v74, v1, vcc_lo                      // 000000DB0044: 0200034A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB0048: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v75, s1                   // 000000DB004C: D5207C04 00069680
	ds_load_b128 v[97:100], v1                                 // 000000DB0054: DBFC0000 61000001
	ds_load_b128 v[101:104], v1 offset:16                      // 000000DB005C: DBFC0010 65000001
	ds_load_b128 v[109:112], v1 offset:528                     // 000000DB0064: DBFC0210 6D000001
	ds_load_b128 v[105:108], v1 offset:512                     // 000000DB006C: DBFC0200 69000001
	ds_load_b128 v[117:120], v1 offset:1040                    // 000000DB0074: DBFC0410 75000001
	ds_load_b128 v[113:116], v1 offset:1024                    // 000000DB007C: DBFC0400 71000001
	ds_load_b128 v[125:128], v1 offset:1552                    // 000000DB0084: DBFC0610 7D000001
	ds_load_b128 v[121:124], v1 offset:1536                    // 000000DB008C: DBFC0600 79000001
	ds_load_b128 v[133:136], v1 offset:2064                    // 000000DB0094: DBFC0810 85000001
	ds_load_b128 v[129:132], v1 offset:2048                    // 000000DB009C: DBFC0800 81000001
	s_clause 0x1                                               // 000000DB00A4: BF850001
	global_load_b128 v[93:96], v[3:4], off offset:16           // 000000DB00A8: DC5E0010 5D7C0003
	global_load_b128 v[89:92], v[3:4], off                     // 000000DB00B0: DC5E0000 597C0003
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 000000DB00B8: BF890087
	v_wmma_f32_16x16x16_f16 v[66:73], v[89:96], v[97:104], v[66:73]// 000000DB00BC: CC404042 1D0AC359
	ds_load_b128 v[101:104], v1 offset:2576                    // 000000DB00C4: DBFC0A10 65000001
	ds_load_b128 v[97:100], v1 offset:2560                     // 000000DB00CC: DBFC0A00 61000001
	s_waitcnt lgkmcnt(8)                                       // 000000DB00D4: BF89FC87
	v_wmma_f32_16x16x16_f16 v[58:65], v[89:96], v[105:112], v[58:65]// 000000DB00D8: CC40403A 1CEAD359
	ds_load_b128 v[109:112], v1 offset:3088                    // 000000DB00E0: DBFC0C10 6D000001
	ds_load_b128 v[105:108], v1 offset:3072                    // 000000DB00E8: DBFC0C00 69000001
	s_waitcnt lgkmcnt(8)                                       // 000000DB00F0: BF89FC87
	v_wmma_f32_16x16x16_f16 v[50:57], v[89:96], v[113:120], v[50:57]// 000000DB00F4: CC404032 1CCAE359
	ds_load_b128 v[117:120], v1 offset:3600                    // 000000DB00FC: DBFC0E10 75000001
	ds_load_b128 v[113:116], v1 offset:3584                    // 000000DB0104: DBFC0E00 71000001
	s_waitcnt lgkmcnt(8)                                       // 000000DB010C: BF89FC87
	v_wmma_f32_16x16x16_f16 v[42:49], v[89:96], v[121:128], v[42:49]// 000000DB0110: CC40402A 1CAAF359
	s_waitcnt lgkmcnt(6)                                       // 000000DB0118: BF89FC67
	v_wmma_f32_16x16x16_f16 v[34:41], v[89:96], v[129:136], v[34:41]// 000000DB011C: CC404022 1C8B0359
	s_waitcnt lgkmcnt(4)                                       // 000000DB0124: BF89FC47
	v_wmma_f32_16x16x16_f16 v[26:33], v[89:96], v[97:104], v[26:33]// 000000DB0128: CC40401A 1C6AC359
	s_waitcnt lgkmcnt(2)                                       // 000000DB0130: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[89:96], v[105:112], v[18:25]// 000000DB0134: CC404012 1C4AD359
	s_waitcnt lgkmcnt(0)                                       // 000000DB013C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[89:96], v[113:120], v[10:17]// 000000DB0140: CC40400A 1C2AE359
	s_branch 65307                                             // 000000DB0148: BFA0FF1B <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x4b8>
	s_waitcnt lgkmcnt(0)                                       // 000000DB014C: BF89FC07
	s_barrier                                                  // 000000DB0150: BFBD0000
	buffer_gl0_inv                                             // 000000DB0154: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 000000DB015C: BE80206A
	s_cbranch_execz 61                                         // 000000DB0160: BFA5003D <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x958>
	s_clause 0x1                                               // 000000DB0164: BF850001
	global_load_b128 v[5:8], v[74:75], off offset:1264         // 000000DB0168: DC5E04F0 057C004A
	global_load_b128 v[1:4], v[74:75], off offset:1248         // 000000DB0170: DC5E04E0 017C004A
	ds_load_b128 v[79:82], v87 offset:4096                     // 000000DB0178: DBFC1000 4F000057
	ds_load_b128 v[83:86], v87 offset:4112                     // 000000DB0180: DBFC1010 53000057
	ds_load_b128 v[92:95], v87 offset:4624                     // 000000DB0188: DBFC1210 5C000057
	ds_load_b128 v[88:91], v87 offset:4608                     // 000000DB0190: DBFC1200 58000057
	ds_load_b128 v[100:103], v87 offset:5136                   // 000000DB0198: DBFC1410 64000057
	ds_load_b128 v[96:99], v87 offset:5120                     // 000000DB01A0: DBFC1400 60000057
	ds_load_b128 v[108:111], v87 offset:5648                   // 000000DB01A8: DBFC1610 6C000057
	ds_load_b128 v[104:107], v87 offset:5632                   // 000000DB01B0: DBFC1600 68000057
	ds_load_b128 v[116:119], v87 offset:6160                   // 000000DB01B8: DBFC1810 74000057
	ds_load_b128 v[112:115], v87 offset:6144                   // 000000DB01C0: DBFC1800 70000057
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 000000DB01C8: BF890087
	v_wmma_f32_16x16x16_f16 v[66:73], v[1:8], v[79:86], v[66:73]// 000000DB01CC: CC404042 1D0A9F01
	ds_load_b128 v[83:86], v87 offset:6672                     // 000000DB01D4: DBFC1A10 53000057
	ds_load_b128 v[79:82], v87 offset:6656                     // 000000DB01DC: DBFC1A00 4F000057
	s_waitcnt lgkmcnt(8)                                       // 000000DB01E4: BF89FC87
	v_wmma_f32_16x16x16_f16 v[58:65], v[1:8], v[88:95], v[58:65]// 000000DB01E8: CC40403A 1CEAB101
	ds_load_b128 v[92:95], v87 offset:7184                     // 000000DB01F0: DBFC1C10 5C000057
	ds_load_b128 v[88:91], v87 offset:7168                     // 000000DB01F8: DBFC1C00 58000057
	s_waitcnt lgkmcnt(8)                                       // 000000DB0200: BF89FC87
	v_wmma_f32_16x16x16_f16 v[50:57], v[1:8], v[96:103], v[50:57]// 000000DB0204: CC404032 1CCAC101
	ds_load_b128 v[100:103], v87 offset:7696                   // 000000DB020C: DBFC1E10 64000057
	ds_load_b128 v[96:99], v87 offset:7680                     // 000000DB0214: DBFC1E00 60000057
	s_waitcnt lgkmcnt(8)                                       // 000000DB021C: BF89FC87
	v_wmma_f32_16x16x16_f16 v[42:49], v[1:8], v[104:111], v[42:49]// 000000DB0220: CC40402A 1CAAD101
	s_waitcnt lgkmcnt(6)                                       // 000000DB0228: BF89FC67
	v_wmma_f32_16x16x16_f16 v[34:41], v[1:8], v[112:119], v[34:41]// 000000DB022C: CC404022 1C8AE101
	s_waitcnt lgkmcnt(4)                                       // 000000DB0234: BF89FC47
	v_wmma_f32_16x16x16_f16 v[26:33], v[1:8], v[79:86], v[26:33]// 000000DB0238: CC40401A 1C6A9F01
	s_waitcnt lgkmcnt(2)                                       // 000000DB0240: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[1:8], v[88:95], v[18:25]// 000000DB0244: CC404012 1C4AB101
	s_waitcnt lgkmcnt(0)                                       // 000000DB024C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[1:8], v[96:103], v[10:17]// 000000DB0250: CC40400A 1C2AC101
	s_or_b32 exec_lo, exec_lo, s0                              // 000000DB0258: 8C7E007E
	s_and_saveexec_b32 s0, vcc_lo                              // 000000DB025C: BE80206A
	s_cbranch_execz 2628                                       // 000000DB0260: BFA50A44 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3274>
	v_sub_f32_e32 v5, v66, v58                                 // 000000DB0264: 080A7542
	v_sub_f32_e32 v7, v50, v42                                 // 000000DB0268: 080E5532
	v_add_f32_e32 v8, v34, v26                                 // 000000DB026C: 06103522
	v_sub_f32_e32 v9, v34, v26                                 // 000000DB0270: 08123522
	v_add_f32_e32 v26, v18, v10                                // 000000DB0274: 06341512
	v_sub_f32_e32 v10, v18, v10                                // 000000DB0278: 08141512
	v_dual_add_f32 v4, v66, v58 :: v_dual_and_b32 v1, 1, v0    // 000000DB027C: C9247542 04000081
	v_add_f32_e32 v6, v50, v42                                 // 000000DB0284: 060C5532
	v_add_f32_e32 v34, v5, v7                                  // 000000DB0288: 06440F05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB028C: BF870004
	v_add_f32_e32 v50, v9, v10                                 // 000000DB0290: 06641509
	s_mul_i32 s1, s12, 0x1400                                  // 000000DB0294: 9601FF0C 00001400
	.long 0xd44a0000                                           // 000000DB029C: D44A0000
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000DB02A0: 02020280
	s_mul_hi_i32 s2, s12, 0x1400                               // 000000DB02A4: 9702FF0C 00001400
	s_add_u32 s1, s10, s1                                      // 000000DB02AC: 8001010A
	v_add_f32_e32 v2, v34, v50                                 // 000000DB02B0: 06046522
	s_addc_u32 s5, s11, s2                                     // 000000DB02B4: 8205020B
	s_lshl_b32 s2, s13, 7                                      // 000000DB02B8: 8402870D
	v_lshrrev_b32_e32 v74, 4, v76                              // 000000DB02BC: 32949884
	s_ashr_i32 s3, s2, 31                                      // 000000DB02C0: 86039F02
	v_mov_b32_dpp v1, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB02C4: 7E0202FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000DB02CC: D5010002 20020502
	s_lshl_b64 s[6:7], s[2:3], 1                               // 000000DB02D4: 84868102
	v_sub_f32_e32 v9, v9, v10                                  // 000000DB02D8: 08121509
	s_add_u32 s4, s1, s6                                       // 000000DB02DC: 80040601
	s_addc_u32 s5, s5, s7                                      // 000000DB02E0: 82050705
	v_dual_add_f32 v1, v2, v1 :: v_dual_and_b32 v2, 2, v0      // 000000DB02E4: C9240302 01020082
	v_sub_f32_e32 v34, v34, v50                                // 000000DB02EC: 08446522
	s_add_u32 s3, s8, s6                                       // 000000DB02F0: 80030608
	s_addc_u32 s6, s9, s7                                      // 000000DB02F4: 82060709
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000DB02F8: BF870252
	v_mov_b32_dpp v3, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB02FC: 7E0602FA FF016201
	.long 0xd44a0002                                           // 000000DB0304: D44A0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000DB0308: 02020480
	v_dual_sub_f32 v5, v5, v7 :: v_dual_and_b32 v2, 4, v0      // 000000DB030C: C9640F05 05020084
	v_add_f32_e32 v42, v8, v26                                 // 000000DB0314: 06543508
	v_and_b32_e32 v0, 8, v0                                    // 000000DB0318: 36000088
	v_cndmask_b32_e64 v1, -v1, v1, s2                          // 000000DB031C: D5010001 200A0301
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB0324: BF870234
	.long 0xd44a0001                                           // 000000DB0328: D44A0001
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000DB032C: 02020480
	v_add_f32_e32 v10, v5, v9                                  // 000000DB0330: 06141305
	v_dual_sub_f32 v9, v5, v9 :: v_dual_lshlrev_b32 v2, 1, v78 // 000000DB0334: C9621305 09029C81
	v_dual_add_f32 v75, v1, v3 :: v_dual_add_f32 v18, v4, v6   // 000000DB033C: C9080701 4B120D04
	v_sub_f32_e32 v4, v4, v6                                   // 000000DB0344: 08080D04
	v_sub_f32_e32 v6, v8, v26                                  // 000000DB0348: 080C3508
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000DB034C: 7C940080
	.long 0xd7000300                                           // 000000DB0350: D7000300
	v_cndmask_b32_e32 v1, s3, v2, vcc_lo                       // 000000DB0354: 02020403
	v_add_f32_e32 v58, v18, v42                                // 000000DB0358: 06745512
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB035C: BF870004
	v_add_f32_e32 v26, v4, v6                                  // 000000DB0360: 06340D04
	v_sub_f32_e32 v18, v18, v42                                // 000000DB0364: 08245512
	v_sub_f32_e32 v50, v4, v6                                  // 000000DB0368: 08640D04
	v_add_co_ci_u32_e64 v1, null, s6, 0, s3                    // 000000DB036C: D5207C01 000D0006
	v_cndmask_b32_e64 v66, -v58, v58, s0                       // 000000DB0374: D5010042 2002753A
	v_mov_b32_dpp v58, v58 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB037C: 7E7402FA FF01613A
	v_mov_b32_dpp v42, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0384: 7E5402FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s0                       // 000000DB038C: D501001A 2002351A
	s_mov_b32 s6, exec_lo                                      // 000000DB0394: BE86007E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB0398: BF870093
	v_add_f32_e32 v58, v66, v58                                // 000000DB039C: 06747542
	v_mov_b32_dpp v7, v58 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB03A0: 7E0E02FA FF01623A
	v_cndmask_b32_e64 v8, -v58, v58, s2                        // 000000DB03A8: D5010008 200A753A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DB03B0: BF870241
	v_add_f32_e32 v7, v8, v7                                   // 000000DB03B4: 060E0F08
	v_mov_b32_dpp v8, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB03B8: 7E1002FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000DB03C0: D501000A 2002150A
	v_add_nc_u32_e32 v3, v77, v74                              // 000000DB03C8: 4A06954D
	v_mov_b32_dpp v4, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB03CC: 7E0802FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000DB03D4: D5010007 20060F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DB03DC: BF870244
	v_add_f32_e32 v6, v10, v8                                  // 000000DB03E0: 060C110A
	v_add_f32_e32 v10, v26, v42                                // 000000DB03E4: 0614551A
	v_mov_b32_dpp v8, v75 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB03E8: 7E1002FA FF01644B
	v_cndmask_b32_e64 v26, -v75, v75, s1                       // 000000DB03F0: D501001A 2006974B
	v_mov_b32_dpp v42, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB03F8: 7E5402FA FF016206
	v_cndmask_b32_e64 v58, -v6, v6, s2                         // 000000DB0400: D501003A 200A0D06
	v_mov_b32_dpp v66, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB0408: 7E8402FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DB0410: D501000A 200A150A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB0418: BF870001
	v_add_f32_e32 v10, v10, v66                                // 000000DB041C: 0614850A
	v_mov_b32_dpp v66, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0420: 7E8402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000DB0428: D5010009 20021309
	v_add_f32_e32 v6, v7, v4                                   // 000000DB0430: 060C0907
	v_add_f32_e32 v7, v26, v8                                  // 000000DB0434: 060E111A
	v_add_f32_e32 v8, v58, v42                                 // 000000DB0438: 0610553A
	v_mov_b32_dpp v58, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB043C: 7E7402FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000DB0444: D5010012 20022512
	v_add_f32_e32 v9, v9, v66                                  // 000000DB044C: 06128509
	v_mov_b32_dpp v42, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0450: 7E5402FA FF01640A
	v_mov_b32_dpp v26, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0458: 7E3402FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB0460: D5010008 20061108
	v_add_f32_e32 v18, v18, v58                                // 000000DB0468: 06247512
	v_mov_b32_dpp v58, v50 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB046C: 7E7402FA FF016132
	v_cndmask_b32_e64 v50, -v50, v50, s0                       // 000000DB0474: D5010032 20026532
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000DB047C: D501000A 2006150A
	v_add_f32_e32 v8, v8, v26                                  // 000000DB0484: 06103508
	v_mov_b32_dpp v26, v34 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0488: 7E3402FA FF016122
	v_cndmask_b32_e64 v34, -v34, v34, s0                       // 000000DB0490: D5010022 20024522
	v_add_f32_e32 v50, v50, v58                                // 000000DB0498: 06647532
	v_mov_b32_dpp v66, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB049C: 7E8402FA FF016209
	v_cndmask_b32_e64 v74, -v9, v9, s2                         // 000000DB04A4: D501004A 200A1309
	v_add_f32_e32 v9, v10, v42                                 // 000000DB04AC: 0612550A
	v_add_f32_e32 v26, v34, v26                                // 000000DB04B0: 06343522
	v_mov_b32_dpp v34, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB04B4: 7E4402FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000DB04BC: D5010012 200A2512
	v_mov_b32_dpp v4, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB04C4: 7E0802FA FF016806
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB04CC: 7E0A02FA FF016807
	v_mov_b32_dpp v58, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB04D4: 7E7402FA FF01621A
	v_cndmask_b32_e64 v26, -v26, v26, s2                       // 000000DB04DC: D501001A 200A351A
	v_add_f32_e32 v18, v18, v34                                // 000000DB04E4: 06244512
	v_mov_b32_dpp v34, v50 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB04E8: 7E4402FA FF016232
	v_cndmask_b32_e64 v50, -v50, v50, s2                       // 000000DB04F0: D5010032 200A6532
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB04F8: BF870214
	v_add_f32_e32 v26, v26, v58                                // 000000DB04FC: 0634751A
	v_mov_b32_dpp v42, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0500: 7E5402FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000DB0508: D5010012 20062512
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB0510: BF870004
	v_add_f32_e32 v10, v50, v34                                // 000000DB0514: 06144532
	v_add_f32_e32 v34, v74, v66                                // 000000DB0518: 0644854A
	v_mov_b32_dpp v50, v26 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB051C: 7E6402FA FF01641A
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000DB0524: D501001A 2006351A
	v_add_f32_e32 v58, v18, v42                                // 000000DB052C: 06745512
	v_mov_b32_dpp v66, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0530: 7E8402FA FF01640A
	v_mov_b32_dpp v75, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0538: 7E9602FA FF016422
	v_cndmask_b32_e64 v76, -v10, v10, s1                       // 000000DB0540: D501004C 2006150A
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000DB0548: D5010022 20064522
	v_add_f32_e32 v74, v26, v50                                // 000000DB0550: 0694651A
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0554: 7E1402FA FF016809
	v_mov_b32_dpp v50, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB055C: 7E6402FA FF016808
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB0564: BF8701B4
	v_dual_add_f32 v66, v76, v66 :: v_dual_add_f32 v75, v34, v75// 000000DB0568: C908854C 424A9722
	v_mov_b32_dpp v34, v58 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0570: 7E4402FA FF01683A
	v_mov_b32_dpp v42, v74 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0578: 7E5402FA FF01684A
	v_mov_b32_dpp v18, v66 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0580: 7E2402FA FF016842
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB0588: BF870004
	v_mov_b32_dpp v26, v75 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB058C: 7E3402FA FF01684B
	.long 0xd4c4007e                                           // 000000DB0594: D4C4007E
	v_cndmask_b32_e32 v1, s15, v3, vcc_lo                      // 000000DB0598: 0202060F
	s_cbranch_execz 149                                        // 000000DB059C: BFA50095 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xef4>
	s_clause 0x7                                               // 000000DB05A0: BF850007
	global_load_d16_b16 v78, v2, s[4:5] offset:32              // 000000DB05A4: DC820020 4E040002
	global_load_d16_b16 v79, v2, s[4:5]                        // 000000DB05AC: DC820000 4F040002
	global_load_d16_b16 v80, v2, s[4:5] offset:64              // 000000DB05B4: DC820040 50040002
	global_load_d16_b16 v81, v2, s[4:5] offset:96              // 000000DB05BC: DC820060 51040002
	global_load_d16_b16 v82, v2, s[4:5] offset:128             // 000000DB05C4: DC820080 52040002
	global_load_d16_b16 v83, v2, s[4:5] offset:160             // 000000DB05CC: DC8200A0 53040002
	global_load_d16_b16 v84, v2, s[4:5] offset:192             // 000000DB05D4: DC8200C0 54040002
	global_load_d16_b16 v85, v2, s[4:5] offset:224             // 000000DB05DC: DC8200E0 55040002
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000DB05E4: D5010007 21AA0F07
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000DB05EC: D5010006 21AA0D06
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DB05F4: D5010009 21AA1309
	v_cndmask_b32_e64 v58, -v58, v58, vcc_lo                   // 000000DB05FC: D501003A 21AA753A
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DB0604: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB060C: BF870214
	v_dual_add_f32 v5, v7, v5 :: v_dual_add_f32 v4, v6, v4     // 000000DB0610: C9080B07 05040906
	v_add_f32_e32 v7, v9, v10                                  // 000000DB0618: 060E1509
	s_waitcnt vmcnt(7)                                         // 000000DB061C: BF891FF7
	.long 0x7f9c3880                                           // 000000DB0620: 7F9C3880
	v_cndmask_b32_e64 v74, -v74, v74, vcc_lo                   // 000000DB0624: D501004A 21AA954A
	v_dual_add_f32 v8, v8, v50 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000DB062C: C9066508 08040AFF 3DB504F3
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000DB0638: 100808FF 3DB504F3
	v_dual_add_f32 v10, v58, v34 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000DB0640: C906453A 0A060EFF 3DB504F3
	v_cndmask_b32_e64 v75, -v75, v75, vcc_lo                   // 000000DB064C: D501004B 21AA974B
	v_cndmask_b32_e64 v66, -v66, v66, vcc_lo                   // 000000DB0654: D5010042 21AA8542
	.long 0x7f1239ce                                           // 000000DB065C: 7F1239CE
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000DB0660: 101010FF 3DB504F3
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000DB0668: 101414FF 3DB504F3
	v_add_f32_e32 v26, v75, v26                                // 000000DB0670: 0634354B
	v_add_f32_e32 v18, v66, v18                                // 000000DB0674: 06242542
	.long 0x7f0c39ce                                           // 000000DB0678: 7F0C39CE
	.long 0x7f6439ce                                           // 000000DB067C: 7F6439CE
	v_mad_i64_i32 v[76:77], null, 0x1400, v3, v[0:1]           // 000000DB0680: D6FF7C4C 040206FF 00001400
	v_mul_f32_e32 v26, 0x3db504f3, v26                         // 000000DB068C: 103434FF 3DB504F3
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 000000DB0694: 102424FF 3DB504F3
	v_fma_mix_f32 v5, v78, v5, neg(0) op_sel_hi:[1,0,0]        // 000000DB069C: CC200005 8A020B4E
	s_waitcnt vmcnt(6)                                         // 000000DB06A4: BF891BF7
	v_fma_mix_f32 v4, v79, v4, neg(0) op_sel_hi:[1,0,0]        // 000000DB06A8: CC200004 8A02094F
	s_waitcnt vmcnt(5)                                         // 000000DB06B0: BF8917F7
	v_fma_mix_f32 v7, v80, v7, neg(0) op_sel_hi:[1,0,0]        // 000000DB06B4: CC200007 8A020F50
	s_waitcnt vmcnt(4)                                         // 000000DB06BC: BF8913F7
	v_fma_mix_f32 v8, v81, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DB06C0: CC200008 8A021151
	s_waitcnt vmcnt(3)                                         // 000000DB06C8: BF890FF7
	v_fma_mix_f32 v10, v82, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DB06CC: CC20000A 8A021552
	.long 0x7e9c3985                                           // 000000DB06D4: 7E9C3985
	s_waitcnt vmcnt(1)                                         // 000000DB06D8: BF8907F7
	v_fma_mix_f32 v18, v84, v18, neg(0) op_sel_hi:[1,0,0]      // 000000DB06DC: CC200012 8A022554
	.long 0x7e123987                                           // 000000DB06E4: 7E123987
	v_add_f32_e32 v34, v74, v42                                // 000000DB06E8: 0644554A
	s_waitcnt vmcnt(0)                                         // 000000DB06EC: BF8903F7
	v_fma_mix_f32 v26, v85, v26, neg(0) op_sel_hi:[1,0,0]      // 000000DB06F0: CC20001A 8A023555
	v_and_b32_e32 v58, 1, v78                                  // 000000DB06F8: 36749C81
	.long 0x7e9c3988                                           // 000000DB06FC: 7E9C3988
	v_dual_mul_f32 v34, 0x3db504f3, v34 :: v_dual_and_b32 v9, 1, v9// 000000DB0700: C8E444FF 22081281 3DB504F3
	.long 0x7e0c3984                                           // 000000DB070C: 7E0C3984
	.long 0x7f5439ce                                           // 000000DB0710: 7F5439CE
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB0714: BF870004
	v_and_b32_e32 v66, 1, v78                                  // 000000DB0718: 36849C81
	.long 0x7e54398a                                           // 000000DB071C: 7E54398A
	v_fma_mix_f32 v34, v83, v34, neg(0) op_sel_hi:[1,0,0]      // 000000DB0720: CC200022 8A024553
	.long 0x7e643992                                           // 000000DB0728: 7E643992
	v_and_b32_e32 v6, 1, v6                                    // 000000DB072C: 360C0C81
	v_add3_u32 v5, v5, v58, 0x7fff                             // 000000DB0730: D6550005 03FE7505 00007FFF
	v_and_b32_e32 v42, 1, v42                                  // 000000DB073C: 36545481
	.long 0x7e9c39a2                                           // 000000DB0740: 7E9C39A2
	v_and_b32_e32 v50, 1, v50                                  // 000000DB0744: 36646481
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000DB0748: D6550004 03FE0D04 00007FFF
	v_add3_u32 v6, v7, v9, 0x7fff                              // 000000DB0754: D6550006 03FE1307 00007FFF
	v_add3_u32 v8, v8, v66, 0x7fff                             // 000000DB0760: D6550008 03FE8508 00007FFF
	v_and_b32_e32 v74, 1, v78                                  // 000000DB076C: 36949C81
	.long 0x7e9c399a                                           // 000000DB0770: 7E9C399A
	v_add3_u32 v9, v10, v42, 0x7fff                            // 000000DB0774: D6550009 03FE550A 00007FFF
	v_add3_u32 v10, v18, v50, 0x7fff                           // 000000DB0780: D655000A 03FE6512 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB078C: BF870214
	v_add3_u32 v18, v34, v74, 0x7fff                           // 000000DB0790: D6550012 03FE9522 00007FFF
	v_and_b32_e32 v7, 1, v78                                   // 000000DB079C: 360E9C81
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB07A0: BF870001
	v_add3_u32 v7, v26, v7, 0x7fff                             // 000000DB07A4: D6550007 03FE0F1A 00007FFF
	s_clause 0x7                                               // 000000DB07B0: BF850007
	global_store_d16_hi_b16 v[76:77], v4, off                  // 000000DB07B4: DC960000 007C044C
	global_store_d16_hi_b16 v[76:77], v5, off offset:32        // 000000DB07BC: DC960020 007C054C
	global_store_d16_hi_b16 v[76:77], v6, off offset:64        // 000000DB07C4: DC960040 007C064C
	global_store_d16_hi_b16 v[76:77], v8, off offset:96        // 000000DB07CC: DC960060 007C084C
	global_store_d16_hi_b16 v[76:77], v9, off offset:128       // 000000DB07D4: DC960080 007C094C
	global_store_d16_hi_b16 v[76:77], v18, off offset:160      // 000000DB07DC: DC9600A0 007C124C
	global_store_d16_hi_b16 v[76:77], v10, off offset:192      // 000000DB07E4: DC9600C0 007C0A4C
	global_store_d16_hi_b16 v[76:77], v7, off offset:224       // 000000DB07EC: DC9600E0 007C074C
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DB07F4: 8C7E067E
	v_add_f32_e32 v6, v51, v43                                 // 000000DB07F8: 060C5733
	v_add_f32_e32 v8, v35, v27                                 // 000000DB07FC: 06103723
	v_add_f32_e32 v9, v19, v11                                 // 000000DB0800: 06121713
	v_add_f32_e32 v4, v67, v59                                 // 000000DB0804: 06087743
	v_sub_f32_e32 v11, v19, v11                                // 000000DB0808: 08161713
	v_sub_f32_e32 v10, v35, v27                                // 000000DB080C: 08143723
	s_mov_b32 s6, exec_lo                                      // 000000DB0810: BE86007E
	v_add_f32_e32 v19, v8, v9                                  // 000000DB0814: 06261308
	v_dual_sub_f32 v5, v67, v59 :: v_dual_add_f32 v18, v4, v6  // 000000DB0818: C9487743 05120D04
	v_dual_sub_f32 v7, v51, v43 :: v_dual_sub_f32 v4, v4, v6   // 000000DB0820: C94A5733 07040D04
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v27, v10, v11  // 000000DB0828: C9481308 081A170A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB0830: BF870193
	v_add_f32_e32 v34, v18, v19                                // 000000DB0834: 06442712
	v_add_f32_e32 v26, v5, v7                                  // 000000DB0838: 06340F05
	v_sub_f32_e32 v6, v5, v7                                   // 000000DB083C: 080C0F05
	v_sub_f32_e32 v9, v10, v11                                 // 000000DB0840: 0812170A
	v_sub_f32_e32 v10, v18, v19                                // 000000DB0844: 08142712
	v_mov_b32_dpp v5, v34 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0848: 7E0A02FA FF016122
	v_cndmask_b32_e64 v7, -v34, v34, s0                        // 000000DB0850: D5010007 20024522
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB0858: BF8701B1
	v_dual_add_f32 v18, v4, v8 :: v_dual_add_f32 v5, v7, v5    // 000000DB085C: C9081104 12040B07
	v_add_f32_e32 v35, v26, v27                                // 000000DB0864: 0646371A
	v_sub_f32_e32 v11, v26, v27                                // 000000DB0868: 0816371A
	v_mov_b32_dpp v26, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB086C: 7E3402FA FF016205
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DB0874: BF870133
	v_mov_b32_dpp v34, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0878: 7E4402FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s0                       // 000000DB0880: D5010023 20024723
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000DB0888: D5010005 200A0B05
	v_add_f32_e32 v7, v35, v34                                 // 000000DB0890: 060E4523
	v_add_f32_e32 v19, v6, v9                                  // 000000DB0894: 06261306
	v_mov_b32_dpp v34, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0898: 7E4402FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000DB08A0: D5010012 20022512
	v_dual_add_f32 v5, v5, v26 :: v_dual_sub_f32 v26, v4, v8   // 000000DB08A8: C90A3505 051A1104
	v_mov_b32_dpp v27, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB08B0: 7E3602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000DB08B8: D5010007 200A0F07
	v_mov_b32_dpp v35, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB08C0: 7E4602FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000DB08C8: D5010013 20022713
	v_add_f32_e32 v4, v18, v34                                 // 000000DB08D0: 06084512
	v_mov_b32_dpp v18, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB08D4: 7E2402FA FF016405
	v_add_f32_e32 v7, v7, v27                                  // 000000DB08DC: 060E3707
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DB08E0: D5010005 20060B05
	v_add_f32_e32 v8, v19, v35                                 // 000000DB08E8: 06104713
	v_mov_b32_dpp v19, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB08EC: 7E2602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000DB08F4: D5010004 200A0904
	v_mov_b32_dpp v34, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB08FC: 7E4402FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000DB0904: D5010007 20060F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB090C: BF8701A3
	v_dual_add_f32 v5, v5, v18 :: v_dual_add_f32 v18, v4, v19  // 000000DB0910: C9082505 05122704
	v_sub_f32_e32 v19, v6, v9                                  // 000000DB0918: 08261306
	v_add_f32_e32 v7, v7, v34                                  // 000000DB091C: 060E4507
	v_mov_b32_dpp v34, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0920: 7E4402FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000DB0928: D501000A 2002150A
	v_mov_b32_dpp v27, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB0930: 7E3602FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DB0938: D5010008 200A1108
	v_mov_b32_dpp v4, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0940: 7E0802FA FF016805
	v_mov_b32_dpp v6, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0948: 7E0C02FA FF016807
	v_add_f32_e32 v10, v10, v34                                // 000000DB0950: 0614450A
	v_mov_b32_dpp v34, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0954: 7E4402FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000DB095C: D5010013 20022713
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DB0964: BF870241
	v_add_f32_e32 v19, v19, v34                                // 000000DB0968: 06264513
	v_mov_b32_dpp v9, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB096C: 7E1202FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000DB0974: D5010012 20062512
	v_add_f32_e32 v8, v8, v27                                  // 000000DB097C: 06103708
	v_mov_b32_dpp v35, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB0980: 7E4602FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000DB0988: D5010013 200A2713
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB0990: BF870214
	v_add_f32_e32 v9, v18, v9                                  // 000000DB0994: 06121312
	v_mov_b32_dpp v27, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0998: 7E3602FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB09A0: D5010008 20061108
	v_mov_b32_dpp v18, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB09A8: 7E2402FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000DB09B0: D501000B 2002170B
	v_add_f32_e32 v19, v19, v35                                // 000000DB09B8: 06264713
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB09BC: BF870112
	v_add_f32_e32 v11, v11, v18                                // 000000DB09C0: 0616250B
	v_mov_b32_dpp v50, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB09C4: 7E6402FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000DB09CC: D5010013 20062713
	v_add_f32_e32 v8, v8, v27                                  // 000000DB09D4: 06103708
	v_mov_b32_dpp v27, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB09D8: 7E3602FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s0                       // 000000DB09E0: D501001A 2002351A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB09E8: BF8701B1
	v_add_f32_e32 v26, v26, v27                                // 000000DB09EC: 0634371A
	v_mov_b32_dpp v27, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB09F0: 7E3602FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000DB09F8: D501000B 200A170B
	v_mov_b32_dpp v34, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB0A00: 7E4402FA FF01621A
	v_cndmask_b32_e64 v26, -v26, v26, s2                       // 000000DB0A08: D501001A 200A351A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB0A10: BF870233
	v_add_f32_e32 v11, v11, v27                                // 000000DB0A14: 0616370B
	v_mov_b32_dpp v18, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB0A18: 7E2402FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DB0A20: D501000A 200A150A
	v_add_f32_e32 v26, v26, v34                                // 000000DB0A28: 0634451A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB0A2C: BF870224
	v_mov_b32_dpp v35, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0A30: 7E4602FA FF01640B
	v_cndmask_b32_e64 v42, -v11, v11, s1                       // 000000DB0A38: D501002A 2006170B
	v_add_f32_e32 v18, v10, v18                                // 000000DB0A40: 0624250A
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0A44: 7E1402FA FF016809
	v_mov_b32_dpp v43, v26 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0A4C: 7E5602FA FF01641A
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000DB0A54: D501001A 2006351A
	v_add_f32_e32 v42, v42, v35                                // 000000DB0A5C: 0654472A
	v_mov_b32_dpp v27, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0A60: 7E3602FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000DB0A68: D5010012 20062512
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB0A70: BF870234
	v_add_f32_e32 v35, v26, v43                                // 000000DB0A74: 0646571A
	v_add_f32_e32 v43, v19, v50                                // 000000DB0A78: 06566513
	v_mov_b32_dpp v11, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0A7C: 7E1602FA FF016808
	v_add_f32_e32 v34, v18, v27                                // 000000DB0A84: 06443712
	v_add_nc_u32_e32 v50, 2, v3                                // 000000DB0A88: 4A640682
	v_mov_b32_dpp v27, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0A8C: 7E3602FA FF01682A
	v_mov_b32_dpp v18, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0A94: 7E2402FA FF016823
	v_mov_b32_dpp v19, v43 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0A9C: 7E2602FA FF01682B
	v_mov_b32_dpp v26, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0AA4: 7E3402FA FF016822
	.long 0xd4c4007e                                           // 000000DB0AAC: D4C4007E
	v_cndmask_b32_e32 v1, s15, v50, vcc_lo                     // 000000DB0AB0: 0202640F
	s_cbranch_execz 148                                        // 000000DB0AB4: BFA50094 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1408>
	s_clause 0x7                                               // 000000DB0AB8: BF850007
	global_load_d16_b16 v58, v2, s[4:5] offset:32              // 000000DB0ABC: DC820020 3A040002
	global_load_d16_b16 v59, v2, s[4:5]                        // 000000DB0AC4: DC820000 3B040002
	global_load_d16_b16 v66, v2, s[4:5] offset:64              // 000000DB0ACC: DC820040 42040002
	global_load_d16_b16 v67, v2, s[4:5] offset:96              // 000000DB0AD4: DC820060 43040002
	global_load_d16_b16 v74, v2, s[4:5] offset:128             // 000000DB0ADC: DC820080 4A040002
	global_load_d16_b16 v75, v2, s[4:5] offset:160             // 000000DB0AE4: DC8200A0 4B040002
	global_load_d16_b16 v76, v2, s[4:5] offset:192             // 000000DB0AEC: DC8200C0 4C040002
	global_load_d16_b16 v77, v2, s[4:5] offset:224             // 000000DB0AF4: DC8200E0 4D040002
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000DB0AFC: D5010007 21AA0F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000DB0B04: D5010005 21AA0B05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DB0B0C: D5010008 21AA1108
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DB0B14: D5010009 21AA1309
	v_cndmask_b32_e64 v42, -v42, v42, vcc_lo                   // 000000DB0B1C: D501002A 21AA552A
	v_cndmask_b32_e64 v34, -v34, v34, vcc_lo                   // 000000DB0B24: D5010022 21AA4522
	v_dual_add_f32 v4, v5, v4 :: v_dual_add_f32 v5, v7, v6     // 000000DB0B2C: C9080905 04040D07
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB0B34: BF870004
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v11   // 000000DB0B38: C9081509 07081708
	s_waitcnt vmcnt(7)                                         // 000000DB0B40: BF891FF7
	.long 0x7f743880                                           // 000000DB0B44: 7F743880
	v_cndmask_b32_e64 v43, -v43, v43, vcc_lo                   // 000000DB0B48: D501002B 21AA572B
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000DB0B50: C8C60AFF 050408FF 3DB504F3
	v_cndmask_b32_e64 v35, -v35, v35, vcc_lo                   // 000000DB0B5C: D5010023 21AA4723
	v_dual_add_f32 v11, v42, v27 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000DB0B64: C906372A 0B0810FF 3DB504F3
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_add_f32 v10, v34, v26// 000000DB0B70: C8C80EFF 070A3522 3DB504F3
	v_add_f32_e32 v19, v43, v19                                // 000000DB0B7C: 0626272B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB0B80: BF8701A3
	v_dual_add_f32 v18, v35, v18 :: v_dual_mul_f32 v11, 0x3db504f3, v11// 000000DB0B84: C9062523 120A16FF 3DB504F3
	.long 0x7f0c39ba                                           // 000000DB0B90: 7F0C39BA
	v_dual_mul_f32 v10, 0x3db504f3, v10 :: v_dual_mul_f32 v19, 0x3db504f3, v19// 000000DB0B94: C8C614FF 0A1226FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB0BA0: BF870003
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 000000DB0BA4: 102424FF 3DB504F3
	.long 0x7f1239ba                                           // 000000DB0BAC: 7F1239BA
	.long 0x7f3439ba                                           // 000000DB0BB0: 7F3439BA
	.long 0x7f3639ba                                           // 000000DB0BB4: 7F3639BA
	v_mad_i64_i32 v[50:51], null, 0x1400, v50, v[0:1]          // 000000DB0BB8: D6FF7C32 040264FF 00001400
	v_fma_mix_f32 v5, v58, v5, neg(0) op_sel_hi:[1,0,0]        // 000000DB0BC4: CC200005 8A020B3A
	s_waitcnt vmcnt(6)                                         // 000000DB0BCC: BF891BF7
	v_fma_mix_f32 v4, v59, v4, neg(0) op_sel_hi:[1,0,0]        // 000000DB0BD0: CC200004 8A02093B
	s_waitcnt vmcnt(5)                                         // 000000DB0BD8: BF8917F7
	v_fma_mix_f32 v7, v66, v7, neg(0) op_sel_hi:[1,0,0]        // 000000DB0BDC: CC200007 8A020F42
	s_waitcnt vmcnt(4)                                         // 000000DB0BE4: BF8913F7
	v_fma_mix_f32 v8, v67, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DB0BE8: CC200008 8A021143
	s_waitcnt vmcnt(3)                                         // 000000DB0BF0: BF890FF7
	v_fma_mix_f32 v10, v74, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DB0BF4: CC20000A 8A02154A
	.long 0x7e743985                                           // 000000DB0BFC: 7E743985
	s_waitcnt vmcnt(2)                                         // 000000DB0C00: BF890BF7
	v_fma_mix_f32 v11, v75, v11, neg(0) op_sel_hi:[1,0,0]      // 000000DB0C04: CC20000B 8A02174B
	s_waitcnt vmcnt(1)                                         // 000000DB0C0C: BF8907F7
	v_fma_mix_f32 v18, v76, v18, neg(0) op_sel_hi:[1,0,0]      // 000000DB0C10: CC200012 8A02254C
	s_waitcnt vmcnt(0)                                         // 000000DB0C18: BF8903F7
	v_fma_mix_f32 v19, v77, v19, neg(0) op_sel_hi:[1,0,0]      // 000000DB0C1C: CC200013 8A02274D
	.long 0x7e0c3984                                           // 000000DB0C24: 7E0C3984
	v_and_b32_e32 v34, 1, v58                                  // 000000DB0C28: 36447481
	.long 0x7e743988                                           // 000000DB0C2C: 7E743988
	.long 0x7e123987                                           // 000000DB0C30: 7E123987
	.long 0x7e34398a                                           // 000000DB0C34: 7E34398A
	.long 0x7e363992                                           // 000000DB0C38: 7E363992
	v_and_b32_e32 v6, 1, v6                                    // 000000DB0C3C: 360C0C81
	v_and_b32_e32 v35, 1, v58                                  // 000000DB0C40: 36467481
	.long 0x7e74398b                                           // 000000DB0C44: 7E74398B
	v_and_b32_e32 v9, 1, v9                                    // 000000DB0C48: 36121281
	v_and_b32_e32 v26, 1, v26                                  // 000000DB0C4C: 36343481
	v_and_b32_e32 v27, 1, v27                                  // 000000DB0C50: 36363681
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000DB0C54: D6550004 03FE0D04 00007FFF
	v_and_b32_e32 v42, 1, v58                                  // 000000DB0C60: 36547481
	.long 0x7e743993                                           // 000000DB0C64: 7E743993
	v_add3_u32 v6, v7, v9, 0x7fff                              // 000000DB0C68: D6550006 03FE1307 00007FFF
	v_add3_u32 v5, v5, v34, 0x7fff                             // 000000DB0C74: D6550005 03FE4505 00007FFF
	v_add3_u32 v8, v8, v35, 0x7fff                             // 000000DB0C80: D6550008 03FE4708 00007FFF
	v_add3_u32 v9, v10, v26, 0x7fff                            // 000000DB0C8C: D6550009 03FE350A 00007FFF
	v_and_b32_e32 v7, 1, v58                                   // 000000DB0C98: 360E7481
	v_add3_u32 v10, v18, v27, 0x7fff                           // 000000DB0C9C: D655000A 03FE3712 00007FFF
	v_add3_u32 v11, v11, v42, 0x7fff                           // 000000DB0CA8: D655000B 03FE550B 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB0CB4: BF870003
	v_add3_u32 v7, v19, v7, 0x7fff                             // 000000DB0CB8: D6550007 03FE0F13 00007FFF
	s_clause 0x7                                               // 000000DB0CC4: BF850007
	global_store_d16_hi_b16 v[50:51], v4, off                  // 000000DB0CC8: DC960000 007C0432
	global_store_d16_hi_b16 v[50:51], v5, off offset:32        // 000000DB0CD0: DC960020 007C0532
	global_store_d16_hi_b16 v[50:51], v6, off offset:64        // 000000DB0CD8: DC960040 007C0632
	global_store_d16_hi_b16 v[50:51], v8, off offset:96        // 000000DB0CE0: DC960060 007C0832
	global_store_d16_hi_b16 v[50:51], v9, off offset:128       // 000000DB0CE8: DC960080 007C0932
	global_store_d16_hi_b16 v[50:51], v11, off offset:160      // 000000DB0CF0: DC9600A0 007C0B32
	global_store_d16_hi_b16 v[50:51], v10, off offset:192      // 000000DB0CF8: DC9600C0 007C0A32
	global_store_d16_hi_b16 v[50:51], v7, off offset:224       // 000000DB0D00: DC9600E0 007C0732
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DB0D08: 8C7E067E
	v_add_f32_e32 v8, v36, v28                                 // 000000DB0D0C: 06103924
	v_sub_f32_e32 v10, v36, v28                                // 000000DB0D10: 08143924
	v_sub_f32_e32 v11, v20, v12                                // 000000DB0D14: 08161914
	v_sub_f32_e32 v5, v68, v60                                 // 000000DB0D18: 080A7944
	v_add_f32_e32 v9, v20, v12                                 // 000000DB0D1C: 06121914
	v_add_f32_e32 v6, v52, v44                                 // 000000DB0D20: 060C5934
	s_mov_b32 s6, exec_lo                                      // 000000DB0D24: BE86007E
	v_add_f32_e32 v20, v10, v11                                // 000000DB0D28: 0628170A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000DB0D2C: BF8700B3
	v_add_f32_e32 v18, v8, v9                                  // 000000DB0D30: 06241308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_sub_f32 v9, v10, v11   // 000000DB0D34: C94A1308 0808170A
	v_sub_f32_e32 v7, v52, v44                                 // 000000DB0D3C: 080E5934
	v_dual_add_f32 v4, v68, v60 :: v_dual_add_f32 v19, v5, v7  // 000000DB0D40: C9087944 04120F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB0D48: BF8701A1
	v_add_f32_e32 v12, v4, v6                                  // 000000DB0D4C: 06180D04
	v_sub_f32_e32 v4, v4, v6                                   // 000000DB0D50: 08080D04
	v_dual_sub_f32 v6, v5, v7 :: v_dual_add_f32 v27, v19, v20  // 000000DB0D54: C9480F05 061A2913
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB0D5C: BF8701A3
	v_dual_sub_f32 v11, v19, v20 :: v_dual_add_f32 v26, v12, v18// 000000DB0D60: C9482913 0B1A250C
	v_sub_f32_e32 v10, v12, v18                                // 000000DB0D68: 0814250C
	v_add_f32_e32 v18, v6, v9                                  // 000000DB0D6C: 06241306
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB0D70: BF8700A3
	v_mov_b32_dpp v5, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0D74: 7E0A02FA FF01611A
	v_cndmask_b32_e64 v7, -v26, v26, s0                        // 000000DB0D7C: D5010007 2002351A
	v_add_f32_e32 v5, v7, v5                                   // 000000DB0D84: 060A0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB0D88: BF8700A1
	v_mov_b32_dpp v19, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB0D8C: 7E2602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000DB0D94: D5010005 200A0B05
	v_add_f32_e32 v5, v5, v19                                  // 000000DB0D9C: 060A2705
	v_mov_b32_dpp v26, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0DA0: 7E3402FA FF01611B
	v_cndmask_b32_e64 v27, -v27, v27, s0                       // 000000DB0DA8: D501001B 2002371B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB0DB0: BF8701B1
	v_add_f32_e32 v7, v27, v26                                 // 000000DB0DB4: 060E351B
	v_mov_b32_dpp v27, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0DB8: 7E3602FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000DB0DC0: D5010012 20022512
	v_mov_b32_dpp v20, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB0DC8: 7E2802FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000DB0DD0: D5010007 200A0F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DB0DD8: BF870131
	v_add_f32_e32 v7, v7, v20                                  // 000000DB0DDC: 060E2907
	v_add_f32_e32 v12, v4, v8                                  // 000000DB0DE0: 06181104
	v_dual_sub_f32 v19, v4, v8 :: v_dual_add_f32 v8, v18, v27  // 000000DB0DE4: C9481104 13083712
	v_mov_b32_dpp v26, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0DEC: 7E3402FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000DB0DF4: D501000C 2002190C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB0DFC: BF8701A3
	v_mov_b32_dpp v20, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB0E00: 7E2802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DB0E08: D5010008 200A1108
	v_add_f32_e32 v4, v12, v26                                 // 000000DB0E10: 0608350C
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0E14: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DB0E1C: D5010005 20060B05
	v_mov_b32_dpp v26, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0E24: 7E3402FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000DB0E2C: D5010007 20060F07
	v_mov_b32_dpp v18, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB0E34: 7E2402FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000DB0E3C: D5010004 200A0904
	v_add_f32_e32 v5, v5, v12                                  // 000000DB0E44: 060A1905
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB0E48: BF870194
	v_dual_add_f32 v8, v8, v20 :: v_dual_add_f32 v7, v7, v26   // 000000DB0E4C: C9082908 08063507
	v_add_f32_e32 v12, v4, v18                                 // 000000DB0E54: 06182504
	v_sub_f32_e32 v18, v6, v9                                  // 000000DB0E58: 08241306
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB0E5C: BF870003
	v_mov_b32_dpp v20, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0E60: 7E2802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB0E68: D5010008 20061108
	v_mov_b32_dpp v4, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0E70: 7E0802FA FF016805
	v_mov_b32_dpp v9, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0E78: 7E1202FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB0E80: D501000C 2006190C
	v_mov_b32_dpp v6, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0E88: 7E0C02FA FF016807
	v_add_f32_e32 v8, v8, v20                                  // 000000DB0E90: 06102908
	v_mov_b32_dpp v20, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0E94: 7E2802FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000DB0E9C: D5010013 20022713
	v_add_f32_e32 v9, v12, v9                                  // 000000DB0EA4: 0612130C
	v_mov_b32_dpp v12, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0EA8: 7E1802FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000DB0EB0: D501000B 2002170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB0EB8: BF870114
	v_add_f32_e32 v19, v19, v20                                // 000000DB0EBC: 06262913
	v_add_f32_e32 v11, v11, v12                                // 000000DB0EC0: 0616190B
	v_mov_b32_dpp v26, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0EC4: 7E3402FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000DB0ECC: D501000A 2002150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB0ED4: BF8701A3
	v_mov_b32_dpp v20, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB0ED8: 7E2802FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000DB0EE0: D501000B 200A170B
	v_add_f32_e32 v10, v10, v26                                // 000000DB0EE8: 0614350A
	v_mov_b32_dpp v26, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB0EEC: 7E3402FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000DB0EF4: D5010012 20022512
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB0EFC: BF870214
	v_add_f32_e32 v11, v11, v20                                // 000000DB0F00: 0616290B
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB0F04: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DB0F0C: D501000A 200A150A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB0F14: BF870004
	v_add_f32_e32 v18, v18, v26                                // 000000DB0F18: 06243512
	v_mov_b32_dpp v26, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB0F1C: 7E3402FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000DB0F24: D5010013 200A2713
	v_cndmask_b32_e64 v28, -v11, v11, s1                       // 000000DB0F2C: D501001C 2006170B
	v_add_f32_e32 v12, v10, v12                                // 000000DB0F34: 0618190A
	v_mov_b32_dpp v27, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB0F38: 7E3602FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000DB0F40: D5010012 200A2512
	v_add_f32_e32 v19, v19, v26                                // 000000DB0F48: 06263513
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0F4C: 7E1402FA FF016809
	v_mov_b32_dpp v20, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0F54: 7E2802FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB0F5C: D501000C 2006190C
	v_add_f32_e32 v18, v18, v27                                // 000000DB0F64: 06243712
	v_mov_b32_dpp v27, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0F68: 7E3602FA FF01640B
	v_mov_b32_dpp v34, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0F70: 7E4402FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000DB0F78: D5010013 20062713
	v_add_f32_e32 v26, v12, v20                                // 000000DB0F80: 0634290C
	v_mov_b32_dpp v35, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB0F84: 7E4602FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000DB0F8C: D5010012 20062512
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB0F94: BF870234
	v_dual_add_f32 v28, v28, v27 :: v_dual_add_f32 v27, v19, v34// 000000DB0F98: C908371C 1C1A4513
	v_mov_b32_dpp v11, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0FA0: 7E1602FA FF016808
	v_mov_b32_dpp v19, v26 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0FA8: 7E2602FA FF01681A
	v_add_f32_e32 v34, v18, v35                                // 000000DB0FB0: 06444712
	v_add_nc_u32_e32 v35, 4, v3                                // 000000DB0FB4: 4A460684
	v_mov_b32_dpp v20, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0FB8: 7E2802FA FF01681C
	v_mov_b32_dpp v12, v27 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0FC0: 7E1802FA FF01681B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB0FC8: BF870214
	v_mov_b32_dpp v18, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB0FCC: 7E2402FA FF016822
	.long 0xd4c4007e                                           // 000000DB0FD4: D4C4007E
	v_cndmask_b32_e32 v1, s15, v35, vcc_lo                     // 000000DB0FD8: 0202460F
	s_cbranch_execz 150                                        // 000000DB0FDC: BFA50096 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1938>
	s_clause 0x7                                               // 000000DB0FE0: BF850007
	global_load_d16_b16 v42, v2, s[4:5] offset:32              // 000000DB0FE4: DC820020 2A040002
	global_load_d16_b16 v43, v2, s[4:5]                        // 000000DB0FEC: DC820000 2B040002
	global_load_d16_b16 v44, v2, s[4:5] offset:64              // 000000DB0FF4: DC820040 2C040002
	global_load_d16_b16 v50, v2, s[4:5] offset:96              // 000000DB0FFC: DC820060 32040002
	global_load_d16_b16 v51, v2, s[4:5] offset:128             // 000000DB1004: DC820080 33040002
	global_load_d16_b16 v52, v2, s[4:5] offset:160             // 000000DB100C: DC8200A0 34040002
	global_load_d16_b16 v58, v2, s[4:5] offset:192             // 000000DB1014: DC8200C0 3A040002
	global_load_d16_b16 v59, v2, s[4:5] offset:224             // 000000DB101C: DC8200E0 3B040002
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000DB1024: D5010007 21AA0F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000DB102C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DB1034: D5010009 21AA1309
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DB103C: D5010008 21AA1108
	v_cndmask_b32_e64 v34, -v34, v34, vcc_lo                   // 000000DB1044: D5010022 21AA4522
	v_cndmask_b32_e64 v26, -v26, v26, vcc_lo                   // 000000DB104C: D501001A 21AA351A
	v_dual_add_f32 v4, v5, v4 :: v_dual_add_f32 v5, v7, v6     // 000000DB1054: C9080905 04040D07
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB105C: BF870004
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v11   // 000000DB1060: C9081509 07081708
	v_cndmask_b32_e64 v27, -v27, v27, vcc_lo                   // 000000DB1068: D501001B 21AA371B
	v_add_f32_e32 v18, v34, v18                                // 000000DB1070: 06242522
	s_waitcnt vmcnt(7)                                         // 000000DB1074: BF891FF7
	.long 0x7f543880                                           // 000000DB1078: 7F543880
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000DB107C: 100E0EFF 3DB504F3
	v_cndmask_b32_e64 v28, -v28, v28, vcc_lo                   // 000000DB1084: D501001C 21AA391C
	v_add_f32_e32 v10, v26, v19                                // 000000DB108C: 0614271A
	v_dual_add_f32 v12, v27, v12 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000DB1090: C906191B 0C040AFF 3DB504F3
	.long 0x7f1239aa                                           // 000000DB109C: 7F1239AA
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB10A0: BF870004
	v_add_f32_e32 v11, v28, v20                                // 000000DB10A4: 0616291C
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000DB10A8: 101010FF 3DB504F3
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000DB10B0: 100808FF 3DB504F3
	.long 0x7f2639aa                                           // 000000DB10B8: 7F2639AA
	.long 0x7f0c39aa                                           // 000000DB10BC: 7F0C39AA
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000DB10C0: 101616FF 3DB504F3
	.long 0x7f2839aa                                           // 000000DB10C8: 7F2839AA
	v_mad_i64_i32 v[35:36], null, 0x1400, v35, v[0:1]          // 000000DB10CC: D6FF7C23 040246FF 00001400
	v_fma_mix_f32 v5, v42, v5, neg(0) op_sel_hi:[1,0,0]        // 000000DB10D8: CC200005 8A020B2A
	s_waitcnt vmcnt(6)                                         // 000000DB10E0: BF891BF7
	v_fma_mix_f32 v4, v43, v4, neg(0) op_sel_hi:[1,0,0]        // 000000DB10E4: CC200004 8A02092B
	s_waitcnt vmcnt(5)                                         // 000000DB10EC: BF8917F7
	v_fma_mix_f32 v7, v44, v7, neg(0) op_sel_hi:[1,0,0]        // 000000DB10F0: CC200007 8A020F2C
	s_waitcnt vmcnt(4)                                         // 000000DB10F8: BF8913F7
	v_fma_mix_f32 v8, v50, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DB10FC: CC200008 8A021132
	.long 0x7e543985                                           // 000000DB1104: 7E543985
	s_waitcnt vmcnt(2)                                         // 000000DB1108: BF890BF7
	v_fma_mix_f32 v11, v52, v11, neg(0) op_sel_hi:[1,0,0]      // 000000DB110C: CC20000B 8A021734
	.long 0x7e123987                                           // 000000DB1114: 7E123987
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000DB1118: 101414FF 3DB504F3
	.long 0x7e0c3984                                           // 000000DB1120: 7E0C3984
	v_and_b32_e32 v26, 1, v42                                  // 000000DB1124: 36345481
	.long 0x7e543988                                           // 000000DB1128: 7E543988
	v_and_b32_e32 v9, 1, v9                                    // 000000DB112C: 36121281
	v_fma_mix_f32 v10, v51, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DB1130: CC20000A 8A021533
	v_and_b32_e32 v6, 1, v6                                    // 000000DB1138: 360C0C81
	v_add3_u32 v5, v5, v26, 0x7fff                             // 000000DB113C: D6550005 03FE3505 00007FFF
	v_and_b32_e32 v27, 1, v42                                  // 000000DB1148: 36365481
	.long 0x7e54398b                                           // 000000DB114C: 7E54398B
	.long 0x7e26398a                                           // 000000DB1150: 7E26398A
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 000000DB1154: 102424FF 3DB504F3
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000DB115C: D6550004 03FE0D04 00007FFF
	v_add3_u32 v6, v7, v9, 0x7fff                              // 000000DB1168: D6550006 03FE1307 00007FFF
	v_and_b32_e32 v28, 1, v42                                  // 000000DB1174: 36385481
	v_and_b32_e32 v19, 1, v19                                  // 000000DB1178: 36262681
	s_waitcnt vmcnt(0)                                         // 000000DB117C: BF8903F7
	v_fma_mix_f32 v18, v59, v18, neg(0) op_sel_hi:[1,0,0]      // 000000DB1180: CC200012 8A02253B
	v_add3_u32 v8, v8, v27, 0x7fff                             // 000000DB1188: D6550008 03FE3708 00007FFF
	v_add3_u32 v11, v11, v28, 0x7fff                           // 000000DB1194: D655000B 03FE390B 00007FFF
	v_add3_u32 v9, v10, v19, 0x7fff                            // 000000DB11A0: D6550009 03FE270A 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB11AC: BF870094
	.long 0x7e543992                                           // 000000DB11B0: 7E543992
	v_dual_mul_f32 v12, 0x3db504f3, v12 :: v_dual_and_b32 v7, 1, v42// 000000DB11B4: C8E418FF 0C065481 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB11C0: BF870111
	v_fma_mix_f32 v12, v58, v12, neg(0) op_sel_hi:[1,0,0]      // 000000DB11C4: CC20000C 8A02193A
	v_add3_u32 v7, v18, v7, 0x7fff                             // 000000DB11CC: D6550007 03FE0F12 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB11D8: BF870092
	.long 0x7e28398c                                           // 000000DB11DC: 7E28398C
	v_and_b32_e32 v20, 1, v20                                  // 000000DB11E0: 36282881
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB11E4: BF870001
	v_add3_u32 v10, v12, v20, 0x7fff                           // 000000DB11E8: D655000A 03FE290C 00007FFF
	s_clause 0x7                                               // 000000DB11F4: BF850007
	global_store_d16_hi_b16 v[35:36], v4, off                  // 000000DB11F8: DC960000 007C0423
	global_store_d16_hi_b16 v[35:36], v5, off offset:32        // 000000DB1200: DC960020 007C0523
	global_store_d16_hi_b16 v[35:36], v6, off offset:64        // 000000DB1208: DC960040 007C0623
	global_store_d16_hi_b16 v[35:36], v8, off offset:96        // 000000DB1210: DC960060 007C0823
	global_store_d16_hi_b16 v[35:36], v9, off offset:128       // 000000DB1218: DC960080 007C0923
	global_store_d16_hi_b16 v[35:36], v11, off offset:160      // 000000DB1220: DC9600A0 007C0B23
	global_store_d16_hi_b16 v[35:36], v10, off offset:192      // 000000DB1228: DC9600C0 007C0A23
	global_store_d16_hi_b16 v[35:36], v7, off offset:224       // 000000DB1230: DC9600E0 007C0723
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DB1238: 8C7E067E
	v_sub_f32_e32 v10, v37, v29                                // 000000DB123C: 08143B25
	v_sub_f32_e32 v11, v21, v13                                // 000000DB1240: 08161B15
	v_add_f32_e32 v4, v69, v61                                 // 000000DB1244: 06087B45
	v_add_f32_e32 v8, v37, v29                                 // 000000DB1248: 06103B25
	v_add_f32_e32 v9, v21, v13                                 // 000000DB124C: 06121B15
	s_mov_b32 s6, exec_lo                                      // 000000DB1250: BE86007E
	v_dual_add_f32 v19, v10, v11 :: v_dual_add_f32 v6, v53, v45// 000000DB1254: C908170A 13065B35
	v_sub_f32_e32 v5, v69, v61                                 // 000000DB125C: 080A7B45
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB1260: BF870092
	v_dual_sub_f32 v7, v53, v45 :: v_dual_add_f32 v12, v4, v6  // 000000DB1264: C9485B35 070C0D04
	v_dual_add_f32 v13, v8, v9 :: v_dual_add_f32 v18, v5, v7   // 000000DB126C: C9081308 0D120F05
	v_dual_sub_f32 v8, v8, v9 :: v_dual_sub_f32 v9, v10, v11   // 000000DB1274: C94A1308 0808170A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DB127C: BF870242
	v_dual_add_f32 v20, v12, v13 :: v_dual_add_f32 v21, v18, v19// 000000DB1280: C9081B0C 14142712
	v_sub_f32_e32 v4, v4, v6                                   // 000000DB1288: 08080D04
	v_sub_f32_e32 v6, v5, v7                                   // 000000DB128C: 080C0F05
	v_sub_f32_e32 v11, v18, v19                                // 000000DB1290: 08162712
	v_mov_b32_dpp v5, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB1294: 7E0A02FA FF016114
	v_cndmask_b32_e64 v7, -v20, v20, s0                        // 000000DB129C: D5010007 20022914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB12A4: BF870091
	v_add_f32_e32 v5, v7, v5                                   // 000000DB12A8: 060A0B07
	v_mov_b32_dpp v18, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB12AC: 7E2402FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000DB12B4: D5010005 200A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000DB12BC: BF8700B1
	v_add_f32_e32 v5, v5, v18                                  // 000000DB12C0: 060A2505
	v_mov_b32_dpp v20, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB12C4: 7E2802FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000DB12CC: D5010015 20022B15
	v_add_f32_e32 v7, v21, v20                                 // 000000DB12D4: 060E2915
	v_sub_f32_e32 v18, v4, v8                                  // 000000DB12D8: 08241104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DB12DC: BF870132
	v_mov_b32_dpp v19, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB12E0: 7E2602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000DB12E8: D5010007 200A0F07
	v_sub_f32_e32 v10, v12, v13                                // 000000DB12F0: 08141B0C
	v_dual_add_f32 v12, v4, v8 :: v_dual_add_f32 v7, v7, v19   // 000000DB12F4: C9081104 0C062707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB12FC: BF8700A1
	v_mov_b32_dpp v20, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB1300: 7E2802FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000DB1308: D501000C 2002190C
	v_dual_add_f32 v13, v6, v9 :: v_dual_add_f32 v4, v12, v20  // 000000DB1310: C9081306 0D04290C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB1318: BF870001
	v_mov_b32_dpp v21, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB131C: 7E2A02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DB1324: D501000D 20021B0D
	v_mov_b32_dpp v20, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB132C: 7E2802FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000DB1334: D5010007 20060F07
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB133C: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DB1344: D5010005 20060B05
	v_add_f32_e32 v8, v13, v21                                 // 000000DB134C: 06102B0D
	v_mov_b32_dpp v13, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1350: 7E1A02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000DB1358: D5010004 200A0904
	v_add_f32_e32 v7, v7, v20                                  // 000000DB1360: 060E2907
	v_add_f32_e32 v5, v5, v12                                  // 000000DB1364: 060A1905
	v_mov_b32_dpp v19, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1368: 7E2602FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DB1370: D5010008 200A1108
	v_add_f32_e32 v12, v4, v13                                 // 000000DB1378: 06181B04
	v_sub_f32_e32 v13, v6, v9                                  // 000000DB137C: 081A1306
	v_mov_b32_dpp v20, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB1380: 7E2802FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000DB1388: D501000A 2002150A
	v_add_f32_e32 v8, v8, v19                                  // 000000DB1390: 06102708
	v_mov_b32_dpp v9, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1394: 7E1202FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB139C: D501000C 2006190C
	v_mov_b32_dpp v4, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB13A4: 7E0802FA FF016805
	v_add_f32_e32 v10, v10, v20                                // 000000DB13AC: 0614290A
	v_mov_b32_dpp v19, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB13B0: 7E2602FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB13B8: D5010008 20061108
	v_add_f32_e32 v9, v12, v9                                  // 000000DB13C0: 0612130C
	v_mov_b32_dpp v12, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB13C4: 7E1802FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000DB13CC: D501000B 2002170B
	v_mov_b32_dpp v20, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB13D4: 7E2802FA FF01610D
	v_add_f32_e32 v8, v8, v19                                  // 000000DB13DC: 06102708
	v_mov_b32_dpp v19, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB13E0: 7E2602FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000DB13E8: D5010012 20022512
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DB13F0: D501000D 20021B0D
	v_add_f32_e32 v11, v11, v12                                // 000000DB13F8: 0616190B
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB13FC: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DB1404: D501000A 200A150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB140C: BF870214
	v_dual_add_f32 v18, v18, v19 :: v_dual_add_f32 v13, v13, v20// 000000DB1410: C9082712 120C290D
	v_mov_b32_dpp v19, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1418: 7E2602FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000DB1420: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB1428: BF870214
	v_add_f32_e32 v12, v10, v12                                // 000000DB142C: 0618190A
	v_mov_b32_dpp v20, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1430: 7E2802FA FF016212
	v_mov_b32_dpp v21, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1438: 7E2A02FA FF01620D
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000DB1440: D5010012 200A2512
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000DB1448: D501000D 200A1B0D
	v_add_f32_e32 v11, v11, v19                                // 000000DB1450: 0616270B
	v_mov_b32_dpp v19, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1454: 7E2602FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB145C: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB1464: BF870214
	v_dual_add_f32 v18, v18, v20 :: v_dual_add_f32 v13, v13, v21// 000000DB1468: C9082912 120C2B0D
	v_mov_b32_dpp v21, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1470: 7E2A02FA FF01640B
	v_cndmask_b32_e64 v26, -v11, v11, s1                       // 000000DB1478: D501001A 2006170B
	v_mov_b32_dpp v6, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB1480: 7E0C02FA FF016807
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB1488: BF870004
	v_mov_b32_dpp v27, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB148C: 7E3602FA FF016412
	v_mov_b32_dpp v28, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1494: 7E3802FA FF01640D
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000DB149C: D5010012 20062512
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000DB14A4: D501000D 20061B0D
	v_add_f32_e32 v20, v12, v19                                // 000000DB14AC: 0628270C
	v_add_f32_e32 v26, v26, v21                                // 000000DB14B0: 06342B1A
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB14B4: 7E1402FA FF016809
	v_add_f32_e32 v21, v18, v27                                // 000000DB14BC: 062A3712
	v_add_f32_e32 v27, v13, v28                                // 000000DB14C0: 0636390D
	v_mov_b32_dpp v11, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB14C4: 7E1602FA FF016808
	v_add_nc_u32_e32 v28, 6, v3                                // 000000DB14CC: 4A380686
	v_mov_b32_dpp v18, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB14D0: 7E2402FA FF016814
	v_mov_b32_dpp v19, v26 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB14D8: 7E2602FA FF01681A
	v_mov_b32_dpp v12, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB14E0: 7E1802FA FF016815
	v_mov_b32_dpp v13, v27 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB14E8: 7E1A02FA FF01681B
	.long 0xd4c4007e                                           // 000000DB14F0: D4C4007E
	v_cndmask_b32_e32 v1, s15, v28, vcc_lo                     // 000000DB14F4: 0202380F
	s_cbranch_execz 146                                        // 000000DB14F8: BFA50092 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1e44>
	s_clause 0x7                                               // 000000DB14FC: BF850007
	global_load_d16_b16 v34, v2, s[4:5] offset:32              // 000000DB1500: DC820020 22040002
	global_load_d16_b16 v35, v2, s[4:5]                        // 000000DB1508: DC820000 23040002
	global_load_d16_b16 v36, v2, s[4:5] offset:64              // 000000DB1510: DC820040 24040002
	global_load_d16_b16 v37, v2, s[4:5] offset:96              // 000000DB1518: DC820060 25040002
	global_load_d16_b16 v42, v2, s[4:5] offset:128             // 000000DB1520: DC820080 2A040002
	global_load_d16_b16 v43, v2, s[4:5] offset:160             // 000000DB1528: DC8200A0 2B040002
	global_load_d16_b16 v44, v2, s[4:5] offset:192             // 000000DB1530: DC8200C0 2C040002
	global_load_d16_b16 v45, v2, s[4:5] offset:224             // 000000DB1538: DC8200E0 2D040002
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000DB1540: D5010007 21AA0F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000DB1548: D5010005 21AA0B05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DB1550: D5010008 21AA1108
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DB1558: D5010009 21AA1309
	v_cndmask_b32_e64 v26, -v26, v26, vcc_lo                   // 000000DB1560: D501001A 21AA351A
	v_cndmask_b32_e64 v20, -v20, v20, vcc_lo                   // 000000DB1568: D5010014 21AA2914
	v_dual_add_f32 v4, v5, v4 :: v_dual_add_f32 v5, v7, v6     // 000000DB1570: C9080905 04040D07
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB1578: BF870004
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v11   // 000000DB157C: C9081509 07081708
	s_waitcnt vmcnt(7)                                         // 000000DB1584: BF891FF7
	.long 0x7f443880                                           // 000000DB1588: 7F443880
	v_cndmask_b32_e64 v27, -v27, v27, vcc_lo                   // 000000DB158C: D501001B 21AA371B
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000DB1594: C8C60AFF 050408FF 3DB504F3
	v_cndmask_b32_e64 v21, -v21, v21, vcc_lo                   // 000000DB15A0: D5010015 21AA2B15
	v_dual_add_f32 v10, v20, v18 :: v_dual_add_f32 v11, v26, v19// 000000DB15A8: C9082514 0A0A271A
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000DB15B0: C8C610FF 08060EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB15BC: BF870193
	v_dual_add_f32 v12, v21, v12 :: v_dual_add_f32 v13, v27, v13// 000000DB15C0: C9081915 0C0C1B1B
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_mul_f32 v10, 0x3db504f3, v10// 000000DB15C8: C8C616FF 0B0A14FF 3DB504F3
	.long 0x7f0c39a2                                           // 000000DB15D4: 7F0C39A2
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB15D8: BF870003
	v_dual_mul_f32 v12, 0x3db504f3, v12 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000DB15DC: C8C618FF 0C0C1AFF 3DB504F3
	.long 0x7f1239a2                                           // 000000DB15E8: 7F1239A2
	.long 0x7f2439a2                                           // 000000DB15EC: 7F2439A2
	.long 0x7f2639a2                                           // 000000DB15F0: 7F2639A2
	v_mad_i64_i32 v[28:29], null, 0x1400, v28, v[0:1]          // 000000DB15F4: D6FF7C1C 040238FF 00001400
	v_fma_mix_f32 v5, v34, v5, neg(0) op_sel_hi:[1,0,0]        // 000000DB1600: CC200005 8A020B22
	s_waitcnt vmcnt(6)                                         // 000000DB1608: BF891BF7
	v_fma_mix_f32 v4, v35, v4, neg(0) op_sel_hi:[1,0,0]        // 000000DB160C: CC200004 8A020923
	s_waitcnt vmcnt(5)                                         // 000000DB1614: BF8917F7
	v_fma_mix_f32 v7, v36, v7, neg(0) op_sel_hi:[1,0,0]        // 000000DB1618: CC200007 8A020F24
	s_waitcnt vmcnt(4)                                         // 000000DB1620: BF8913F7
	v_fma_mix_f32 v8, v37, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DB1624: CC200008 8A021125
	s_waitcnt vmcnt(3)                                         // 000000DB162C: BF890FF7
	v_fma_mix_f32 v10, v42, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DB1630: CC20000A 8A02152A
	.long 0x7e443985                                           // 000000DB1638: 7E443985
	s_waitcnt vmcnt(2)                                         // 000000DB163C: BF890BF7
	v_fma_mix_f32 v11, v43, v11, neg(0) op_sel_hi:[1,0,0]      // 000000DB1640: CC20000B 8A02172B
	s_waitcnt vmcnt(1)                                         // 000000DB1648: BF8907F7
	v_fma_mix_f32 v12, v44, v12, neg(0) op_sel_hi:[1,0,0]      // 000000DB164C: CC20000C 8A02192C
	s_waitcnt vmcnt(0)                                         // 000000DB1654: BF8903F7
	v_fma_mix_f32 v13, v45, v13, neg(0) op_sel_hi:[1,0,0]      // 000000DB1658: CC20000D 8A021B2D
	.long 0x7e0c3984                                           // 000000DB1660: 7E0C3984
	v_and_b32_e32 v20, 1, v34                                  // 000000DB1664: 36284481
	.long 0x7e443988                                           // 000000DB1668: 7E443988
	.long 0x7e123987                                           // 000000DB166C: 7E123987
	.long 0x7e24398a                                           // 000000DB1670: 7E24398A
	.long 0x7e26398c                                           // 000000DB1674: 7E26398C
	v_and_b32_e32 v6, 1, v6                                    // 000000DB1678: 360C0C81
	v_and_b32_e32 v21, 1, v34                                  // 000000DB167C: 362A4481
	.long 0x7e44398b                                           // 000000DB1680: 7E44398B
	v_and_b32_e32 v9, 1, v9                                    // 000000DB1684: 36121281
	v_and_b32_e32 v18, 1, v18                                  // 000000DB1688: 36242481
	v_and_b32_e32 v19, 1, v19                                  // 000000DB168C: 36262681
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000DB1690: D6550004 03FE0D04 00007FFF
	v_and_b32_e32 v26, 1, v34                                  // 000000DB169C: 36344481
	.long 0x7e44398d                                           // 000000DB16A0: 7E44398D
	v_add3_u32 v6, v7, v9, 0x7fff                              // 000000DB16A4: D6550006 03FE1307 00007FFF
	v_add3_u32 v5, v5, v20, 0x7fff                             // 000000DB16B0: D6550005 03FE2905 00007FFF
	v_add3_u32 v8, v8, v21, 0x7fff                             // 000000DB16BC: D6550008 03FE2B08 00007FFF
	v_add3_u32 v9, v10, v18, 0x7fff                            // 000000DB16C8: D6550009 03FE250A 00007FFF
	v_and_b32_e32 v7, 1, v34                                   // 000000DB16D4: 360E4481
	v_add3_u32 v10, v12, v19, 0x7fff                           // 000000DB16D8: D655000A 03FE270C 00007FFF
	v_add3_u32 v11, v11, v26, 0x7fff                           // 000000DB16E4: D655000B 03FE350B 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB16F0: BF870003
	v_add3_u32 v7, v13, v7, 0x7fff                             // 000000DB16F4: D6550007 03FE0F0D 00007FFF
	s_clause 0x7                                               // 000000DB1700: BF850007
	global_store_d16_hi_b16 v[28:29], v4, off                  // 000000DB1704: DC960000 007C041C
	global_store_d16_hi_b16 v[28:29], v5, off offset:32        // 000000DB170C: DC960020 007C051C
	global_store_d16_hi_b16 v[28:29], v6, off offset:64        // 000000DB1714: DC960040 007C061C
	global_store_d16_hi_b16 v[28:29], v8, off offset:96        // 000000DB171C: DC960060 007C081C
	global_store_d16_hi_b16 v[28:29], v9, off offset:128       // 000000DB1724: DC960080 007C091C
	global_store_d16_hi_b16 v[28:29], v11, off offset:160      // 000000DB172C: DC9600A0 007C0B1C
	global_store_d16_hi_b16 v[28:29], v10, off offset:192      // 000000DB1734: DC9600C0 007C0A1C
	global_store_d16_hi_b16 v[28:29], v7, off offset:224       // 000000DB173C: DC9600E0 007C071C
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DB1744: 8C7E067E
	v_add_f32_e32 v8, v38, v30                                 // 000000DB1748: 06103D26
	v_add_f32_e32 v9, v22, v14                                 // 000000DB174C: 06121D16
	v_add_f32_e32 v4, v70, v62                                 // 000000DB1750: 06087D46
	v_sub_f32_e32 v5, v70, v62                                 // 000000DB1754: 080A7D46
	v_sub_f32_e32 v10, v38, v30                                // 000000DB1758: 08143D26
	s_mov_b32 s6, exec_lo                                      // 000000DB175C: BE86007E
	v_dual_add_f32 v13, v8, v9 :: v_dual_add_f32 v6, v54, v46  // 000000DB1760: C9081308 0D065D36
	v_sub_f32_e32 v8, v8, v9                                   // 000000DB1768: 08101308
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000DB176C: BF8700B2
	v_add_f32_e32 v12, v4, v6                                  // 000000DB1770: 06180D04
	v_sub_f32_e32 v7, v54, v46                                 // 000000DB1774: 080E5D36
	v_sub_f32_e32 v11, v22, v14                                // 000000DB1778: 08161D16
	v_add_f32_e32 v18, v10, v11                                // 000000DB177C: 0624170A
	v_sub_f32_e32 v9, v10, v11                                 // 000000DB1780: 0812170A
	v_add_f32_e32 v19, v12, v13                                // 000000DB1784: 06261B0C
	v_sub_f32_e32 v10, v12, v13                                // 000000DB1788: 08141B0C
	v_add_f32_e32 v14, v5, v7                                  // 000000DB178C: 061C0F05
	v_sub_f32_e32 v4, v4, v6                                   // 000000DB1790: 08080D04
	v_sub_f32_e32 v6, v5, v7                                   // 000000DB1794: 080C0F05
	v_mov_b32_dpp v5, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB1798: 7E0A02FA FF016113
	v_cndmask_b32_e64 v7, -v19, v19, s0                        // 000000DB17A0: D5010007 20022713
	v_add_f32_e32 v20, v14, v18                                // 000000DB17A8: 0628250E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB17AC: BF8701A4
	v_add_f32_e32 v13, v6, v9                                  // 000000DB17B0: 061A1306
	v_dual_sub_f32 v11, v14, v18 :: v_dual_add_f32 v12, v4, v8 // 000000DB17B4: C948250E 0B0C1104
	v_mov_b32_dpp v19, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB17BC: 7E2602FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000DB17C4: D5010014 20022914
	v_add_f32_e32 v5, v7, v5                                   // 000000DB17CC: 060A0B07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB17D0: BF870112
	v_add_f32_e32 v7, v20, v19                                 // 000000DB17D4: 060E2714
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB17D8: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000DB17E0: D5010005 200A0B05
	v_mov_b32_dpp v19, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB17E8: 7E2602FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000DB17F0: D501000C 2002190C
	v_mov_b32_dpp v20, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB17F8: 7E2802FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DB1800: D501000D 20021B0D
	v_add_f32_e32 v5, v5, v14                                  // 000000DB1808: 060A1D05
	v_mov_b32_dpp v18, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB180C: 7E2402FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000DB1814: D5010007 200A0F07
	v_sub_f32_e32 v14, v4, v8                                  // 000000DB181C: 081C1104
	v_add_f32_e32 v4, v12, v19                                 // 000000DB1820: 0608270C
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1824: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DB182C: D5010005 20060B05
	v_add_f32_e32 v7, v7, v18                                  // 000000DB1834: 060E2507
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB1838: BF870112
	v_add_f32_e32 v5, v5, v12                                  // 000000DB183C: 060A1905
	v_mov_b32_dpp v19, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1840: 7E2602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000DB1848: D5010007 20060F07
	v_add_f32_e32 v8, v13, v20                                 // 000000DB1850: 0610290D
	v_mov_b32_dpp v13, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1854: 7E1A02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000DB185C: D5010004 200A0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB1864: BF870234
	v_add_f32_e32 v7, v7, v19                                  // 000000DB1868: 060E2707
	v_mov_b32_dpp v19, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB186C: 7E2602FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000DB1874: D501000A 2002150A
	v_add_f32_e32 v12, v4, v13                                 // 000000DB187C: 06181B04
	v_sub_f32_e32 v13, v6, v9                                  // 000000DB1880: 081A1306
	v_mov_b32_dpp v18, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1884: 7E2402FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DB188C: D5010008 200A1108
	v_add_f32_e32 v10, v10, v19                                // 000000DB1894: 0614270A
	v_mov_b32_dpp v4, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB1898: 7E0802FA FF016805
	v_mov_b32_dpp v19, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB18A0: 7E2602FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DB18A8: D501000D 20021B0D
	v_mov_b32_dpp v6, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB18B0: 7E0C02FA FF016807
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB18B8: BF8701B2
	v_add_f32_e32 v13, v13, v19                                // 000000DB18BC: 061A270D
	v_mov_b32_dpp v9, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB18C0: 7E1202FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB18C8: D501000C 2006190C
	v_mov_b32_dpp v20, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB18D0: 7E2802FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000DB18D8: D501000D 200A1B0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB18E0: BF870233
	v_add_f32_e32 v9, v12, v9                                  // 000000DB18E4: 0612130C
	v_mov_b32_dpp v12, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB18E8: 7E1802FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000DB18F0: D501000B 2002170B
	v_dual_add_f32 v8, v8, v18 :: v_dual_add_f32 v13, v13, v20 // 000000DB18F8: C9082508 080C290D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB1900: BF870112
	v_add_f32_e32 v11, v11, v12                                // 000000DB1904: 0616190B
	v_mov_b32_dpp v18, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1908: 7E2402FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB1910: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB1918: BF8701A4
	v_mov_b32_dpp v26, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB191C: 7E3402FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000DB1924: D501000D 20061B0D
	v_add_f32_e32 v8, v8, v18                                  // 000000DB192C: 06102508
	v_mov_b32_dpp v18, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB1930: 7E2402FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000DB1938: D501000E 20021D0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB1940: BF8701B1
	v_add_f32_e32 v14, v14, v18                                // 000000DB1944: 061C250E
	v_mov_b32_dpp v18, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1948: 7E2402FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000DB1950: D501000B 200A170B
	v_mov_b32_dpp v19, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1958: 7E2602FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000DB1960: D501000E 200A1D0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB1968: BF8701B3
	v_add_f32_e32 v11, v11, v18                                // 000000DB196C: 0616250B
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1970: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DB1978: D501000A 200A150A
	v_mov_b32_dpp v20, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1980: 7E2802FA FF01640B
	v_cndmask_b32_e64 v21, -v11, v11, s1                       // 000000DB1988: D5010015 2006170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB1990: BF8701B3
	v_add_f32_e32 v12, v10, v12                                // 000000DB1994: 0618190A
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB1998: 7E1402FA FF016809
	v_mov_b32_dpp v11, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB19A0: 7E1602FA FF016808
	v_mov_b32_dpp v18, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB19A8: 7E2402FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB19B0: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB19B8: BF870091
	v_dual_add_f32 v14, v14, v19 :: v_dual_add_f32 v19, v12, v18// 000000DB19BC: C908270E 0E12250C
	v_mov_b32_dpp v22, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB19C4: 7E2C02FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000DB19CC: D501000E 20061D0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DB19D4: BF870241
	v_dual_add_f32 v21, v21, v20 :: v_dual_add_f32 v20, v14, v22// 000000DB19D8: C9082915 15142D0E
	v_add_f32_e32 v22, v13, v26                                // 000000DB19E0: 062C350D
	v_add_nc_u32_e32 v26, 8, v3                                // 000000DB19E4: 4A340688
	v_mov_b32_dpp v14, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB19E8: 7E1C02FA FF016813
	v_mov_b32_dpp v18, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB19F0: 7E2402FA FF016815
	v_mov_b32_dpp v12, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB19F8: 7E1802FA FF016814
	v_mov_b32_dpp v13, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB1A00: 7E1A02FA FF016816
	.long 0xd4c4007e                                           // 000000DB1A08: D4C4007E
	v_cndmask_b32_e32 v1, s15, v26, vcc_lo                     // 000000DB1A0C: 0202340F
	s_cbranch_execz 148                                        // 000000DB1A10: BFA50094 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2364>
	s_clause 0x7                                               // 000000DB1A14: BF850007
	global_load_d16_b16 v28, v2, s[4:5] offset:32              // 000000DB1A18: DC820020 1C040002
	global_load_d16_b16 v29, v2, s[4:5]                        // 000000DB1A20: DC820000 1D040002
	global_load_d16_b16 v30, v2, s[4:5] offset:64              // 000000DB1A28: DC820040 1E040002
	global_load_d16_b16 v34, v2, s[4:5] offset:96              // 000000DB1A30: DC820060 22040002
	global_load_d16_b16 v35, v2, s[4:5] offset:128             // 000000DB1A38: DC820080 23040002
	global_load_d16_b16 v36, v2, s[4:5] offset:160             // 000000DB1A40: DC8200A0 24040002
	global_load_d16_b16 v37, v2, s[4:5] offset:192             // 000000DB1A48: DC8200C0 25040002
	global_load_d16_b16 v38, v2, s[4:5] offset:224             // 000000DB1A50: DC8200E0 26040002
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000DB1A58: D5010007 21AA0F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000DB1A60: D5010005 21AA0B05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DB1A68: D5010008 21AA1108
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DB1A70: D5010009 21AA1309
	v_cndmask_b32_e64 v21, -v21, v21, vcc_lo                   // 000000DB1A78: D5010015 21AA2B15
	v_cndmask_b32_e64 v19, -v19, v19, vcc_lo                   // 000000DB1A80: D5010013 21AA2713
	v_dual_add_f32 v4, v5, v4 :: v_dual_add_f32 v5, v7, v6     // 000000DB1A88: C9080905 04040D07
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB1A90: BF870004
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v11   // 000000DB1A94: C9081509 07081708
	s_waitcnt vmcnt(7)                                         // 000000DB1A9C: BF891FF7
	.long 0x7f383880                                           // 000000DB1AA0: 7F383880
	v_cndmask_b32_e64 v22, -v22, v22, vcc_lo                   // 000000DB1AA4: D5010016 21AA2D16
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000DB1AAC: C8C60AFF 050408FF 3DB504F3
	v_cndmask_b32_e64 v20, -v20, v20, vcc_lo                   // 000000DB1AB8: D5010014 21AA2914
	v_dual_add_f32 v11, v21, v18 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000DB1AC0: C9062515 0B0810FF 3DB504F3
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_add_f32 v10, v19, v14// 000000DB1ACC: C8C80EFF 070A1D13 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB1AD8: BF870193
	v_dual_add_f32 v13, v22, v13 :: v_dual_add_f32 v12, v20, v12// 000000DB1ADC: C9081B16 0D0C1914
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000DB1AE4: 101616FF 3DB504F3
	.long 0x7f0c399c                                           // 000000DB1AEC: 7F0C399C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB1AF0: BF870213
	v_dual_mul_f32 v10, 0x3db504f3, v10 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000DB1AF4: C8C614FF 0A0C1AFF 3DB504F3
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000DB1B00: 101818FF 3DB504F3
	.long 0x7f12399c                                           // 000000DB1B08: 7F12399C
	.long 0x7f1c399c                                           // 000000DB1B0C: 7F1C399C
	.long 0x7f24399c                                           // 000000DB1B10: 7F24399C
	v_mad_i64_i32 v[26:27], null, 0x1400, v26, v[0:1]          // 000000DB1B14: D6FF7C1A 040234FF 00001400
	v_fma_mix_f32 v5, v28, v5, neg(0) op_sel_hi:[1,0,0]        // 000000DB1B20: CC200005 8A020B1C
	s_waitcnt vmcnt(6)                                         // 000000DB1B28: BF891BF7
	v_fma_mix_f32 v4, v29, v4, neg(0) op_sel_hi:[1,0,0]        // 000000DB1B2C: CC200004 8A02091D
	s_waitcnt vmcnt(5)                                         // 000000DB1B34: BF8917F7
	v_fma_mix_f32 v7, v30, v7, neg(0) op_sel_hi:[1,0,0]        // 000000DB1B38: CC200007 8A020F1E
	s_waitcnt vmcnt(4)                                         // 000000DB1B40: BF8913F7
	v_fma_mix_f32 v8, v34, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DB1B44: CC200008 8A021122
	s_waitcnt vmcnt(3)                                         // 000000DB1B4C: BF890FF7
	v_fma_mix_f32 v10, v35, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DB1B50: CC20000A 8A021523
	.long 0x7e383985                                           // 000000DB1B58: 7E383985
	s_waitcnt vmcnt(2)                                         // 000000DB1B5C: BF890BF7
	v_fma_mix_f32 v11, v36, v11, neg(0) op_sel_hi:[1,0,0]      // 000000DB1B60: CC20000B 8A021724
	s_waitcnt vmcnt(1)                                         // 000000DB1B68: BF8907F7
	v_fma_mix_f32 v12, v37, v12, neg(0) op_sel_hi:[1,0,0]      // 000000DB1B6C: CC20000C 8A021925
	s_waitcnt vmcnt(0)                                         // 000000DB1B74: BF8903F7
	v_fma_mix_f32 v13, v38, v13, neg(0) op_sel_hi:[1,0,0]      // 000000DB1B78: CC20000D 8A021B26
	.long 0x7e0c3984                                           // 000000DB1B80: 7E0C3984
	v_and_b32_e32 v19, 1, v28                                  // 000000DB1B84: 36263881
	.long 0x7e383988                                           // 000000DB1B88: 7E383988
	.long 0x7e123987                                           // 000000DB1B8C: 7E123987
	.long 0x7e1c398a                                           // 000000DB1B90: 7E1C398A
	.long 0x7e24398c                                           // 000000DB1B94: 7E24398C
	v_and_b32_e32 v6, 1, v6                                    // 000000DB1B98: 360C0C81
	v_and_b32_e32 v20, 1, v28                                  // 000000DB1B9C: 36283881
	.long 0x7e38398b                                           // 000000DB1BA0: 7E38398B
	v_and_b32_e32 v9, 1, v9                                    // 000000DB1BA4: 36121281
	v_and_b32_e32 v14, 1, v14                                  // 000000DB1BA8: 361C1C81
	v_and_b32_e32 v18, 1, v18                                  // 000000DB1BAC: 36242481
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000DB1BB0: D6550004 03FE0D04 00007FFF
	v_and_b32_e32 v21, 1, v28                                  // 000000DB1BBC: 362A3881
	.long 0x7e38398d                                           // 000000DB1BC0: 7E38398D
	v_add3_u32 v6, v7, v9, 0x7fff                              // 000000DB1BC4: D6550006 03FE1307 00007FFF
	v_add3_u32 v5, v5, v19, 0x7fff                             // 000000DB1BD0: D6550005 03FE2705 00007FFF
	v_add3_u32 v8, v8, v20, 0x7fff                             // 000000DB1BDC: D6550008 03FE2908 00007FFF
	v_add3_u32 v9, v10, v14, 0x7fff                            // 000000DB1BE8: D6550009 03FE1D0A 00007FFF
	v_and_b32_e32 v7, 1, v28                                   // 000000DB1BF4: 360E3881
	v_add3_u32 v10, v12, v18, 0x7fff                           // 000000DB1BF8: D655000A 03FE250C 00007FFF
	v_add3_u32 v11, v11, v21, 0x7fff                           // 000000DB1C04: D655000B 03FE2B0B 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB1C10: BF870003
	v_add3_u32 v7, v13, v7, 0x7fff                             // 000000DB1C14: D6550007 03FE0F0D 00007FFF
	s_clause 0x7                                               // 000000DB1C20: BF850007
	global_store_d16_hi_b16 v[26:27], v4, off                  // 000000DB1C24: DC960000 007C041A
	global_store_d16_hi_b16 v[26:27], v5, off offset:32        // 000000DB1C2C: DC960020 007C051A
	global_store_d16_hi_b16 v[26:27], v6, off offset:64        // 000000DB1C34: DC960040 007C061A
	global_store_d16_hi_b16 v[26:27], v8, off offset:96        // 000000DB1C3C: DC960060 007C081A
	global_store_d16_hi_b16 v[26:27], v9, off offset:128       // 000000DB1C44: DC960080 007C091A
	global_store_d16_hi_b16 v[26:27], v11, off offset:160      // 000000DB1C4C: DC9600A0 007C0B1A
	global_store_d16_hi_b16 v[26:27], v10, off offset:192      // 000000DB1C54: DC9600C0 007C0A1A
	global_store_d16_hi_b16 v[26:27], v7, off offset:224       // 000000DB1C5C: DC9600E0 007C071A
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DB1C64: 8C7E067E
	v_add_f32_e32 v6, v55, v47                                 // 000000DB1C68: 060C5F37
	v_add_f32_e32 v8, v39, v31                                 // 000000DB1C6C: 06103F27
	v_add_f32_e32 v9, v23, v15                                 // 000000DB1C70: 06121F17
	v_add_f32_e32 v4, v71, v63                                 // 000000DB1C74: 06087F47
	v_sub_f32_e32 v10, v39, v31                                // 000000DB1C78: 08143F27
	s_mov_b32 s6, exec_lo                                      // 000000DB1C7C: BE86007E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB1C80: BF870193
	v_add_f32_e32 v13, v8, v9                                  // 000000DB1C84: 061A1308
	v_dual_sub_f32 v5, v71, v63 :: v_dual_add_f32 v12, v4, v6  // 000000DB1C88: C9487F47 050C0D04
	v_dual_sub_f32 v7, v55, v47 :: v_dual_sub_f32 v4, v4, v6   // 000000DB1C90: C94A5F37 07040D04
	v_dual_sub_f32 v11, v23, v15 :: v_dual_sub_f32 v8, v8, v9  // 000000DB1C98: C94A1F17 0B081308
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB1CA0: BF870193
	v_add_f32_e32 v18, v12, v13                                // 000000DB1CA4: 06241B0C
	v_add_f32_e32 v14, v5, v7                                  // 000000DB1CA8: 061C0F05
	v_sub_f32_e32 v6, v5, v7                                   // 000000DB1CAC: 080C0F05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000DB1CB0: BF870154
	v_add_f32_e32 v15, v10, v11                                // 000000DB1CB4: 061E170A
	v_sub_f32_e32 v9, v10, v11                                 // 000000DB1CB8: 0812170A
	v_mov_b32_dpp v5, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB1CBC: 7E0A02FA FF016112
	v_cndmask_b32_e64 v7, -v18, v18, s0                        // 000000DB1CC4: D5010007 20022512
	v_sub_f32_e32 v10, v12, v13                                // 000000DB1CCC: 08141B0C
	v_dual_add_f32 v12, v4, v8 :: v_dual_add_f32 v5, v7, v5    // 000000DB1CD0: C9081104 0C040B07
	v_add_f32_e32 v19, v14, v15                                // 000000DB1CD8: 06261F0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB1CDC: BF8700A1
	v_mov_b32_dpp v18, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB1CE0: 7E2402FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000DB1CE8: D5010013 20022713
	v_add_f32_e32 v7, v19, v18                                 // 000000DB1CF0: 060E2513
	v_mov_b32_dpp v18, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB1CF4: 7E2402FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000DB1CFC: D501000C 2002190C
	v_sub_f32_e32 v11, v14, v15                                // 000000DB1D04: 08161F0E
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1D08: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000DB1D10: D5010005 200A0B05
	v_mov_b32_dpp v15, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1D18: 7E1E02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000DB1D20: D5010007 200A0F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB1D28: BF870123
	v_dual_add_f32 v5, v5, v14 :: v_dual_sub_f32 v14, v4, v8   // 000000DB1D2C: C90A1D05 050E1104
	v_dual_add_f32 v13, v6, v9 :: v_dual_add_f32 v4, v12, v18  // 000000DB1D34: C9081306 0D04250C
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1D3C: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DB1D44: D5010005 20060B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB1D4C: BF8701A3
	v_mov_b32_dpp v19, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB1D50: 7E2602FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DB1D58: D501000D 20021B0D
	v_add_f32_e32 v5, v5, v12                                  // 000000DB1D60: 060A1905
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000DB1D64: BF8700B2
	v_add_f32_e32 v8, v13, v19                                 // 000000DB1D68: 0610270D
	v_mov_b32_dpp v13, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1D6C: 7E1A02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000DB1D74: D5010004 200A0904
	v_dual_add_f32 v7, v7, v15 :: v_dual_add_f32 v12, v4, v13  // 000000DB1D7C: C9081F07 070C1B04
	v_sub_f32_e32 v13, v6, v9                                  // 000000DB1D84: 081A1306
	v_mov_b32_dpp v15, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1D88: 7E1E02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DB1D90: D5010008 200A1108
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB1D98: BF870004
	v_mov_b32_dpp v18, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1D9C: 7E2402FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000DB1DA4: D5010007 20060F07
	v_mov_b32_dpp v9, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1DAC: 7E1202FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB1DB4: D501000C 2006190C
	v_add_f32_e32 v8, v8, v15                                  // 000000DB1DBC: 06101F08
	v_mov_b32_dpp v4, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB1DC0: 7E0802FA FF016805
	v_add_f32_e32 v7, v7, v18                                  // 000000DB1DC8: 060E2507
	v_mov_b32_dpp v18, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB1DCC: 7E2402FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000DB1DD4: D501000A 2002150A
	v_mov_b32_dpp v15, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1DDC: 7E1E02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB1DE4: D5010008 20061108
	v_add_f32_e32 v9, v12, v9                                  // 000000DB1DEC: 0612130C
	v_mov_b32_dpp v12, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB1DF0: 7E1802FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000DB1DF8: D501000B 2002170B
	v_add_f32_e32 v10, v10, v18                                // 000000DB1E00: 0614250A
	v_add_f32_e32 v8, v8, v15                                  // 000000DB1E04: 06101F08
	v_mov_b32_dpp v15, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB1E08: 7E1E02FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000DB1E10: D501000E 20021D0E
	v_mov_b32_dpp v18, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB1E18: 7E2402FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DB1E20: D501000D 20021B0D
	v_add_f32_e32 v11, v11, v12                                // 000000DB1E28: 0616190B
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1E2C: 7E1802FA FF01620A
	v_add_f32_e32 v14, v14, v15                                // 000000DB1E34: 061C1F0E
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DB1E38: D501000A 200A150A
	v_add_f32_e32 v13, v13, v18                                // 000000DB1E40: 061A250D
	v_mov_b32_dpp v15, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1E44: 7E1E02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000DB1E4C: D501000B 200A170B
	v_mov_b32_dpp v18, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1E54: 7E2402FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000DB1E5C: D501000E 200A1D0E
	v_mov_b32_dpp v19, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB1E64: 7E2602FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000DB1E6C: D501000D 200A1B0D
	v_dual_add_f32 v12, v10, v12 :: v_dual_add_f32 v11, v11, v15// 000000DB1E74: C908190A 0C0A1F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB1E7C: BF870224
	v_add_f32_e32 v14, v14, v18                                // 000000DB1E80: 061C250E
	v_mov_b32_dpp v6, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB1E84: 7E0C02FA FF016807
	v_add_f32_e32 v13, v13, v19                                // 000000DB1E8C: 061A270D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB1E90: BF870004
	v_mov_b32_dpp v15, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1E94: 7E1E02FA FF01640C
	v_mov_b32_dpp v19, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1E9C: 7E2602FA FF01640B
	v_cndmask_b32_e64 v20, -v11, v11, s1                       // 000000DB1EA4: D5010014 2006170B
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB1EAC: D501000C 2006190C
	v_mov_b32_dpp v21, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1EB4: 7E2A02FA FF01640E
	v_mov_b32_dpp v22, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB1EBC: 7E2C02FA FF01640D
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000DB1EC4: D501000E 20061D0E
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000DB1ECC: D501000D 20061B0D
	v_add_f32_e32 v18, v12, v15                                // 000000DB1ED4: 06241F0C
	v_add_f32_e32 v20, v20, v19                                // 000000DB1ED8: 06282714
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB1EDC: 7E1402FA FF016809
	v_add_f32_e32 v19, v14, v21                                // 000000DB1EE4: 06262B0E
	v_add_f32_e32 v21, v13, v22                                // 000000DB1EE8: 062A2D0D
	v_mov_b32_dpp v11, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB1EEC: 7E1602FA FF016808
	v_add_nc_u32_e32 v22, 10, v3                               // 000000DB1EF4: 4A2C068A
	v_mov_b32_dpp v14, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB1EF8: 7E1C02FA FF016812
	v_mov_b32_dpp v15, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB1F00: 7E1E02FA FF016814
	v_mov_b32_dpp v12, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB1F08: 7E1802FA FF016813
	v_mov_b32_dpp v13, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB1F10: 7E1A02FA FF016815
	.long 0xd4c4007e                                           // 000000DB1F18: D4C4007E
	v_cndmask_b32_e32 v1, s15, v22, vcc_lo                     // 000000DB1F1C: 02022C0F
	s_cbranch_execz 146                                        // 000000DB1F20: BFA50092 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x286c>
	s_clause 0x7                                               // 000000DB1F24: BF850007
	global_load_d16_b16 v26, v2, s[4:5] offset:32              // 000000DB1F28: DC820020 1A040002
	global_load_d16_b16 v27, v2, s[4:5]                        // 000000DB1F30: DC820000 1B040002
	global_load_d16_b16 v28, v2, s[4:5] offset:64              // 000000DB1F38: DC820040 1C040002
	global_load_d16_b16 v29, v2, s[4:5] offset:96              // 000000DB1F40: DC820060 1D040002
	global_load_d16_b16 v30, v2, s[4:5] offset:128             // 000000DB1F48: DC820080 1E040002
	global_load_d16_b16 v31, v2, s[4:5] offset:160             // 000000DB1F50: DC8200A0 1F040002
	global_load_d16_b16 v34, v2, s[4:5] offset:192             // 000000DB1F58: DC8200C0 22040002
	global_load_d16_b16 v35, v2, s[4:5] offset:224             // 000000DB1F60: DC8200E0 23040002
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000DB1F68: D5010007 21AA0F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000DB1F70: D5010005 21AA0B05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DB1F78: D5010008 21AA1108
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DB1F80: D5010009 21AA1309
	v_cndmask_b32_e64 v20, -v20, v20, vcc_lo                   // 000000DB1F88: D5010014 21AA2914
	v_cndmask_b32_e64 v18, -v18, v18, vcc_lo                   // 000000DB1F90: D5010012 21AA2512
	v_dual_add_f32 v4, v5, v4 :: v_dual_add_f32 v5, v7, v6     // 000000DB1F98: C9080905 04040D07
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB1FA0: BF870004
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v11   // 000000DB1FA4: C9081509 07081708
	s_waitcnt vmcnt(7)                                         // 000000DB1FAC: BF891FF7
	.long 0x7f343880                                           // 000000DB1FB0: 7F343880
	v_cndmask_b32_e64 v21, -v21, v21, vcc_lo                   // 000000DB1FB4: D5010015 21AA2B15
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000DB1FBC: C8C60AFF 050408FF 3DB504F3
	v_cndmask_b32_e64 v19, -v19, v19, vcc_lo                   // 000000DB1FC8: D5010013 21AA2713
	v_dual_add_f32 v10, v18, v14 :: v_dual_add_f32 v11, v20, v15// 000000DB1FD0: C9081D12 0A0A1F14
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000DB1FD8: C8C610FF 08060EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB1FE4: BF870193
	v_dual_add_f32 v12, v19, v12 :: v_dual_add_f32 v13, v21, v13// 000000DB1FE8: C9081913 0C0C1B15
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_mul_f32 v10, 0x3db504f3, v10// 000000DB1FF0: C8C616FF 0B0A14FF 3DB504F3
	.long 0x7f0c399a                                           // 000000DB1FFC: 7F0C399A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB2000: BF870003
	v_dual_mul_f32 v12, 0x3db504f3, v12 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000DB2004: C8C618FF 0C0C1AFF 3DB504F3
	.long 0x7f12399a                                           // 000000DB2010: 7F12399A
	.long 0x7f1c399a                                           // 000000DB2014: 7F1C399A
	.long 0x7f1e399a                                           // 000000DB2018: 7F1E399A
	v_mad_i64_i32 v[22:23], null, 0x1400, v22, v[0:1]          // 000000DB201C: D6FF7C16 04022CFF 00001400
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 000000DB2028: CC200005 8A020B1A
	s_waitcnt vmcnt(6)                                         // 000000DB2030: BF891BF7
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000DB2034: CC200004 8A02091B
	s_waitcnt vmcnt(5)                                         // 000000DB203C: BF8917F7
	v_fma_mix_f32 v7, v28, v7, neg(0) op_sel_hi:[1,0,0]        // 000000DB2040: CC200007 8A020F1C
	s_waitcnt vmcnt(4)                                         // 000000DB2048: BF8913F7
	v_fma_mix_f32 v8, v29, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DB204C: CC200008 8A02111D
	s_waitcnt vmcnt(3)                                         // 000000DB2054: BF890FF7
	v_fma_mix_f32 v10, v30, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DB2058: CC20000A 8A02151E
	.long 0x7e343985                                           // 000000DB2060: 7E343985
	s_waitcnt vmcnt(2)                                         // 000000DB2064: BF890BF7
	v_fma_mix_f32 v11, v31, v11, neg(0) op_sel_hi:[1,0,0]      // 000000DB2068: CC20000B 8A02171F
	s_waitcnt vmcnt(1)                                         // 000000DB2070: BF8907F7
	v_fma_mix_f32 v12, v34, v12, neg(0) op_sel_hi:[1,0,0]      // 000000DB2074: CC20000C 8A021922
	s_waitcnt vmcnt(0)                                         // 000000DB207C: BF8903F7
	v_fma_mix_f32 v13, v35, v13, neg(0) op_sel_hi:[1,0,0]      // 000000DB2080: CC20000D 8A021B23
	.long 0x7e0c3984                                           // 000000DB2088: 7E0C3984
	v_and_b32_e32 v18, 1, v26                                  // 000000DB208C: 36243481
	.long 0x7e343988                                           // 000000DB2090: 7E343988
	.long 0x7e123987                                           // 000000DB2094: 7E123987
	.long 0x7e1c398a                                           // 000000DB2098: 7E1C398A
	.long 0x7e1e398c                                           // 000000DB209C: 7E1E398C
	v_and_b32_e32 v6, 1, v6                                    // 000000DB20A0: 360C0C81
	v_and_b32_e32 v19, 1, v26                                  // 000000DB20A4: 36263481
	.long 0x7e34398b                                           // 000000DB20A8: 7E34398B
	v_and_b32_e32 v9, 1, v9                                    // 000000DB20AC: 36121281
	v_and_b32_e32 v14, 1, v14                                  // 000000DB20B0: 361C1C81
	v_and_b32_e32 v15, 1, v15                                  // 000000DB20B4: 361E1E81
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000DB20B8: D6550004 03FE0D04 00007FFF
	v_and_b32_e32 v20, 1, v26                                  // 000000DB20C4: 36283481
	.long 0x7e34398d                                           // 000000DB20C8: 7E34398D
	v_add3_u32 v6, v7, v9, 0x7fff                              // 000000DB20CC: D6550006 03FE1307 00007FFF
	v_add3_u32 v5, v5, v18, 0x7fff                             // 000000DB20D8: D6550005 03FE2505 00007FFF
	v_add3_u32 v8, v8, v19, 0x7fff                             // 000000DB20E4: D6550008 03FE2708 00007FFF
	v_add3_u32 v9, v10, v14, 0x7fff                            // 000000DB20F0: D6550009 03FE1D0A 00007FFF
	v_and_b32_e32 v7, 1, v26                                   // 000000DB20FC: 360E3481
	v_add3_u32 v10, v12, v15, 0x7fff                           // 000000DB2100: D655000A 03FE1F0C 00007FFF
	v_add3_u32 v11, v11, v20, 0x7fff                           // 000000DB210C: D655000B 03FE290B 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB2118: BF870003
	v_add3_u32 v7, v13, v7, 0x7fff                             // 000000DB211C: D6550007 03FE0F0D 00007FFF
	s_clause 0x7                                               // 000000DB2128: BF850007
	global_store_d16_hi_b16 v[22:23], v4, off                  // 000000DB212C: DC960000 007C0416
	global_store_d16_hi_b16 v[22:23], v5, off offset:32        // 000000DB2134: DC960020 007C0516
	global_store_d16_hi_b16 v[22:23], v6, off offset:64        // 000000DB213C: DC960040 007C0616
	global_store_d16_hi_b16 v[22:23], v8, off offset:96        // 000000DB2144: DC960060 007C0816
	global_store_d16_hi_b16 v[22:23], v9, off offset:128       // 000000DB214C: DC960080 007C0916
	global_store_d16_hi_b16 v[22:23], v11, off offset:160      // 000000DB2154: DC9600A0 007C0B16
	global_store_d16_hi_b16 v[22:23], v10, off offset:192      // 000000DB215C: DC9600C0 007C0A16
	global_store_d16_hi_b16 v[22:23], v7, off offset:224       // 000000DB2164: DC9600E0 007C0716
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DB216C: 8C7E067E
	v_sub_f32_e32 v7, v56, v48                                 // 000000DB2170: 080E6138
	v_sub_f32_e32 v10, v40, v32                                // 000000DB2174: 08144128
	v_sub_f32_e32 v11, v24, v16                                // 000000DB2178: 08162118
	v_add_f32_e32 v4, v72, v64                                 // 000000DB217C: 06088148
	v_add_f32_e32 v6, v56, v48                                 // 000000DB2180: 060C6138
	v_add_f32_e32 v8, v40, v32                                 // 000000DB2184: 06104128
	s_mov_b32 s6, exec_lo                                      // 000000DB2188: BE86007E
	v_add_f32_e32 v15, v10, v11                                // 000000DB218C: 061E170A
	v_sub_f32_e32 v5, v72, v64                                 // 000000DB2190: 080A8148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB2194: BF870091
	v_dual_add_f32 v9, v24, v16 :: v_dual_add_f32 v14, v5, v7  // 000000DB2198: C9082118 090E0F05
	v_add_f32_e32 v13, v8, v9                                  // 000000DB21A0: 061A1308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_sub_f32 v9, v10, v11   // 000000DB21A4: C94A1308 0808170A
	v_add_f32_e32 v12, v4, v6                                  // 000000DB21AC: 06180D04
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB21B0: BF870234
	v_add_f32_e32 v18, v14, v15                                // 000000DB21B4: 06241F0E
	v_sub_f32_e32 v4, v4, v6                                   // 000000DB21B8: 08080D04
	v_sub_f32_e32 v6, v5, v7                                   // 000000DB21BC: 080C0F05
	v_dual_sub_f32 v11, v14, v15 :: v_dual_add_f32 v16, v12, v13// 000000DB21C0: C9481F0E 0B101B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB21C8: BF8700A1
	v_mov_b32_dpp v5, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB21CC: 7E0A02FA FF016110
	v_cndmask_b32_e64 v7, -v16, v16, s0                        // 000000DB21D4: D5010007 20022110
	v_add_f32_e32 v5, v7, v5                                   // 000000DB21DC: 060A0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB21E0: BF8700A1
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB21E4: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000DB21EC: D5010005 200A0B05
	v_add_f32_e32 v5, v5, v14                                  // 000000DB21F4: 060A1D05
	v_mov_b32_dpp v16, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB21F8: 7E2002FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000DB2200: D5010012 20022512
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB2208: BF870121
	v_dual_add_f32 v7, v18, v16 :: v_dual_sub_f32 v10, v12, v13// 000000DB220C: C90A2112 070A1B0C
	v_add_f32_e32 v13, v6, v9                                  // 000000DB2214: 061A1306
	v_mov_b32_dpp v15, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB2218: 7E1E02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000DB2220: D5010007 200A0F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB2228: BF8701A3
	v_mov_b32_dpp v18, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB222C: 7E2402FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DB2234: D501000D 20021B0D
	v_dual_add_f32 v7, v7, v15 :: v_dual_add_f32 v12, v4, v8   // 000000DB223C: C9081F07 070C1104
	v_sub_f32_e32 v14, v4, v8                                  // 000000DB2244: 081C1104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB2248: BF870193
	v_add_f32_e32 v8, v13, v18                                 // 000000DB224C: 0610250D
	v_mov_b32_dpp v16, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB2250: 7E2002FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000DB2258: D501000C 2002190C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB2260: BF8701A3
	v_mov_b32_dpp v15, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB2264: 7E1E02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DB226C: D5010008 200A1108
	v_add_f32_e32 v4, v12, v16                                 // 000000DB2274: 0608210C
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB2278: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DB2280: D5010005 20060B05
	v_mov_b32_dpp v16, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB2288: 7E2002FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000DB2290: D5010007 20060F07
	v_mov_b32_dpp v13, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB2298: 7E1A02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000DB22A0: D5010004 200A0904
	v_add_f32_e32 v5, v5, v12                                  // 000000DB22A8: 060A1905
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB22AC: BF870224
	v_add_f32_e32 v7, v7, v16                                  // 000000DB22B0: 060E2107
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB22B4: 7E2002FA FF01610A
	v_add_f32_e32 v12, v4, v13                                 // 000000DB22BC: 06181B04
	v_sub_f32_e32 v13, v6, v9                                  // 000000DB22C0: 081A1306
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000DB22C4: D501000A 2002150A
	v_mov_b32_dpp v4, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB22CC: 7E0802FA FF016805
	v_mov_b32_dpp v6, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB22D4: 7E0C02FA FF016807
	v_mov_b32_dpp v9, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB22DC: 7E1202FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB22E4: D501000C 2006190C
	v_add_f32_e32 v10, v10, v16                                // 000000DB22EC: 0614210A
	v_mov_b32_dpp v16, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB22F0: 7E2002FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DB22F8: D501000D 20021B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB2300: BF870234
	v_add_f32_e32 v9, v12, v9                                  // 000000DB2304: 0612130C
	v_mov_b32_dpp v12, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB2308: 7E1802FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000DB2310: D501000B 2002170B
	v_dual_add_f32 v8, v8, v15 :: v_dual_add_f32 v13, v13, v16 // 000000DB2318: C9081F08 080C210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB2320: BF870112
	v_add_f32_e32 v11, v11, v12                                // 000000DB2324: 0616190B
	v_mov_b32_dpp v15, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB2328: 7E1E02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB2330: D5010008 20061108
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB2338: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DB2340: D501000A 200A150A
	v_mov_b32_dpp v18, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB2348: 7E2402FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000DB2350: D501000D 200A1B0D
	v_add_f32_e32 v8, v8, v15                                  // 000000DB2358: 06101F08
	v_mov_b32_dpp v15, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB235C: 7E1E02FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000DB2364: D501000E 20021D0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB236C: BF8701B1
	v_dual_add_f32 v13, v13, v18 :: v_dual_add_f32 v14, v14, v15// 000000DB2370: C908250D 0D0E1F0E
	v_mov_b32_dpp v15, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB2378: 7E1E02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000DB2380: D501000B 200A170B
	v_mov_b32_dpp v21, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB2388: 7E2A02FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000DB2390: D501000D 20061B0D
	v_mov_b32_dpp v16, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB2398: 7E2002FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000DB23A0: D501000E 200A1D0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB23A8: BF870091
	v_dual_add_f32 v11, v11, v15 :: v_dual_add_f32 v14, v14, v16// 000000DB23AC: C9081F0B 0B0E210E
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB23B4: 7E2402FA FF01640B
	v_cndmask_b32_e64 v19, -v11, v11, s1                       // 000000DB23BC: D5010013 2006170B
	v_add_f32_e32 v12, v10, v12                                // 000000DB23C4: 0618190A
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB23C8: 7E1402FA FF016809
	v_mov_b32_dpp v20, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB23D0: 7E2802FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000DB23D8: D501000E 20061D0E
	v_add_f32_e32 v19, v19, v18                                // 000000DB23E0: 06262513
	v_mov_b32_dpp v15, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB23E4: 7E1E02FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB23EC: D501000C 2006190C
	v_mov_b32_dpp v11, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB23F4: 7E1602FA FF016808
	v_add_f32_e32 v18, v14, v20                                // 000000DB23FC: 0624290E
	v_dual_add_f32 v20, v13, v21 :: v_dual_add_nc_u32 v21, 12, v3// 000000DB2400: C9202B0D 1414068C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB2408: BF870224
	v_add_f32_e32 v16, v12, v15                                // 000000DB240C: 06201F0C
	v_mov_b32_dpp v15, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB2410: 7E1E02FA FF016813
	v_mov_b32_dpp v12, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB2418: 7E1802FA FF016812
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB2420: BF870214
	v_mov_b32_dpp v13, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB2424: 7E1A02FA FF016814
	v_mov_b32_dpp v14, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB242C: 7E1C02FA FF016810
	.long 0xd4c4007e                                           // 000000DB2434: D4C4007E
	v_cndmask_b32_e32 v1, s15, v21, vcc_lo                     // 000000DB2438: 02022A0F
	s_cbranch_execz 146                                        // 000000DB243C: BFA50092 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2d88>
	s_clause 0x7                                               // 000000DB2440: BF850007
	global_load_d16_b16 v23, v2, s[4:5] offset:32              // 000000DB2444: DC820020 17040002
	global_load_d16_b16 v24, v2, s[4:5]                        // 000000DB244C: DC820000 18040002
	global_load_d16_b16 v26, v2, s[4:5] offset:64              // 000000DB2454: DC820040 1A040002
	global_load_d16_b16 v27, v2, s[4:5] offset:96              // 000000DB245C: DC820060 1B040002
	global_load_d16_b16 v28, v2, s[4:5] offset:128             // 000000DB2464: DC820080 1C040002
	global_load_d16_b16 v29, v2, s[4:5] offset:160             // 000000DB246C: DC8200A0 1D040002
	global_load_d16_b16 v30, v2, s[4:5] offset:192             // 000000DB2474: DC8200C0 1E040002
	global_load_d16_b16 v31, v2, s[4:5] offset:224             // 000000DB247C: DC8200E0 1F040002
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000DB2484: D5010007 21AA0F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000DB248C: D5010005 21AA0B05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DB2494: D5010008 21AA1108
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DB249C: D5010009 21AA1309
	v_cndmask_b32_e64 v19, -v19, v19, vcc_lo                   // 000000DB24A4: D5010013 21AA2713
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000DB24AC: D5010010 21AA2110
	v_dual_add_f32 v4, v5, v4 :: v_dual_add_f32 v5, v7, v6     // 000000DB24B4: C9080905 04040D07
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB24BC: BF870004
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v11   // 000000DB24C0: C9081509 07081708
	s_waitcnt vmcnt(7)                                         // 000000DB24C8: BF891FF7
	.long 0x7f2e3880                                           // 000000DB24CC: 7F2E3880
	v_cndmask_b32_e64 v20, -v20, v20, vcc_lo                   // 000000DB24D0: D5010014 21AA2914
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000DB24D8: C8C60AFF 050408FF 3DB504F3
	v_cndmask_b32_e64 v18, -v18, v18, vcc_lo                   // 000000DB24E4: D5010012 21AA2512
	v_dual_add_f32 v10, v16, v14 :: v_dual_add_f32 v11, v19, v15// 000000DB24EC: C9081D10 0A0A1F13
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000DB24F4: C8C610FF 08060EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB2500: BF870193
	v_dual_add_f32 v12, v18, v12 :: v_dual_add_f32 v13, v20, v13// 000000DB2504: C9081912 0C0C1B14
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_mul_f32 v10, 0x3db504f3, v10// 000000DB250C: C8C616FF 0B0A14FF 3DB504F3
	.long 0x7f0c3997                                           // 000000DB2518: 7F0C3997
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB251C: BF870003
	v_dual_mul_f32 v12, 0x3db504f3, v12 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000DB2520: C8C618FF 0C0C1AFF 3DB504F3
	.long 0x7f123997                                           // 000000DB252C: 7F123997
	.long 0x7f1c3997                                           // 000000DB2530: 7F1C3997
	.long 0x7f1e3997                                           // 000000DB2534: 7F1E3997
	v_mad_i64_i32 v[21:22], null, 0x1400, v21, v[0:1]          // 000000DB2538: D6FF7C15 04022AFF 00001400
	v_fma_mix_f32 v5, v23, v5, neg(0) op_sel_hi:[1,0,0]        // 000000DB2544: CC200005 8A020B17
	s_waitcnt vmcnt(6)                                         // 000000DB254C: BF891BF7
	v_fma_mix_f32 v4, v24, v4, neg(0) op_sel_hi:[1,0,0]        // 000000DB2550: CC200004 8A020918
	s_waitcnt vmcnt(5)                                         // 000000DB2558: BF8917F7
	v_fma_mix_f32 v7, v26, v7, neg(0) op_sel_hi:[1,0,0]        // 000000DB255C: CC200007 8A020F1A
	s_waitcnt vmcnt(4)                                         // 000000DB2564: BF8913F7
	v_fma_mix_f32 v8, v27, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DB2568: CC200008 8A02111B
	s_waitcnt vmcnt(3)                                         // 000000DB2570: BF890FF7
	v_fma_mix_f32 v10, v28, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DB2574: CC20000A 8A02151C
	.long 0x7e2e3985                                           // 000000DB257C: 7E2E3985
	s_waitcnt vmcnt(2)                                         // 000000DB2580: BF890BF7
	v_fma_mix_f32 v11, v29, v11, neg(0) op_sel_hi:[1,0,0]      // 000000DB2584: CC20000B 8A02171D
	s_waitcnt vmcnt(1)                                         // 000000DB258C: BF8907F7
	v_fma_mix_f32 v12, v30, v12, neg(0) op_sel_hi:[1,0,0]      // 000000DB2590: CC20000C 8A02191E
	s_waitcnt vmcnt(0)                                         // 000000DB2598: BF8903F7
	v_fma_mix_f32 v13, v31, v13, neg(0) op_sel_hi:[1,0,0]      // 000000DB259C: CC20000D 8A021B1F
	.long 0x7e0c3984                                           // 000000DB25A4: 7E0C3984
	v_and_b32_e32 v16, 1, v23                                  // 000000DB25A8: 36202E81
	.long 0x7e2e3988                                           // 000000DB25AC: 7E2E3988
	.long 0x7e123987                                           // 000000DB25B0: 7E123987
	.long 0x7e1c398a                                           // 000000DB25B4: 7E1C398A
	.long 0x7e1e398c                                           // 000000DB25B8: 7E1E398C
	v_and_b32_e32 v6, 1, v6                                    // 000000DB25BC: 360C0C81
	v_and_b32_e32 v18, 1, v23                                  // 000000DB25C0: 36242E81
	.long 0x7e2e398b                                           // 000000DB25C4: 7E2E398B
	v_and_b32_e32 v9, 1, v9                                    // 000000DB25C8: 36121281
	v_and_b32_e32 v14, 1, v14                                  // 000000DB25CC: 361C1C81
	v_and_b32_e32 v15, 1, v15                                  // 000000DB25D0: 361E1E81
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000DB25D4: D6550004 03FE0D04 00007FFF
	v_and_b32_e32 v19, 1, v23                                  // 000000DB25E0: 36262E81
	.long 0x7e2e398d                                           // 000000DB25E4: 7E2E398D
	v_add3_u32 v6, v7, v9, 0x7fff                              // 000000DB25E8: D6550006 03FE1307 00007FFF
	v_add3_u32 v5, v5, v16, 0x7fff                             // 000000DB25F4: D6550005 03FE2105 00007FFF
	v_add3_u32 v8, v8, v18, 0x7fff                             // 000000DB2600: D6550008 03FE2508 00007FFF
	v_add3_u32 v9, v10, v14, 0x7fff                            // 000000DB260C: D6550009 03FE1D0A 00007FFF
	v_and_b32_e32 v7, 1, v23                                   // 000000DB2618: 360E2E81
	v_add3_u32 v10, v12, v15, 0x7fff                           // 000000DB261C: D655000A 03FE1F0C 00007FFF
	v_add3_u32 v11, v11, v19, 0x7fff                           // 000000DB2628: D655000B 03FE270B 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB2634: BF870003
	v_add3_u32 v7, v13, v7, 0x7fff                             // 000000DB2638: D6550007 03FE0F0D 00007FFF
	s_clause 0x7                                               // 000000DB2644: BF850007
	global_store_d16_hi_b16 v[21:22], v4, off                  // 000000DB2648: DC960000 007C0415
	global_store_d16_hi_b16 v[21:22], v5, off offset:32        // 000000DB2650: DC960020 007C0515
	global_store_d16_hi_b16 v[21:22], v6, off offset:64        // 000000DB2658: DC960040 007C0615
	global_store_d16_hi_b16 v[21:22], v8, off offset:96        // 000000DB2660: DC960060 007C0815
	global_store_d16_hi_b16 v[21:22], v9, off offset:128       // 000000DB2668: DC960080 007C0915
	global_store_d16_hi_b16 v[21:22], v11, off offset:160      // 000000DB2670: DC9600A0 007C0B15
	global_store_d16_hi_b16 v[21:22], v10, off offset:192      // 000000DB2678: DC9600C0 007C0A15
	global_store_d16_hi_b16 v[21:22], v7, off offset:224       // 000000DB2680: DC9600E0 007C0715
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DB2688: 8C7E067E
	v_sub_f32_e32 v10, v41, v33                                // 000000DB268C: 08144329
	v_sub_f32_e32 v11, v25, v17                                // 000000DB2690: 08162319
	v_add_f32_e32 v4, v73, v65                                 // 000000DB2694: 06088349
	v_add_f32_e32 v8, v41, v33                                 // 000000DB2698: 06104329
	v_add_f32_e32 v9, v25, v17                                 // 000000DB269C: 06122319
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB26A0: BF870124
	v_dual_add_f32 v15, v10, v11 :: v_dual_add_f32 v6, v57, v49// 000000DB26A4: C908170A 0F066339
	v_sub_f32_e32 v5, v73, v65                                 // 000000DB26AC: 080A8349
	v_dual_sub_f32 v7, v57, v49 :: v_dual_add_f32 v12, v4, v6  // 000000DB26B0: C9486339 070C0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB26B8: BF870121
	v_dual_add_f32 v13, v8, v9 :: v_dual_add_f32 v14, v5, v7   // 000000DB26BC: C9081308 0D0E0F05
	v_dual_sub_f32 v8, v8, v9 :: v_dual_sub_f32 v9, v10, v11   // 000000DB26C4: C94A1308 0808170A
	v_dual_add_f32 v16, v12, v13 :: v_dual_add_f32 v17, v14, v15// 000000DB26CC: C9081B0C 10101F0E
	v_sub_f32_e32 v4, v4, v6                                   // 000000DB26D4: 08080D04
	v_sub_f32_e32 v6, v5, v7                                   // 000000DB26D8: 080C0F05
	v_sub_f32_e32 v11, v14, v15                                // 000000DB26DC: 08161F0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB26E0: BF8700A4
	v_mov_b32_dpp v5, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB26E4: 7E0A02FA FF016110
	v_cndmask_b32_e64 v7, -v16, v16, s0                        // 000000DB26EC: D5010007 20022110
	v_add_f32_e32 v5, v7, v5                                   // 000000DB26F4: 060A0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB26F8: BF8700A1
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB26FC: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000DB2704: D5010005 200A0B05
	v_add_f32_e32 v5, v5, v14                                  // 000000DB270C: 060A1D05
	v_mov_b32_dpp v16, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB2710: 7E2002FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 000000DB2718: D5010011 20022311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB2720: BF870121
	v_add_f32_e32 v7, v17, v16                                 // 000000DB2724: 060E2111
	v_sub_f32_e32 v14, v4, v8                                  // 000000DB2728: 081C1104
	v_mov_b32_dpp v15, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB272C: 7E1E02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000DB2734: D5010007 200A0F07
	v_sub_f32_e32 v10, v12, v13                                // 000000DB273C: 08141B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB2740: BF870092
	v_dual_add_f32 v12, v4, v8 :: v_dual_add_f32 v7, v7, v15   // 000000DB2744: C9081104 0C061F07
	v_mov_b32_dpp v16, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB274C: 7E2002FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000DB2754: D501000C 2002190C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB275C: BF870091
	v_dual_add_f32 v13, v6, v9 :: v_dual_add_f32 v4, v12, v16  // 000000DB2760: C9081306 0D04210C
	v_mov_b32_dpp v17, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB2768: 7E2202FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DB2770: D501000D 20021B0D
	v_mov_b32_dpp v16, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB2778: 7E2002FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000DB2780: D5010007 20060F07
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB2788: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DB2790: D5010005 20060B05
	v_add_f32_e32 v8, v13, v17                                 // 000000DB2798: 0610230D
	v_mov_b32_dpp v13, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB279C: 7E1A02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000DB27A4: D5010004 200A0904
	v_add_f32_e32 v7, v7, v16                                  // 000000DB27AC: 060E2107
	v_add_f32_e32 v5, v5, v12                                  // 000000DB27B0: 060A1905
	v_mov_b32_dpp v15, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB27B4: 7E1E02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DB27BC: D5010008 200A1108
	v_add_f32_e32 v12, v4, v13                                 // 000000DB27C4: 06181B04
	v_sub_f32_e32 v13, v6, v9                                  // 000000DB27C8: 081A1306
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB27CC: 7E2002FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000DB27D4: D501000A 2002150A
	v_add_f32_e32 v8, v8, v15                                  // 000000DB27DC: 06101F08
	v_mov_b32_dpp v9, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB27E0: 7E1202FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB27E8: D501000C 2006190C
	v_mov_b32_dpp v4, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB27F0: 7E0802FA FF016805
	v_add_f32_e32 v10, v10, v16                                // 000000DB27F8: 0614210A
	v_mov_b32_dpp v15, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB27FC: 7E1E02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB2804: D5010008 20061108
	v_add_f32_e32 v9, v12, v9                                  // 000000DB280C: 0612130C
	v_mov_b32_dpp v12, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB2810: 7E1802FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000DB2818: D501000B 2002170B
	v_mov_b32_dpp v16, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB2820: 7E2002FA FF01610D
	v_add_f32_e32 v8, v8, v15                                  // 000000DB2828: 06101F08
	v_mov_b32_dpp v15, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB282C: 7E1E02FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000DB2834: D501000E 20021D0E
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DB283C: D501000D 20021B0D
	v_add_f32_e32 v11, v11, v12                                // 000000DB2844: 0616190B
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB2848: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DB2850: D501000A 200A150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB2858: BF870214
	v_dual_add_f32 v14, v14, v15 :: v_dual_add_f32 v13, v13, v16// 000000DB285C: C9081F0E 0E0C210D
	v_mov_b32_dpp v15, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB2864: 7E1E02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000DB286C: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB2874: BF870214
	v_add_f32_e32 v12, v10, v12                                // 000000DB2878: 0618190A
	v_mov_b32_dpp v16, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB287C: 7E2002FA FF01620E
	v_mov_b32_dpp v17, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB2884: 7E2202FA FF01620D
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000DB288C: D501000E 200A1D0E
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000DB2894: D501000D 200A1B0D
	v_add_f32_e32 v11, v11, v15                                // 000000DB289C: 06161F0B
	v_mov_b32_dpp v15, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB28A0: 7E1E02FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB28A8: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB28B0: BF870214
	v_dual_add_f32 v14, v14, v16 :: v_dual_add_f32 v13, v13, v17// 000000DB28B4: C908210E 0E0C230D
	v_mov_b32_dpp v16, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB28BC: 7E2002FA FF01640B
	v_cndmask_b32_e64 v17, -v11, v11, s1                       // 000000DB28C4: D5010011 2006170B
	v_mov_b32_dpp v6, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB28CC: 7E0C02FA FF016807
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB28D4: BF870004
	v_mov_b32_dpp v18, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB28D8: 7E2402FA FF01640E
	v_mov_b32_dpp v19, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB28E0: 7E2602FA FF01640D
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000DB28E8: D501000E 20061D0E
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000DB28F0: D501000D 20061B0D
	v_add_f32_e32 v15, v12, v15                                // 000000DB28F8: 061E1F0C
	v_add_f32_e32 v17, v17, v16                                // 000000DB28FC: 06222111
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB2900: 7E1402FA FF016809
	v_add_f32_e32 v16, v14, v18                                // 000000DB2908: 0620250E
	v_add_f32_e32 v18, v13, v19                                // 000000DB290C: 0624270D
	v_add_nc_u32_e32 v19, 14, v3                               // 000000DB2910: 4A26068E
	v_mov_b32_dpp v11, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB2914: 7E1602FA FF016808
	v_mov_b32_dpp v13, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB291C: 7E1A02FA FF01680F
	v_mov_b32_dpp v14, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB2924: 7E1C02FA FF016811
	v_mov_b32_dpp v3, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB292C: 7E0602FA FF016810
	v_mov_b32_dpp v12, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB2934: 7E1802FA FF016812
	.long 0xd4440000                                           // 000000DB293C: D4440000
	v_cndmask_b32_e32 v1, s15, v19, vcc_lo                     // 000000DB2940: 0202260F
	s_and_b32 exec_lo, exec_lo, s0                             // 000000DB2944: 8B7E007E
	s_cbranch_execz 138                                        // 000000DB2948: BFA5008A <_ZN7halogen12_GLOBAL__N_111k_ht_moe_dnILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3274>
	s_clause 0x7                                               // 000000DB294C: BF850007
	global_load_d16_b16 v20, v2, s[4:5] offset:32              // 000000DB2950: DC820020 14040002
	global_load_d16_b16 v21, v2, s[4:5]                        // 000000DB2958: DC820000 15040002
	global_load_d16_b16 v22, v2, s[4:5] offset:64              // 000000DB2960: DC820040 16040002
	global_load_d16_b16 v23, v2, s[4:5] offset:96              // 000000DB2968: DC820060 17040002
	global_load_d16_b16 v24, v2, s[4:5] offset:128             // 000000DB2970: DC820080 18040002
	global_load_d16_b16 v25, v2, s[4:5] offset:160             // 000000DB2978: DC8200A0 19040002
	global_load_d16_b16 v26, v2, s[4:5] offset:192             // 000000DB2980: DC8200C0 1A040002
	global_load_d16_b16 v2, v2, s[4:5] offset:224              // 000000DB2988: DC8200E0 02040002
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000DB2990: D5010007 21AA0F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000DB2998: D5010005 21AA0B05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DB29A0: D5010008 21AA1108
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DB29A8: D5010009 21AA1309
	v_cndmask_b32_e64 v17, -v17, v17, vcc_lo                   // 000000DB29B0: D5010011 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000DB29B8: D501000F 21AA1F0F
	v_dual_add_f32 v4, v5, v4 :: v_dual_add_f32 v5, v7, v6     // 000000DB29C0: C9080905 04040D07
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB29C8: BF870234
	v_dual_add_f32 v6, v9, v10 :: v_dual_add_f32 v7, v8, v11   // 000000DB29CC: C9081509 06061708
	v_cndmask_b32_e64 v18, -v18, v18, vcc_lo                   // 000000DB29D4: D5010012 21AA2512
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000DB29DC: D5010010 21AA2110
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000DB29E4: C8C60AFF 050408FF 3DB504F3
	v_dual_add_f32 v9, v15, v13 :: v_dual_add_f32 v10, v17, v14// 000000DB29F0: C9081B0F 090A1D11
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 000000DB29F8: C8C60EFF 07060CFF 3DB504F3
	v_mad_i64_i32 v[0:1], null, 0x1400, v19, v[0:1]            // 000000DB2A04: D6FF7C00 040226FF 00001400
	.long 0x7f263880                                           // 000000DB2A10: 7F263880
	v_dual_add_f32 v3, v16, v3 :: v_dual_add_f32 v12, v18, v12 // 000000DB2A14: C9080710 030C1912
	v_dual_mul_f32 v10, 0x3db504f3, v10 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 000000DB2A1C: C8C614FF 0A0812FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000DB2A28: BF8903F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB2A2C: BF870193
	.long 0x7f043993                                           // 000000DB2A30: 7F043993
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v12, 0x3db504f3, v12// 000000DB2A34: C8C606FF 030C18FF 3DB504F3
	.long 0x7f103993                                           // 000000DB2A40: 7F103993
	.long 0x7f163993                                           // 000000DB2A44: 7F163993
	.long 0x7f1a3993                                           // 000000DB2A48: 7F1A3993
	v_fma_mix_f32 v5, v20, v5, neg(0) op_sel_hi:[1,0,0]        // 000000DB2A4C: CC200005 8A020B14
	v_fma_mix_f32 v4, v21, v4, neg(0) op_sel_hi:[1,0,0]        // 000000DB2A54: CC200004 8A020915
	v_fma_mix_f32 v6, v22, v6, neg(0) op_sel_hi:[1,0,0]        // 000000DB2A5C: CC200006 8A020D16
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 000000DB2A64: CC200007 8A020F17
	v_fma_mix_f32 v9, v24, v9, neg(0) op_sel_hi:[1,0,0]        // 000000DB2A6C: CC200009 8A021318
	.long 0x7e263985                                           // 000000DB2A74: 7E263985
	v_fma_mix_f32 v10, v25, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DB2A78: CC20000A 8A021519
	v_fma_mix_f32 v3, v26, v3, neg(0) op_sel_hi:[1,0,0]        // 000000DB2A80: CC200003 8A02071A
	v_fma_mix_f32 v12, v2, v12, neg(0) op_sel_hi:[1,0,0]       // 000000DB2A88: CC20000C 8A021902
	.long 0x7e043984                                           // 000000DB2A90: 7E043984
	v_and_b32_e32 v14, 1, v19                                  // 000000DB2A94: 361C2681
	.long 0x7e263987                                           // 000000DB2A98: 7E263987
	.long 0x7e103986                                           // 000000DB2A9C: 7E103986
	.long 0x7e163989                                           // 000000DB2AA0: 7E163989
	.long 0x7e1a3983                                           // 000000DB2AA4: 7E1A3983
	v_and_b32_e32 v2, 1, v2                                    // 000000DB2AA8: 36040481
	v_and_b32_e32 v15, 1, v19                                  // 000000DB2AAC: 361E2681
	.long 0x7e26398a                                           // 000000DB2AB0: 7E26398A
	v_and_b32_e32 v8, 1, v8                                    // 000000DB2AB4: 36101081
	v_and_b32_e32 v11, 1, v11                                  // 000000DB2AB8: 36161681
	v_and_b32_e32 v13, 1, v13                                  // 000000DB2ABC: 361A1A81
	v_add3_u32 v2, v4, v2, 0x7fff                              // 000000DB2AC0: D6550002 03FE0504 00007FFF
	v_and_b32_e32 v16, 1, v19                                  // 000000DB2ACC: 36202681
	.long 0x7e26398c                                           // 000000DB2AD0: 7E26398C
	v_add3_u32 v4, v6, v8, 0x7fff                              // 000000DB2AD4: D6550004 03FE1106 00007FFF
	v_add3_u32 v5, v5, v14, 0x7fff                             // 000000DB2AE0: D6550005 03FE1D05 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000DB2AEC: D6550007 03FE1F07 00007FFF
	v_add3_u32 v8, v9, v11, 0x7fff                             // 000000DB2AF8: D6550008 03FE1709 00007FFF
	v_and_b32_e32 v6, 1, v19                                   // 000000DB2B04: 360C2681
	v_add3_u32 v3, v3, v13, 0x7fff                             // 000000DB2B08: D6550003 03FE1B03 00007FFF
	v_add3_u32 v9, v10, v16, 0x7fff                            // 000000DB2B14: D6550009 03FE210A 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB2B20: BF870003
	v_add3_u32 v6, v12, v6, 0x7fff                             // 000000DB2B24: D6550006 03FE0D0C 00007FFF
	s_clause 0x7                                               // 000000DB2B30: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000DB2B34: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v5, off offset:32          // 000000DB2B3C: DC960020 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:64          // 000000DB2B44: DC960040 007C0400
	global_store_d16_hi_b16 v[0:1], v7, off offset:96          // 000000DB2B4C: DC960060 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:128         // 000000DB2B54: DC960080 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:160         // 000000DB2B5C: DC9600A0 007C0900
	global_store_d16_hi_b16 v[0:1], v3, off offset:192         // 000000DB2B64: DC9600C0 007C0300
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 000000DB2B6C: DC9600E0 007C0600
	s_nop 0                                                    // 000000DB2B74: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000DB2B78: BFB60003
	s_endpgm                                                   // 000000DB2B7C: BFB00000
		...

