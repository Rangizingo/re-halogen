00000000009a2e00 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi():
	s_clause 0x1                                               // 0000009A2E00: BF850001
	s_load_b32 s3, s[0:1], 0x88                                // 0000009A2E04: F40000C0 F8000088
	s_load_b512 s[12:27], s[0:1], null                         // 0000009A2E0C: F4100300 F8000000
	v_and_b32_e32 v72, 31, v0                                  // 0000009A2E14: 3690009F
	v_lshrrev_b32_e32 v71, 5, v0                               // 0000009A2E18: 328E0085
	s_mov_b32 s4, -1                                           // 0000009A2E1C: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 0000009A2E20: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 0000009A2E24: BF040302
	s_cbranch_scc1 2424                                        // 0000009A2E28: BFA20978 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x260c>
	s_load_b64 s[8:9], s[0:1], 0x7c                            // 0000009A2E2C: F4040200 F800007C
	s_sub_i32 s3, s2, s3                                       // 0000009A2E34: 81830302
	s_clause 0x1                                               // 0000009A2E38: BF850001
	s_load_b256 s[44:51], s[0:1], 0x60                         // 0000009A2E3C: F40C0B00 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 0000009A2E44: F40C0900 F8000040
	s_mov_b32 s34, 0                                           // 0000009A2E4C: BEA20080
	s_mov_b32 s33, exec_lo                                     // 0000009A2E50: BEA1007E
	s_waitcnt lgkmcnt(0)                                       // 0000009A2E54: BF89FC07
	s_abs_i32 s4, s9                                           // 0000009A2E58: BE841509
	s_ashr_i32 s7, s9, 31                                      // 0000009A2E5C: 86079F09
	s_cvt_f32_u32 s5, s4                                       // 0000009A2E60: BE856504
	s_sub_i32 s6, 0, s4                                        // 0000009A2E64: 81860480
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000009A2E68: BF87029A
	v_rcp_iflag_f32_e32 v1, s5                                 // 0000009A2E6C: 7E025605
	v_readfirstlane_b32 s5, v1                                 // 0000009A2E70: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 0000009A2E74: A205FF05 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000009A2E7C: BF87059B
	s_cvt_u32_f32 s5, s5                                       // 0000009A2E80: BE856705
	s_mul_i32 s6, s6, s5                                       // 0000009A2E84: 96060506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009A2E88: BF870499
	s_mul_hi_u32 s6, s5, s6                                    // 0000009A2E8C: 96860605
	s_add_i32 s5, s5, s6                                       // 0000009A2E90: 81050605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009A2E94: BF870499
	s_mul_hi_u32 s5, s3, s5                                    // 0000009A2E98: 96850503
	s_mul_i32 s6, s5, s4                                       // 0000009A2E9C: 96060405
	s_add_i32 s10, s5, 1                                       // 0000009A2EA0: 810A8105
	s_sub_i32 s6, s3, s6                                       // 0000009A2EA4: 81860603
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009A2EA8: BF870009
	s_sub_i32 s11, s6, s4                                      // 0000009A2EAC: 818B0406
	s_cmp_ge_u32 s6, s4                                        // 0000009A2EB0: BF090406
	s_cselect_b32 s5, s10, s5                                  // 0000009A2EB4: 9805050A
	s_cselect_b32 s6, s11, s6                                  // 0000009A2EB8: 9806060B
	s_add_i32 s10, s5, 1                                       // 0000009A2EBC: 810A8105
	s_cmp_ge_u32 s6, s4                                        // 0000009A2EC0: BF090406
	s_cselect_b32 s4, s10, s5                                  // 0000009A2EC4: 9804050A
	s_ashr_i32 s11, s50, 31                                    // 0000009A2EC8: 860B9F32
	s_xor_b32 s4, s4, s7                                       // 0000009A2ECC: 8D040704
	s_lshr_b32 s1, s11, 25                                     // 0000009A2ED0: 8501990B
	s_sub_i32 s10, s4, s7                                      // 0000009A2ED4: 818A0704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009A2ED8: BF870499
	s_mul_i32 s0, s10, s9                                      // 0000009A2EDC: 9600090A
	s_sub_i32 s30, s3, s0                                      // 0000009A2EE0: 819E0003
	s_add_i32 s0, s50, s1                                      // 0000009A2EE4: 81000132
	s_mul_i32 s31, s30, s8                                     // 0000009A2EE8: 961F081E
	s_ashr_i32 s0, s0, 7                                       // 0000009A2EEC: 86008700
	s_add_i32 s1, s31, s8                                      // 0000009A2EF0: 8101081F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009A2EF4: BF870499
	s_min_i32 s0, s0, s1                                       // 0000009A2EF8: 89000100
	s_sub_i32 s29, s0, s31                                     // 0000009A2EFC: 819D1F00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009A2F00: BF870499
	s_lshl_b32 s28, s29, 1                                     // 0000009A2F04: 841C811D
	.long 0xd4c4007e                                           // 0000009A2F08: D4C4007E
	v_cndmask_b32_e32 v1, s28, v71, vcc_lo                     // 0000009A2F0C: 02028E1C
	s_cbranch_execz 503                                        // 0000009A2F10: BFA501F7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f0>
	s_add_i32 s35, s48, -1                                     // 0000009A2F14: 8123C130
	s_cmp_lg_u64 s[40:41], 0                                   // 0000009A2F18: BF118028
	v_dual_mov_b32 v8, v71 :: v_dual_and_b32 v1, 1, v0         // 0000009A2F1C: CA240147 08000081
	s_cselect_b32 s51, -1, 0                                   // 0000009A2F24: 983380C1
	s_abs_i32 s52, s29                                         // 0000009A2F28: BEB4151D
	v_and_b32_e32 v2, 2, v0                                    // 0000009A2F2C: 36040082
	s_cvt_f32_u32 s0, s52                                      // 0000009A2F30: BE806534
	v_lshlrev_b32_e32 v6, 3, v72                               // 0000009A2F34: 300C9083
	v_lshlrev_b32_e32 v7, 7, v71                               // 0000009A2F38: 300E8E87
	v_and_b32_e32 v3, 4, v0                                    // 0000009A2F3C: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 0000009A2F40: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 0000009A2F44: 360A0088
	.long 0xd44a0001                                           // 0000009A2F48: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000009A2F4C: 02020280
	.long 0xd44a0003                                           // 0000009A2F50: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000009A2F54: 02020480
	v_lshl_or_b32 v1, v71, 8, v6                               // 0000009A2F58: D6560001 04191147
	v_lshl_add_u32 v2, s31, 7, v7                              // 0000009A2F60: D6460002 041D0E1F
	s_ashr_i32 s54, s29, 31                                    // 0000009A2F68: 86369F1D
	s_sub_i32 s56, 0, s52                                      // 0000009A2F6C: 81B83480
	s_mul_i32 s8, s54, 0x1400                                  // 0000009A2F70: 9608FF36 00001400
	.long 0xd44c0000                                           // 0000009A2F78: D44C0000
	v_cndmask_b32_e32 v1, 16, v72, vcc_lo                      // 0000009A2F7C: 02029090
	v_readfirstlane_b32 s5, v4                                 // 0000009A2F80: 7E0A0504
	.long 0xd44a0004                                           // 0000009A2F84: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 0000009A2F88: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 0000009A2F8C: 4E120208
	v_lshl_or_b32 v1, v72, 2, v2                               // 0000009A2F90: D6560001 04090548
	s_lshl_b32 s6, s29, 7                                      // 0000009A2F98: 8406871D
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 0000009A2F9C: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 0000009A2FA4: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000009A2FA8: 02020A80
	s_mov_b32 s53, 0x76543210                                  // 0000009A2FAC: BEB500FF 76543210
	s_lshl_b32 s55, s29, 8                                     // 0000009A2FB4: 8437881D
	s_cvt_u32_f32 s7, s7                                       // 0000009A2FB8: BE876707
	s_mov_b32 s58, 0x3db504f3                                  // 0000009A2FBC: BEBA00FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009A2FC4: BF87049A
	s_mul_i32 s56, s56, s7                                     // 0000009A2FC8: 96380738
	s_mul_hi_u32 s8, s7, s56                                   // 0000009A2FCC: 96883807
	s_sub_i32 s56, 0, s6                                       // 0000009A2FD0: 81B80680
	s_add_i32 s57, s7, s8                                      // 0000009A2FD4: 81390807
	s_branch 164                                               // 0000009A2FD8: BFA000A4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x46c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A2FDC: BF870091
	.long 0xd7006a02                                           // 0000009A2FE0: D7006A02
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 0000009A2FE4: 0202041A
	v_add_co_ci_u32_e64 v3, null, s27, v3, vcc_lo              // 0000009A2FE8: D5207C03 01AA061B
	v_sub_f32_e32 v4, v15, v13                                 // 0000009A2FF0: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 0000009A2FF4: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 0000009A2FFC: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 0000009A3004: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 0000009A3008: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 0000009A3010: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 0000009A3018: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A301C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 0000009A3020: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 0000009A3024: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 0000009A3028: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 0000009A302C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A3030: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A3034: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A303C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000009A3044: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000009A304C: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000009A3054: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 0000009A3058: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A305C: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000009A3064: D5010007 20060F07
	.long 0xd72c0006                                           // 0000009A306C: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 0000009A3070: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 0000009A3078: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A307C: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000009A3084: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A308C: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 0000009A3090: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A3094: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000009A309C: D5010003 20060703
	.long 0xd72c0007                                           // 0000009A30A4: D72C0007
	v_cndmask_b32_e32 v1, s55, v10, vcc_lo                     // 0000009A30A8: 02021437
	v_add_f32_e32 v2, v2, v13                                  // 0000009A30AC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A30B0: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 0000009A30B8: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 0000009A30C0: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009A30C4: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A30C8: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 0000009A30D0: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 0000009A30D8: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A30DC: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 0000009A30E4: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A30EC: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 0000009A30F4: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 0000009A30FC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A3100: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 0000009A3108: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 0000009A310C: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 0000009A3114: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A3118: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 0000009A3120: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A3128: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 0000009A3130: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A3138: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 0000009A3140: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 0000009A3148: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 0000009A314C: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 0000009A3150: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A3154: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 0000009A3158: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A315C: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 0000009A3164: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000009A316C: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A3170: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 0000009A3178: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 0000009A3180: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A3184: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 0000009A318C: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 0000009A3194: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 0000009A319C: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s28, v8                           // 0000009A31A0: 7C86101C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A31A4: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 0000009A31A8: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 0000009A31B0: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A31B8: BF870234
	v_mov_b32_e32 v13, v2                                      // 0000009A31BC: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 0000009A31C0: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 0000009A31C8: D5010004 20020904
	v_permlanex16_b32 v11, v11, s53, 0xfedcba98                // 0000009A31D0: D65C000B 03FC6B0B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 0000009A31DC: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 0000009A31E0: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000009A31E8: D5010003 20020703
	v_permlanex16_b32 v10, v10, s53, 0xfedcba98                // 0000009A31F0: D65C000A 03FC6B0A FEDCBA98
	v_permlanex16_b32 v13, v13, s53, 0xfedcba98                // 0000009A31FC: D65C000D 03FC6B0D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 0000009A3208: 060A1705
	v_permlanex16_b32 v12, v12, s53, 0xfedcba98                // 0000009A320C: D65C000C 03FC6B0C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A3218: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 0000009A321C: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 0000009A3228: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A322C: BF870214
	v_fma_mixhi_f16 v2, v5, s58, 0                             // 0000009A3230: CC220002 02007505
	v_add_f32_e32 v10, v3, v12                                 // 0000009A3238: 06141903
	s_or_b32 s34, vcc_lo, s34                                  // 0000009A323C: 8C22226A
	v_fma_mixlo_f16 v2, v4, s58, 0                             // 0000009A3240: CC210002 02007504
	v_fma_mixhi_f16 v3, v7, s58, 0                             // 0000009A3248: CC220003 02007507
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A3250: BF870003
	v_fma_mixlo_f16 v3, v10, s58, 0                            // 0000009A3254: CC210003 0200750A
	ds_store_b64 v6, v[2:3]                                    // 0000009A325C: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s34                       // 0000009A3264: 917E227E
	s_cbranch_execz 289                                        // 0000009A3268: BFA50121 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f0>
	.long 0xd72d0002                                           // 0000009A326C: D72D0002
	v_cndmask_b32_e32 v0, v8, v57, vcc_lo                      // 0000009A3270: 02007308
	s_mov_b32 s6, -1                                           // 0000009A3274: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A3278: BF870091
	.long 0xd72c0003                                           // 0000009A327C: D72C0003
	v_cndmask_b32_e32 v0, v2, v52, vcc_lo                      // 0000009A3280: 02006902
	v_sub_nc_u32_e32 v3, v8, v3                                // 0000009A3284: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009A3288: BF870121
	v_subrev_nc_u32_e32 v5, s52, v3                            // 0000009A328C: 4E0A0634
	v_cmp_le_u32_e32 vcc_lo, s52, v3                           // 0000009A3290: 7C960634
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 0000009A3294: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A329C: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 0000009A32A0: 02040902
	v_cmp_le_u32_e32 vcc_lo, s52, v3                           // 0000009A32A4: 7C960634
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A32A8: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 0000009A32AC: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 0000009A32B0: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s51                        // 0000009A32B4: 916A337E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A32B8: BF870091
	v_xor_b32_e32 v11, s54, v2                                 // 0000009A32BC: 3A160436
	v_subrev_nc_u32_e32 v10, s54, v11                          // 0000009A32C0: 4E141636
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009A32C4: BF8700A1
	v_mad_u64_u32 v[6:7], null, s56, v10, v[1:2]               // 0000009A32C8: D6FE7C06 04061438
	v_min_i32_e32 v2, s35, v10                                 // 0000009A32D0: 22041423
	v_mad_i64_i32 v[4:5], null, v2, s50, 0                     // 0000009A32D4: D6FF7C04 02006502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A32DC: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000009A32E0: 340E0C9F
	.long 0xd73c0002                                           // 0000009A32E4: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000009A32E8: 02020C81
	s_cbranch_vccnz 212                                        // 0000009A32EC: BFA400D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x840>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A32F0: BF870093
	.long 0xd7006a06                                           // 0000009A32F4: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000009A32F8: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 0000009A32FC: D5207C07 01AA0F05
	.long 0x7f383880                                           // 0000009A3304: 7F383880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A3308: BF870112
	.long 0xd73c0006                                           // 0000009A330C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000009A3310: 02020C81
	.long 0x7f3e399c                                           // 0000009A3314: 7F3E399C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A3318: BF870092
	.long 0xd7006a0c                                           // 0000009A331C: D7006A0C
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 0000009A3320: 02020C26
	v_add_co_ci_u32_e64 v13, null, s39, v7, vcc_lo             // 0000009A3324: D5207C0D 01AA0E27
	.long 0xd7006a06                                           // 0000009A332C: D7006A06
	v_cndmask_b32_e32 v1, s40, v6, vcc_lo                      // 0000009A3330: 02020C28
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A3334: BF870001
	v_add_co_ci_u32_e64 v7, null, s41, v7, vcc_lo              // 0000009A3338: D5207C07 01AA0E29
	global_load_b64 v[12:13], v[12:13], off                    // 0000009A3340: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 0000009A3348: D7006A0E
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 0000009A334C: 0202041A
	global_load_b64 v[6:7], v[6:7], off                        // 0000009A3350: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s27, v3, vcc_lo             // 0000009A3358: D5207C0F 01AA061B
	s_clause 0x1                                               // 0000009A3360: BF850001
	global_load_b32 v16, v[14:15], off                         // 0000009A3364: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 0000009A336C: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 0000009A3374: BF890FF7
	.long 0x7e1e390c                                           // 0000009A3378: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 0000009A337C: BF890BF7
	v_and_b32_e32 v38, 0xffff0000, v6                          // 0000009A3380: 364C0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000009A3388: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A338C: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 0000009A3390: 301E1E90
	v_mul_f32_e32 v19, 0xbfb8aa3b, v15                         // 0000009A3394: 10261EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000009A339C: BF870291
	v_exp_f32_e32 v19, v19                                     // 0000009A33A0: 7E264B13
	v_dual_add_f32 v19, 1.0, v19 :: v_dual_and_b32 v12, 0xffff0000, v12// 0000009A33A4: C92426F2 130C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A33B0: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 0000009A33B4: 102418FF BFB8AA3B
	v_div_scale_f32 v23, null, v19, v19, v15                   // 0000009A33BC: D6FC7C17 043E2713
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009A33C4: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 0000009A33C8: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 0000009A33CC: 30221A90
	v_div_scale_f32 v36, s7, v15, v19, v15                     // 0000009A33D0: D6FC0724 043E270F
	v_rcp_f32_e32 v27, v23                                     // 0000009A33D8: 7E365517
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A33DC: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 0000009A33E0: 062424F2
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 0000009A33E4: 102822FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A33EC: BF870195
	v_fma_f32 v35, -v23, v27, 1.0                              // 0000009A33F0: D6130023 23CA3717
	v_div_scale_f32 v22, null, v18, v18, v12                   // 0000009A33F8: D6FC7C16 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009A3400: BF8701B3
	v_exp_f32_e32 v20, v20                                     // 0000009A3404: 7E284B14
	v_and_b32_e32 v13, 0xffff0000, v13                         // 0000009A3408: 361A1AFF FFFF0000
	v_div_scale_f32 v32, vcc_lo, v12, v18, v12                 // 0000009A3410: D6FC6A20 0432250C
	v_rcp_f32_e32 v25, v22                                     // 0000009A3418: 7E325516
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 0000009A341C: BF870106
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_mul_f32 v21, 0xbfb8aa3b, v13// 0000009A3420: C90628F2 14141AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A342C: BF870115
	v_fma_f32 v33, -v22, v25, 1.0                              // 0000009A3430: D6130021 23CA3316
	v_div_scale_f32 v24, null, v20, v20, v17                   // 0000009A3438: D6FC7C18 04462914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A3440: BF8701A3
	v_exp_f32_e32 v21, v21                                     // 0000009A3444: 7E2A4B15
	v_div_scale_f32 v34, s6, v17, v20, v17                     // 0000009A3448: D6FC0622 04462911
	v_fmac_f32_e32 v25, v33, v25                               // 0000009A3450: 56323321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000009A3454: BF870313
	v_rcp_f32_e32 v29, v24                                     // 0000009A3458: 7E3A5518
	v_add_f32_e32 v21, 1.0, v21                                // 0000009A345C: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A3460: BF870115
	v_fma_f32 v37, -v24, v29, 1.0                              // 0000009A3464: D6130025 23CA3B18
	v_div_scale_f32 v26, null, v21, v21, v13                   // 0000009A346C: D6FC7C1A 04362B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A3474: BF8701A2
	v_fmac_f32_e32 v29, v37, v29                               // 0000009A3478: 563A3B25
	v_mul_f32_e32 v37, v32, v25                                // 0000009A347C: 104A3320
	v_rcp_f32_e32 v30, v26                                     // 0000009A3480: 7E3C551A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A3484: BF870091
	v_fma_f32 v40, -v22, v37, v32                              // 0000009A3488: D6130028 24824B16
	v_fmac_f32_e32 v37, v40, v25                               // 0000009A3490: 564A3328
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A3494: BF870115
	v_fma_f32 v33, -v26, v30, 1.0                              // 0000009A3498: D6130021 23CA3D1A
	v_fma_f32 v22, -v22, v37, v32                              // 0000009A34A0: D6130016 24824B16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A34A8: BF870112
	v_fmac_f32_e32 v30, v33, v30                               // 0000009A34AC: 563C3D21
	v_div_fmas_f32 v22, v22, v25, v37                          // 0000009A34B0: D6370016 04963316
	s_mov_b32 vcc_lo, s7                                       // 0000009A34B8: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009A34BC: BF8701B1
	v_div_fixup_f32 v12, v22, v18, v12                         // 0000009A34C0: D627000C 04322516
	v_fmac_f32_e32 v27, v35, v27                               // 0000009A34C8: 56363723
	v_div_scale_f32 v35, s8, v13, v21, v13                     // 0000009A34CC: D6FC0823 04362B0D
	v_mul_f32_e32 v12, v12, v38                                // 0000009A34D4: 10184D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A34D8: BF870193
	v_mul_f32_e32 v33, v36, v27                                // 0000009A34DC: 10423724
	v_mul_f32_e32 v41, v35, v30                                // 0000009A34E0: 10523D23
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A34E4: BF870193
	.long 0x7e38398c                                           // 0000009A34E8: 7E38398C
	v_fma_f32 v42, -v23, v33, v36                              // 0000009A34EC: D613002A 24924317
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A34F4: BF870113
	v_fma_f32 v40, -v26, v41, v35                              // 0000009A34F8: D6130028 248E531A
	v_fmac_f32_e32 v33, v42, v27                               // 0000009A3500: 5642372A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A3504: BF870112
	v_fmac_f32_e32 v41, v40, v30                               // 0000009A3508: 56523D28
	v_fma_f32 v23, -v23, v33, v36                              // 0000009A350C: D6130017 24924317
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A3514: BF870112
	v_fma_f32 v22, -v26, v41, v35                              // 0000009A3518: D6130016 248E531A
	v_div_fmas_f32 v23, v23, v27, v33                          // 0000009A3520: D6370017 04863717
	s_mov_b32 vcc_lo, s6                                       // 0000009A3528: BEEA0006
	s_mov_b32 s6, 0                                            // 0000009A352C: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009A3530: BF870121
	v_div_fixup_f32 v15, v23, v19, v15                         // 0000009A3534: D627000F 043E2717
	v_lshlrev_b32_e32 v19, 16, v7                              // 0000009A353C: 30260E90
	v_dual_mul_f32 v6, v15, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 0000009A3540: C8E40D0F 06060EFF FFFF0000
	v_mul_f32_e32 v39, v34, v29                                // 0000009A354C: 104E3B22
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A3550: BF870112
	.long 0x7e3e3986                                           // 0000009A3554: 7E3E3986
	v_fma_f32 v43, -v24, v39, v34                              // 0000009A3558: D613002B 248A4F18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A3560: BF870091
	v_fmac_f32_e32 v39, v43, v29                               // 0000009A3564: 564E3B2B
	v_fma_f32 v24, -v24, v39, v34                              // 0000009A3568: D6130018 248A4F18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000009A3570: BF870131
	v_div_fmas_f32 v18, v24, v29, v39                          // 0000009A3574: D6370012 049E3B18
	s_mov_b32 vcc_lo, s8                                       // 0000009A357C: BEEA0008
	v_div_fmas_f32 v15, v22, v30, v41                          // 0000009A3580: D637000F 04A63D16
	v_div_fixup_f32 v17, v18, v20, v17                         // 0000009A3588: D6270011 04462912
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A3590: BF8701A2
	v_div_fixup_f32 v13, v15, v21, v13                         // 0000009A3594: D627000D 04362B0F
	v_and_b32_e32 v15, 1, v28                                  // 0000009A359C: 361E3881
	v_mul_f32_e32 v17, v17, v19                                // 0000009A35A0: 10222711
	v_and_b32_e32 v19, 1, v31                                  // 0000009A35A4: 36263E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A35A8: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 0000009A35AC: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 0000009A35B0: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A35BC: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 0000009A35C0: D6100012 02052111
	v_add3_u32 v6, v6, v19, 0x7fff                             // 0000009A35C8: D6550006 03FE2706 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A35D4: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 0000009A35D8: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 0000009A35E0: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A35E8: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 0000009A35EC: D655000D 03FE2511 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000009A35F8: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A3600: BF870194
	v_add3_u32 v7, v7, v15, 0x7fff                             // 0000009A3604: D6550007 03FE1F07 00007FFF
	v_and_b32_e32 v17, 0xffff0000, v13                         // 0000009A3610: 36221AFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 0000009A3618: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000009A361C: CC20080D 8A021910
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 0000009A3624: CC20000F 8A020D10
	s_waitcnt vmcnt(0)                                         // 0000009A362C: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 0000009A3630: CC20000C 8A02230E
	v_and_b32_e32 v14, 0xffff0000, v7                          // 0000009A3638: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 0000009A3640: 916A067E
	s_cbranch_vccnz 65125                                      // 0000009A3644: BFA4FE65 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A3648: BF870093
	.long 0xd73c0004                                           // 0000009A364C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000009A3650: 02020881
	.long 0xd7006a04                                           // 0000009A3654: D7006A04
	v_cndmask_b32_e32 v1, s38, v4, vcc_lo                      // 0000009A3658: 02020826
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A365C: BF870111
	v_add_co_ci_u32_e64 v5, null, s39, v5, vcc_lo              // 0000009A3660: D5207C05 01AA0A27
	.long 0xd7006a04                                           // 0000009A3668: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000009A366C: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009A3670: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000009A3674: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000009A367C: D7006A06
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 0000009A3680: 0202041A
	v_add_co_ci_u32_e64 v7, null, s27, v3, vcc_lo              // 0000009A3684: D5207C07 01AA061B
	global_load_b64 v[4:5], v[4:5], off                        // 0000009A368C: DC560000 047C0004
	s_clause 0x1                                               // 0000009A3694: BF850001
	global_load_b32 v14, v[6:7], off                           // 0000009A3698: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 0000009A36A0: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 0000009A36A8: BF890BF7
	.long 0x7e0e3904                                           // 0000009A36AC: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000009A36B0: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 0000009A36B8: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A36BC: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000009A36C0: 300E0E90
	s_waitcnt vmcnt(1)                                         // 0000009A36C4: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000009A36C8: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 0000009A36D0: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 0000009A36D4: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 0000009A36DC: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 0000009A36E4: 361C0AFF FFFF0000
	s_branch 65083                                             // 0000009A36EC: BFA0FE3B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_or_b32 exec_lo, exec_lo, s33                             // 0000009A36F0: 8C7E217E
	s_bfe_i32 s28, s29, 0x1001c                                // 0000009A36F4: 939CFF1D 0001001C
	s_lshr_b32 s3, s11, 28                                     // 0000009A36FC: 85039C0B
	s_lshr_b64 s[0:1], s[28:29], 29                            // 0000009A3700: 85809D1C
	s_add_i32 s3, s50, s3                                      // 0000009A3704: 81030332
	s_add_i32 s0, s0, 7                                        // 0000009A3708: 81008700
	s_lshl_b32 s1, s29, 3                                      // 0000009A370C: 8401831D
	s_ashr_i32 s0, s0, 3                                       // 0000009A3710: 86008300
	s_lshl_b32 s4, s31, 3                                      // 0000009A3714: 8404831F
	.long 0xd72c0001                                           // 0000009A3718: D72C0001
	v_cndmask_b32_e32 v1, s0, v71, vcc_lo                      // 0000009A371C: 02028E00
	v_lshlrev_b32_e32 v11, 2, v72                              // 0000009A3720: 30169082
	s_waitcnt lgkmcnt(0)                                       // 0000009A3724: BF89FC07
	s_barrier                                                  // 0000009A3728: BFBD0000
	buffer_gl0_inv                                             // 0000009A372C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 0000009A3734: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 0000009A3738: 86008403
	s_ashr_i32 s3, s4, 31                                      // 0000009A373C: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 0000009A3740: 9705000A
	s_mul_i32 s0, s10, s0                                      // 0000009A3744: 9600000A
	v_min_i32_e32 v12, s1, v2                                  // 0000009A3748: 22180401
	s_add_u32 s0, s0, s4                                       // 0000009A374C: 80000400
	s_addc_u32 s1, s5, s3                                      // 0000009A3750: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A3754: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 0000009A3758: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v12                           // 0000009A375C: 7C821901
	s_add_u32 s1, s24, s4                                      // 0000009A3760: 80010418
	s_addc_u32 s3, s25, s5                                     // 0000009A3764: 82030519
	s_and_saveexec_b32 s4, vcc_lo                              // 0000009A3768: BE84206A
	s_cbranch_execz 93                                         // 0000009A376C: BFA5005D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xae4>
	.long 0xd7010002                                           // 0000009A3770: D7010002
	v_cndmask_b32_e32 v0, v72, v129, vcc_lo                    // 0000009A3774: 02010348
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009A3778: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 0000009A377C: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000009A3784: 3404029F
	.long 0xd44c0000                                           // 0000009A3788: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 0000009A378C: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A3790: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 0000009A3794: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 0000009A37A0: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A37A8: BF870114
	.long 0xd73c0005                                           // 0000009A37AC: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000009A37B0: 0202028A
	.long 0xd73c0002                                           // 0000009A37B4: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 0000009A37B8: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009A37BC: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 0000009A37C0: 30080E98
	v_bfe_i32 v8, v7, 7, 1                                     // 0000009A37C4: D6110008 02050F07
	.long 0xd7000009                                           // 0000009A37CC: D7000009
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 0000009A37D0: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A37D4: BF870211
	v_add_co_ci_u32_e64 v10, null, s3, v6, s0                  // 0000009A37D8: D5207C0A 00020C03
	v_ashrrev_i32_e32 v4, 22, v4                               // 0000009A37E0: 34080896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A37E4: BF870093
	.long 0xd7000005                                           // 0000009A37E8: D7000005
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 0000009A37EC: 02020509
	v_add_co_ci_u32_e64 v6, null, v10, v3, s0                  // 0000009A37F0: D5207C06 0002070A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A37F8: BF870093
	.long 0xd7000007                                           // 0000009A37FC: D7000007
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000009A3800: 02020909
	v_add_co_ci_u32_e64 v8, null, v10, v8, s0                  // 0000009A3804: D5207C08 0002110A
	.long 0xd7000009                                           // 0000009A380C: D7000009
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 0000009A3810: 02021709
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A3814: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v10, s0                  // 0000009A3818: D5207C0A 00021480
	s_clause 0x17                                              // 0000009A3820: BF850017
	global_load_b32 v4, v[5:6], off                            // 0000009A3824: DC520000 047C0005
	global_load_b32 v2, v[5:6], off offset:128                 // 0000009A382C: DC520080 027C0005
	global_load_b32 v63, v[5:6], off offset:256                // 0000009A3834: DC520100 3F7C0005
	global_load_b32 v60, v[5:6], off offset:384                // 0000009A383C: DC520180 3C7C0005
	global_load_b32 v57, v[5:6], off offset:512                // 0000009A3844: DC520200 397C0005
	global_load_b32 v54, v[5:6], off offset:640                // 0000009A384C: DC520280 367C0005
	global_load_b32 v51, v[5:6], off offset:768                // 0000009A3854: DC520300 337C0005
	global_load_b32 v33, v[5:6], off offset:896                // 0000009A385C: DC520380 217C0005
	global_load_b32 v6, v[7:8], off                            // 0000009A3864: DC520000 067C0007
	global_load_b32 v3, v[7:8], off offset:128                 // 0000009A386C: DC520080 037C0007
	global_load_b32 v64, v[7:8], off offset:256                // 0000009A3874: DC520100 407C0007
	global_load_b32 v61, v[7:8], off offset:384                // 0000009A387C: DC520180 3D7C0007
	global_load_b32 v58, v[7:8], off offset:512                // 0000009A3884: DC520200 3A7C0007
	global_load_b32 v55, v[7:8], off offset:640                // 0000009A388C: DC520280 377C0007
	global_load_b32 v53, v[7:8], off offset:768                // 0000009A3894: DC520300 357C0007
	global_load_b32 v34, v[7:8], off offset:896                // 0000009A389C: DC520380 227C0007
	global_load_b32 v5, v[9:10], off                           // 0000009A38A4: DC520000 057C0009
	global_load_b32 v65, v[9:10], off offset:128               // 0000009A38AC: DC520080 417C0009
	global_load_b32 v62, v[9:10], off offset:256               // 0000009A38B4: DC520100 3E7C0009
	global_load_b32 v59, v[9:10], off offset:384               // 0000009A38BC: DC520180 3B7C0009
	global_load_b32 v56, v[9:10], off offset:512               // 0000009A38C4: DC520200 387C0009
	global_load_b32 v52, v[9:10], off offset:640               // 0000009A38CC: DC520280 347C0009
	global_load_b32 v50, v[9:10], off offset:768               // 0000009A38D4: DC520300 327C0009
	global_load_b32 v32, v[9:10], off offset:896               // 0000009A38DC: DC520380 207C0009
	s_or_b32 exec_lo, exec_lo, s4                              // 0000009A38E4: 8C7E047E
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v16, 0             // 0000009A38E8: CA100080 0D100080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v18, 0             // 0000009A38F0: CA100080 0F120080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000009A38F8: CA100080 13140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000009A3900: CA100080 16160080
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v17, 0             // 0000009A3908: CA100080 0E100080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, 0             // 0000009A3910: CA100080 18140080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 0000009A3918: CA100080 1A1A0080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v28, 0             // 0000009A3920: CA100080 191C0080
	s_ashr_i32 s11, s10, 31                                    // 0000009A3928: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 0000009A392C: BE80206A
	s_cbranch_execz 1006                                       // 0000009A3930: BFA503EE <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1aec>
	v_dual_mov_b32 v16, 0 :: v_dual_add_nc_u32 v7, -1, v0      // 0000009A3934: CA200080 100600C1
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v30, 2, v72    // 0000009A393C: CA220080 0D1E9082
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v29, 16, v0        // 0000009A3944: CA240080 121C0090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009A394C: BF8701B3
	v_dual_mov_b32 v22, 0 :: v_dual_and_b32 v7, 31, v7         // 0000009A3950: CA240080 16060E9F
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v20, 0             // 0000009A3958: CA100080 0F140080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v14, 0             // 0000009A3960: CA100080 130E0080
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v31, 2, v7     // 0000009A3968: CA220080 181E0E82
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v26, 0             // 0000009A3970: CA100080 171A0080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v28, 0             // 0000009A3978: CA100080 111C0080
	v_mov_b32_e32 v21, 0                                       // 0000009A3980: 7E2A0280
	v_mov_b32_e32 v27, 0                                       // 0000009A3984: 7E360280
	v_mov_b32_e32 v25, 0                                       // 0000009A3988: 7E320280
	s_mov_b32 s4, 0                                            // 0000009A398C: BE840080
	s_movk_i32 s5, 0x1eee                                      // 0000009A3990: B0051EEE
	s_branch 922                                               // 0000009A3994: BFA0039A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1a00>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000009A3998: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 0000009A399C: BF893FF7
	v_alignbit_b32 v4, v4, v6, 16                              // 0000009A39A0: D6160004 02420D04
	s_waitcnt vmcnt(7)                                         // 0000009A39A8: BF891FF7
	v_bfe_u32 v66, v5, 12, 16                                  // 0000009A39AC: D6100042 02411905
	v_bfe_u32 v67, v5, 8, 16                                   // 0000009A39B4: D6100043 02411105
	v_bfe_u32 v68, v5, 4, 16                                   // 0000009A39BC: D6100044 02410905
	v_lshl_or_b32 v1, v1, 5, v29                               // 0000009A39C4: D6560001 04750B01
	v_and_b32_e32 v7, 0xffff, v4                               // 0000009A39CC: 360E08FF 0000FFFF
	v_bfe_u32 v74, v4, 4, 16                                   // 0000009A39D4: D610004A 02410904
	.long 0xd72c0042                                           // 0000009A39DC: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 0000009A39E0: 020284FF 83DCD12D
	.long 0xd72c0043                                           // 0000009A39E8: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 0000009A39EC: 020286FF 83DCD12D
	v_bfe_u32 v6, v4, 12, 16                                   // 0000009A39F4: D6100006 02411904
	.long 0xd72c004c                                           // 0000009A39FC: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 0000009A3A00: 02020EFF 83DCD12D
	.long 0xd72c004a                                           // 0000009A3A08: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 0000009A3A0C: 020294FF 83DCD12D
	v_alignbit_b32 v70, v2, v3, 16                             // 0000009A3A14: D6160046 02420702
	.long 0xd72c0044                                           // 0000009A3A1C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 0000009A3A20: 020288FF 83DCD12D
	.long 0xd72c0049                                           // 0000009A3A28: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 0000009A3A2C: 02020CFF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009A3A34: D6220042 03FD0142 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 0000009A3A40: D6220043 03FD0143 00006400
	s_waitcnt vmcnt(6)                                         // 0000009A3A4C: BF891BF7
	v_bfe_u32 v77, v65, 4, 16                                  // 0000009A3A50: D610004D 02410941
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000009A3A58: D622004C 03FD014C 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000009A3A64: D622004A 03FD014A 00006400
	v_and_b32_e32 v66, 0xffff, v66                             // 0000009A3A70: 368484FF 0000FFFF
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000009A3A78: D6220044 03FD0144 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000009A3A84: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 0000009A3A90: 30989890
	v_alignbit_b32 v63, v63, v64, 16                           // 0000009A3A94: D616003F 0242813F
	v_lshl_or_b32 v66, v67, 16, v66                            // 0000009A3A9C: D6560042 05092143
	v_alignbit_b32 v60, v60, v61, 16                           // 0000009A3AA4: D616003C 02427B3C
	v_alignbit_b32 v57, v57, v58, 16                           // 0000009A3AAC: D6160039 02427539
	v_and_or_b32 v74, 0xffff, v74, v76                         // 0000009A3AB4: D657004A 053294FF 0000FFFF
	v_bfe_u32 v76, v65, 8, 16                                  // 0000009A3AC0: D610004C 02411141
	v_pk_fma_f16 v66, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A3AC8: CC0E0042 0BFC0B42 0000C931
	v_alignbit_b32 v54, v54, v55, 16                           // 0000009A3AD4: D6160036 02426F36
	v_alignbit_b32 v51, v51, v53, 16                           // 0000009A3ADC: D6160033 02426B33
	v_pk_fma_f16 v67, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A3AE4: CC0E0043 0BFC0B4A 0000C931
	v_and_b32_e32 v69, 0xffff, v5                              // 0000009A3AF0: 368A0AFF 0000FFFF
	v_bfe_u32 v5, v4, 8, 16                                    // 0000009A3AF8: D6100005 02411104
	v_bfe_u32 v74, v70, 12, 16                                 // 0000009A3B00: D610004A 02411946
	.long 0xd72c004c                                           // 0000009A3B08: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000009A3B0C: 020298FF 83DCD12D
	v_bfe_u32 v53, v51, 12, 16                                 // 0000009A3B14: D6100035 02411933
	v_alignbit_b32 v33, v33, v34, 16                           // 0000009A3B1C: D6160021 02424521
	.long 0xd72c004b                                           // 0000009A3B24: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 0000009A3B28: 02020AFF 83DCD12D
	ds_load_b128 v[5:8], v1                                    // 0000009A3B30: DBFC0000 05000001
	ds_load_b128 v[1:4], v1 offset:5120                        // 0000009A3B38: DBFC1400 01000001
	v_and_b32_e32 v73, 0xffff, v73                             // 0000009A3B40: 369292FF 0000FFFF
	.long 0xd72c004a                                           // 0000009A3B48: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 0000009A3B4C: 020294FF 83DCD12D
	.long 0xd72c0035                                           // 0000009A3B54: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000009A3B58: 02026AFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000009A3B60: D622004C 03FD014C 00006400
	v_cmp_eq_u32_e32 vcc_lo, v9, v12                           // 0000009A3B6C: 7C941909
	v_sad_u8 v75, v75, 0, 0x6400                               // 0000009A3B70: D622004B 03FD014B 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000009A3B7C: D622004A 03FD014A 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009A3B88: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009A3B94: BF8701B3
	v_lshl_or_b32 v73, v75, 16, v73                            // 0000009A3B98: D6560049 0525214B
	v_bfe_u32 v75, v70, 8, 16                                  // 0000009A3BA0: D610004B 02411146
	s_or_b32 s4, vcc_lo, s4                                    // 0000009A3BA8: 8C04046A
	v_and_b32_e32 v53, 0xffff, v53                             // 0000009A3BAC: 366A6AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A3BB4: BF870193
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A3BB8: CC0E0049 0BFC0B49 0000C931
	.long 0xd72c004b                                           // 0000009A3BC4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 0000009A3BC8: 020296FF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 0000009A3BD0: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009A3BD4: BF870242
	v_dot2acc_f32_f16 v28, v73, v5                             // 0000009A3BD8: 04380B49
	s_waitcnt lgkmcnt(0)                                       // 0000009A3BDC: BF89FC07
	v_dot2acc_f32_f16 v25, v73, v1                             // 0000009A3BE0: 04320349
	v_bfe_u32 v73, v65, 12, 16                                 // 0000009A3BE4: D6100049 02411941
	v_sad_u8 v75, v75, 0, 0x6400                               // 0000009A3BEC: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v28, v67, v6                             // 0000009A3BF8: 04380D43
	.long 0xd72c0045                                           // 0000009A3BFC: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000009A3C00: 02028AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009A3C08: BF8701C4
	.long 0xd72c0049                                           // 0000009A3C0C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 0000009A3C10: 020292FF 83DCD12D
	v_dot2acc_f32_f16 v25, v67, v2                             // 0000009A3C18: 04320543
	v_and_b32_e32 v74, 0xffff, v74                             // 0000009A3C1C: 369494FF 0000FFFF
	v_dot2acc_f32_f16 v28, v66, v7                             // 0000009A3C24: 04380F42
	v_dot2acc_f32_f16 v25, v66, v3                             // 0000009A3C28: 04320742
	v_sad_u8 v69, v69, 0, 0x6400                               // 0000009A3C2C: D6220045 03FD0145 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000009A3C38: D6220049 03FD0149 00006400
	v_lshl_or_b32 v74, v75, 16, v74                            // 0000009A3C44: D656004A 0529214B
	.long 0xd72c004b                                           // 0000009A3C4C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000009A3C50: 02029AFF 83DCD12D
	v_bfe_u32 v66, v63, 4, 16                                  // 0000009A3C58: D6100042 0241093F
	v_lshlrev_b32_e32 v69, 16, v69                             // 0000009A3C60: 308A8A90
	v_and_b32_e32 v73, 0xffff, v73                             // 0000009A3C64: 369292FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A3C6C: BF870193
	.long 0xd72c0042                                           // 0000009A3C70: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 0000009A3C74: 020284FF 83DCD12D
	v_and_or_b32 v68, 0xffff, v68, v69                         // 0000009A3C7C: D6570044 051688FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009A3C88: BF8701B1
	v_pk_fma_f16 v68, v68, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A3C8C: CC0E0044 0BFC0B44 0000C931
	v_and_b32_e32 v69, 0xffff, v70                             // 0000009A3C98: 368A8CFF 0000FFFF
	v_bfe_u32 v70, v70, 4, 16                                  // 0000009A3CA0: D6100046 02410946
	v_dot2acc_f32_f16 v28, v68, v8                             // 0000009A3CA8: 04381144
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A3CAC: BF870193
	.long 0xd72c0045                                           // 0000009A3CB0: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000009A3CB4: 02028AFF 83DCD12D
	.long 0xd72c0046                                           // 0000009A3CBC: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 0000009A3CC0: 02028CFF 83DCD12D
	v_dot2acc_f32_f16 v25, v68, v4                             // 0000009A3CC8: 04320944
	s_waitcnt vmcnt(5)                                         // 0000009A3CCC: BF8917F7
	v_bfe_u32 v68, v62, 8, 16                                  // 0000009A3CD0: D6100044 0241113E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A3CD8: BF870214
	v_sad_u8 v69, v69, 0, 0x6400                               // 0000009A3CDC: D6220045 03FD0145 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 0000009A3CE8: D6220046 03FD0146 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A3CF4: BF870193
	.long 0xd72c0044                                           // 0000009A3CF8: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 0000009A3CFC: 020288FF 83DCD12D
	v_lshlrev_b32_e32 v69, 16, v69                             // 0000009A3D04: 308A8A90
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A3D08: BF870001
	v_and_or_b32 v67, 0xffff, v70, v69                         // 0000009A3D0C: D6570043 05168CFF 0000FFFF
	v_pk_fma_f16 v69, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A3D18: CC0E0045 0BFC0B4A 0000C931
	v_lshl_or_b32 v70, v76, 16, v73                            // 0000009A3D24: D6560046 0525214C
	v_sad_u8 v73, v75, 0, 0x6400                               // 0000009A3D2C: D6220049 03FD014B 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000009A3D38: D6220044 03FD0144 00006400
	v_pk_fma_f16 v67, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A3D44: CC0E0043 0BFC0B43 0000C931
	v_dot2acc_f32_f16 v26, v69, v1                             // 0000009A3D50: 04340345
	v_dot2acc_f32_f16 v27, v69, v5                             // 0000009A3D54: 04360B45
	v_pk_fma_f16 v69, v70, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A3D58: CC0E0045 0BFC0B46 0000C931
	s_waitcnt vmcnt(4)                                         // 0000009A3D64: BF8913F7
	v_bfe_u32 v70, v59, 4, 16                                  // 0000009A3D68: D6100046 0241093B
	v_dual_dot2acc_f32_f16 v26, v67, v2 :: v_dual_and_b32 v65, 0xffff, v65// 0000009A3D70: CB240543 1A4082FF 0000FFFF
	v_dot2acc_f32_f16 v27, v67, v6                             // 0000009A3D7C: 04360D43
	v_bfe_u32 v67, v62, 12, 16                                 // 0000009A3D80: D6100043 0241193E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A3D88: BF870213
	v_dot2acc_f32_f16 v26, v69, v3                             // 0000009A3D8C: 04340745
	.long 0xd72c0041                                           // 0000009A3D90: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000009A3D94: 020282FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009A3D9C: BF8701C4
	v_dot2acc_f32_f16 v27, v69, v7                             // 0000009A3DA0: 04360F45
	v_and_b32_e32 v69, 0xffff, v62                             // 0000009A3DA4: 368A7CFF 0000FFFF
	v_bfe_u32 v62, v62, 4, 16                                  // 0000009A3DAC: D610003E 0241093E
	.long 0xd72c0043                                           // 0000009A3DB4: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 0000009A3DB8: 020286FF 83DCD12D
	.long 0xd72c0045                                           // 0000009A3DC0: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000009A3DC4: 02028AFF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009A3DCC: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A3DD8: BF870214
	.long 0xd72c003e                                           // 0000009A3DDC: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009A3DE0: 02027CFF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 0000009A3DE8: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A3DF4: BF870113
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000009A3DF8: 30828290
	v_and_b32_e32 v67, 0xffff, v67                             // 0000009A3DFC: 368686FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A3E04: BF8701A2
	v_and_or_b32 v65, 0xffff, v73, v65                         // 0000009A3E08: D6570041 050692FF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009A3E14: D622003E 03FD013E 00006400
	v_lshl_or_b32 v61, v68, 16, v67                            // 0000009A3E20: D656003D 050D2144
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A3E28: BF870003
	v_pk_fma_f16 v64, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A3E2C: CC0E0040 0BFC0B41 0000C931
	v_bfe_u32 v65, v63, 12, 16                                 // 0000009A3E38: D6100041 0241193F
	v_bfe_u32 v67, v60, 8, 16                                  // 0000009A3E40: D6100043 0241113C
	v_bfe_u32 v68, v59, 12, 16                                 // 0000009A3E48: D6100044 0241193B
	v_pk_fma_f16 v61, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A3E50: CC0E003D 0BFC0B3D 0000C931
	v_dot2acc_f32_f16 v27, v64, v8                             // 0000009A3E5C: 04361140
	.long 0xd72c0041                                           // 0000009A3E60: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000009A3E64: 020282FF 83DCD12D
	v_dot2acc_f32_f16 v26, v64, v4                             // 0000009A3E6C: 04340940
	v_bfe_u32 v64, v63, 8, 16                                  // 0000009A3E70: D6100040 0241113F
	v_and_b32_e32 v63, 0xffff, v63                             // 0000009A3E78: 367E7EFF 0000FFFF
	.long 0xd72c0043                                           // 0000009A3E80: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 0000009A3E84: 020286FF 83DCD12D
	.long 0xd72c0044                                           // 0000009A3E8C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 0000009A3E90: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A3E98: BF870214
	.long 0xd72c0040                                           // 0000009A3E9C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000009A3EA0: 020280FF 83DCD12D
	.long 0xd72c003f                                           // 0000009A3EA8: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000009A3EAC: 02027EFF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009A3EB4: D6220041 03FD0141 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 0000009A3EC0: D6220043 03FD0143 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000009A3ECC: D6220044 03FD0144 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000009A3ED8: BF870133
	v_and_b32_e32 v65, 0xffff, v65                             // 0000009A3EDC: 368282FF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009A3EE4: D6220040 03FD0140 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 0000009A3EF0: D622003F 03FD013F 00006400
	v_lshl_or_b32 v64, v64, 16, v65                            // 0000009A3EFC: D6560040 05052140
	v_sad_u8 v65, v66, 0, 0x6400                               // 0000009A3F04: D6220041 03FD0142 00006400
	v_sad_u8 v66, v69, 0, 0x6400                               // 0000009A3F10: D6220042 03FD0145 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A3F1C: BF870004
	v_lshlrev_b32_e32 v63, 16, v63                             // 0000009A3F20: 307E7E90
	v_bfe_u32 v69, v59, 8, 16                                  // 0000009A3F24: D6100045 0241113B
	v_pk_fma_f16 v64, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A3F2C: CC0E0040 0BFC0B40 0000C931
	v_and_b32_e32 v59, 0xffff, v59                             // 0000009A3F38: 367676FF 0000FFFF
	v_lshlrev_b32_e32 v66, 16, v66                             // 0000009A3F40: 30848490
	v_and_or_b32 v63, 0xffff, v65, v63                         // 0000009A3F44: D657003F 04FE82FF 0000FFFF
	v_bfe_u32 v65, v60, 12, 16                                 // 0000009A3F50: D6100041 0241193C
	v_dot2acc_f32_f16 v21, v64, v5                             // 0000009A3F58: 042A0B40
	v_dot2acc_f32_f16 v17, v64, v1                             // 0000009A3F5C: 04220340
	v_and_or_b32 v62, 0xffff, v62, v66                         // 0000009A3F60: D657003E 050A7CFF 0000FFFF
	v_and_b32_e32 v66, 0xffff, v60                             // 0000009A3F6C: 368478FF 0000FFFF
	.long 0xd72c0041                                           // 0000009A3F74: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000009A3F78: 020282FF 83DCD12D
	v_bfe_u32 v60, v60, 4, 16                                  // 0000009A3F80: D610003C 0241093C
	.long 0xd72c0045                                           // 0000009A3F88: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000009A3F8C: 02028AFF 83DCD12D
	.long 0xd72c003b                                           // 0000009A3F94: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009A3F98: 020276FF 83DCD12D
	.long 0xd72c0042                                           // 0000009A3FA0: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 0000009A3FA4: 020284FF 83DCD12D
	v_pk_fma_f16 v63, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A3FAC: CC0E003F 0BFC0B3F 0000C931
	.long 0xd72c003c                                           // 0000009A3FB8: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000009A3FBC: 020278FF 83DCD12D
	v_pk_fma_f16 v62, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A3FC4: CC0E003E 0BFC0B3E 0000C931
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009A3FD0: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A3FDC: BF870234
	v_dot2acc_f32_f16 v17, v63, v2                             // 0000009A3FE0: 0422053F
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009A3FE4: D622003B 03FD013B 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009A3FF0: D6220042 03FD0142 00006400
	v_and_b32_e32 v65, 0xffff, v65                             // 0000009A3FFC: 368282FF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009A4004: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A4010: BF870214
	v_lshlrev_b32_e32 v59, 16, v59                             // 0000009A4014: 30767690
	v_lshlrev_b32_e32 v66, 16, v66                             // 0000009A4018: 30848490
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A401C: BF870234
	v_lshl_or_b32 v65, v67, 16, v65                            // 0000009A4020: D6560041 05052143
	v_and_b32_e32 v67, 0xffff, v68                             // 0000009A4028: 368688FF 0000FFFF
	v_sad_u8 v68, v69, 0, 0x6400                               // 0000009A4030: D6220044 03FD0145 00006400
	v_and_or_b32 v60, 0xffff, v60, v66                         // 0000009A403C: D657003C 050A78FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009A4048: BF870224
	v_pk_fma_f16 v64, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A404C: CC0E0040 0BFC0B41 0000C931
	.long 0xd72c0042                                           // 0000009A4058: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 0000009A405C: 02028CFF 83DCD12D
	v_lshl_or_b32 v65, v68, 16, v67                            // 0000009A4064: D6560041 050D2144
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A406C: BF870214
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A4070: CC0E003C 0BFC0B3C 0000C931
	v_dot2acc_f32_f16 v24, v64, v5                             // 0000009A407C: 04300B40
	v_dot2acc_f32_f16 v23, v64, v1                             // 0000009A4080: 042E0340
	s_waitcnt vmcnt(2)                                         // 0000009A4084: BF890BF7
	v_bfe_u32 v64, v52, 4, 16                                  // 0000009A4088: D6100040 02410934
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009A4090: D6220042 03FD0142 00006400
	v_dot2acc_f32_f16 v24, v60, v6                             // 0000009A409C: 04300D3C
	v_dual_dot2acc_f32_f16 v23, v60, v2 :: v_dual_and_b32 v60, 0xffff, v57// 0000009A40A0: CB24053C 173C72FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A40AC: BF870113
	v_and_or_b32 v59, 0xffff, v66, v59                         // 0000009A40B0: D657003B 04EE84FF 0000FFFF
	.long 0xd72c003c                                           // 0000009A40BC: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000009A40C0: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A40C8: BF8701A2
	v_pk_fma_f16 v58, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A40CC: CC0E003A 0BFC0B3B 0000C931
	v_bfe_u32 v59, v57, 12, 16                                 // 0000009A40D8: D610003B 02411939
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009A40E0: D622003C 03FD013C 00006400
	v_dot2acc_f32_f16 v21, v63, v6                             // 0000009A40EC: 042A0D3F
	v_pk_fma_f16 v63, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A40F0: CC0E003F 0BFC0B41 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A40FC: BF870214
	.long 0xd72c003b                                           // 0000009A4100: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009A4104: 020276FF 83DCD12D
	v_dual_mov_b32 v65, v48 :: v_dual_lshlrev_b32 v60, 16, v60 // 0000009A410C: CA220130 413C7890
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A4114: BF870214
	v_dot2acc_f32_f16 v21, v61, v7                             // 0000009A4118: 042A0F3D
	v_dot2acc_f32_f16 v24, v63, v7                             // 0000009A411C: 04300F3F
	v_dot2acc_f32_f16 v23, v63, v3                             // 0000009A4120: 042E073F
	v_bfe_u32 v63, v56, 4, 16                                  // 0000009A4124: D610003F 02410938
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009A412C: D622003B 03FD013B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A4138: BF870214
	v_dot2acc_f32_f16 v24, v58, v8                             // 0000009A413C: 0430113A
	v_dot2acc_f32_f16 v23, v58, v4                             // 0000009A4140: 042E093A
	v_bfe_u32 v58, v57, 8, 16                                  // 0000009A4144: D610003A 02411139
	v_bfe_u32 v57, v57, 4, 16                                  // 0000009A414C: D6100039 02410939
	v_and_b32_e32 v59, 0xffff, v59                             // 0000009A4154: 367676FF 0000FFFF
	.long 0xd72c003f                                           // 0000009A415C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000009A4160: 02027EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A4168: BF870214
	.long 0xd72c003a                                           // 0000009A416C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009A4170: 020274FF 83DCD12D
	.long 0xd72c0039                                           // 0000009A4178: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009A417C: 020272FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A4184: BF870193
	v_sad_u8 v63, v63, 0, 0x6400                               // 0000009A4188: D622003F 03FD013F 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009A4194: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A41A0: BF870113
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009A41A4: D6220039 03FD0139 00006400
	v_lshl_or_b32 v58, v58, 16, v59                            // 0000009A41B0: D656003A 04ED213A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A41B8: BF870232
	v_and_or_b32 v57, 0xffff, v57, v60                         // 0000009A41BC: D6570039 04F272FF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v54                             // 0000009A41C8: 36786CFF 0000FFFF
	v_bfe_u32 v59, v54, 12, 16                                 // 0000009A41D0: D610003B 02411936
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A41D8: CC0E003A 0BFC0B3A 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A41E4: BF870214
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A41E8: CC0E0039 0BFC0B39 0000C931
	.long 0xd72c003c                                           // 0000009A41F4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000009A41F8: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A4200: BF870214
	.long 0xd72c003b                                           // 0000009A4204: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009A4208: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v22, v58, v1                             // 0000009A4210: 042C033A
	v_dot2acc_f32_f16 v14, v58, v5                             // 0000009A4214: 041C0B3A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A4218: BF870194
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009A421C: D622003C 03FD013C 00006400
	v_dual_dot2acc_f32_f16 v22, v57, v2 :: v_dual_dot2acc_f32_f16 v21, v62, v8// 0000009A4228: CB180539 1614113E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009A4230: BF870223
	v_dot2acc_f32_f16 v14, v57, v6                             // 0000009A4234: 041C0D39
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009A4238: D622003B 03FD013B 00006400
	v_dual_dot2acc_f32_f16 v17, v61, v3 :: v_dual_lshlrev_b32 v60, 16, v60// 0000009A4244: CB22073D 113C7890
	v_bfe_u32 v61, v56, 12, 16                                 // 0000009A424C: D610003D 02411938
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A4254: BF870193
	v_and_b32_e32 v59, 0xffff, v59                             // 0000009A4258: 367676FF 0000FFFF
	v_dot2acc_f32_f16 v17, v62, v4                             // 0000009A4260: 0422093E
	v_bfe_u32 v62, v56, 8, 16                                  // 0000009A4264: D610003E 02411138
	v_and_b32_e32 v56, 0xffff, v56                             // 0000009A426C: 367070FF 0000FFFF
	.long 0xd72c003d                                           // 0000009A4274: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000009A4278: 02027AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A4280: BF870193
	.long 0xd72c003e                                           // 0000009A4284: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009A4288: 02027CFF 83DCD12D
	.long 0xd72c0038                                           // 0000009A4290: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009A4294: 020270FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A429C: BF870193
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009A42A0: D622003D 03FD013D 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009A42AC: D622003E 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A42B8: BF870193
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009A42BC: D6220038 03FD0138 00006400
	v_and_b32_e32 v61, 0xffff, v61                             // 0000009A42C8: 367A7AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A42D0: BF870112
	v_lshlrev_b32_e32 v56, 16, v56                             // 0000009A42D4: 30707090
	v_lshl_or_b32 v55, v62, 16, v61                            // 0000009A42D8: D6560037 04F5213E
	v_bfe_u32 v61, v54, 8, 16                                  // 0000009A42E0: D610003D 02411136
	v_bfe_u32 v54, v54, 4, 16                                  // 0000009A42E8: D6100036 02410936
	v_bfe_u32 v62, v52, 12, 16                                 // 0000009A42F0: D610003E 02411934
	v_and_or_b32 v56, 0xffff, v63, v56                         // 0000009A42F8: D6570038 04E27EFF 0000FFFF
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A4304: CC0E0037 0BFC0B37 0000C931
	.long 0xd72c003d                                           // 0000009A4310: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000009A4314: 02027AFF 83DCD12D
	.long 0xd72c0036                                           // 0000009A431C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009A4320: 02026CFF 83DCD12D
	v_bfe_u32 v63, v52, 8, 16                                  // 0000009A4328: D610003F 02411134
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A4330: CC0E0038 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v14, v55, v7                             // 0000009A433C: 041C0F37
	v_dot2acc_f32_f16 v22, v55, v3                             // 0000009A4340: 042C0737
	.long 0xd72c003e                                           // 0000009A4344: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009A4348: 02027CFF 83DCD12D
	.long 0xd72c003f                                           // 0000009A4350: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000009A4354: 02027EFF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009A435C: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v14, v56, v8                             // 0000009A4368: 041C1138
	v_dot2acc_f32_f16 v22, v56, v4                             // 0000009A436C: 042C0938
	s_waitcnt vmcnt(1)                                         // 0000009A4370: BF8907F7
	v_bfe_u32 v56, v50, 12, 16                                 // 0000009A4374: D6100038 02411932
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009A437C: D6220036 03FD0136 00006400
	v_lshl_or_b32 v59, v61, 16, v59                            // 0000009A4388: D656003B 04ED213D
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009A4390: D622003E 03FD013E 00006400
	v_and_b32_e32 v52, 0xffff, v52                             // 0000009A439C: 366868FF 0000FFFF
	.long 0xd72c0038                                           // 0000009A43A4: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009A43A8: 020270FF 83DCD12D
	v_and_or_b32 v54, 0xffff, v54, v60                         // 0000009A43B0: D6570036 04F26CFF 0000FFFF
	v_pk_fma_f16 v58, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A43BC: CC0E003A 0BFC0B3B 0000C931
	.long 0xd72c003c                                           // 0000009A43C8: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000009A43CC: 020280FF 83DCD12D
	.long 0xd72c0034                                           // 0000009A43D4: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009A43D8: 020268FF 83DCD12D
	v_mov_b32_e32 v64, v47                                     // 0000009A43E0: 7E80032F
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A43E4: CC0E0036 0BFC0B36 0000C931
	v_dot2acc_f32_f16 v20, v58, v5                             // 0000009A43F0: 04280B3A
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009A43F4: D6220038 03FD0138 00006400
	v_dot2acc_f32_f16 v19, v58, v1                             // 0000009A4400: 0426033A
	v_bfe_u32 v58, v50, 4, 16                                  // 0000009A4404: D610003A 02410932
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009A440C: D622003C 03FD013C 00006400
	v_dot2acc_f32_f16 v20, v54, v6                             // 0000009A4418: 04280D36
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009A441C: BF8701C4
	v_dual_dot2acc_f32_f16 v19, v54, v2 :: v_dual_and_b32 v56, 0xffff, v56// 0000009A4420: CB240536 133870FF 0000FFFF
	v_bfe_u32 v54, v51, 8, 16                                  // 0000009A442C: D6100036 02411133
	.long 0xd72c003a                                           // 0000009A4434: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009A4438: 020274FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009A4440: D6220034 03FD0134 00006400
	.long 0xd72c0036                                           // 0000009A444C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009A4450: 02026CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A4458: BF870212
	v_lshlrev_b32_e32 v52, 16, v52                             // 0000009A445C: 30686890
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009A4460: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A446C: BF870212
	v_and_or_b32 v52, 0xffff, v60, v52                         // 0000009A4470: D6570034 04D278FF 0000FFFF
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009A447C: D6220036 03FD0136 00006400
	v_mov_b32_e32 v60, v38                                     // 0000009A4488: 7E780326
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A448C: BF870193
	v_pk_fma_f16 v52, v52, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A4490: CC0E0034 0BFC0B34 0000C931
	v_lshl_or_b32 v53, v54, 16, v53                            // 0000009A449C: D6560035 04D52136
	v_bfe_u32 v54, v33, 12, 16                                 // 0000009A44A4: D6100036 02411921
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A44AC: BF870232
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A44B0: CC0E0035 0BFC0B35 0000C931
	v_and_b32_e32 v61, 0xffff, v62                             // 0000009A44BC: 367A7CFF 0000FFFF
	v_sad_u8 v62, v63, 0, 0x6400                               // 0000009A44C4: D622003E 03FD013F 00006400
	.long 0xd72c0036                                           // 0000009A44D0: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009A44D4: 02026CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009A44DC: BF870224
	v_dual_mov_b32 v63, v39 :: v_dual_dot2acc_f32_f16 v16, v53, v1// 0000009A44E0: CA180127 3F100335
	v_and_b32_e32 v55, 0xffff, v51                             // 0000009A44E8: 366E66FF 0000FFFF
	v_lshl_or_b32 v59, v62, 16, v61                            // 0000009A44F0: D656003B 04F5213E
	v_bfe_u32 v51, v51, 4, 16                                  // 0000009A44F8: D6100033 02410933
	v_dual_dot2acc_f32_f16 v18, v53, v5 :: v_dual_mov_b32 v61, v46// 0000009A4500: CB100B35 123C012E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A4508: BF870214
	.long 0xd72c0037                                           // 0000009A450C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000009A4510: 02026EFF 83DCD12D
	v_pk_fma_f16 v57, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A4518: CC0E0039 0BFC0B3B 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A4524: BF870004
	.long 0xd72c0033                                           // 0000009A4528: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000009A452C: 020266FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009A4534: D6220036 03FD0136 00006400
	s_waitcnt vmcnt(0)                                         // 0000009A4540: BF8903F7
	v_bfe_u32 v59, v32, 4, 16                                  // 0000009A4544: D610003B 02410920
	v_mov_b32_e32 v62, v47                                     // 0000009A454C: 7E7C032F
	v_dot2acc_f32_f16 v20, v57, v7                             // 0000009A4550: 04280F39
	v_dot2acc_f32_f16 v19, v57, v3                             // 0000009A4554: 04260739
	v_bfe_u32 v57, v50, 8, 16                                  // 0000009A4558: D6100039 02411132
	v_and_b32_e32 v50, 0xffff, v50                             // 0000009A4560: 366464FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009A4568: D6220037 03FD0137 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009A4574: D6220033 03FD0133 00006400
	v_and_b32_e32 v54, 0xffff, v54                             // 0000009A4580: 366C6CFF 0000FFFF
	.long 0xd72c0039                                           // 0000009A4588: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009A458C: 020272FF 83DCD12D
	.long 0xd72c0032                                           // 0000009A4594: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000009A4598: 020264FF 83DCD12D
	v_dot2acc_f32_f16 v20, v52, v8                             // 0000009A45A0: 04281134
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A45A4: BF870193
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009A45A8: D6220039 03FD0139 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009A45B4: D6220032 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A45C0: BF870112
	v_lshl_or_b32 v34, v57, 16, v56                            // 0000009A45C4: D6560022 04E12139
	v_lshlrev_b32_e32 v50, 16, v50                             // 0000009A45CC: 30646490
	v_bfe_u32 v56, v33, 8, 16                                  // 0000009A45D0: D6100038 02411121
	v_bfe_u32 v57, v32, 12, 16                                 // 0000009A45D8: D6100039 02411920
	v_dot2acc_f32_f16 v19, v52, v4                             // 0000009A45E0: 04260934
	v_pk_fma_f16 v34, v34, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A45E4: CC0E0022 0BFC0B22 0000C931
	v_and_or_b32 v50, 0xffff, v58, v50                         // 0000009A45F0: D6570032 04CA74FF 0000FFFF
	.long 0xd72c0038                                           // 0000009A45FC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009A4600: 020270FF 83DCD12D
	v_bfe_u32 v58, v32, 8, 16                                  // 0000009A4608: D610003A 02411120
	.long 0xd72c0039                                           // 0000009A4610: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009A4614: 020272FF 83DCD12D
	v_and_b32_e32 v32, 0xffff, v32                             // 0000009A461C: 364040FF 0000FFFF
	v_pk_fma_f16 v50, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A4624: CC0E0032 0BFC0B32 0000C931
	v_lshlrev_b32_e32 v55, 16, v55                             // 0000009A4630: 306E6E90
	.long 0xd72c003a                                           // 0000009A4634: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009A4638: 020274FF 83DCD12D
	v_mov_b32_e32 v52, v44                                     // 0000009A4640: 7E68032C
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009A4644: D6220038 03FD0138 00006400
	.long 0xd72c0020                                           // 0000009A4650: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 0000009A4654: 020240FF 83DCD12D
	v_and_or_b32 v51, 0xffff, v51, v55                         // 0000009A465C: D6570033 04DE66FF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009A4668: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A4674: BF870194
	v_lshl_or_b32 v54, v56, 16, v54                            // 0000009A4678: D6560036 04D92138
	v_pk_fma_f16 v51, v51, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A4680: CC0E0033 0BFC0B33 0000C931
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000009A468C: D6220020 03FD0120 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A4698: BF870193
	v_pk_fma_f16 v53, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A469C: CC0E0035 0BFC0B36 0000C931
	v_dual_dot2acc_f32_f16 v16, v51, v2 :: v_dual_and_b32 v55, 0xffff, v33// 0000009A46A8: CB240533 103642FF 0000FFFF
	v_bfe_u32 v33, v33, 4, 16                                  // 0000009A46B4: D6100021 02410921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A46BC: BF870193
	v_dual_dot2acc_f32_f16 v15, v53, v5 :: v_dual_lshlrev_b32 v32, 16, v32// 0000009A46C0: CB220B35 0F204090
	v_dual_dot2acc_f32_f16 v13, v53, v1 :: v_dual_dot2acc_f32_f16 v16, v34, v3// 0000009A46C8: CB180335 0D100722
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A46D0: BF870214
	.long 0xd72c0037                                           // 0000009A46D4: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000009A46D8: 02026EFF 83DCD12D
	.long 0xd72c0021                                           // 0000009A46E0: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000009A46E4: 020242FF 83DCD12D
	v_dot2acc_f32_f16 v18, v51, v6                             // 0000009A46EC: 04240D33
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A46F0: BF870114
	v_dual_mov_b32 v51, v35 :: v_dual_dot2acc_f32_f16 v16, v50, v4// 0000009A46F4: CA180123 33100932
	v_dual_mov_b32 v53, v43 :: v_dual_dot2acc_f32_f16 v18, v34, v7// 0000009A46FC: CA18012B 35120F22
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009A4704: D6220037 03FD0137 00006400
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000009A4710: D6220021 03FD0121 00006400
	v_mov_b32_e32 v34, v41                                     // 0000009A471C: 7E440329
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009A4720: BF870123
	v_dual_dot2acc_f32_f16 v18, v50, v8 :: v_dual_lshlrev_b32 v55, 16, v55// 0000009A4724: CB221132 12366E90
	v_mov_b32_e32 v50, v43                                     // 0000009A472C: 7E64032B
	v_and_or_b32 v33, 0xffff, v33, v55                         // 0000009A4730: D6570021 04DE42FF 0000FFFF
	.long 0xd72c0037                                           // 0000009A473C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009A4740: 020276FF 83DCD12D
	v_mov_b32_e32 v59, v46                                     // 0000009A4748: 7E76032E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A474C: BF870003
	v_pk_fma_f16 v33, v33, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009A4750: CC0E0021 0BFC0B21 0000C931
	v_and_b32_e32 v56, 0xffff, v57                             // 0000009A475C: 367072FF 0000FFFF
	v_sad_u8 v57, v58, 0, 0x6400                               // 0000009A4764: D6220039 03FD013A 00006400
	v_mov_b32_e32 v58, v45                                     // 0000009A4770: 7E74032D
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009A4774: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v15, v33, v6                             // 0000009A4780: 041E0D21
	v_dot2acc_f32_f16 v13, v33, v2                             // 0000009A4784: 041A0521
	v_lshl_or_b32 v54, v57, 16, v56                            // 0000009A4788: D6560036 04E12139
	v_mov_b32_e32 v56, v45                                     // 0000009A4790: 7E70032D
	v_and_or_b32 v5, 0xffff, v55, v32                          // 0000009A4794: D6570005 04826EFF 0000FFFF
	v_mov_b32_e32 v55, v44                                     // 0000009A47A0: 7E6E032C
	v_mov_b32_e32 v57, v37                                     // 0000009A47A4: 7E720325
	v_pk_fma_f16 v1, v54, s5, 0xc931 op_sel_hi:[1,0,0]         // 0000009A47A8: CC0E0001 0BFC0B36 0000C931
	v_mov_b32_e32 v54, v36                                     // 0000009A47B4: 7E6C0324
	v_pk_fma_f16 v2, v5, s5, 0xc931 op_sel_hi:[1,0,0]          // 0000009A47B8: CC0E0002 0BFC0B05 0000C931
	v_mov_b32_e32 v5, v49                                      // 0000009A47C4: 7E0A0331
	v_mov_b32_e32 v6, v49                                      // 0000009A47C8: 7E0C0331
	v_dot2acc_f32_f16 v15, v1, v7                              // 0000009A47CC: 041E0F01
	v_dot2acc_f32_f16 v13, v1, v3                              // 0000009A47D0: 041A0701
	v_dual_mov_b32 v3, v48 :: v_dual_mov_b32 v32, v41          // 0000009A47D4: CA100130 03200129
	v_mov_b32_e32 v33, v10                                     // 0000009A47DC: 7E42030A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A47E0: BF870214
	v_dot2acc_f32_f16 v15, v2, v8                              // 0000009A47E4: 041E1102
	v_dot2acc_f32_f16 v13, v2, v4                              // 0000009A47E8: 041A0902
	v_mov_b32_e32 v2, v42                                      // 0000009A47EC: 7E04032A
	v_dual_mov_b32 v4, v40 :: v_dual_mov_b32 v1, v9            // 0000009A47F0: CA100128 04000109
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000009A47F8: 917E047E
	s_cbranch_execz 58                                         // 0000009A47FC: BFA5003A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1ae8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009A4800: BF8700A1
	v_add_nc_u32_e32 v9, 1, v1                                 // 0000009A4804: 4A120281
	s_mov_b32 s6, exec_lo                                      // 0000009A4808: BE86007E
	.long 0xd4c1007e                                           // 0000009A480C: D4C1007E
	v_cndmask_b32_e32 v1, v9, v12, vcc_lo                      // 0000009A4810: 02021909
	s_cbranch_execz 64608                                      // 0000009A4814: BFA5FC60 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xb98>
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000009A4818: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A481C: BF870091
	.long 0xd73c0007                                           // 0000009A4820: D73C0007
	v_cndmask_b32_e32 v1, 10, v9, vcc_lo                       // 0000009A4824: 0202128A
	.long 0xd7006a0a                                           // 0000009A4828: D7006A0A
	v_cndmask_b32_e32 v1, s1, v7, vcc_lo                       // 0000009A482C: 02020E01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A4830: BF870111
	v_add_co_ci_u32_e64 v35, null, s3, v8, vcc_lo              // 0000009A4834: D5207C23 01AA1003
	.long 0xd7006a07                                           // 0000009A483C: D7006A07
	v_cndmask_b32_e32 v1, v10, v31, vcc_lo                     // 0000009A4840: 02023F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009A4844: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v35, vcc_lo               // 0000009A4848: D5207C08 01AA4680
	.long 0xd7006a42                                           // 0000009A4850: D7006A42
	v_cndmask_b32_e32 v1, v10, v30, vcc_lo                     // 0000009A4854: 02023D0A
	v_add_co_ci_u32_e64 v67, null, 0, v35, vcc_lo              // 0000009A4858: D5207C43 01AA4680
	s_clause 0xf                                               // 0000009A4860: BF85000F
	global_load_b32 v40, v[7:8], off                           // 0000009A4864: DC520000 287C0007
	global_load_b32 v42, v[7:8], off offset:128                // 0000009A486C: DC520080 2A7C0007
	global_load_b32 v39, v[7:8], off offset:256                // 0000009A4874: DC520100 277C0007
	global_load_b32 v38, v[7:8], off offset:384                // 0000009A487C: DC520180 267C0007
	global_load_b32 v37, v[7:8], off offset:512                // 0000009A4884: DC520200 257C0007
	global_load_b32 v36, v[7:8], off offset:640                // 0000009A488C: DC520280 247C0007
	global_load_b32 v35, v[7:8], off offset:768                // 0000009A4894: DC520300 237C0007
	global_load_b32 v10, v[7:8], off offset:896                // 0000009A489C: DC520380 0A7C0007
	global_load_b32 v49, v[66:67], off                         // 0000009A48A4: DC520000 317C0042
	global_load_b32 v48, v[66:67], off offset:128              // 0000009A48AC: DC520080 307C0042
	global_load_b32 v47, v[66:67], off offset:256              // 0000009A48B4: DC520100 2F7C0042
	global_load_b32 v46, v[66:67], off offset:384              // 0000009A48BC: DC520180 2E7C0042
	global_load_b32 v45, v[66:67], off offset:512              // 0000009A48C4: DC520200 2D7C0042
	global_load_b32 v44, v[66:67], off offset:640              // 0000009A48CC: DC520280 2C7C0042
	global_load_b32 v43, v[66:67], off offset:768              // 0000009A48D4: DC520300 2B7C0042
	global_load_b32 v41, v[66:67], off offset:896              // 0000009A48DC: DC520380 297C0042
	s_branch 64556                                             // 0000009A48E4: BFA0FC2C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xb98>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000009A48E8: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009A48EC: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009A48F0: 8C7E007E
	s_waitcnt vmcnt(22)                                        // 0000009A48F4: BF895BF7
	v_dual_mov_b32 v1, v28 :: v_dual_mov_b32 v2, v25           // 0000009A48F8: CA10011C 01020119
	s_waitcnt vmcnt(14)                                        // 0000009A4900: BF893BF7
	v_dual_mov_b32 v3, v27 :: v_dual_mov_b32 v6, v26           // 0000009A4904: CA10011B 0306011A
	v_dual_mov_b32 v4, v21 :: v_dual_mov_b32 v9, v23           // 0000009A490C: CA100115 04080117
	s_waitcnt vmcnt(7)                                         // 0000009A4914: BF891FF7
	v_dual_mov_b32 v5, v17 :: v_dual_mov_b32 v8, v24           // 0000009A4918: CA100111 05080118
	v_dual_mov_b32 v7, v14 :: v_dual_mov_b32 v12, v20          // 0000009A4920: CA10010E 070C0114
	v_dual_mov_b32 v10, v22 :: v_dual_mov_b32 v29, v19         // 0000009A4928: CA100116 0A1C0113
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v31, v16         // 0000009A4930: CA100112 1E1E0110
	s_waitcnt vmcnt(0)                                         // 0000009A4938: BF8903F7
	v_dual_mov_b32 v32, v15 :: v_dual_mov_b32 v33, v13         // 0000009A493C: CA10010F 2020010D
	s_mov_b32 s0, 0x76543210                                   // 0000009A4944: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009A494C: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 0000009A4950: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 0000009A495C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 0000009A4968: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000009A4974: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 0000009A4980: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 0000009A498C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 0000009A4998: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 0000009A49A4: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 0000009A49B0: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 0000009A49BC: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 0000009A49C8: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v29, v29, s0, 0xfedcba98                 // 0000009A49D4: D65C001D 03FC011D FEDCBA98
	v_permlanex16_b32 v30, v30, s0, 0xfedcba98                 // 0000009A49E0: D65C001E 03FC011E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 0000009A49EC: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 0000009A49F8: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 0000009A4A04: D65C0021 03FC0121 FEDCBA98
	.long 0xd44c0000                                           // 0000009A4A10: D44C0000
	v_cndmask_b32_e32 v1, 16, v72, vcc_lo                      // 0000009A4A14: 02029090
	s_barrier                                                  // 0000009A4A18: BFBD0000
	buffer_gl0_inv                                             // 0000009A4A1C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000009A4A24: BE812000
	s_cbranch_execz 34                                         // 0000009A4A28: BFA50022 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1cb4>
	v_dual_add_f32 v8, v24, v8 :: v_dual_add_f32 v3, v27, v3   // 0000009A4A2C: C9081118 0802071B
	v_dual_add_f32 v6, v26, v6 :: v_dual_add_f32 v1, v28, v1   // 0000009A4A34: C9080D1A 0600031C
	v_lshl_or_b32 v11, v71, 10, v11                            // 0000009A4A3C: D656000B 042D1547
	v_dual_add_f32 v2, v25, v2 :: v_dual_add_f32 v7, v14, v7   // 0000009A4A44: C9080519 02060F0E
	v_add_f32_e32 v4, v21, v4                                  // 0000009A4A4C: 06080915
	v_dual_add_f32 v10, v22, v10 :: v_dual_add_f32 v9, v23, v9 // 0000009A4A50: C9081516 0A081317
	v_add_f32_e32 v5, v17, v5                                  // 0000009A4A58: 060A0B11
	v_dual_add_f32 v19, v19, v29 :: v_dual_add_f32 v12, v20, v12// 0000009A4A5C: C9083B13 130C1914
	v_dual_add_f32 v13, v13, v33 :: v_dual_add_f32 v16, v16, v31// 0000009A4A64: C908430D 0D103F10
	v_dual_add_f32 v15, v15, v32 :: v_dual_add_f32 v18, v18, v30// 0000009A4A6C: C908410F 0F123D12
	ds_store_2addr_b32 v11, v1, v3 offset1:16                  // 0000009A4A74: D8381000 0003010B
	ds_store_2addr_b32 v11, v2, v6 offset0:128 offset1:144     // 0000009A4A7C: D8389080 0006020B
	ds_store_2addr_b32 v11, v4, v8 offset0:32 offset1:48       // 0000009A4A84: D8383020 0008040B
	ds_store_2addr_b32 v11, v5, v9 offset0:160 offset1:176     // 0000009A4A8C: D838B0A0 0009050B
	ds_store_2addr_b32 v11, v7, v12 offset0:64 offset1:80      // 0000009A4A94: D8385040 000C070B
	ds_store_2addr_b32 v11, v10, v19 offset0:192 offset1:208   // 0000009A4A9C: D838D0C0 00130A0B
	ds_store_2addr_b32 v11, v18, v15 offset0:96 offset1:112    // 0000009A4AA4: D8387060 000F120B
	ds_store_2addr_b32 v11, v16, v13 offset0:224 offset1:240   // 0000009A4AAC: D838F0E0 000D100B
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009A4AB4: 8C7E017E
	.long 0xd44c0001                                           // 0000009A4AB8: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 0000009A4ABC: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000009A4AC4: BF89FC07
	s_barrier                                                  // 0000009A4AC8: BFBD0000
	buffer_gl0_inv                                             // 0000009A4ACC: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 0000009A4AD4: BE832001
	s_cbranch_execnz 7                                         // 0000009A4AD8: BFA60007 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1cf8>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009A4ADC: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 0000009A4AE0: BF048209
	s_mov_b32 s3, -1                                           // 0000009A4AE4: BE8300C1
	s_cbranch_scc0 33                                          // 0000009A4AE8: BFA10021 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d70>
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000009A4AEC: 8B6A037E
	s_cbranch_vccnz 200                                        // 0000009A4AF0: BFA400C8 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2014>
	s_branch 580                                               // 0000009A4AF4: BFA00244 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2608>
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000009A4AF8: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 0000009A4AFC: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 0000009A4B04: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 0000009A4B0C: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 0000009A4B14: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 0000009A4B18: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009A4B1C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 0000009A4B20: 06020501
	s_waitcnt lgkmcnt(1)                                       // 0000009A4B24: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 0000009A4B28: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 0000009A4B2C: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 0000009A4B34: 06060903
	s_waitcnt lgkmcnt(1)                                       // 0000009A4B38: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A4B3C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000009A4B40: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000009A4B44: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000009A4B48: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A4B4C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000009A4B50: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000009A4B54: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 0000009A4B58: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009A4B60: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 0000009A4B64: BF048209
	s_mov_b32 s3, -1                                           // 0000009A4B68: BE8300C1
	s_cbranch_scc1 65503                                       // 0000009A4B6C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1cec>
	s_waitcnt lgkmcnt(0)                                       // 0000009A4B70: BF89FC07
	s_barrier                                                  // 0000009A4B74: BFBD0000
	buffer_gl0_inv                                             // 0000009A4B78: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 0000009A4B80: BE832001
	s_cbranch_execz 41                                         // 0000009A4B84: BFA50029 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1e2c>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000009A4B88: 32020087
	s_ashr_i32 s4, s49, 31                                     // 0000009A4B8C: 86049F31
	v_lshlrev_b32_e32 v4, 2, v0                                // 0000009A4B90: 30080082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000009A4B94: BF8704D2
	v_lshl_or_b32 v1, s30, 1, v1                               // 0000009A4B98: D6560001 0405021E
	ds_load_b32 v4, v4 offset:8192                             // 0000009A4BA0: D8D82000 04000004
	.long 0xd72c0003                                           // 0000009A4BA8: D72C0003
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000009A4BAC: 02000901
	v_mad_u64_u32 v[1:2], null, v1, s49, 0                     // 0000009A4BB0: D6FE7C01 02006301
	s_ashr_i32 s4, s30, 31                                     // 0000009A4BB8: 86049F1E
	s_mul_i32 s4, s4, s49                                      // 0000009A4BBC: 96043104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000009A4BC0: BF870149
	v_add3_u32 v2, v2, v3, s4                                  // 0000009A4BC4: D6550002 00120702
	s_lshl_b32 s4, s10, 7                                      // 0000009A4BCC: 8404870A
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000009A4BD0: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 0000009A4BD8: 86059F04
	.long 0xd73c0001                                           // 0000009A4BDC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000009A4BE0: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 0000009A4BE4: 84848204
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000009A4BE8: BF870132
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000009A4BEC: 30060682
	s_add_u32 s4, s44, s4                                      // 0000009A4BF0: 8004042C
	s_addc_u32 s5, s45, s5                                     // 0000009A4BF4: 8205052D
	.long 0xd7006a01                                           // 0000009A4BF8: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000009A4BFC: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A4C00: BF870111
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000009A4C04: D5207C02 01AA0405
	.long 0xd7006a01                                           // 0000009A4C0C: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000009A4C10: 02020701
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A4C14: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000009A4C18: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 0000009A4C20: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 0000009A4C24: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009A4C2C: 8C7E037E
	.long 0xd44a0003                                           // 0000009A4C30: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000009A4C34: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 0000009A4C38: BC7C0000
	buffer_gl1_inv                                             // 0000009A4C3C: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009A4C44: E0AC0000 00000000
	s_barrier                                                  // 0000009A4C4C: BFBD0000
	buffer_gl0_inv                                             // 0000009A4C50: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000009A4C58: BE842003
	s_cbranch_execz 29                                         // 0000009A4C5C: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1ed4>
	s_mov_b32 s6, exec_lo                                      // 0000009A4C60: BE86007E
	s_mov_b32 s5, exec_lo                                      // 0000009A4C64: BE85007E
	.long 0xd71f0001                                           // 0000009A4C68: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 0000009A4C6C: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A4C70: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000009A4C74: 7D940280
	s_cbranch_execz 9                                          // 0000009A4C78: BFA50009 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1ea0>
	s_lshl_b64 s[24:25], s[10:11], 2                           // 0000009A4C7C: 8498820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000009A4C80: BF8704B9
	s_add_u32 s24, s46, s24                                    // 0000009A4C84: 8018182E
	s_addc_u32 s25, s47, s25                                   // 0000009A4C88: 8219192F
	s_bcnt1_i32_b32 s6, s6                                     // 0000009A4C8C: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 0000009A4C90: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[24:25] glc             // 0000009A4C98: DCD64000 02180302
	s_or_b32 exec_lo, exec_lo, s5                              // 0000009A4CA0: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 0000009A4CA4: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 0000009A4CA8: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A4CAC: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 0000009A4CB0: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 0000009A4CB8: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000009A4CBC: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 0000009A4CC0: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000009A4CC4: D5010001 01A90280
	ds_store_b32 v2, v1 offset:18432                           // 0000009A4CCC: D8344800 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 0000009A4CD4: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 0000009A4CD8: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000009A4CDC: BF89FC07
	s_barrier                                                  // 0000009A4CE0: BFBD0000
	buffer_gl0_inv                                             // 0000009A4CE4: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:18432                            // 0000009A4CEC: D8D84800 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000009A4CF4: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000009A4CF8: 7C940280
	s_cbranch_vccnz 68                                         // 0000009A4CFC: BFA40044 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2010>
	buffer_gl1_inv                                             // 0000009A4D00: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009A4D08: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 0000009A4D10: BE842001
	s_cbranch_execz 50                                         // 0000009A4D14: BFA50032 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1fe0>
	v_and_b32_e32 v2, 0x7f, v0                                 // 0000009A4D18: 360400FF 0000007F
	s_lshl_b32 s6, s10, 7                                      // 0000009A4D20: 8406870A
	s_ashr_i32 s1, s49, 31                                     // 0000009A4D24: 86019F31
	s_ashr_i32 s7, s6, 31                                      // 0000009A4D28: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000009A4D2C: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 0000009A4D30: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 0000009A4D38: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009A4D3C: BF8700A9
	s_add_u32 s5, s44, s6                                      // 0000009A4D40: 8005062C
	s_addc_u32 s6, s45, s7                                     // 0000009A4D44: 8206072D
	.long 0xd7000503                                           // 0000009A4D48: D7000503
	v_cndmask_b32_e32 v1, s5, v3, vcc_lo                       // 0000009A4D4C: 02020605
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A4D50: BF870001
	v_add_co_ci_u32_e64 v4, null, s6, 0, s5                    // 0000009A4D54: D5207C04 00150006
	s_mov_b32 s5, s49                                          // 0000009A4D5C: BE850031
	s_nop 0                                                    // 0000009A4D60: BF800000
	s_nop 0                                                    // 0000009A4D64: BF800000
	s_nop 0                                                    // 0000009A4D68: BF800000
	s_nop 0                                                    // 0000009A4D6C: BF800000
	s_nop 0                                                    // 0000009A4D70: BF800000
	s_nop 0                                                    // 0000009A4D74: BF800000
	s_nop 0                                                    // 0000009A4D78: BF800000
	s_nop 0                                                    // 0000009A4D7C: BF800000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000009A4D80: BF8704A9
	v_mad_u64_u32 v[5:6], null, v1, s5, 0                      // 0000009A4D84: D6FE7C05 02000B01
	s_add_i32 s9, s9, -1                                       // 0000009A4D8C: 8109C109
	s_cmp_eq_u32 s9, 0                                         // 0000009A4D90: BF068009
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 0000009A4D94: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 0000009A4D9C: 4A020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A4DA0: BF870092
	.long 0xd73c0005                                           // 0000009A4DA4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000009A4DA8: 02020A82
	.long 0xd7006a05                                           // 0000009A4DAC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000009A4DB0: 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A4DB4: BF870001
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 0000009A4DB8: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 0000009A4DC0: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000009A4DC8: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 0000009A4DCC: 06040B02
	s_cbranch_scc0 65515                                       // 0000009A4DD0: BFA1FFEB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1f80>
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000009A4DD4: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 0000009A4DD8: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s4                              // 0000009A4DE0: 8C7E047E
	s_and_saveexec_b32 s1, s3                                  // 0000009A4DE4: BE812003
	s_cbranch_execz 6                                          // 0000009A4DE8: BFA50006 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2004>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000009A4DEC: 8484820A
	v_mov_b32_e32 v1, 0                                        // 0000009A4DF0: 7E020280
	s_add_u32 s4, s46, s4                                      // 0000009A4DF4: 8004042E
	s_addc_u32 s5, s47, s5                                     // 0000009A4DF8: 8205052F
	global_store_b32 v1, v1, s[4:5]                            // 0000009A4DFC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009A4E04: 8C7E017E
	s_cbranch_execnz 2                                         // 0000009A4E08: BFA60002 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2014>
	s_branch 382                                               // 0000009A4E0C: BFA0017E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2608>
	s_branch 381                                               // 0000009A4E10: BFA0017D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2608>
	v_cmp_gt_i32_e32 vcc_lo, s48, v71                          // 0000009A4E14: 7C888E30
	.long 0xd44c0001                                           // 0000009A4E18: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 0000009A4E1C: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 0000009A4E20: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000009A4E24: BC7C0000
	s_barrier                                                  // 0000009A4E28: BFBD0000
	buffer_gl0_inv                                             // 0000009A4E2C: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 0000009A4E34: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009A4E38: BF870009
	s_and_saveexec_b32 s3, s1                                  // 0000009A4E3C: BE832001
	s_cbranch_execz 368                                        // 0000009A4E40: BFA50170 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2604>
	v_and_b32_e32 v1, 15, v0                                   // 0000009A4E44: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A4E48: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000009A4E4C: 30040282
	v_lshl_or_b32 v2, v71, 9, v2                               // 0000009A4E50: D6560002 04091347
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A4E58: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 0000009A4E5C: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000009A4E64: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000009A4E6C: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000009A4E74: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000009A4E7C: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000009A4E84: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000009A4E88: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000009A4E8C: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000009A4E90: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 0000009A4E98: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000009A4E9C: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000009A4EA4: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000009A4EA8: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000009A4EB0: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000009A4EB4: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 0000009A4EBC: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 0000009A4EC4: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009A4EC8: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 0000009A4ECC: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 0000009A4ED4: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000009A4EDC: 7C941480
	.long 0xd44a0001                                           // 0000009A4EE0: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 0000009A4EE4: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 0000009A4EE8: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 0000009A4EF0: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 0000009A4EF4: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A4EF8: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 0000009A4EFC: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 0000009A4F00: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 0000009A4F08: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 0000009A4F0C: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 0000009A4F10: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A4F14: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000009A4F1C: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A4F24: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000009A4F2C: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A4F34: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000009A4F3C: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A4F44: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000009A4F4C: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A4F54: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000009A4F5C: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A4F64: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000009A4F6C: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A4F74: 7E2402FA FF016103
	v_cndmask_b32_e64 v19, -v3, v3, vcc_lo                     // 0000009A4F7C: D5010013 21AA0703
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 0000009A4F84: D5010015 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000009A4F8C: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 0000009A4F90: C9080D07 03082108
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A4F98: 7E2802FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 0000009A4FA0: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A4FA8: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A4FAC: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000009A4FB4: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 0000009A4FBC: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A4FC0: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000009A4FC8: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A4FD0: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 0000009A4FD8: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A4FDC: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000009A4FE4: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 0000009A4FEC: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000009A4FF0: D5010008 21AA1108
	v_add_f32_e32 v13, v21, v20                                // 0000009A4FF8: 061A2915
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A4FFC: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 0000009A5004: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A5008: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000009A5010: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000009A5018: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 0000009A5020: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A5024: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000009A502C: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 0000009A5034: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A5038: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000009A5040: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 0000009A5048: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A504C: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000009A5054: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 0000009A505C: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 0000009A5060: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 0000009A5064: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A506C: 7E0402FA FF016402
	v_add_f32_e32 v6, v6, v11                                  // 0000009A5074: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A5078: 7E1602FA FF016408
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 0000009A5080: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A5088: BF870234
	v_add_f32_e32 v7, v7, v2                                   // 0000009A508C: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A5090: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000009A5098: D5010004 20060904
	v_add_f32_e32 v14, v14, v11                                // 0000009A50A0: 061C170E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A50A4: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A50AC: 7E0A02FA FF016807
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A50B4: 7E1002FA FF016806
	v_add_f32_e32 v4, v4, v10                                  // 0000009A50BC: 06081504
	v_add_f32_e32 v10, v19, v18                                // 0000009A50C0: 06142513
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009A50C4: BF8700A1
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A50C8: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000009A50D0: D501000A 21AA150A
	v_add_f32_e32 v10, v10, v12                                // 0000009A50D8: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 0000009A50DC: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A50E0: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000009A50E8: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A50F0: BF870214
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A50F4: 7E1E02FA FF01640A
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A50FC: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009A5104: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 0000009A510C: D501000C 2006190C
	v_add_f32_e32 v16, v9, v13                                 // 0000009A5114: 06201B09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A5118: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A5120: BF870214
	v_add_f32_e32 v15, v10, v15                                // 0000009A5124: 061E1F0A
	v_add_f32_e32 v17, v12, v17                                // 0000009A5128: 0622230C
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A512C: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A5134: 7E1602FA FF016810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A513C: BF870214
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A5140: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A5148: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 0000009A5150: 8B7E007E
	s_cbranch_execz 171                                        // 0000009A5154: BFA500AB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2604>
	v_lshl_or_b32 v18, s10, 7, v1                              // 0000009A5158: D6560012 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 0000009A5160: 36020088
	.long 0x7f2c3880                                           // 0000009A5164: 7F2C3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A5168: BF870113
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000009A516C: 3426249F
	.long 0x7f323996                                           // 0000009A5170: 7F323996
	.long 0x7f2e3996                                           // 0000009A5174: 7F2E3996
	.long 0x7f303996                                           // 0000009A5178: 7F303996
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A517C: BF870094
	.long 0xd73c0012                                           // 0000009A5180: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000009A5184: 02022481
	.long 0xd7006a14                                           // 0000009A5188: D7006A14
	v_cndmask_b32_e32 v1, s36, v18, vcc_lo                     // 0000009A518C: 02022424
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A5190: BF870001
	v_add_co_ci_u32_e64 v21, null, s37, v19, vcc_lo            // 0000009A5194: D5207C15 01AA2625
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000009A519C: 7C940280
	s_clause 0x7                                               // 0000009A51A0: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 0000009A51A4: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 0000009A51AC: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 0000009A51B4: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 0000009A51BC: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 0000009A51C4: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 0000009A51CC: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 0000009A51D4: DC8200C0 1C7C0014
	global_load_d16_b16 v29, v[20:21], off offset:224          // 0000009A51DC: DC8200E0 1D7C0014
	v_mad_i64_i32 v[20:21], null, s49, v71, 0                  // 0000009A51E4: D6FF7C14 02028E31
	v_cndmask_b32_e64 v1, -v7, v7, vcc_lo                      // 0000009A51EC: D5010001 21AA0F07
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000009A51F4: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000009A51FC: D501000E 21AA1D0E
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000009A5204: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 0000009A520C: D501000F 21AA1F0F
	v_add_f32_e32 v1, v1, v5                                   // 0000009A5214: 06020B01
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 0000009A5218: D5010005 21AA0D06
	.long 0xd73c0014                                           // 0000009A5220: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000009A5224: 02022881
	v_cndmask_b32_e64 v6, -v16, v16, vcc_lo                    // 0000009A5228: D5010006 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 0000009A5230: D5010010 21AA2311
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000009A5238: BF8700B4
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 0000009A523C: C9081304 04041105
	v_add_f32_e32 v8, v14, v10                                 // 0000009A5244: 0610150E
	.long 0xd7006a11                                           // 0000009A5248: D7006A11
	v_cndmask_b32_e32 v1, s42, v20, vcc_lo                     // 0000009A524C: 0202282A
	v_add_co_ci_u32_e64 v20, null, s43, v21, vcc_lo            // 0000009A5250: D5207C14 01AA2A2B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009A5258: BF8701C4
	v_dual_mul_f32 v21, 0x3db504f3, v1 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 0000009A525C: C8C602FF 150408FF 3DB504F3
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v6, v6, v11    // 0000009A5268: C9080503 03061706
	v_dual_add_f32 v9, v15, v12 :: v_dual_add_f32 v10, v16, v13// 0000009A5270: C908190F 090A1B10
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 0000009A5278: 100A0AFF 3DB504F3
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 0000009A5280: C8C606FF 030810FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A528C: BF870214
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 0000009A5290: 100C0CFF 3DB504F3
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 0000009A5298: 101414FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 0000009A52A0: BF891FF7
	.long 0x7f0e3996                                           // 0000009A52A4: 7F0E3996
	.long 0xd7006a01                                           // 0000009A52A8: D7006A01
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000009A52AC: 02022511
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A52B0: BF870001
	v_add_co_ci_u32_e64 v2, null, v20, v19, vcc_lo             // 0000009A52B4: D5207C02 01AA2714
	v_fma_mix_f32 v11, v22, v21, neg(0) op_sel_hi:[1,0,0]      // 0000009A52BC: CC20000B 8A022B16
	s_waitcnt vmcnt(6)                                         // 0000009A52C4: BF891BF7
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 0000009A52C8: CC200003 8A020717
	s_waitcnt vmcnt(5)                                         // 0000009A52D0: BF8917F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 0000009A52D4: CC200005 8A020B18
	s_waitcnt vmcnt(4)                                         // 0000009A52DC: BF8913F7
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 0000009A52E0: CC200004 8A020919
	s_waitcnt vmcnt(3)                                         // 0000009A52E8: BF890FF7
	v_fma_mix_f32 v8, v26, v8, neg(0) op_sel_hi:[1,0,0]        // 0000009A52EC: CC200008 8A02111A
	.long 0x7e2c398b                                           // 0000009A52F4: 7E2C398B
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 0000009A52F8: 101212FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 0000009A5300: BF890BF7
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 0000009A5304: CC200006 8A020D1B
	s_waitcnt vmcnt(0)                                         // 0000009A530C: BF8903F7
	v_fma_mix_f32 v10, v29, v10, neg(0) op_sel_hi:[1,0,0]      // 0000009A5310: CC20000A 8A02151D
	.long 0x7e0e3983                                           // 0000009A5318: 7E0E3983
	v_and_b32_e32 v12, 1, v22                                  // 0000009A531C: 36182C81
	.long 0x7e2c3984                                           // 0000009A5320: 7E2C3984
	v_fma_mix_f32 v9, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009A5324: CC200009 8A02131C
	.long 0x7e2e3985                                           // 0000009A532C: 7E2E3985
	.long 0x7e303988                                           // 0000009A5330: 7E303988
	v_and_b32_e32 v7, 1, v7                                    // 0000009A5334: 360E0E81
	v_and_b32_e32 v13, 1, v22                                  // 0000009A5338: 361A2C81
	.long 0x7e2c3986                                           // 0000009A533C: 7E2C3986
	.long 0x7e323989                                           // 0000009A5340: 7E323989
	v_and_b32_e32 v14, 1, v23                                  // 0000009A5344: 361C2E81
	v_and_b32_e32 v15, 1, v24                                  // 0000009A5348: 361E3081
	v_add3_u32 v3, v3, v7, 0x7fff                              // 0000009A534C: D6550003 03FE0F03 00007FFF
	v_and_b32_e32 v16, 1, v22                                  // 0000009A5358: 36202C81
	.long 0x7e2c398a                                           // 0000009A535C: 7E2C398A
	v_and_b32_e32 v17, 1, v25                                  // 0000009A5360: 36223281
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000009A5364: D655000B 03FE190B 00007FFF
	v_add3_u32 v5, v5, v14, 0x7fff                             // 0000009A5370: D6550005 03FE1D05 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 0000009A537C: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v7, 1, v22                                   // 0000009A5388: 360E2C81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 0000009A538C: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 0000009A5398: D6550009 03FE2309 00007FFF
	v_add3_u32 v6, v6, v16, 0x7fff                             // 0000009A53A4: D6550006 03FE2106 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A53B0: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 0000009A53B4: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 0000009A53C0: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 0000009A53C4: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v11, off offset:32         // 0000009A53CC: DC960020 007C0B01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 0000009A53D4: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 0000009A53DC: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 0000009A53E4: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v6, off offset:160         // 0000009A53EC: DC9600A0 007C0601
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 0000009A53F4: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v7, off offset:224         // 0000009A53FC: DC9600E0 007C0701
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009A5404: 8C7E037E
	s_mov_b32 s4, 0                                            // 0000009A5408: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009A540C: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000009A5410: 8B6A047E
	s_cbranch_vccz 3865                                        // 0000009A5414: BFA30F19 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x627c>
	s_mul_hi_i32 s0, s2, 0x66666667                            // 0000009A5418: 9700FF02 66666667
	v_mov_b32_e32 v1, 0                                        // 0000009A5420: 7E020280
	s_lshr_b32 s1, s0, 31                                      // 0000009A5424: 85019F00
	s_ashr_i32 s0, s0, 1                                       // 0000009A5428: 86008100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009A542C: BF870499
	s_add_i32 s10, s0, s1                                      // 0000009A5430: 810A0100
	s_ashr_i32 s11, s10, 31                                    // 0000009A5434: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009A5438: BF870499
	s_lshl_b64 s[0:1], s[10:11], 2                             // 0000009A543C: 8480820A
	s_add_u32 s0, s16, s0                                      // 0000009A5440: 80000010
	s_addc_u32 s1, s17, s1                                     // 0000009A5444: 82010111
	global_load_b32 v1, v1, s[0:1]                             // 0000009A5448: DC520000 01000001
	s_mov_b32 s1, exec_lo                                      // 0000009A5450: BE81007E
	s_waitcnt vmcnt(0)                                         // 0000009A5454: BF8903F7
	v_readfirstlane_b32 s4, v1                                 // 0000009A5458: 7E080501
	v_cmpx_gt_u32_e32 0x140, v0                                // 0000009A545C: 7D9800FF 00000140
	s_cbranch_execz 42                                         // 0000009A5464: BFA5002A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2710>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 0000009A5468: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 0000009A5470: 30080084
	s_lshr_b32 s3, s0, 31                                      // 0000009A5474: 85039F00
	s_ashr_i32 s0, s0, 4                                       // 0000009A5478: 86008400
	v_or_b32_e32 v3, 0xffffff00, v0                            // 0000009A547C: 380600FF FFFFFF00
	s_add_i32 s0, s0, s3                                       // 0000009A5484: 81000300
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009A5488: BF8700D9
	s_mul_i32 s3, s0, 0x1400                                   // 0000009A548C: 9603FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 0000009A5494: 9700FF00 00001400
	s_add_u32 s3, s14, s3                                      // 0000009A549C: 8003030E
	s_addc_u32 s0, s15, s0                                     // 0000009A54A0: 8200000F
	.long 0xd7000301                                           // 0000009A54A4: D7000301
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 0000009A54A8: 02020803
	v_add_co_ci_u32_e64 v2, null, s0, 0, s3                    // 0000009A54AC: D5207C02 000D0000
	s_mov_b32 s3, 0                                            // 0000009A54B4: BE830080
	s_nop 0                                                    // 0000009A54B8: BF800000
	s_nop 0                                                    // 0000009A54BC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 0000009A54C0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 0000009A54C8: 4A0606FF 00000100
	.long 0xd7006a01                                           // 0000009A54D0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 0000009A54D4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A54DC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000009A54E0: D5207C02 01AA0480
	.long 0xd4490000                                           // 0000009A54E8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 0000009A54EC: 020206BF
	s_or_b32 s3, s0, s3                                        // 0000009A54F0: 8C030300
	s_waitcnt vmcnt(0)                                         // 0000009A54F4: BF8903F7
	ds_store_b128 v4, v[5:8] offset:10240                      // 0000009A54F8: DB7C2800 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 0000009A5500: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000009A5508: 917E037E
	s_cbranch_execnz 65516                                     // 0000009A550C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x26c0>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009A5510: 8C7E017E
	v_mul_u32_u24_e32 v25, 20, v71                             // 0000009A5514: 16328E94
	v_mad_u32_u24 v88, v72, 24, 0x2f0                          // 0000009A5518: D60B0058 03FD3148 000002F0
	v_cmp_eq_u32_e32 vcc_lo, 0, v72                            // 0000009A5524: 7C949080
	s_mul_i32 s5, s10, -5                                      // 0000009A5528: 9605C50A
	s_mul_i32 s1, s4, 0x12c000                                 // 0000009A552C: 9601FF04 0012C000
	v_min_u32_e32 v26, 0x8c, v25                               // 0000009A5534: 263432FF 0000008C
	v_lshrrev_b32_e32 v1, 5, v88                               // 0000009A553C: 3202B085
	s_mul_hi_i32 s0, s4, 0x12c000                              // 0000009A5540: 9700FF04 0012C000
	s_add_i32 s5, s5, s2                                       // 0000009A5548: 81050205
	s_add_u32 s1, s12, s1                                      // 0000009A554C: 8001010C
	v_add_nc_u32_e32 v73, 20, v26                              // 0000009A5550: 4A923494
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000009A5554: 4E020298
	s_addc_u32 s3, s13, s0                                     // 0000009A5558: 8203000D
	s_mul_i32 s2, s5, 0x3c000                                  // 0000009A555C: 9602FF05 0003C000
	v_add_nc_u32_e32 v89, 8, v88                               // 0000009A5564: 4AB2B088
	.long 0xd4490000                                           // 0000009A5568: D4490000
	v_cndmask_b32_e32 v1, v25, v73, vcc_lo                     // 0000009A556C: 02029319
	v_cndmask_b32_e64 v15, v1, 23, vcc_lo                      // 0000009A5570: D501000F 01A92F01
	s_mul_hi_i32 s6, s5, 0x3c000                               // 0000009A5578: 9706FF05 0003C000
	s_add_u32 s2, s1, s2                                       // 0000009A5580: 80020201
	s_addc_u32 s3, s3, s6                                      // 0000009A5584: 82030603
	s_waitcnt lgkmcnt(0)                                       // 0000009A5588: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000009A558C: BC7C0000
	s_barrier                                                  // 0000009A5590: BFBD0000
	buffer_gl0_inv                                             // 0000009A5594: E0AC0000 00000000
	s_and_saveexec_b32 s6, s0                                  // 0000009A559C: BE862000
	s_cbranch_execz 190                                        // 0000009A55A0: BFA500BE <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2a9c>
	v_lshrrev_b32_e32 v1, 5, v89                               // 0000009A55A4: 3202B285
	.long 0xd4440001                                           // 0000009A55A8: D4440001
	v_cndmask_b32_e32 v1, 23, v15, vcc_lo                      // 0000009A55AC: 02021E97
	v_mul_u32_u24_e32 v6, 0x7800, v71                          // 0000009A55B0: 160C8EFF 00007800
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A55B8: BF870193
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000009A55BC: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 0000009A55C0: D5010002 000502FF 000000E9
	v_mov_b32_e32 v16, 0                                       // 0000009A55CC: 7E200280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A55D0: BF870193
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 0000009A55D4: D5010001 01A92F01
	v_add_nc_u32_e32 v5, v2, v15                               // 0000009A55DC: 4A0A1F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009A55E0: BF870223
	.long 0xd73c0003                                           // 0000009A55E4: D73C0003
	v_cndmask_b32_e32 v1, 2, v15, vcc_lo                       // 0000009A55E8: 02021E82
	v_mov_b32_e32 v2, v16                                      // 0000009A55EC: 7E040310
	.long 0xd4440001                                           // 0000009A55F0: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 0000009A55F4: 02020297
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A55F8: BF8701A4
	v_lshlrev_b32_e32 v7, 24, v5                               // 0000009A55FC: 300E0A98
	v_bfe_i32 v9, v5, 7, 1                                     // 0000009A5600: D6110009 02050F05
	v_cndmask_b32_e64 v8, 0xe9, 1, s1                          // 0000009A5608: D5010008 000502FF 000000E9
	.long 0xd700010b                                           // 0000009A5614: D700010B
	v_cndmask_b32_e32 v1, s2, v6, vcc_lo                       // 0000009A5618: 02020C02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A561C: BF870191
	v_add_co_ci_u32_e64 v12, null, s3, 0, s1                   // 0000009A5620: D5207C0C 00050003
	v_add_nc_u32_e32 v10, v8, v1                               // 0000009A5628: 4A140308
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A562C: BF870233
	.long 0xd7000105                                           // 0000009A5630: D7000105
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 0000009A5634: 0202070B
	v_ashrrev_i32_e32 v7, 22, v7                               // 0000009A5638: 340E0E96
	.long 0xd73c0001                                           // 0000009A563C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000009A5640: 02020282
	v_lshlrev_b32_e32 v3, 24, v10                              // 0000009A5644: 30061498
	v_add_co_ci_u32_e64 v6, null, v12, v4, s1                  // 0000009A5648: D5207C06 0006090C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A5650: BF870194
	.long 0xd7000107                                           // 0000009A5654: D7000107
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                      // 0000009A5658: 02020F0B
	v_ashrrev_i32_e32 v3, 22, v3                               // 0000009A565C: 34060696
	v_bfe_i32 v4, v10, 7, 1                                    // 0000009A5660: D6110004 02050F0A
	v_add_co_ci_u32_e64 v8, null, v12, v9, s1                  // 0000009A5668: D5207C08 0006130C
	.long 0xd7000109                                           // 0000009A5670: D7000109
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000009A5674: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009A5678: BF8700A1
	v_add_co_ci_u32_e64 v10, null, v12, v2, s1                 // 0000009A567C: D5207C0A 0006050C
	.long 0xd700014a                                           // 0000009A5684: D700014A
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 0000009A5688: 0202070B
	v_add_co_ci_u32_e64 v75, null, v12, v4, s1                 // 0000009A568C: D5207C4B 0006090C
	s_clause 0x1f                                              // 0000009A5694: BF85001F
	global_load_b32 v2, v[5:6], off                            // 0000009A5698: DC520000 027C0005
	global_load_b32 v68, v[5:6], off offset:96                 // 0000009A56A0: DC520060 447C0005
	global_load_b32 v64, v[5:6], off offset:192                // 0000009A56A8: DC5200C0 407C0005
	global_load_b32 v60, v[5:6], off offset:288                // 0000009A56B0: DC520120 3C7C0005
	global_load_b32 v56, v[5:6], off offset:384                // 0000009A56B8: DC520180 387C0005
	global_load_b32 v52, v[5:6], off offset:480                // 0000009A56C0: DC5201E0 347C0005
	global_load_b32 v48, v[5:6], off offset:576                // 0000009A56C8: DC520240 307C0005
	global_load_b32 v44, v[5:6], off offset:672                // 0000009A56D0: DC5202A0 2C7C0005
	global_load_b32 v1, v[7:8], off                            // 0000009A56D8: DC520000 017C0007
	global_load_b32 v67, v[7:8], off offset:96                 // 0000009A56E0: DC520060 437C0007
	global_load_b32 v63, v[7:8], off offset:192                // 0000009A56E8: DC5200C0 3F7C0007
	global_load_b32 v59, v[7:8], off offset:288                // 0000009A56F0: DC520120 3B7C0007
	global_load_b32 v55, v[7:8], off offset:384                // 0000009A56F8: DC520180 377C0007
	global_load_b32 v51, v[7:8], off offset:480                // 0000009A5700: DC5201E0 337C0007
	global_load_b32 v47, v[7:8], off offset:576                // 0000009A5708: DC520240 2F7C0007
	global_load_b32 v43, v[7:8], off offset:672                // 0000009A5710: DC5202A0 2B7C0007
	global_load_b32 v4, v[9:10], off                           // 0000009A5718: DC520000 047C0009
	global_load_b32 v70, v[9:10], off offset:96                // 0000009A5720: DC520060 467C0009
	global_load_b32 v66, v[9:10], off offset:192               // 0000009A5728: DC5200C0 427C0009
	global_load_b32 v62, v[9:10], off offset:288               // 0000009A5730: DC520120 3E7C0009
	global_load_b32 v58, v[9:10], off offset:384               // 0000009A5738: DC520180 3A7C0009
	global_load_b32 v54, v[9:10], off offset:480               // 0000009A5740: DC5201E0 367C0009
	global_load_b32 v50, v[9:10], off offset:576               // 0000009A5748: DC520240 327C0009
	global_load_b32 v46, v[9:10], off offset:672               // 0000009A5750: DC5202A0 2E7C0009
	global_load_b32 v3, v[74:75], off                          // 0000009A5758: DC520000 037C004A
	global_load_b32 v69, v[74:75], off offset:96               // 0000009A5760: DC520060 457C004A
	global_load_b32 v65, v[74:75], off offset:192              // 0000009A5768: DC5200C0 417C004A
	global_load_b32 v61, v[74:75], off offset:288              // 0000009A5770: DC520120 3D7C004A
	global_load_b32 v57, v[74:75], off offset:384              // 0000009A5778: DC520180 397C004A
	global_load_b32 v53, v[74:75], off offset:480              // 0000009A5780: DC5201E0 357C004A
	global_load_b32 v49, v[74:75], off offset:576              // 0000009A5788: DC520240 317C004A
	global_load_b32 v45, v[74:75], off offset:672              // 0000009A5790: DC5202A0 2D7C004A
	s_clause 0x1f                                              // 0000009A5798: BF85001F
	global_load_b32 v40, v[5:6], off offset:768                // 0000009A579C: DC520300 287C0005
	global_load_b32 v36, v[5:6], off offset:864                // 0000009A57A4: DC520360 247C0005
	global_load_b32 v32, v[5:6], off offset:960                // 0000009A57AC: DC5203C0 207C0005
	global_load_b32 v28, v[5:6], off offset:1056               // 0000009A57B4: DC520420 1C7C0005
	global_load_b32 v22, v[5:6], off offset:1152               // 0000009A57BC: DC520480 167C0005
	global_load_b32 v18, v[5:6], off offset:1248               // 0000009A57C4: DC5204E0 127C0005
	global_load_b32 v12, v[5:6], off offset:1344               // 0000009A57CC: DC520540 0C7C0005
	global_load_b32 v6, v[5:6], off offset:1440                // 0000009A57D4: DC5205A0 067C0005
	global_load_b32 v39, v[7:8], off offset:768                // 0000009A57DC: DC520300 277C0007
	global_load_b32 v35, v[7:8], off offset:864                // 0000009A57E4: DC520360 237C0007
	global_load_b32 v31, v[7:8], off offset:960                // 0000009A57EC: DC5203C0 1F7C0007
	global_load_b32 v27, v[7:8], off offset:1056               // 0000009A57F4: DC520420 1B7C0007
	global_load_b32 v21, v[7:8], off offset:1152               // 0000009A57FC: DC520480 157C0007
	global_load_b32 v17, v[7:8], off offset:1248               // 0000009A5804: DC5204E0 117C0007
	global_load_b32 v11, v[7:8], off offset:1344               // 0000009A580C: DC520540 0B7C0007
	global_load_b32 v5, v[7:8], off offset:1440                // 0000009A5814: DC5205A0 057C0007
	global_load_b32 v42, v[9:10], off offset:768               // 0000009A581C: DC520300 2A7C0009
	global_load_b32 v38, v[9:10], off offset:864               // 0000009A5824: DC520360 267C0009
	global_load_b32 v34, v[9:10], off offset:960               // 0000009A582C: DC5203C0 227C0009
	global_load_b32 v30, v[9:10], off offset:1056              // 0000009A5834: DC520420 1E7C0009
	global_load_b32 v24, v[9:10], off offset:1152              // 0000009A583C: DC520480 187C0009
	global_load_b32 v20, v[9:10], off offset:1248              // 0000009A5844: DC5204E0 147C0009
	global_load_b32 v14, v[9:10], off offset:1344              // 0000009A584C: DC520540 0E7C0009
	global_load_b32 v8, v[9:10], off offset:1440               // 0000009A5854: DC5205A0 087C0009
	global_load_b32 v41, v[74:75], off offset:768              // 0000009A585C: DC520300 297C004A
	global_load_b32 v37, v[74:75], off offset:864              // 0000009A5864: DC520360 257C004A
	global_load_b32 v33, v[74:75], off offset:960              // 0000009A586C: DC5203C0 217C004A
	global_load_b32 v29, v[74:75], off offset:1056             // 0000009A5874: DC520420 1D7C004A
	global_load_b32 v23, v[74:75], off offset:1152             // 0000009A587C: DC520480 177C004A
	global_load_b32 v19, v[74:75], off offset:1248             // 0000009A5884: DC5204E0 137C004A
	global_load_b32 v13, v[74:75], off offset:1344             // 0000009A588C: DC520540 0D7C004A
	global_load_b32 v7, v[74:75], off offset:1440              // 0000009A5894: DC5205A0 077C004A
	s_or_b32 exec_lo, exec_lo, s6                              // 0000009A589C: 8C7E067E
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v75, 0             // 0000009A58A0: CA100080 0A4A0080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v77, 0             // 0000009A58A8: CA100080 4A4C0080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v79, 0             // 0000009A58B0: CA100080 4C4E0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v81, 0             // 0000009A58B8: CA100080 4E500080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v83, 0             // 0000009A58C0: CA100080 50520080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v85, 0             // 0000009A58C8: CA100080 52540080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v87, 0             // 0000009A58D0: CA100080 54560080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v9, 0              // 0000009A58D8: CA100080 56080080
	s_and_saveexec_b32 s1, s0                                  // 0000009A58E0: BE812000
	s_cbranch_execz 2083                                       // 0000009A58E4: BFA50823 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4b74>
	v_lshrrev_b32_e32 v9, 5, v89                               // 0000009A58E8: 3212B285
	v_mul_i32_i24_e32 v74, 0xffffffe8, v72                     // 0000009A58EC: 129490FF FFFFFFE8
	v_dual_mov_b32 v10, 0 :: v_dual_and_b32 v75, 0x7e0, v88    // 0000009A58F4: CA240080 0A4AB0FF 000007E0
	v_and_b32_e32 v78, 16, v0                                  // 0000009A5900: 369C0090
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A5904: BF870004
	v_subrev_nc_u32_e32 v9, 24, v9                             // 0000009A5908: 4E121298
	v_sub_nc_u32_e32 v89, 0, v26                               // 0000009A590C: 4CB23480
	v_add_nc_u32_e32 v88, 1, v25                               // 0000009A5910: 4AB03281
	v_add3_u32 v90, v74, v75, 0xfffffd34                       // 0000009A5914: D655005A 03FE974A FFFFFD34
	v_mov_b32_e32 v75, v10                                     // 0000009A5920: 7E96030A
	v_cndmask_b32_e64 v9, v9, 23, vcc_lo                       // 0000009A5924: D5010009 01A92F09
	v_lshl_or_b32 v91, v25, 5, v78                             // 0000009A592C: D656005B 05390B19
	.long 0xd4440000                                           // 0000009A5934: D4440000
	v_cndmask_b32_e32 v1, 23, v15, vcc_lo                      // 0000009A5938: 02021E97
	v_lshl_or_b32 v76, v72, 3, 4                               // 0000009A593C: D656004C 02110748
	v_ashrrev_i32_e32 v16, 31, v15                             // 0000009A5944: 34201E9F
	.long 0xd703001a                                           // 0000009A5948: D703001A
	v_cndmask_b32_e32 v0, v9, v129, vcc_lo                     // 0000009A594C: 02010309
	v_mov_b32_e32 v79, v10                                     // 0000009A5950: 7E9E030A
	v_cndmask_b32_e64 v77, 0xe9, 1, s0                         // 0000009A5954: D501004D 000102FF 000000E9
	v_mad_u32_u24 v83, v76, 3, 0x2f0                           // 0000009A5960: D60B0053 03FD074C 000002F0
	v_mul_i32_i24_e32 v85, -3, v76                             // 0000009A596C: 12AA98C3
	.long 0xd7620019                                           // 0000009A5970: D7620019
	v_cndmask_b32_e32 v1, 0xff, v26, vcc_lo                    // 0000009A5974: 020234FF 000000FF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A597C: BF870234
	v_dual_mov_b32 v81, v10 :: v_dual_add_nc_u32 v84, v77, v15 // 0000009A5980: CA20010A 51541F4D
	.long 0xd73c000f                                           // 0000009A5988: D73C000F
	v_cndmask_b32_e32 v1, 2, v15, vcc_lo                       // 0000009A598C: 02021E82
	v_mov_b32_e32 v77, v10                                     // 0000009A5990: 7E9A030A
	v_cmp_ne_u16_e32 vcc_lo, 24, v25                           // 0000009A5994: 7C7A3298
	v_mov_b32_e32 v78, v10                                     // 0000009A5998: 7E9C030A
	v_and_b32_e32 v86, 0xff, v84                               // 0000009A599C: 36ACA8FF 000000FF
	v_mov_b32_e32 v80, v10                                     // 0000009A59A4: 7EA0030A
	v_mov_b32_e32 v82, v10                                     // 0000009A59A8: 7EA4030A
	v_cndmask_b16 v25, 0, v26, vcc_lo                          // 0000009A59AC: D65D0019 01AA3480
	v_mov_b32_e32 v74, v10                                     // 0000009A59B4: 7E94030A
	v_dual_mov_b32 v83, v10 :: v_dual_and_b32 v26, 0x7e0, v83  // 0000009A59B8: CA24010A 531AA6FF 000007E0
	v_dual_mov_b32 v76, v10 :: v_dual_lshlrev_b32 v93, 2, v86  // 0000009A59C4: CA22010A 4C5CAC82
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A59CC: BF870194
	v_and_b32_e32 v25, 0xff, v25                               // 0000009A59D0: 363232FF 000000FF
	v_add3_u32 v92, v85, v26, 0xfffffd34                       // 0000009A59D8: D655005C 03FE3555 FFFFFD34
	v_mov_b32_e32 v84, v10                                     // 0000009A59E4: 7EA8030A
	v_mov_b32_e32 v86, v10                                     // 0000009A59E8: 7EAC030A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A59EC: BF870004
	v_dual_mov_b32 v85, v10 :: v_dual_lshlrev_b32 v94, 2, v25  // 0000009A59F0: CA22010A 555E3282
	.long 0xd73c0019                                           // 0000009A59F8: D73C0019
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 0000009A59FC: 02021282
	v_mov_b32_e32 v87, v10                                     // 0000009A5A00: 7EAE030A
	v_mov_b32_e32 v9, v10                                      // 0000009A5A04: 7E12030A
	s_mov_b32 s0, 0                                            // 0000009A5A08: BE800080
	s_mov_b32 s6, 0xdcd12d                                     // 0000009A5A0C: BE8600FF 00DCD12D
	s_movk_i32 s7, 0x83                                        // 0000009A5A14: B0070083
	s_movk_i32 s8, 0x1eee                                      // 0000009A5A18: B0081EEE
	s_branch 1847                                              // 0000009A5A1C: BFA00737 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x48fc>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000009A5A20: 8C7E097E
	s_waitcnt vmcnt(55)                                        // 0000009A5A24: BF89DFF7
	.long 0xd73d0001                                           // 0000009A5A28: D73D0001
	v_cndmask_b32_e32 v1, v90, v1, vcc_lo                      // 0000009A5A2C: 0202035A
	s_waitcnt vmcnt(39)                                        // 0000009A5A30: BF899FF7
	.long 0xd73d0002                                           // 0000009A5A34: D73D0002
	v_cndmask_b32_e32 v1, v92, v3, vcc_lo                      // 0000009A5A38: 0202075C
	.long 0xd73d0043                                           // 0000009A5A3C: D73D0043
	v_cndmask_b32_e32 v1, v90, v67, vcc_lo                     // 0000009A5A40: 0202875A
	s_waitcnt vmcnt(38)                                        // 0000009A5A44: BF899BF7
	.long 0xd73d0044                                           // 0000009A5A48: D73D0044
	v_cndmask_b32_e32 v1, v92, v69, vcc_lo                     // 0000009A5A4C: 02028B5C
	.long 0xd73d003f                                           // 0000009A5A50: D73D003F
	v_cndmask_b32_e32 v1, v90, v63, vcc_lo                     // 0000009A5A54: 02027F5A
	.long 0xd73d003b                                           // 0000009A5A58: D73D003B
	v_cndmask_b32_e32 v1, v90, v59, vcc_lo                     // 0000009A5A5C: 0202775A
	v_bfe_u32 v3, v1, 9, 16                                    // 0000009A5A60: D6100003 02411301
	v_bfe_u32 v160, v2, 9, 16                                  // 0000009A5A68: D61000A0 02411302
	v_bfe_u32 v161, v2, 6, 16                                  // 0000009A5A70: D61000A1 02410D02
	v_bfe_u32 v162, v2, 3, 16                                  // 0000009A5A78: D61000A2 02410702
	v_and_b32_e32 v163, 0xffff, v2                             // 0000009A5A80: 374604FF 0000FFFF
	v_mul_u32_u24_e32 v2, s6, v3                               // 0000009A5A88: 16040606
	v_mul_u32_u24_e32 v3, s7, v3                               // 0000009A5A8C: 16060607
	v_lshl_add_u32 v2, v3, 24, v2                              // 0000009A5A90: D6460002 04093103
	v_bfe_u32 v4, v1, 6, 16                                    // 0000009A5A98: D6100004 02410D01
	v_mul_u32_u24_e32 v3, s6, v4                               // 0000009A5AA0: 16060806
	v_bfe_u32 v159, v1, 3, 16                                  // 0000009A5AA4: D610009F 02410701
	v_mul_u32_u24_e32 v4, s7, v4                               // 0000009A5AAC: 16080807
	v_sad_u8 v2, v2, 0, 0x6400                                 // 0000009A5AB0: D6220002 03FD0102 00006400
	v_lshl_add_u32 v3, v4, 24, v3                              // 0000009A5ABC: D6460003 040D3104
	v_and_b32_e32 v1, 0xffff, v1                               // 0000009A5AC4: 360202FF 0000FFFF
	v_mul_u32_u24_e32 v164, s6, v159                           // 0000009A5ACC: 17493E06
	v_mul_u32_u24_e32 v4, s7, v159                             // 0000009A5AD0: 16093E07
	v_mul_u32_u24_e32 v159, s6, v160                           // 0000009A5AD4: 173F4006
	v_and_b32_e32 v166, 0xffff, v2                             // 0000009A5AD8: 374C04FF 0000FFFF
	v_mul_u32_u24_e32 v2, s7, v160                             // 0000009A5AE0: 16054007
	v_lshl_add_u32 v159, v2, 24, v159                          // 0000009A5AE4: D646009F 067D3102
	v_mul_u32_u24_e32 v2, s6, v1                               // 0000009A5AEC: 16040206
	v_mul_u32_u24_e32 v1, s7, v1                               // 0000009A5AF0: 16020207
	v_lshl_add_u32 v160, v1, 24, v2                            // 0000009A5AF4: D64600A0 04093101
	v_mul_u32_u24_e32 v1, s6, v161                             // 0000009A5AFC: 16034206
	v_mul_u32_u24_e32 v2, s7, v161                             // 0000009A5B00: 16054207
	v_lshl_add_u32 v161, v2, 24, v1                            // 0000009A5B04: D64600A1 04053102
	v_mul_u32_u24_e32 v1, s6, v162                             // 0000009A5B0C: 16034406
	v_mul_u32_u24_e32 v2, s7, v162                             // 0000009A5B10: 16054407
	v_lshl_add_u32 v164, v4, 24, v164                          // 0000009A5B14: D64600A4 06913104
	v_sad_u8 v165, v3, 0, 0x6400                               // 0000009A5B1C: D62200A5 03FD0103 00006400
	v_lshl_add_u32 v162, v2, 24, v1                            // 0000009A5B28: D64600A2 04053102
	ds_load_b128 v[1:4], v91 offset:10240                      // 0000009A5B30: DBFC2800 0100005B
	v_sad_u8 v159, v159, 0, 0x6400                             // 0000009A5B38: D622009F 03FD019F 00006400
	v_sad_u8 v164, v164, 0, 0x6400                             // 0000009A5B44: D62200A4 03FD01A4 00006400
	v_lshl_or_b32 v165, v165, 16, v166                         // 0000009A5B50: D65600A5 069921A5
	v_sad_u8 v160, v160, 0, 0x6400                             // 0000009A5B58: D62200A0 03FD01A0 00006400
	v_sad_u8 v161, v161, 0, 0x6400                             // 0000009A5B64: D62200A1 03FD01A1 00006400
	v_and_b32_e32 v159, 0xffff, v159                           // 0000009A5B70: 373F3EFF 0000FFFF
	v_and_b32_e32 v164, 0xffff, v164                           // 0000009A5B78: 374948FF 0000FFFF
	v_pk_fma_f16 v165, v165, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000009A5B80: CC0E00A5 0BFC11A5 0000C931
	v_mul_u32_u24_e32 v167, s6, v163                           // 0000009A5B8C: 174F4606
	v_mul_u32_u24_e32 v163, s7, v163                           // 0000009A5B90: 17474607
	v_lshl_add_u32 v163, v163, 24, v167                        // 0000009A5B94: D64600A3 069D31A3
	v_lshl_or_b32 v160, v160, 16, v164                         // 0000009A5B9C: D65600A0 069121A0
	v_sad_u8 v162, v162, 0, 0x6400                             // 0000009A5BA4: D62200A2 03FD01A2 00006400
	v_lshl_or_b32 v159, v161, 16, v159                         // 0000009A5BB0: D656009F 067D21A1
	v_bfe_u32 v69, v67, 9, 16                                  // 0000009A5BB8: D6100045 02411343
	v_sad_u8 v163, v163, 0, 0x6400                             // 0000009A5BC0: D62200A3 03FD01A3 00006400
	v_pk_fma_f16 v160, v160, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000009A5BCC: CC0E00A0 0BFC11A0 0000C931
	v_mul_u32_u24_e32 v164, s6, v69                            // 0000009A5BD8: 17488A06
	v_pk_fma_f16 v159, v159, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000009A5BDC: CC0E009F 0BFC119F 0000C931
	s_waitcnt lgkmcnt(0)                                       // 0000009A5BE8: BF89FC07
	v_dot2acc_f32_f16 v9, v165, v1                             // 0000009A5BEC: 041203A5
	v_mul_u32_u24_e32 v69, s7, v69                             // 0000009A5BF0: 168A8A07
	v_lshl_add_u32 v69, v69, 24, v164                          // 0000009A5BF4: D6460045 06913145
	v_bfe_u32 v70, v67, 6, 16                                  // 0000009A5BFC: D6100046 02410D43
	v_bfe_u32 v164, v68, 6, 16                                 // 0000009A5C04: D61000A4 02410D44
	v_dot2acc_f32_f16 v9, v160, v2                             // 0000009A5C0C: 041205A0
	v_and_b32_e32 v162, 0xffff, v162                           // 0000009A5C10: 374544FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 0000009A5C18: D6220045 03FD0145 00006400
	v_bfe_u32 v165, v68, 3, 16                                 // 0000009A5C24: D61000A5 02410744
	s_waitcnt vmcnt(36)                                        // 0000009A5C2C: BF8993F7
	.long 0xd73d003c                                           // 0000009A5C30: D73D003C
	v_cndmask_b32_e32 v1, v92, v61, vcc_lo                     // 0000009A5C34: 02027B5C
	v_dot2acc_f32_f16 v9, v159, v3                             // 0000009A5C38: 0412079F
	v_lshl_or_b32 v161, v163, 16, v162                         // 0000009A5C3C: D65600A1 068921A3
	v_bfe_u32 v162, v67, 3, 16                                 // 0000009A5C44: D61000A2 02410743
	v_mul_u32_u24_e32 v166, s6, v162                           // 0000009A5C4C: 174D4406
	v_mul_u32_u24_e32 v162, s7, v162                           // 0000009A5C50: 17454407
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A5C54: BF870001
	v_lshl_add_u32 v162, v162, 24, v166                        // 0000009A5C58: D64600A2 069931A2
	v_mul_u32_u24_e32 v166, s6, v70                            // 0000009A5C60: 174C8C06
	v_mul_u32_u24_e32 v70, s7, v70                             // 0000009A5C64: 168C8C07
	v_lshl_add_u32 v70, v70, 24, v166                          // 0000009A5C68: D6460046 06993146
	v_and_b32_e32 v67, 0xffff, v67                             // 0000009A5C70: 368686FF 0000FFFF
	v_bfe_u32 v163, v68, 9, 16                                 // 0000009A5C78: D61000A3 02411344
	v_mul_u32_u24_e32 v166, s6, v67                            // 0000009A5C80: 174C8606
	v_mul_u32_u24_e32 v67, s7, v67                             // 0000009A5C84: 16868607
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A5C88: BF870002
	v_lshl_add_u32 v67, v67, 24, v166                          // 0000009A5C8C: D6460043 06993143
	v_mul_u32_u24_e32 v166, s6, v163                           // 0000009A5C94: 174D4606
	v_mul_u32_u24_e32 v163, s7, v163                           // 0000009A5C98: 17474607
	v_lshl_add_u32 v163, v163, 24, v166                        // 0000009A5C9C: D64600A3 069931A3
	v_sad_u8 v162, v162, 0, 0x6400                             // 0000009A5CA4: D62200A2 03FD01A2 00006400
	v_and_b32_e32 v69, 0xffff, v69                             // 0000009A5CB0: 368A8AFF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 0000009A5CB8: D6220046 03FD0146 00006400
	v_mul_u32_u24_e32 v166, s6, v164                           // 0000009A5CC4: 174D4806
	v_mul_u32_u24_e32 v164, s7, v164                           // 0000009A5CC8: 17494807
	v_lshl_add_u32 v164, v164, 24, v166                        // 0000009A5CCC: D64600A4 069931A4
	v_and_b32_e32 v162, 0xffff, v162                           // 0000009A5CD4: 374544FF 0000FFFF
	v_sad_u8 v67, v67, 0, 0x6400                               // 0000009A5CDC: D6220043 03FD0143 00006400
	v_sad_u8 v163, v163, 0, 0x6400                             // 0000009A5CE8: D62200A3 03FD01A3 00006400
	v_lshl_or_b32 v69, v70, 16, v69                            // 0000009A5CF4: D6560045 05152146
	v_bfe_u32 v61, v59, 9, 16                                  // 0000009A5CFC: D610003D 0241133B
	v_bfe_u32 v62, v59, 6, 16                                  // 0000009A5D04: D610003E 02410D3B
	v_lshl_or_b32 v67, v67, 16, v162                           // 0000009A5D0C: D6560043 06892143
	v_and_b32_e32 v70, 0xffff, v163                            // 0000009A5D14: 368D46FF 0000FFFF
	v_sad_u8 v162, v164, 0, 0x6400                             // 0000009A5D1C: D62200A2 03FD01A4 00006400
	v_pk_fma_f16 v69, v69, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A5D28: CC0E0045 0BFC1145 0000C931
	v_mul_u32_u24_e32 v166, s6, v165                           // 0000009A5D34: 174D4A06
	v_pk_fma_f16 v67, v67, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A5D38: CC0E0043 0BFC1143 0000C931
	v_mul_u32_u24_e32 v165, s7, v165                           // 0000009A5D44: 174B4A07
	v_lshl_or_b32 v70, v162, 16, v70                           // 0000009A5D48: D6560046 051921A2
	v_dual_dot2acc_f32_f16 v87, v69, v1 :: v_dual_and_b32 v68, 0xffff, v68// 0000009A5D50: CB240345 574488FF 0000FFFF
	v_bfe_u32 v69, v63, 9, 16                                  // 0000009A5D5C: D6100045 0241133F
	v_lshl_add_u32 v165, v165, 24, v166                        // 0000009A5D64: D64600A5 069931A5
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A5D6C: BF870214
	v_pk_fma_f16 v64, v70, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A5D70: CC0E0040 0BFC1146 0000C931
	v_dot2acc_f32_f16 v87, v67, v2                             // 0000009A5D7C: 04AE0543
	v_bfe_u32 v70, v63, 6, 16                                  // 0000009A5D80: D6100046 02410D3F
	v_pk_fma_f16 v67, v161, s8, 0xc931 op_sel_hi:[1,0,0]       // 0000009A5D88: CC0E0043 0BFC11A1 0000C931
	v_mul_u32_u24_e32 v161, s6, v70                            // 0000009A5D94: 17428C06
	v_mul_u32_u24_e32 v70, s7, v70                             // 0000009A5D98: 168C8C07
	v_dot2acc_f32_f16 v87, v64, v3                             // 0000009A5D9C: 04AE0740
	.long 0xd73d0040                                           // 0000009A5DA0: D73D0040
	v_cndmask_b32_e32 v1, v92, v65, vcc_lo                     // 0000009A5DA4: 0202835C
	v_mul_u32_u24_e32 v65, s6, v69                             // 0000009A5DA8: 16828A06
	v_mul_u32_u24_e32 v66, s7, v69                             // 0000009A5DAC: 16848A07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A5DB0: BF870001
	v_lshl_add_u32 v65, v66, 24, v65                           // 0000009A5DB4: D6460041 05053142
	v_lshl_add_u32 v70, v70, 24, v161                          // 0000009A5DBC: D6460046 06853146
	v_bfe_u32 v66, v63, 3, 16                                  // 0000009A5DC4: D6100042 0241073F
	v_bfe_u32 v69, v64, 9, 16                                  // 0000009A5DCC: D6100045 02411340
	v_mul_u32_u24_e32 v161, s6, v66                            // 0000009A5DD4: 17428406
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009A5DD8: D6220041 03FD0141 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 0000009A5DE4: D6220046 03FD0146 00006400
	v_mul_u32_u24_e32 v66, s7, v66                             // 0000009A5DF0: 16848407
	v_and_b32_e32 v63, 0xffff, v63                             // 0000009A5DF4: 367E7EFF 0000FFFF
	v_lshl_add_u32 v66, v66, 24, v161                          // 0000009A5DFC: D6460042 06853142
	v_and_b32_e32 v65, 0xffff, v65                             // 0000009A5E04: 368282FF 0000FFFF
	v_mul_u32_u24_e32 v161, s6, v69                            // 0000009A5E0C: 17428A06
	v_mul_u32_u24_e32 v69, s7, v69                             // 0000009A5E10: 168A8A07
	v_bfe_u32 v159, v64, 6, 16                                 // 0000009A5E14: D610009F 02410D40
	v_lshl_add_u32 v69, v69, 24, v161                          // 0000009A5E1C: D6460045 06853145
	v_lshl_or_b32 v65, v70, 16, v65                            // 0000009A5E24: D6560041 05052146
	v_mul_u32_u24_e32 v161, s6, v63                            // 0000009A5E2C: 17427E06
	v_mul_u32_u24_e32 v63, s7, v63                             // 0000009A5E30: 167E7E07
	v_lshl_add_u32 v63, v63, 24, v161                          // 0000009A5E34: D646003F 0685313F
	v_mul_u32_u24_e32 v161, s6, v159                           // 0000009A5E3C: 17433E06
	v_pk_fma_f16 v65, v65, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A5E40: CC0E0041 0BFC1141 0000C931
	v_mul_u32_u24_e32 v159, s7, v159                           // 0000009A5E4C: 173F3E07
	v_lshl_add_u32 v159, v159, 24, v161                        // 0000009A5E50: D646009F 0685319F
	v_mul_u32_u24_e32 v161, s6, v61                            // 0000009A5E58: 17427A06
	v_mul_u32_u24_e32 v61, s7, v61                             // 0000009A5E5C: 167A7A07
	v_lshl_add_u32 v61, v61, 24, v161                          // 0000009A5E60: D646003D 0685313D
	v_dot2acc_f32_f16 v86, v65, v1                             // 0000009A5E68: 04AC0341
	v_bfe_u32 v65, v59, 3, 16                                  // 0000009A5E6C: D6100041 0241073B
	v_mul_u32_u24_e32 v161, s6, v65                            // 0000009A5E74: 17428206
	v_mul_u32_u24_e32 v65, s7, v65                             // 0000009A5E78: 16828207
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A5E7C: BF870001
	v_lshl_add_u32 v65, v65, 24, v161                          // 0000009A5E80: D6460041 06853141
	v_mul_u32_u24_e32 v161, s6, v62                            // 0000009A5E88: 17427C06
	v_mul_u32_u24_e32 v62, s7, v62                             // 0000009A5E8C: 167C7C07
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009A5E90: D622003D 03FD013D 00006400
	v_lshl_add_u32 v62, v62, 24, v161                          // 0000009A5E9C: D646003E 0685313E
	v_and_b32_e32 v59, 0xffff, v59                             // 0000009A5EA4: 367676FF 0000FFFF
	v_mul_u32_u24_e32 v161, s6, v59                            // 0000009A5EAC: 17427606
	v_mul_u32_u24_e32 v59, s7, v59                             // 0000009A5EB0: 16767607
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009A5EB4: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A5EC0: BF870002
	v_lshl_add_u32 v59, v59, 24, v161                          // 0000009A5EC4: D646003B 0685313B
	v_and_b32_e32 v61, 0xffff, v61                             // 0000009A5ECC: 367A7AFF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009A5ED4: D622003E 03FD013E 00006400
	v_sad_u8 v163, v165, 0, 0x6400                             // 0000009A5EE0: D62200A3 03FD01A5 00006400
	v_and_b32_e32 v65, 0xffff, v65                             // 0000009A5EEC: 368282FF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009A5EF4: D622003B 03FD013B 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009A5F00: D6220042 03FD0142 00006400
	v_lshl_or_b32 v61, v62, 16, v61                            // 0000009A5F0C: D656003D 04F5213E
	v_sad_u8 v69, v69, 0, 0x6400                               // 0000009A5F14: D6220045 03FD0145 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 0000009A5F20: D622003F 03FD013F 00006400
	v_lshl_or_b32 v59, v59, 16, v65                            // 0000009A5F2C: D656003B 0505213B
	v_sad_u8 v70, v159, 0, 0x6400                              // 0000009A5F34: D6220046 03FD019F 00006400
	v_pk_fma_f16 v61, v61, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A5F40: CC0E003D 0BFC113D 0000C931
	v_and_b32_e32 v69, 0xffff, v69                             // 0000009A5F4C: 368A8AFF 0000FFFF
	v_bfe_u32 v160, v64, 3, 16                                 // 0000009A5F54: D61000A0 02410740
	v_pk_fma_f16 v59, v59, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A5F5C: CC0E003B 0BFC113B 0000C931
	v_mul_u32_u24_e32 v159, s6, v160                           // 0000009A5F68: 173F4006
	v_dual_dot2acc_f32_f16 v85, v61, v1 :: v_dual_and_b32 v162, 0xffff, v163// 0000009A5F6C: CB24033D 55A346FF 0000FFFF
	v_and_b32_e32 v64, 0xffff, v64                             // 0000009A5F78: 368080FF 0000FFFF
	v_mul_u32_u24_e32 v160, s7, v160                           // 0000009A5F80: 17414007
	v_lshl_add_u32 v159, v160, 24, v159                        // 0000009A5F84: D646009F 067D31A0
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A5F8C: BF870003
	v_dot2acc_f32_f16 v85, v59, v2                             // 0000009A5F90: 04AA053B
	v_and_b32_e32 v66, 0xffff, v66                             // 0000009A5F94: 368484FF 0000FFFF
	v_bfe_u32 v160, v60, 3, 16                                 // 0000009A5F9C: D61000A0 0241073C
	v_dot2acc_f32_f16 v9, v67, v4                              // 0000009A5FA4: 04120943
	v_mul_u32_u24_e32 v164, s6, v68                            // 0000009A5FA8: 17488806
	v_mul_u32_u24_e32 v68, s7, v68                             // 0000009A5FAC: 16888807
	v_lshl_or_b32 v63, v63, 16, v66                            // 0000009A5FB0: D656003F 0509213F
	v_lshl_or_b32 v66, v70, 16, v69                            // 0000009A5FB8: D6560042 05152146
	v_mul_u32_u24_e32 v70, s6, v64                             // 0000009A5FC0: 168C8006
	v_mul_u32_u24_e32 v64, s7, v64                             // 0000009A5FC4: 16808007
	v_lshl_add_u32 v64, v64, 24, v70                           // 0000009A5FC8: D6460040 05193140
	v_bfe_u32 v70, v60, 9, 16                                  // 0000009A5FD0: D6100046 0241133C
	v_mul_u32_u24_e32 v161, s6, v70                            // 0000009A5FD8: 17428C06
	v_mul_u32_u24_e32 v70, s7, v70                             // 0000009A5FDC: 168C8C07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009A5FE0: BF8700D1
	v_lshl_add_u32 v70, v70, 24, v161                          // 0000009A5FE4: D6460046 06853146
	v_sad_u8 v69, v159, 0, 0x6400                              // 0000009A5FEC: D6220045 03FD019F 00006400
	v_bfe_u32 v159, v60, 6, 16                                 // 0000009A5FF8: D610009F 02410D3C
	v_mul_u32_u24_e32 v161, s6, v159                           // 0000009A6000: 17433E06
	v_mul_u32_u24_e32 v159, s7, v159                           // 0000009A6004: 173F3E07
	v_lshl_add_u32 v159, v159, 24, v161                        // 0000009A6008: D646009F 0685319F
	v_mul_u32_u24_e32 v161, s6, v160                           // 0000009A6010: 17434006
	v_mul_u32_u24_e32 v160, s7, v160                           // 0000009A6014: 17414007
	v_sad_u8 v70, v70, 0, 0x6400                               // 0000009A6018: D6220046 03FD0146 00006400
	v_lshl_add_u32 v160, v160, 24, v161                        // 0000009A6024: D64600A0 068531A0
	v_and_b32_e32 v60, 0xffff, v60                             // 0000009A602C: 367878FF 0000FFFF
	v_sad_u8 v65, v159, 0, 0x6400                              // 0000009A6034: D6220041 03FD019F 00006400
	v_mul_u32_u24_e32 v159, s6, v60                            // 0000009A6040: 173E7806
	v_mul_u32_u24_e32 v60, s7, v60                             // 0000009A6044: 16787807
	v_and_b32_e32 v62, 0xffff, v70                             // 0000009A6048: 367C8CFF 0000FFFF
	v_sad_u8 v70, v160, 0, 0x6400                              // 0000009A6050: D6220046 03FD01A0 00006400
	v_lshl_add_u32 v60, v60, 24, v159                          // 0000009A605C: D646003C 067D313C
	v_pk_fma_f16 v63, v63, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6064: CC0E003F 0BFC113F 0000C931
	v_and_b32_e32 v69, 0xffff, v69                             // 0000009A6070: 368A8AFF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009A6078: D6220040 03FD0140 00006400
	v_lshl_or_b32 v62, v65, 16, v62                            // 0000009A6084: D656003E 04F92141
	v_and_b32_e32 v65, 0xffff, v70                             // 0000009A608C: 36828CFF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009A6094: D622003C 03FD013C 00006400
	v_pk_fma_f16 v66, v66, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A60A0: CC0E0042 0BFC1142 0000C931
	v_lshl_or_b32 v61, v64, 16, v69                            // 0000009A60AC: D656003D 05152140
	v_dot2acc_f32_f16 v86, v63, v2                             // 0000009A60B4: 04AC053F
	v_pk_fma_f16 v62, v62, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A60B8: CC0E003E 0BFC113E 0000C931
	v_lshl_or_b32 v60, v60, 16, v65                            // 0000009A60C4: D656003C 0505213C
	v_lshl_add_u32 v68, v68, 24, v164                          // 0000009A60CC: D6460044 06913144
	.long 0xd73d0037                                           // 0000009A60D4: D73D0037
	v_cndmask_b32_e32 v1, v90, v55, vcc_lo                     // 0000009A60D8: 02026F5A
	v_pk_fma_f16 v59, v61, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A60DC: CC0E003B 0BFC113D 0000C931
	v_dot2acc_f32_f16 v86, v66, v3                             // 0000009A60E8: 04AC0742
	v_pk_fma_f16 v56, v60, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A60EC: CC0E0038 0BFC113C 0000C931
	v_dot2acc_f32_f16 v85, v62, v3                             // 0000009A60F8: 04AA073E
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000009A60FC: D6220044 03FD0144 00006400
	v_bfe_u32 v60, v55, 6, 16                                  // 0000009A6108: D610003C 02410D37
	v_dot2acc_f32_f16 v86, v59, v4                             // 0000009A6110: 04AC093B
	v_bfe_u32 v59, v55, 9, 16                                  // 0000009A6114: D610003B 02411337
	v_dot2acc_f32_f16 v85, v56, v4                             // 0000009A611C: 04AA0938
	s_waitcnt vmcnt(35)                                        // 0000009A6120: BF898FF7
	.long 0xd73d0038                                           // 0000009A6124: D73D0038
	v_cndmask_b32_e32 v1, v92, v57, vcc_lo                     // 0000009A6128: 0202735C
	v_mul_u32_u24_e32 v58, s6, v59                             // 0000009A612C: 16747606
	v_lshl_or_b32 v68, v68, 16, v162                           // 0000009A6130: D6560044 06892144
	v_mul_u32_u24_e32 v59, s7, v59                             // 0000009A6138: 16767607
	v_lshl_add_u32 v58, v59, 24, v58                           // 0000009A613C: D646003A 04E9313B
	v_bfe_u32 v57, v55, 3, 16                                  // 0000009A6144: D6100039 02410737
	v_mul_u32_u24_e32 v63, s6, v60                             // 0000009A614C: 167E7806
	v_mul_u32_u24_e32 v60, s7, v60                             // 0000009A6150: 16787807
	v_pk_fma_f16 v68, v68, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6154: CC0E0044 0BFC1144 0000C931
	v_bfe_u32 v59, v56, 9, 16                                  // 0000009A6160: D610003B 02411338
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009A6168: D622003A 03FD013A 00006400
	v_lshl_add_u32 v60, v60, 24, v63                           // 0000009A6174: D646003C 04FD313C
	v_mul_u32_u24_e32 v63, s6, v57                             // 0000009A617C: 167E7206
	v_mul_u32_u24_e32 v57, s7, v57                             // 0000009A6180: 16727207
	v_lshl_add_u32 v57, v57, 24, v63                           // 0000009A6184: D6460039 04FD3139
	v_mul_u32_u24_e32 v63, s6, v59                             // 0000009A618C: 167E7606
	v_mul_u32_u24_e32 v59, s7, v59                             // 0000009A6190: 16767607
	v_lshl_add_u32 v59, v59, 24, v63                           // 0000009A6194: D646003B 04FD313B
	v_and_b32_e32 v55, 0xffff, v55                             // 0000009A619C: 366E6EFF 0000FFFF
	v_bfe_u32 v61, v56, 6, 16                                  // 0000009A61A4: D610003D 02410D38
	v_mul_u32_u24_e32 v63, s6, v55                             // 0000009A61AC: 167E6E06
	v_mul_u32_u24_e32 v55, s7, v55                             // 0000009A61B0: 166E6E07
	v_dual_dot2acc_f32_f16 v87, v68, v4 :: v_dual_and_b32 v58, 0xffff, v58// 0000009A61B4: CB240944 573A74FF 0000FFFF
	v_bfe_u32 v62, v56, 3, 16                                  // 0000009A61C0: D610003E 02410738
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009A61C8: D622003C 03FD013C 00006400
	v_lshl_add_u32 v55, v55, 24, v63                           // 0000009A61D4: D6460037 04FD3137
	v_mul_u32_u24_e32 v63, s6, v61                             // 0000009A61DC: 167E7A06
	v_mul_u32_u24_e32 v61, s7, v61                             // 0000009A61E0: 167A7A07
	v_lshl_add_u32 v61, v61, 24, v63                           // 0000009A61E4: D646003D 04FD313D
	v_mul_u32_u24_e32 v63, s6, v62                             // 0000009A61EC: 167E7C06
	v_mul_u32_u24_e32 v62, s7, v62                             // 0000009A61F0: 167C7C07
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009A61F4: D6220039 03FD0139 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009A6200: D622003B 03FD013B 00006400
	v_lshl_add_u32 v62, v62, 24, v63                           // 0000009A620C: D646003E 04FD313E
	v_lshl_or_b32 v58, v60, 16, v58                            // 0000009A6214: D656003A 04E9213C
	.long 0xd73d0033                                           // 0000009A621C: D73D0033
	v_cndmask_b32_e32 v1, v90, v51, vcc_lo                     // 0000009A6220: 0202675A
	v_and_b32_e32 v57, 0xffff, v57                             // 0000009A6224: 367272FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009A622C: D6220037 03FD0137 00006400
	v_and_b32_e32 v59, 0xffff, v59                             // 0000009A6238: 367676FF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009A6240: D622003D 03FD013D 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009A624C: D622003E 03FD013E 00006400
	v_pk_fma_f16 v58, v58, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6258: CC0E003A 0BFC113A 0000C931
	s_waitcnt vmcnt(34)                                        // 0000009A6264: BF898BF7
	.long 0xd73d0034                                           // 0000009A6268: D73D0034
	v_cndmask_b32_e32 v1, v92, v53, vcc_lo                     // 0000009A626C: 02026B5C
	v_bfe_u32 v53, v51, 9, 16                                  // 0000009A6270: D6100035 02411333
	v_lshl_or_b32 v55, v55, 16, v57                            // 0000009A6278: D6560037 04E52137
	v_lshl_or_b32 v57, v61, 16, v59                            // 0000009A6280: D6560039 04ED213D
	v_and_b32_e32 v59, 0xffff, v62                             // 0000009A6288: 36767CFF 0000FFFF
	v_mul_u32_u24_e32 v62, s6, v53                             // 0000009A6290: 167C6A06
	v_mul_u32_u24_e32 v53, s7, v53                             // 0000009A6294: 166A6A07
	v_lshl_add_u32 v53, v53, 24, v62                           // 0000009A6298: D6460035 04F93135
	v_dot2acc_f32_f16 v84, v58, v1                             // 0000009A62A0: 04A8033A
	v_bfe_u32 v58, v51, 3, 16                                  // 0000009A62A4: D610003A 02410733
	v_bfe_u32 v54, v51, 6, 16                                  // 0000009A62AC: D6100036 02410D33
	v_mul_u32_u24_e32 v62, s6, v58                             // 0000009A62B4: 167C7406
	v_mul_u32_u24_e32 v58, s7, v58                             // 0000009A62B8: 16747407
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A62BC: BF870002
	v_lshl_add_u32 v58, v58, 24, v62                           // 0000009A62C0: D646003A 04F9313A
	v_mul_u32_u24_e32 v62, s6, v54                             // 0000009A62C8: 167C6C06
	v_mul_u32_u24_e32 v54, s7, v54                             // 0000009A62CC: 166C6C07
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009A62D0: D6220035 03FD0135 00006400
	v_lshl_add_u32 v54, v54, 24, v62                           // 0000009A62DC: D6460036 04F93136
	v_and_b32_e32 v51, 0xffff, v51                             // 0000009A62E4: 366666FF 0000FFFF
	v_mul_u32_u24_e32 v62, s6, v51                             // 0000009A62EC: 167C6606
	v_mul_u32_u24_e32 v51, s7, v51                             // 0000009A62F0: 16666607
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009A62F4: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A6300: BF870002
	v_lshl_add_u32 v51, v51, 24, v62                           // 0000009A6304: D6460033 04F93133
	v_and_b32_e32 v53, 0xffff, v53                             // 0000009A630C: 366A6AFF 0000FFFF
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009A6314: D6220036 03FD0136 00006400
	v_bfe_u32 v60, v52, 6, 16                                  // 0000009A6320: D610003C 02410D34
	v_and_b32_e32 v58, 0xffff, v58                             // 0000009A6328: 367474FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009A6330: D6220033 03FD0133 00006400
	.long 0xd73d002f                                           // 0000009A633C: D73D002F
	v_cndmask_b32_e32 v1, v90, v47, vcc_lo                     // 0000009A6340: 02025F5A
	v_lshl_or_b32 v53, v54, 16, v53                            // 0000009A6344: D6560035 04D52136
	v_pk_fma_f16 v55, v55, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A634C: CC0E0037 0BFC1137 0000C931
	v_bfe_u32 v61, v52, 3, 16                                  // 0000009A6358: D610003D 02410734
	v_lshl_or_b32 v51, v51, 16, v58                            // 0000009A6360: D6560033 04E92133
	v_pk_fma_f16 v57, v57, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6368: CC0E0039 0BFC1139 0000C931
	v_pk_fma_f16 v53, v53, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6374: CC0E0035 0BFC1135 0000C931
	v_dot2acc_f32_f16 v84, v55, v2                             // 0000009A6380: 04A80537
	.long 0xd73d002b                                           // 0000009A6384: D73D002B
	v_cndmask_b32_e32 v1, v90, v43, vcc_lo                     // 0000009A6388: 0202575A
	v_pk_fma_f16 v51, v51, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A638C: CC0E0033 0BFC1133 0000C931
	s_waitcnt vmcnt(32)                                        // 0000009A6398: BF8983F7
	.long 0xd73d002c                                           // 0000009A639C: D73D002C
	v_cndmask_b32_e32 v1, v92, v45, vcc_lo                     // 0000009A63A0: 02025B5C
	v_dual_dot2acc_f32_f16 v83, v53, v1 :: v_dual_and_b32 v56, 0xffff, v56// 0000009A63A4: CB240335 533870FF 0000FFFF
	v_bfe_u32 v53, v47, 9, 16                                  // 0000009A63B0: D6100035 0241132F
	v_dot2acc_f32_f16 v84, v57, v3                             // 0000009A63B8: 04A80739
	v_bfe_u32 v45, v43, 9, 16                                  // 0000009A63BC: D610002D 0241132B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A63C4: BF870004
	v_dot2acc_f32_f16 v83, v51, v2                             // 0000009A63C8: 04A60533
	v_mul_u32_u24_e32 v63, s6, v56                             // 0000009A63CC: 167E7006
	v_mul_u32_u24_e32 v56, s7, v56                             // 0000009A63D0: 16707007
	v_lshl_add_u32 v56, v56, 24, v63                           // 0000009A63D4: D6460038 04FD3138
	v_bfe_u32 v46, v43, 6, 16                                  // 0000009A63DC: D610002E 02410D2B
	s_waitcnt vmcnt(23)                                        // 0000009A63E4: BF895FF7
	.long 0xd73d0027                                           // 0000009A63E8: D73D0027
	v_cndmask_b32_e32 v1, v90, v39, vcc_lo                     // 0000009A63EC: 02024F5A
	s_waitcnt vmcnt(22)                                        // 0000009A63F0: BF895BF7
	.long 0xd73d0023                                           // 0000009A63F4: D73D0023
	v_cndmask_b32_e32 v1, v90, v35, vcc_lo                     // 0000009A63F8: 0202475A
	s_waitcnt vmcnt(6)                                         // 0000009A63FC: BF891BF7
	.long 0xd73d0024                                           // 0000009A6400: D73D0024
	v_cndmask_b32_e32 v1, v92, v37, vcc_lo                     // 0000009A6404: 02024B5C
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009A6408: D6220038 03FD0138 00006400
	.long 0xd73d001f                                           // 0000009A6414: D73D001F
	v_cndmask_b32_e32 v1, v90, v31, vcc_lo                     // 0000009A6418: 02023F5A
	.long 0xd73d001b                                           // 0000009A641C: D73D001B
	v_cndmask_b32_e32 v1, v90, v27, vcc_lo                     // 0000009A6420: 0202375A
	s_waitcnt vmcnt(4)                                         // 0000009A6424: BF8913F7
	.long 0xd73d001c                                           // 0000009A6428: D73D001C
	v_cndmask_b32_e32 v1, v92, v29, vcc_lo                     // 0000009A642C: 02023B5C
	v_bfe_u32 v37, v35, 9, 16                                  // 0000009A6430: D6100025 02411323
	v_lshl_or_b32 v56, v56, 16, v59                            // 0000009A6438: D6560038 04ED2138
	v_bfe_u32 v59, v52, 9, 16                                  // 0000009A6440: D610003B 02411334
	v_mul_u32_u24_e32 v62, s6, v59                             // 0000009A6448: 167C7606
	v_mul_u32_u24_e32 v59, s7, v59                             // 0000009A644C: 16767607
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A6450: BF870001
	v_lshl_add_u32 v59, v59, 24, v62                           // 0000009A6454: D646003B 04F9313B
	v_mul_u32_u24_e32 v62, s6, v60                             // 0000009A645C: 167C7806
	v_mul_u32_u24_e32 v60, s7, v60                             // 0000009A6460: 16787807
	v_lshl_add_u32 v60, v60, 24, v62                           // 0000009A6464: D646003C 04F9313C
	v_mul_u32_u24_e32 v62, s6, v61                             // 0000009A646C: 167C7A06
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009A6470: D622003B 03FD013B 00006400
	v_mul_u32_u24_e32 v61, s7, v61                             // 0000009A647C: 167A7A07
	v_lshl_add_u32 v61, v61, 24, v62                           // 0000009A6480: D646003D 04F9313D
	v_sad_u8 v58, v60, 0, 0x6400                               // 0000009A6488: D622003A 03FD013C 00006400
	v_pk_fma_f16 v51, v56, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6494: CC0E0033 0BFC1138 0000C931
	v_and_b32_e32 v54, 0xffff, v59                             // 0000009A64A0: 366C76FF 0000FFFF
	v_bfe_u32 v38, v35, 6, 16                                  // 0000009A64A8: D6100026 02410D23
	v_sad_u8 v59, v61, 0, 0x6400                               // 0000009A64B0: D622003B 03FD013D 00006400
	v_bfe_u32 v29, v27, 9, 16                                  // 0000009A64BC: D610001D 0241131B
	v_bfe_u32 v30, v27, 6, 16                                  // 0000009A64C4: D610001E 02410D1B
	v_lshl_or_b32 v54, v58, 16, v54                            // 0000009A64CC: D6560036 04D9213A
	.long 0xd73d0015                                           // 0000009A64D4: D73D0015
	v_cndmask_b32_e32 v1, v90, v21, vcc_lo                     // 0000009A64D8: 02022B5A
	.long 0xd73d0011                                           // 0000009A64DC: D73D0011
	v_cndmask_b32_e32 v1, v90, v17, vcc_lo                     // 0000009A64E0: 0202235A
	s_waitcnt vmcnt(2)                                         // 0000009A64E4: BF890BF7
	.long 0xd73d0012                                           // 0000009A64E8: D73D0012
	v_cndmask_b32_e32 v1, v92, v19, vcc_lo                     // 0000009A64EC: 0202275C
	.long 0xd73d000b                                           // 0000009A64F0: D73D000B
	v_cndmask_b32_e32 v1, v90, v11, vcc_lo                     // 0000009A64F4: 0202175A
	v_pk_fma_f16 v48, v54, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A64F8: CC0E0030 0BFC1136 0000C931
	v_and_b32_e32 v52, 0xffff, v52                             // 0000009A6504: 366868FF 0000FFFF
	v_bfe_u32 v54, v47, 6, 16                                  // 0000009A650C: D6100036 02410D2F
	v_mul_u32_u24_e32 v57, s6, v54                             // 0000009A6514: 16726C06
	v_mul_u32_u24_e32 v54, s7, v54                             // 0000009A6518: 166C6C07
	v_dot2acc_f32_f16 v83, v48, v3                             // 0000009A651C: 04A60730
	.long 0xd73d0030                                           // 0000009A6520: D73D0030
	v_cndmask_b32_e32 v1, v92, v49, vcc_lo                     // 0000009A6524: 0202635C
	v_mul_u32_u24_e32 v49, s6, v53                             // 0000009A6528: 16626A06
	v_mul_u32_u24_e32 v50, s7, v53                             // 0000009A652C: 16646A07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A6530: BF870001
	v_lshl_add_u32 v49, v50, 24, v49                           // 0000009A6534: D6460031 04C53132
	v_lshl_add_u32 v54, v54, 24, v57                           // 0000009A653C: D6460036 04E53136
	v_bfe_u32 v50, v47, 3, 16                                  // 0000009A6544: D6100032 0241072F
	v_bfe_u32 v53, v48, 9, 16                                  // 0000009A654C: D6100035 02411330
	v_mul_u32_u24_e32 v57, s6, v50                             // 0000009A6554: 16726406
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009A6558: D6220031 03FD0131 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009A6564: D6220036 03FD0136 00006400
	v_mul_u32_u24_e32 v50, s7, v50                             // 0000009A6570: 16646407
	v_and_b32_e32 v47, 0xffff, v47                             // 0000009A6574: 365E5EFF 0000FFFF
	v_lshl_add_u32 v50, v50, 24, v57                           // 0000009A657C: D6460032 04E53132
	v_and_b32_e32 v49, 0xffff, v49                             // 0000009A6584: 366262FF 0000FFFF
	v_mul_u32_u24_e32 v57, s6, v53                             // 0000009A658C: 16726A06
	v_mul_u32_u24_e32 v53, s7, v53                             // 0000009A6590: 166A6A07
	v_bfe_u32 v55, v48, 6, 16                                  // 0000009A6594: D6100037 02410D30
	v_lshl_add_u32 v53, v53, 24, v57                           // 0000009A659C: D6460035 04E53135
	v_lshl_or_b32 v49, v54, 16, v49                            // 0000009A65A4: D6560031 04C52136
	v_mul_u32_u24_e32 v57, s6, v47                             // 0000009A65AC: 16725E06
	v_mul_u32_u24_e32 v47, s7, v47                             // 0000009A65B0: 165E5E07
	v_lshl_add_u32 v47, v47, 24, v57                           // 0000009A65B4: D646002F 04E5312F
	v_mul_u32_u24_e32 v57, s6, v55                             // 0000009A65BC: 16726E06
	v_pk_fma_f16 v49, v49, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A65C0: CC0E0031 0BFC1131 0000C931
	v_mul_u32_u24_e32 v55, s7, v55                             // 0000009A65CC: 166E6E07
	v_lshl_add_u32 v55, v55, 24, v57                           // 0000009A65D0: D6460037 04E53137
	v_mul_u32_u24_e32 v57, s6, v45                             // 0000009A65D8: 16725A06
	v_mul_u32_u24_e32 v45, s7, v45                             // 0000009A65DC: 165A5A07
	v_lshl_add_u32 v45, v45, 24, v57                           // 0000009A65E0: D646002D 04E5312D
	v_dot2acc_f32_f16 v82, v49, v1                             // 0000009A65E8: 04A40331
	v_bfe_u32 v49, v43, 3, 16                                  // 0000009A65EC: D6100031 0241072B
	v_mul_u32_u24_e32 v57, s6, v49                             // 0000009A65F4: 16726206
	v_mul_u32_u24_e32 v49, s7, v49                             // 0000009A65F8: 16626207
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A65FC: BF870001
	v_lshl_add_u32 v49, v49, 24, v57                           // 0000009A6600: D6460031 04E53131
	v_mul_u32_u24_e32 v57, s6, v46                             // 0000009A6608: 16725C06
	v_mul_u32_u24_e32 v46, s7, v46                             // 0000009A660C: 165C5C07
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009A6610: D622002D 03FD012D 00006400
	v_lshl_add_u32 v46, v46, 24, v57                           // 0000009A661C: D646002E 04E5312E
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009A6624: 365656FF 0000FFFF
	v_mul_u32_u24_e32 v57, s6, v43                             // 0000009A662C: 16725606
	v_mul_u32_u24_e32 v43, s7, v43                             // 0000009A6630: 16565607
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009A6634: D6220031 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A6640: BF870002
	v_lshl_add_u32 v43, v43, 24, v57                           // 0000009A6644: D646002B 04E5312B
	v_and_b32_e32 v45, 0xffff, v45                             // 0000009A664C: 365A5AFF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009A6654: D622002E 03FD012E 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009A6660: D6220032 03FD0132 00006400
	v_and_b32_e32 v49, 0xffff, v49                             // 0000009A666C: 366262FF 0000FFFF
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009A6674: D622002B 03FD012B 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009A6680: D6220035 03FD0135 00006400
	v_lshl_or_b32 v45, v46, 16, v45                            // 0000009A668C: D656002D 04B5212E
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009A6694: D622002F 03FD012F 00006400
	v_sad_u8 v54, v55, 0, 0x6400                               // 0000009A66A0: D6220036 03FD0137 00006400
	v_lshl_or_b32 v43, v43, 16, v49                            // 0000009A66AC: D656002B 04C5212B
	v_and_b32_e32 v53, 0xffff, v53                             // 0000009A66B4: 366A6AFF 0000FFFF
	v_pk_fma_f16 v45, v45, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A66BC: CC0E002D 0BFC112D 0000C931
	v_mul_u32_u24_e32 v60, s6, v52                             // 0000009A66C8: 16786806
	v_mul_u32_u24_e32 v52, s7, v52                             // 0000009A66CC: 16686807
	v_pk_fma_f16 v43, v43, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A66D0: CC0E002B 0BFC112B 0000C931
	v_lshl_add_u32 v52, v52, 24, v60                           // 0000009A66DC: D6460034 04F13134
	v_dual_dot2acc_f32_f16 v81, v45, v1 :: v_dual_and_b32 v58, 0xffff, v59// 0000009A66E4: CB24032D 513A76FF 0000FFFF
	v_bfe_u32 v56, v48, 3, 16                                  // 0000009A66F0: D6100038 02410730
	v_mul_u32_u24_e32 v55, s6, v56                             // 0000009A66F8: 166E7006
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A66FC: BF870002
	v_dual_dot2acc_f32_f16 v81, v43, v2 :: v_dual_and_b32 v48, 0xffff, v48// 0000009A6700: CB24052B 513060FF 0000FFFF
	v_and_b32_e32 v50, 0xffff, v50                             // 0000009A670C: 366464FF 0000FFFF
	v_mul_u32_u24_e32 v56, s7, v56                             // 0000009A6714: 16707007
	v_lshl_add_u32 v55, v56, 24, v55                           // 0000009A6718: D6460037 04DD3138
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009A6720: D6220034 03FD0134 00006400
	v_bfe_u32 v56, v44, 3, 16                                  // 0000009A672C: D6100038 0241072C
	v_lshl_or_b32 v47, v47, 16, v50                            // 0000009A6734: D656002F 04C9212F
	v_lshl_or_b32 v50, v54, 16, v53                            // 0000009A673C: D6560032 04D52136
	v_mul_u32_u24_e32 v54, s6, v48                             // 0000009A6744: 166C6006
	v_mul_u32_u24_e32 v48, s7, v48                             // 0000009A6748: 16606007
	v_lshl_add_u32 v48, v48, 24, v54                           // 0000009A674C: D6460030 04D93130
	v_bfe_u32 v54, v44, 9, 16                                  // 0000009A6754: D6100036 0241132C
	v_mul_u32_u24_e32 v57, s6, v54                             // 0000009A675C: 16726C06
	v_mul_u32_u24_e32 v54, s7, v54                             // 0000009A6760: 166C6C07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009A6764: BF8700D1
	v_lshl_add_u32 v54, v54, 24, v57                           // 0000009A6768: D6460036 04E53136
	v_sad_u8 v53, v55, 0, 0x6400                               // 0000009A6770: D6220035 03FD0137 00006400
	v_bfe_u32 v55, v44, 6, 16                                  // 0000009A677C: D6100037 02410D2C
	v_mul_u32_u24_e32 v57, s6, v55                             // 0000009A6784: 16726E06
	v_mul_u32_u24_e32 v55, s7, v55                             // 0000009A6788: 166E6E07
	v_lshl_add_u32 v55, v55, 24, v57                           // 0000009A678C: D6460037 04E53137
	v_mul_u32_u24_e32 v57, s6, v56                             // 0000009A6794: 16727006
	v_mul_u32_u24_e32 v56, s7, v56                             // 0000009A6798: 16707007
	v_lshl_or_b32 v52, v52, 16, v58                            // 0000009A679C: D6560034 04E92134
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009A67A4: D6220036 03FD0136 00006400
	v_lshl_add_u32 v56, v56, 24, v57                           // 0000009A67B0: D6460038 04E53138
	v_and_b32_e32 v44, 0xffff, v44                             // 0000009A67B8: 365858FF 0000FFFF
	v_sad_u8 v49, v55, 0, 0x6400                               // 0000009A67C0: D6220031 03FD0137 00006400
	v_mul_u32_u24_e32 v55, s6, v44                             // 0000009A67CC: 166E5806
	v_mul_u32_u24_e32 v44, s7, v44                             // 0000009A67D0: 16585807
	v_pk_fma_f16 v52, v52, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A67D4: CC0E0034 0BFC1134 0000C931
	v_and_b32_e32 v46, 0xffff, v54                             // 0000009A67E0: 365C6CFF 0000FFFF
	v_sad_u8 v54, v56, 0, 0x6400                               // 0000009A67E8: D6220036 03FD0138 00006400
	v_lshl_add_u32 v44, v44, 24, v55                           // 0000009A67F4: D646002C 04DD312C
	v_pk_fma_f16 v47, v47, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A67FC: CC0E002F 0BFC112F 0000C931
	v_and_b32_e32 v53, 0xffff, v53                             // 0000009A6808: 366A6AFF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000009A6810: D6220030 03FD0130 00006400
	v_dot2acc_f32_f16 v83, v52, v4                             // 0000009A681C: 04A60934
	v_lshl_or_b32 v46, v49, 16, v46                            // 0000009A6820: D656002E 04B92131
	v_and_b32_e32 v49, 0xffff, v54                             // 0000009A6828: 36626CFF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009A6830: D622002C 03FD012C 00006400
	v_pk_fma_f16 v50, v50, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A683C: CC0E0032 0BFC1132 0000C931
	v_lshl_or_b32 v45, v48, 16, v53                            // 0000009A6848: D656002D 04D52130
	v_dot2acc_f32_f16 v82, v47, v2                             // 0000009A6850: 04A4052F
	v_pk_fma_f16 v46, v46, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6854: CC0E002E 0BFC112E 0000C931
	v_lshl_or_b32 v44, v44, 16, v49                            // 0000009A6860: D656002C 04C5212C
	v_bfe_u32 v19, v17, 9, 16                                  // 0000009A6868: D6100013 02411311
	v_pk_fma_f16 v43, v45, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6870: CC0E002B 0BFC112D 0000C931
	v_dot2acc_f32_f16 v82, v50, v3                             // 0000009A687C: 04A40732
	v_dot2acc_f32_f16 v81, v46, v3                             // 0000009A6880: 04A2072E
	v_pk_fma_f16 v40, v44, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6884: CC0E0028 0BFC112C 0000C931
	v_bfe_u32 v44, v39, 6, 16                                  // 0000009A6890: D610002C 02410D27
	v_mul_u32_u24_e32 v47, s6, v44                             // 0000009A6898: 165E5806
	v_dot2acc_f32_f16 v82, v43, v4                             // 0000009A689C: 04A4092B
	v_bfe_u32 v43, v39, 9, 16                                  // 0000009A68A0: D610002B 02411327
	v_dot2acc_f32_f16 v81, v40, v4                             // 0000009A68A8: 04A20928
	.long 0xd73d0028                                           // 0000009A68AC: D73D0028
	v_cndmask_b32_e32 v1, v92, v41, vcc_lo                     // 0000009A68B0: 0202535C
	v_mul_u32_u24_e32 v42, s6, v43                             // 0000009A68B4: 16545606
	v_mul_u32_u24_e32 v43, s7, v43                             // 0000009A68B8: 16565607
	v_lshl_add_u32 v42, v43, 24, v42                           // 0000009A68BC: D646002A 04A9312B
	v_bfe_u32 v41, v39, 3, 16                                  // 0000009A68C4: D6100029 02410727
	v_mul_u32_u24_e32 v44, s7, v44                             // 0000009A68CC: 16585807
	v_bfe_u32 v43, v40, 9, 16                                  // 0000009A68D0: D610002B 02411328
	v_lshl_add_u32 v44, v44, 24, v47                           // 0000009A68D8: D646002C 04BD312C
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009A68E0: D622002A 03FD012A 00006400
	v_mul_u32_u24_e32 v47, s6, v41                             // 0000009A68EC: 165E5206
	v_mul_u32_u24_e32 v41, s7, v41                             // 0000009A68F0: 16525207
	v_lshl_add_u32 v41, v41, 24, v47                           // 0000009A68F4: D6460029 04BD3129
	v_mul_u32_u24_e32 v47, s6, v43                             // 0000009A68FC: 165E5606
	v_mul_u32_u24_e32 v43, s7, v43                             // 0000009A6900: 16565607
	v_lshl_add_u32 v43, v43, 24, v47                           // 0000009A6904: D646002B 04BD312B
	v_and_b32_e32 v39, 0xffff, v39                             // 0000009A690C: 364E4EFF 0000FFFF
	v_bfe_u32 v45, v40, 6, 16                                  // 0000009A6914: D610002D 02410D28
	v_mul_u32_u24_e32 v47, s6, v39                             // 0000009A691C: 165E4E06
	v_mul_u32_u24_e32 v39, s7, v39                             // 0000009A6920: 164E4E07
	v_bfe_u32 v46, v40, 3, 16                                  // 0000009A6924: D610002E 02410728
	v_and_b32_e32 v42, 0xffff, v42                             // 0000009A692C: 365454FF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009A6934: D622002C 03FD012C 00006400
	v_lshl_add_u32 v39, v39, 24, v47                           // 0000009A6940: D6460027 04BD3127
	v_mul_u32_u24_e32 v47, s6, v45                             // 0000009A6948: 165E5A06
	v_mul_u32_u24_e32 v45, s7, v45                             // 0000009A694C: 165A5A07
	v_lshl_add_u32 v45, v45, 24, v47                           // 0000009A6950: D646002D 04BD312D
	v_mul_u32_u24_e32 v47, s6, v46                             // 0000009A6958: 165E5C06
	v_mul_u32_u24_e32 v46, s7, v46                             // 0000009A695C: 165C5C07
	v_sad_u8 v41, v41, 0, 0x6400                               // 0000009A6960: D6220029 03FD0129 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009A696C: D622002B 03FD012B 00006400
	v_lshl_add_u32 v46, v46, 24, v47                           // 0000009A6978: D646002E 04BD312E
	v_lshl_or_b32 v42, v44, 16, v42                            // 0000009A6980: D656002A 04A9212C
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000009A6988: D6220027 03FD0127 00006400
	v_and_b32_e32 v41, 0xffff, v41                             // 0000009A6994: 365252FF 0000FFFF
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009A699C: 365656FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009A69A4: D622002D 03FD012D 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009A69B0: D622002E 03FD012E 00006400
	v_pk_fma_f16 v42, v42, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A69BC: CC0E002A 0BFC112A 0000C931
	v_lshl_or_b32 v39, v39, 16, v41                            // 0000009A69C8: D6560027 04A52127
	v_bfe_u32 v44, v36, 6, 16                                  // 0000009A69D0: D610002C 02410D24
	v_lshl_or_b32 v41, v45, 16, v43                            // 0000009A69D8: D6560029 04AD212D
	v_and_b32_e32 v43, 0xffff, v46                             // 0000009A69E0: 36565CFF 0000FFFF
	v_mul_u32_u24_e32 v46, s6, v37                             // 0000009A69E8: 165C4A06
	v_mul_u32_u24_e32 v37, s7, v37                             // 0000009A69EC: 164A4A07
	v_lshl_add_u32 v37, v37, 24, v46                           // 0000009A69F0: D6460025 04B93125
	v_dot2acc_f32_f16 v80, v42, v1                             // 0000009A69F8: 04A0032A
	v_bfe_u32 v42, v35, 3, 16                                  // 0000009A69FC: D610002A 02410723
	v_mul_u32_u24_e32 v46, s6, v42                             // 0000009A6A04: 165C5406
	v_mul_u32_u24_e32 v42, s7, v42                             // 0000009A6A08: 16545407
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A6A0C: BF870001
	v_lshl_add_u32 v42, v42, 24, v46                           // 0000009A6A10: D646002A 04B9312A
	v_mul_u32_u24_e32 v46, s6, v38                             // 0000009A6A18: 165C4C06
	v_mul_u32_u24_e32 v38, s7, v38                             // 0000009A6A1C: 164C4C07
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000009A6A20: D6220025 03FD0125 00006400
	v_lshl_add_u32 v38, v38, 24, v46                           // 0000009A6A2C: D6460026 04B93126
	v_and_b32_e32 v35, 0xffff, v35                             // 0000009A6A34: 364646FF 0000FFFF
	v_mul_u32_u24_e32 v46, s6, v35                             // 0000009A6A3C: 165C4606
	v_mul_u32_u24_e32 v35, s7, v35                             // 0000009A6A40: 16464607
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009A6A44: D622002A 03FD012A 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A6A50: BF870002
	v_lshl_add_u32 v35, v35, 24, v46                           // 0000009A6A54: D6460023 04B93123
	v_and_b32_e32 v37, 0xffff, v37                             // 0000009A6A5C: 364A4AFF 0000FFFF
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000009A6A64: D6220026 03FD0126 00006400
	v_pk_fma_f16 v39, v39, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6A70: CC0E0027 0BFC1127 0000C931
	v_and_b32_e32 v42, 0xffff, v42                             // 0000009A6A7C: 365454FF 0000FFFF
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000009A6A84: D6220023 03FD0123 00006400
	v_pk_fma_f16 v41, v41, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6A90: CC0E0029 0BFC1129 0000C931
	v_lshl_or_b32 v37, v38, 16, v37                            // 0000009A6A9C: D6560025 04952126
	v_dot2acc_f32_f16 v80, v39, v2                             // 0000009A6AA4: 04A00527
	v_bfe_u32 v45, v36, 3, 16                                  // 0000009A6AA8: D610002D 02410724
	v_lshl_or_b32 v35, v35, 16, v42                            // 0000009A6AB0: D6560023 04A92123
	v_bfe_u32 v20, v17, 6, 16                                  // 0000009A6AB8: D6100014 02410D11
	v_pk_fma_f16 v37, v37, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6AC0: CC0E0025 0BFC1125 0000C931
	v_dot2acc_f32_f16 v80, v41, v3                             // 0000009A6ACC: 04A00729
	.long 0xd73d0005                                           // 0000009A6AD0: D73D0005
	v_cndmask_b32_e32 v1, v90, v5, vcc_lo                      // 0000009A6AD4: 02020B5A
	v_pk_fma_f16 v35, v35, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6AD8: CC0E0023 0BFC1123 0000C931
	s_waitcnt vmcnt(0)                                         // 0000009A6AE4: BF8903F7
	.long 0xd73d0006                                           // 0000009A6AE8: D73D0006
	v_cndmask_b32_e32 v1, v92, v7, vcc_lo                      // 0000009A6AEC: 02020F5C
	v_dot2acc_f32_f16 v79, v37, v1                             // 0000009A6AF0: 049E0325
	v_bfe_u32 v37, v31, 9, 16                                  // 0000009A6AF4: D6100025 0241131F
	v_add_nc_u32_e32 v88, 1, v88                               // 0000009A6AFC: 4AB0B081
	v_bfe_u32 v7, v5, 9, 16                                    // 0000009A6B00: D6100007 02411305
	v_bfe_u32 v8, v5, 6, 16                                    // 0000009A6B08: D6100008 02410D05
	v_dual_dot2acc_f32_f16 v79, v35, v2 :: v_dual_and_b32 v40, 0xffff, v40// 0000009A6B10: CB240523 4F2850FF 0000FFFF
	v_mul_u32_u24_e32 v47, s6, v40                             // 0000009A6B1C: 165E5006
	v_mul_u32_u24_e32 v40, s7, v40                             // 0000009A6B20: 16505007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009A6B24: BF8701B1
	v_lshl_add_u32 v40, v40, 24, v47                           // 0000009A6B28: D6460028 04BD3128
	v_dual_dot2acc_f32_f16 v84, v51, v4 :: v_dual_add_nc_u32 v91, 32, v91// 0000009A6B30: CB200933 545AB6A0
	v_dual_mov_b32 v62, v124 :: v_dual_mov_b32 v49, v122       // 0000009A6B38: CA10017C 3E30017A
	v_sad_u8 v40, v40, 0, 0x6400                               // 0000009A6B40: D6220028 03FD0128 00006400
	v_mov_b32_e32 v47, v104                                    // 0000009A6B4C: 7E5E0368
	v_mov_b32_e32 v53, v125                                    // 0000009A6B50: 7E6A037D
	v_mov_b32_e32 v51, v105                                    // 0000009A6B54: 7E660369
	v_mov_b32_e32 v57, v129                                    // 0000009A6B58: 7E720381
	v_lshl_or_b32 v40, v40, 16, v43                            // 0000009A6B5C: D6560028 04AD2128
	v_bfe_u32 v43, v36, 9, 16                                  // 0000009A6B64: D610002B 02411324
	v_mul_u32_u24_e32 v46, s6, v43                             // 0000009A6B6C: 165C5606
	v_mul_u32_u24_e32 v43, s7, v43                             // 0000009A6B70: 16565607
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A6B74: BF870001
	v_lshl_add_u32 v43, v43, 24, v46                           // 0000009A6B78: D646002B 04B9312B
	v_mul_u32_u24_e32 v46, s6, v44                             // 0000009A6B80: 165C5806
	v_mul_u32_u24_e32 v44, s7, v44                             // 0000009A6B84: 16585807
	v_lshl_add_u32 v44, v44, 24, v46                           // 0000009A6B88: D646002C 04B9312C
	v_pk_fma_f16 v35, v40, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6B90: CC0E0023 0BFC1128 0000C931
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009A6B9C: D622002B 03FD012B 00006400
	v_mul_u32_u24_e32 v46, s6, v45                             // 0000009A6BA8: 165C5A06
	v_mul_u32_u24_e32 v45, s7, v45                             // 0000009A6BAC: 165A5A07
	v_sad_u8 v42, v44, 0, 0x6400                               // 0000009A6BB0: D622002A 03FD012C 00006400
	v_lshl_add_u32 v45, v45, 24, v46                           // 0000009A6BBC: D646002D 04B9312D
	v_and_b32_e32 v38, 0xffff, v43                             // 0000009A6BC4: 364C56FF 0000FFFF
	v_dot2acc_f32_f16 v80, v35, v4                             // 0000009A6BCC: 04A00923
	v_dual_mov_b32 v46, v106 :: v_dual_mov_b32 v35, v147       // 0000009A6BD0: CA10016A 2E220193
	v_mov_b32_e32 v64, v100                                    // 0000009A6BD8: 7E800364
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A6BDC: BF870004
	v_lshl_or_b32 v38, v42, 16, v38                            // 0000009A6BE0: D6560026 0499212A
	v_sad_u8 v43, v45, 0, 0x6400                               // 0000009A6BE8: D622002B 03FD012D 00006400
	v_mov_b32_e32 v45, v119                                    // 0000009A6BF4: 7E5A0377
	v_mov_b32_e32 v55, v107                                    // 0000009A6BF8: 7E6E036B
	v_mov_b32_e32 v61, v132                                    // 0000009A6BFC: 7E7A0384
	v_pk_fma_f16 v32, v38, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6C00: CC0E0020 0BFC1126 0000C931
	v_bfe_u32 v38, v31, 6, 16                                  // 0000009A6C0C: D6100026 02410D1F
	v_mul_u32_u24_e32 v41, s6, v38                             // 0000009A6C14: 16524C06
	v_mul_u32_u24_e32 v38, s7, v38                             // 0000009A6C18: 164C4C07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009A6C1C: BF8700D1
	v_lshl_add_u32 v38, v38, 24, v41                           // 0000009A6C20: D6460026 04A53126
	v_dot2acc_f32_f16 v79, v32, v3                             // 0000009A6C28: 049E0720
	.long 0xd73d0020                                           // 0000009A6C2C: D73D0020
	v_cndmask_b32_e32 v1, v92, v33, vcc_lo                     // 0000009A6C30: 0202435C
	v_mul_u32_u24_e32 v33, s6, v37                             // 0000009A6C34: 16424A06
	v_mul_u32_u24_e32 v34, s7, v37                             // 0000009A6C38: 16444A07
	v_lshl_add_u32 v33, v34, 24, v33                           // 0000009A6C3C: D6460021 04853122
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000009A6C44: D6220026 03FD0126 00006400
	v_bfe_u32 v34, v31, 3, 16                                  // 0000009A6C50: D6100022 0241071F
	v_bfe_u32 v37, v32, 9, 16                                  // 0000009A6C58: D6100025 02411320
	v_mul_u32_u24_e32 v41, s6, v34                             // 0000009A6C60: 16524406
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000009A6C64: D6220021 03FD0121 00006400
	v_mul_u32_u24_e32 v34, s7, v34                             // 0000009A6C70: 16444407
	v_lshl_add_u32 v34, v34, 24, v41                           // 0000009A6C74: D6460022 04A53122
	v_mul_u32_u24_e32 v41, s6, v37                             // 0000009A6C7C: 16524A06
	v_mul_u32_u24_e32 v37, s7, v37                             // 0000009A6C80: 164A4A07
	v_and_b32_e32 v33, 0xffff, v33                             // 0000009A6C84: 364242FF 0000FFFF
	v_lshl_add_u32 v37, v37, 24, v41                           // 0000009A6C8C: D6460025 04A53125
	v_and_b32_e32 v31, 0xffff, v31                             // 0000009A6C94: 363E3EFF 0000FFFF
	v_bfe_u32 v39, v32, 6, 16                                  // 0000009A6C9C: D6100027 02410D20
	v_mul_u32_u24_e32 v41, s6, v31                             // 0000009A6CA4: 16523E06
	v_lshl_or_b32 v33, v38, 16, v33                            // 0000009A6CA8: D6560021 04852126
	v_mul_u32_u24_e32 v31, s7, v31                             // 0000009A6CB0: 163E3E07
	v_lshl_add_u32 v31, v31, 24, v41                           // 0000009A6CB4: D646001F 04A5311F
	v_mul_u32_u24_e32 v41, s6, v39                             // 0000009A6CBC: 16524E06
	v_mul_u32_u24_e32 v39, s7, v39                             // 0000009A6CC0: 164E4E07
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000009A6CC4: D6220022 03FD0122 00006400
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000009A6CD0: D6220025 03FD0125 00006400
	v_lshl_add_u32 v39, v39, 24, v41                           // 0000009A6CDC: D6460027 04A53127
	v_pk_fma_f16 v33, v33, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6CE4: CC0E0021 0BFC1121 0000C931
	v_mul_u32_u24_e32 v41, s6, v29                             // 0000009A6CF0: 16523A06
	v_mul_u32_u24_e32 v29, s7, v29                             // 0000009A6CF4: 163A3A07
	v_lshl_add_u32 v29, v29, 24, v41                           // 0000009A6CF8: D646001D 04A5311D
	v_and_b32_e32 v34, 0xffff, v34                             // 0000009A6D00: 364444FF 0000FFFF
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000009A6D08: D622001F 03FD011F 00006400
	v_and_b32_e32 v37, 0xffff, v37                             // 0000009A6D14: 364A4AFF 0000FFFF
	v_sad_u8 v38, v39, 0, 0x6400                               // 0000009A6D1C: D6220026 03FD0127 00006400
	v_dot2acc_f32_f16 v78, v33, v1                             // 0000009A6D28: 049C0321
	v_bfe_u32 v33, v27, 3, 16                                  // 0000009A6D2C: D6100021 0241071B
	v_mul_u32_u24_e32 v41, s6, v33                             // 0000009A6D34: 16524206
	v_mul_u32_u24_e32 v33, s7, v33                             // 0000009A6D38: 16424207
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A6D3C: BF870001
	v_lshl_add_u32 v33, v33, 24, v41                           // 0000009A6D40: D6460021 04A53121
	v_mul_u32_u24_e32 v41, s6, v30                             // 0000009A6D48: 16523C06
	v_mul_u32_u24_e32 v30, s7, v30                             // 0000009A6D4C: 163C3C07
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000009A6D50: D622001D 03FD011D 00006400
	v_lshl_add_u32 v30, v30, 24, v41                           // 0000009A6D5C: D646001E 04A5311E
	v_bfe_u32 v40, v32, 3, 16                                  // 0000009A6D64: D6100028 02410720
	v_mul_u32_u24_e32 v39, s6, v40                             // 0000009A6D6C: 164E5006
	v_and_b32_e32 v32, 0xffff, v32                             // 0000009A6D70: 364040FF 0000FFFF
	v_mul_u32_u24_e32 v40, s7, v40                             // 0000009A6D78: 16505007
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A6D7C: BF870002
	v_lshl_add_u32 v39, v40, 24, v39                           // 0000009A6D80: D6460027 049D3128
	v_lshl_or_b32 v31, v31, 16, v34                            // 0000009A6D88: D656001F 0489211F
	v_lshl_or_b32 v34, v38, 16, v37                            // 0000009A6D90: D6560022 04952126
	v_mul_u32_u24_e32 v38, s6, v32                             // 0000009A6D98: 164C4006
	v_mul_u32_u24_e32 v32, s7, v32                             // 0000009A6D9C: 16404007
	v_and_b32_e32 v27, 0xffff, v27                             // 0000009A6DA0: 363636FF 0000FFFF
	v_lshl_add_u32 v32, v32, 24, v38                           // 0000009A6DA8: D6460020 04993120
	v_bfe_u32 v38, v28, 9, 16                                  // 0000009A6DB0: D6100026 0241131C
	v_mul_u32_u24_e32 v41, s6, v27                             // 0000009A6DB8: 16523606
	v_mul_u32_u24_e32 v27, s7, v27                             // 0000009A6DBC: 16363607
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000009A6DC0: D6220021 03FD0121 00006400
	v_lshl_add_u32 v27, v27, 24, v41                           // 0000009A6DCC: D646001B 04A5311B
	v_mul_u32_u24_e32 v41, s6, v38                             // 0000009A6DD4: 16524C06
	v_mul_u32_u24_e32 v38, s7, v38                             // 0000009A6DD8: 164C4C07
	v_lshl_add_u32 v38, v38, 24, v41                           // 0000009A6DDC: D6460026 04A53126
	v_and_b32_e32 v29, 0xffff, v29                             // 0000009A6DE4: 363A3AFF 0000FFFF
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000009A6DEC: D622001E 03FD011E 00006400
	v_sad_u8 v37, v39, 0, 0x6400                               // 0000009A6DF8: D6220025 03FD0127 00006400
	v_bfe_u32 v39, v28, 6, 16                                  // 0000009A6E04: D6100027 02410D1C
	v_bfe_u32 v40, v28, 3, 16                                  // 0000009A6E0C: D6100028 0241071C
	v_mul_u32_u24_e32 v41, s6, v39                             // 0000009A6E14: 16524E06
	v_mul_u32_u24_e32 v39, s7, v39                             // 0000009A6E18: 164E4E07
	v_and_b32_e32 v33, 0xffff, v33                             // 0000009A6E1C: 364242FF 0000FFFF
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000009A6E24: D622001B 03FD011B 00006400
	v_lshl_add_u32 v39, v39, 24, v41                           // 0000009A6E30: D6460027 04A53127
	v_mul_u32_u24_e32 v41, s6, v40                             // 0000009A6E38: 16525006
	v_mul_u32_u24_e32 v40, s7, v40                             // 0000009A6E3C: 16505007
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000009A6E40: D6220026 03FD0126 00006400
	v_lshl_add_u32 v40, v40, 24, v41                           // 0000009A6E4C: D6460028 04A53128
	v_lshl_or_b32 v29, v30, 16, v29                            // 0000009A6E54: D656001D 0475211E
	v_and_b32_e32 v28, 0xffff, v28                             // 0000009A6E5C: 363838FF 0000FFFF
	v_lshl_or_b32 v27, v27, 16, v33                            // 0000009A6E64: D656001B 0485211B
	v_sad_u8 v33, v39, 0, 0x6400                               // 0000009A6E6C: D6220021 03FD0127 00006400
	v_mul_u32_u24_e32 v39, s6, v28                             // 0000009A6E78: 164E3806
	v_mul_u32_u24_e32 v28, s7, v28                             // 0000009A6E7C: 16383807
	v_and_b32_e32 v30, 0xffff, v38                             // 0000009A6E80: 363C4CFF 0000FFFF
	v_sad_u8 v38, v40, 0, 0x6400                               // 0000009A6E88: D6220026 03FD0128 00006400
	v_lshl_add_u32 v28, v28, 24, v39                           // 0000009A6E94: D646001C 049D311C
	v_pk_fma_f16 v29, v29, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6E9C: CC0E001D 0BFC111D 0000C931
	v_and_b32_e32 v36, 0xffff, v36                             // 0000009A6EA8: 364848FF 0000FFFF
	v_pk_fma_f16 v31, v31, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6EB0: CC0E001F 0BFC111F 0000C931
	v_and_b32_e32 v37, 0xffff, v37                             // 0000009A6EBC: 364A4AFF 0000FFFF
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000009A6EC4: D6220020 03FD0120 00006400
	v_pk_fma_f16 v27, v27, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6ED0: CC0E001B 0BFC111B 0000C931
	v_lshl_or_b32 v30, v33, 16, v30                            // 0000009A6EDC: D656001E 04792121
	v_and_b32_e32 v33, 0xffff, v38                             // 0000009A6EE4: 36424CFF 0000FFFF
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000009A6EEC: D622001C 03FD011C 00006400
	v_dot2acc_f32_f16 v77, v29, v1                             // 0000009A6EF8: 049A031D
	v_pk_fma_f16 v34, v34, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6EFC: CC0E0022 0BFC1122 0000C931
	v_lshl_or_b32 v29, v32, 16, v37                            // 0000009A6F08: D656001D 04952120
	v_dot2acc_f32_f16 v78, v31, v2                             // 0000009A6F10: 049C051F
	v_pk_fma_f16 v30, v30, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6F14: CC0E001E 0BFC111E 0000C931
	v_lshl_or_b32 v28, v28, 16, v33                            // 0000009A6F20: D656001C 0485211C
	v_dot2acc_f32_f16 v77, v27, v2                             // 0000009A6F28: 049A051B
	v_pk_fma_f16 v27, v29, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6F2C: CC0E001B 0BFC111D 0000C931
	v_dot2acc_f32_f16 v78, v34, v3                             // 0000009A6F38: 049C0722
	v_mul_u32_u24_e32 v44, s6, v36                             // 0000009A6F3C: 16584806
	v_pk_fma_f16 v22, v28, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A6F40: CC0E0016 0BFC111C 0000C931
	v_dot2acc_f32_f16 v77, v30, v3                             // 0000009A6F4C: 049A071E
	v_bfe_u32 v28, v21, 6, 16                                  // 0000009A6F50: D610001C 02410D15
	v_dot2acc_f32_f16 v78, v27, v4                             // 0000009A6F58: 049C091B
	v_bfe_u32 v27, v21, 9, 16                                  // 0000009A6F5C: D610001B 02411315
	v_mul_u32_u24_e32 v31, s6, v28                             // 0000009A6F64: 163E3806
	v_dot2acc_f32_f16 v77, v22, v4                             // 0000009A6F68: 049A0916
	.long 0xd73d0016                                           // 0000009A6F6C: D73D0016
	v_cndmask_b32_e32 v1, v92, v23, vcc_lo                     // 0000009A6F70: 02022F5C
	v_mul_u32_u24_e32 v24, s6, v27                             // 0000009A6F74: 16303606
	v_mul_u32_u24_e32 v27, s7, v27                             // 0000009A6F78: 16363607
	v_lshl_add_u32 v24, v27, 24, v24                           // 0000009A6F7C: D6460018 0461311B
	v_bfe_u32 v23, v21, 3, 16                                  // 0000009A6F84: D6100017 02410715
	v_mul_u32_u24_e32 v28, s7, v28                             // 0000009A6F8C: 16383807
	v_bfe_u32 v27, v22, 9, 16                                  // 0000009A6F90: D610001B 02411316
	v_lshl_add_u32 v28, v28, 24, v31                           // 0000009A6F98: D646001C 047D311C
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000009A6FA0: D6220018 03FD0118 00006400
	v_mul_u32_u24_e32 v31, s6, v23                             // 0000009A6FAC: 163E2E06
	v_mul_u32_u24_e32 v23, s7, v23                             // 0000009A6FB0: 162E2E07
	v_lshl_add_u32 v23, v23, 24, v31                           // 0000009A6FB4: D6460017 047D3117
	v_mul_u32_u24_e32 v31, s6, v27                             // 0000009A6FBC: 163E3606
	v_mul_u32_u24_e32 v27, s7, v27                             // 0000009A6FC0: 16363607
	v_lshl_add_u32 v27, v27, 24, v31                           // 0000009A6FC4: D646001B 047D311B
	v_and_b32_e32 v21, 0xffff, v21                             // 0000009A6FCC: 362A2AFF 0000FFFF
	v_bfe_u32 v29, v22, 6, 16                                  // 0000009A6FD4: D610001D 02410D16
	v_mul_u32_u24_e32 v31, s6, v21                             // 0000009A6FDC: 163E2A06
	v_mul_u32_u24_e32 v21, s7, v21                             // 0000009A6FE0: 162A2A07
	v_mul_u32_u24_e32 v36, s7, v36                             // 0000009A6FE4: 16484807
	v_bfe_u32 v30, v22, 3, 16                                  // 0000009A6FE8: D610001E 02410716
	v_and_b32_e32 v24, 0xffff, v24                             // 0000009A6FF0: 363030FF 0000FFFF
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000009A6FF8: D622001C 03FD011C 00006400
	v_lshl_add_u32 v21, v21, 24, v31                           // 0000009A7004: D6460015 047D3115
	v_mul_u32_u24_e32 v31, s6, v29                             // 0000009A700C: 163E3A06
	v_mul_u32_u24_e32 v29, s7, v29                             // 0000009A7010: 163A3A07
	v_lshl_add_u32 v36, v36, 24, v44                           // 0000009A7014: D6460024 04B13124
	v_lshl_add_u32 v29, v29, 24, v31                           // 0000009A701C: D646001D 047D311D
	v_mul_u32_u24_e32 v31, s6, v30                             // 0000009A7024: 163E3C06
	v_mul_u32_u24_e32 v30, s7, v30                             // 0000009A7028: 163C3C07
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000009A702C: D6220017 03FD0117 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000009A7038: D622001B 03FD011B 00006400
	v_lshl_add_u32 v30, v30, 24, v31                           // 0000009A7044: D646001E 047D311E
	v_lshl_or_b32 v24, v28, 16, v24                            // 0000009A704C: D6560018 0461211C
	v_and_b32_e32 v42, 0xffff, v43                             // 0000009A7054: 365456FF 0000FFFF
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000009A705C: D6220024 03FD0124 00006400
	v_dual_mov_b32 v34, v151 :: v_dual_and_b32 v23, 0xffff, v23// 0000009A7068: CA240197 22162EFF 0000FFFF
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000009A7074: D6220015 03FD0115 00006400
	v_dual_mov_b32 v32, v116 :: v_dual_and_b32 v27, 0xffff, v27// 0000009A7080: CA240174 201A36FF 0000FFFF
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000009A708C: D622001D 03FD011D 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000009A7098: D622001E 03FD011E 00006400
	v_and_b32_e32 v22, 0xffff, v22                             // 0000009A70A4: 362C2CFF 0000FFFF
	v_mul_u32_u24_e32 v31, s6, v22                             // 0000009A70AC: 163E2C06
	v_mul_u32_u24_e32 v22, s7, v22                             // 0000009A70B0: 162C2C07
	v_pk_fma_f16 v24, v24, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A70B4: CC0E0018 0BFC1118 0000C931
	v_lshl_or_b32 v36, v36, 16, v42                            // 0000009A70C0: D6560024 04A92124
	v_lshl_add_u32 v22, v22, 24, v31                           // 0000009A70C8: D6460016 047D3116
	v_lshl_or_b32 v21, v21, 16, v23                            // 0000009A70D0: D6560015 045D2115
	v_lshl_or_b32 v23, v29, 16, v27                            // 0000009A70D8: D6560017 046D211D
	v_dual_mov_b32 v38, v153 :: v_dual_and_b32 v27, 0xffff, v30// 0000009A70E0: CA240199 261A3CFF 0000FFFF
	v_mul_u32_u24_e32 v30, s6, v19                             // 0000009A70EC: 163C2606
	v_mul_u32_u24_e32 v19, s7, v19                             // 0000009A70F0: 16262607
	v_lshl_add_u32 v19, v19, 24, v30                           // 0000009A70F4: D6460013 04793113
	v_dot2acc_f32_f16 v76, v24, v1                             // 0000009A70FC: 04980318
	v_bfe_u32 v24, v17, 3, 16                                  // 0000009A7100: D6100018 02410711
	v_pk_fma_f16 v36, v36, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A7108: CC0E0024 0BFC1124 0000C931
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000009A7114: D6220016 03FD0116 00006400
	v_mul_u32_u24_e32 v30, s6, v24                             // 0000009A7120: 163C3006
	v_mul_u32_u24_e32 v24, s7, v24                             // 0000009A7124: 16303007
	v_lshl_add_u32 v24, v24, 24, v30                           // 0000009A7128: D6460018 04793118
	v_mul_u32_u24_e32 v30, s6, v20                             // 0000009A7130: 163C2806
	v_mul_u32_u24_e32 v20, s7, v20                             // 0000009A7134: 16282807
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000009A7138: D6220013 03FD0113 00006400
	v_lshl_add_u32 v20, v20, 24, v30                           // 0000009A7144: D6460014 04793114
	v_and_b32_e32 v17, 0xffff, v17                             // 0000009A714C: 362222FF 0000FFFF
	v_dot2acc_f32_f16 v79, v36, v4                             // 0000009A7154: 049E0924
	v_lshl_or_b32 v22, v22, 16, v27                            // 0000009A7158: D6560016 046D2116
	v_bfe_u32 v27, v18, 9, 16                                  // 0000009A7160: D610001B 02411312
	v_mov_b32_e32 v36, v117                                    // 0000009A7168: 7E480375
	v_mul_u32_u24_e32 v30, s6, v17                             // 0000009A716C: 163C2206
	v_mul_u32_u24_e32 v17, s7, v17                             // 0000009A7170: 16222207
	v_lshl_add_u32 v17, v17, 24, v30                           // 0000009A7174: D6460011 04793111
	v_mul_u32_u24_e32 v30, s6, v27                             // 0000009A717C: 163C3606
	v_mul_u32_u24_e32 v27, s7, v27                             // 0000009A7180: 16363607
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000009A7184: D6220018 03FD0118 00006400
	v_lshl_add_u32 v27, v27, 24, v30                           // 0000009A7190: D646001B 0479311B
	v_dual_mov_b32 v42, v155 :: v_dual_and_b32 v19, 0xffff, v19// 0000009A7198: CA24019B 2A1226FF 0000FFFF
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000009A71A4: D6220014 03FD0114 00006400
	v_bfe_u32 v28, v18, 6, 16                                  // 0000009A71B0: D610001C 02410D12
	v_mul_u32_u24_e32 v30, s6, v28                             // 0000009A71B8: 163C3806
	v_mul_u32_u24_e32 v28, s7, v28                             // 0000009A71BC: 16383807
	v_and_b32_e32 v24, 0xffff, v24                             // 0000009A71C0: 363030FF 0000FFFF
	v_sad_u8 v17, v17, 0, 0x6400                               // 0000009A71C8: D6220011 03FD0111 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000009A71D4: D622001B 03FD011B 00006400
	v_lshl_add_u32 v28, v28, 24, v30                           // 0000009A71E0: D646001C 0479311C
	v_lshl_or_b32 v19, v20, 16, v19                            // 0000009A71E8: D6560013 044D2114
	v_pk_fma_f16 v21, v21, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A71F0: CC0E0015 0BFC1115 0000C931
	v_lshl_or_b32 v17, v17, 16, v24                            // 0000009A71FC: D6560011 04612111
	v_and_b32_e32 v20, 0xffff, v27                             // 0000009A7204: 362836FF 0000FFFF
	v_sad_u8 v24, v28, 0, 0x6400                               // 0000009A720C: D6220018 03FD011C 00006400
	v_pk_fma_f16 v19, v19, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A7218: CC0E0013 0BFC1113 0000C931
	v_pk_fma_f16 v23, v23, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A7224: CC0E0017 0BFC1117 0000C931
	v_pk_fma_f16 v17, v17, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A7230: CC0E0011 0BFC1111 0000C931
	v_dot2acc_f32_f16 v76, v21, v2                             // 0000009A723C: 04980515
	v_lshl_or_b32 v20, v24, 16, v20                            // 0000009A7240: D6560014 04512118
	v_dot2acc_f32_f16 v75, v19, v1                             // 0000009A7248: 04960313
	v_bfe_u32 v19, v11, 9, 16                                  // 0000009A724C: D6100013 0241130B
	v_mov_b32_e32 v40, v118                                    // 0000009A7254: 7E500376
	v_dot2acc_f32_f16 v76, v23, v3                             // 0000009A7258: 04980717
	v_pk_fma_f16 v12, v20, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A725C: CC0E000C 0BFC1114 0000C931
	v_dot2acc_f32_f16 v75, v17, v2                             // 0000009A7268: 04960511
	v_bfe_u32 v20, v11, 6, 16                                  // 0000009A726C: D6100014 02410D0B
	v_mul_u32_u24_e32 v23, s6, v20                             // 0000009A7274: 162E2806
	v_mul_u32_u24_e32 v20, s7, v20                             // 0000009A7278: 16282807
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009A727C: BF8700D1
	v_lshl_add_u32 v20, v20, 24, v23                           // 0000009A7280: D6460014 045D3114
	v_dot2acc_f32_f16 v75, v12, v3                             // 0000009A7288: 0496070C
	.long 0xd73d000c                                           // 0000009A728C: D73D000C
	v_cndmask_b32_e32 v1, v92, v13, vcc_lo                     // 0000009A7290: 02021B5C
	v_mul_u32_u24_e32 v13, s6, v19                             // 0000009A7294: 161A2606
	v_mul_u32_u24_e32 v14, s7, v19                             // 0000009A7298: 161C2607
	v_lshl_add_u32 v13, v14, 24, v13                           // 0000009A729C: D646000D 0435310E
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000009A72A4: D6220014 03FD0114 00006400
	v_bfe_u32 v14, v11, 3, 16                                  // 0000009A72B0: D610000E 0241070B
	v_bfe_u32 v19, v12, 9, 16                                  // 0000009A72B8: D6100013 0241130C
	v_mul_u32_u24_e32 v23, s6, v14                             // 0000009A72C0: 162E1C06
	v_sad_u8 v13, v13, 0, 0x6400                               // 0000009A72C4: D622000D 03FD010D 00006400
	v_mul_u32_u24_e32 v14, s7, v14                             // 0000009A72D0: 161C1C07
	v_and_b32_e32 v11, 0xffff, v11                             // 0000009A72D4: 361616FF 0000FFFF
	v_lshl_add_u32 v14, v14, 24, v23                           // 0000009A72DC: D646000E 045D310E
	v_mul_u32_u24_e32 v23, s6, v19                             // 0000009A72E4: 162E2606
	v_and_b32_e32 v13, 0xffff, v13                             // 0000009A72E8: 361A1AFF 0000FFFF
	v_mul_u32_u24_e32 v19, s7, v19                             // 0000009A72F0: 16262607
	v_bfe_u32 v21, v12, 6, 16                                  // 0000009A72F4: D6100015 02410D0C
	v_lshl_add_u32 v19, v19, 24, v23                           // 0000009A72FC: D6460013 045D3113
	v_mul_u32_u24_e32 v23, s6, v11                             // 0000009A7304: 162E1606
	v_lshl_or_b32 v13, v20, 16, v13                            // 0000009A7308: D656000D 04352114
	v_mul_u32_u24_e32 v11, s7, v11                             // 0000009A7310: 16161607
	v_lshl_add_u32 v11, v11, 24, v23                           // 0000009A7314: D646000B 045D310B
	v_mul_u32_u24_e32 v23, s6, v21                             // 0000009A731C: 162E2A06
	v_mul_u32_u24_e32 v21, s7, v21                             // 0000009A7320: 162A2A07
	v_pk_fma_f16 v13, v13, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A7324: CC0E000D 0BFC110D 0000C931
	v_lshl_add_u32 v21, v21, 24, v23                           // 0000009A7330: D6460015 045D3115
	v_mul_u32_u24_e32 v23, s6, v7                              // 0000009A7338: 162E0E06
	v_mul_u32_u24_e32 v7, s7, v7                               // 0000009A733C: 160E0E07
	v_lshl_add_u32 v7, v7, 24, v23                             // 0000009A7340: D6460007 045D3107
	v_dot2acc_f32_f16 v74, v13, v1                             // 0000009A7348: 0494030D
	v_bfe_u32 v13, v5, 3, 16                                   // 0000009A734C: D610000D 02410705
	v_mul_u32_u24_e32 v23, s6, v13                             // 0000009A7354: 162E1A06
	v_mul_u32_u24_e32 v13, s7, v13                             // 0000009A7358: 161A1A07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A735C: BF870001
	v_lshl_add_u32 v13, v13, 24, v23                           // 0000009A7360: D646000D 045D310D
	v_mul_u32_u24_e32 v23, s6, v8                              // 0000009A7368: 162E1006
	v_mul_u32_u24_e32 v8, s7, v8                               // 0000009A736C: 16101007
	v_sad_u8 v7, v7, 0, 0x6400                                 // 0000009A7370: D6220007 03FD0107 00006400
	v_lshl_add_u32 v8, v8, 24, v23                             // 0000009A737C: D6460008 045D3108
	v_sad_u8 v14, v14, 0, 0x6400                               // 0000009A7384: D622000E 03FD010E 00006400
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000009A7390: D6220013 03FD0113 00006400
	v_dual_mov_b32 v48, v96 :: v_dual_and_b32 v5, 0xffff, v5   // 0000009A739C: CA240160 30040AFF 0000FFFF
	v_mul_u32_u24_e32 v23, s6, v5                              // 0000009A73A8: 162E0A06
	v_mul_u32_u24_e32 v5, s7, v5                               // 0000009A73AC: 160A0A07
	v_sad_u8 v13, v13, 0, 0x6400                               // 0000009A73B0: D622000D 03FD010D 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A73BC: BF870002
	v_lshl_add_u32 v5, v5, 24, v23                             // 0000009A73C0: D6460005 045D3105
	v_dual_mov_b32 v54, v110 :: v_dual_and_b32 v7, 0xffff, v7  // 0000009A73C8: CA24016E 36060EFF 0000FFFF
	v_sad_u8 v8, v8, 0, 0x6400                                 // 0000009A73D4: D6220008 03FD0108 00006400
	v_pk_fma_f16 v17, v22, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A73E0: CC0E0011 0BFC1116 0000C931
	v_and_b32_e32 v14, 0xffff, v14                             // 0000009A73EC: 361C1CFF 0000FFFF
	v_sad_u8 v11, v11, 0, 0x6400                               // 0000009A73F4: D622000B 03FD010B 00006400
	v_dual_mov_b32 v44, v95 :: v_dual_and_b32 v19, 0xffff, v19 // 0000009A7400: CA24015F 2C1226FF 0000FFFF
	v_sad_u8 v20, v21, 0, 0x6400                               // 0000009A740C: D6220014 03FD0115 00006400
	v_bfe_u32 v22, v12, 3, 16                                  // 0000009A7418: D6100016 0241070C
	v_and_b32_e32 v12, 0xffff, v12                             // 0000009A7420: 361818FF 0000FFFF
	v_dual_mov_b32 v52, v97 :: v_dual_and_b32 v13, 0xffff, v13 // 0000009A7428: CA240161 340C1AFF 0000FFFF
	v_sad_u8 v5, v5, 0, 0x6400                                 // 0000009A7434: D6220005 03FD0105 00006400
	v_lshl_or_b32 v7, v8, 16, v7                               // 0000009A7440: D6560007 041D2108
	v_mul_u32_u24_e32 v21, s6, v22                             // 0000009A7448: 162A2C06
	v_dot2acc_f32_f16 v76, v17, v4                             // 0000009A744C: 04980911
	v_mov_b32_e32 v17, v133                                    // 0000009A7450: 7E220385
	v_lshl_or_b32 v11, v11, 16, v14                            // 0000009A7454: D656000B 0439210B
	v_lshl_or_b32 v14, v20, 16, v19                            // 0000009A745C: D656000E 044D2114
	v_mul_u32_u24_e32 v20, s6, v12                             // 0000009A7464: 16281806
	v_mul_u32_u24_e32 v12, s7, v12                             // 0000009A7468: 16181807
	v_mul_u32_u24_e32 v22, s7, v22                             // 0000009A746C: 162C2C07
	v_lshl_add_u32 v21, v22, 24, v21                           // 0000009A7470: D6460015 04553116
	v_lshl_add_u32 v12, v12, 24, v20                           // 0000009A7478: D646000C 0451310C
	v_bfe_u32 v20, v6, 9, 16                                   // 0000009A7480: D6100014 02411306
	v_mul_u32_u24_e32 v23, s6, v20                             // 0000009A7488: 162E2806
	v_mul_u32_u24_e32 v20, s7, v20                             // 0000009A748C: 16282807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A7490: BF870001
	v_lshl_add_u32 v20, v20, 24, v23                           // 0000009A7494: D6460014 045D3114
	v_lshl_or_b32 v5, v5, 16, v13                              // 0000009A749C: D6560005 04352105
	v_pk_fma_f16 v7, v7, s8, 0xc931 op_sel_hi:[1,0,0]          // 0000009A74A4: CC0E0007 0BFC1107 0000C931
	v_sad_u8 v19, v21, 0, 0x6400                               // 0000009A74B0: D6220013 03FD0115 00006400
	v_bfe_u32 v21, v6, 6, 16                                   // 0000009A74BC: D6100015 02410D06
	v_mul_u32_u24_e32 v23, s6, v21                             // 0000009A74C4: 162E2A06
	v_mul_u32_u24_e32 v21, s7, v21                             // 0000009A74C8: 162A2A07
	v_bfe_u32 v29, v18, 3, 16                                  // 0000009A74CC: D610001D 02410712
	v_bfe_u32 v22, v6, 3, 16                                   // 0000009A74D4: D6100016 02410706
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000009A74DC: D6220014 03FD0114 00006400
	v_lshl_add_u32 v21, v21, 24, v23                           // 0000009A74E8: D6460015 045D3115
	v_mul_u32_u24_e32 v30, s6, v29                             // 0000009A74F0: 163C3A06
	v_mul_u32_u24_e32 v29, s7, v29                             // 0000009A74F4: 163A3A07
	v_mul_u32_u24_e32 v23, s6, v22                             // 0000009A74F8: 162E2C06
	v_mul_u32_u24_e32 v22, s7, v22                             // 0000009A74FC: 162C2C07
	v_pk_fma_f16 v5, v5, s8, 0xc931 op_sel_hi:[1,0,0]          // 0000009A7500: CC0E0005 0BFC1105 0000C931
	v_dot2acc_f32_f16 v10, v7, v1                              // 0000009A750C: 04140307
	v_lshl_add_u32 v29, v29, 24, v30                           // 0000009A7510: D646001D 0479311D
	v_lshl_add_u32 v22, v22, 24, v23                           // 0000009A7518: D6460016 045D3116
	v_and_b32_e32 v18, 0xffff, v18                             // 0000009A7520: 362424FF 0000FFFF
	v_and_b32_e32 v6, 0xffff, v6                               // 0000009A7528: 360C0CFF 0000FFFF
	v_and_b32_e32 v8, 0xffff, v20                              // 0000009A7530: 361028FF 0000FFFF
	v_sad_u8 v13, v21, 0, 0x6400                               // 0000009A7538: D622000D 03FD0115 00006400
	v_mul_u32_u24_e32 v21, s6, v6                              // 0000009A7544: 162A0C06
	v_mul_u32_u24_e32 v6, s7, v6                               // 0000009A7548: 160C0C07
	v_dual_dot2acc_f32_f16 v10, v5, v2 :: v_dual_mov_b32 v5, v126// 0000009A754C: CB100505 0A04017E
	v_mul_u32_u24_e32 v28, s6, v18                             // 0000009A7554: 16382406
	v_mul_u32_u24_e32 v18, s7, v18                             // 0000009A7558: 16242407
	v_sad_u8 v27, v29, 0, 0x6400                               // 0000009A755C: D622001B 03FD011D 00006400
	v_lshl_add_u32 v18, v18, 24, v28                           // 0000009A7568: D6460012 04713112
	v_sad_u8 v20, v22, 0, 0x6400                               // 0000009A7570: D6220014 03FD0116 00006400
	v_lshl_add_u32 v6, v6, 24, v21                             // 0000009A757C: D6460006 04553106
	v_pk_fma_f16 v11, v11, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A7584: CC0E000B 0BFC110B 0000C931
	v_mov_b32_e32 v29, v154                                    // 0000009A7590: 7E3A039A
	v_lshl_or_b32 v8, v13, 16, v8                              // 0000009A7594: D6560008 0421210D
	v_and_b32_e32 v24, 0xffff, v27                             // 0000009A759C: 363036FF 0000FFFF
	v_sad_u8 v18, v18, 0, 0x6400                               // 0000009A75A4: D6220012 03FD0112 00006400
	v_dual_mov_b32 v50, v108 :: v_dual_and_b32 v19, 0xffff, v19// 0000009A75B0: CA24016C 321226FF 0000FFFF
	v_sad_u8 v12, v12, 0, 0x6400                               // 0000009A75BC: D622000C 03FD010C 00006400
	v_dual_mov_b32 v58, v121 :: v_dual_and_b32 v13, 0xffff, v20// 0000009A75C8: CA240179 3A0C28FF 0000FFFF
	v_sad_u8 v6, v6, 0, 0x6400                                 // 0000009A75D4: D6220006 03FD0106 00006400
	v_pk_fma_f16 v14, v14, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A75E0: CC0E000E 0BFC110E 0000C931
	v_dot2acc_f32_f16 v74, v11, v2                             // 0000009A75EC: 0494050B
	v_pk_fma_f16 v7, v8, s8, 0xc931 op_sel_hi:[1,0,0]          // 0000009A75F0: CC0E0007 0BFC1108 0000C931
	v_lshl_or_b32 v1, v12, 16, v19                             // 0000009A75FC: D6560001 044D210C
	v_lshl_or_b32 v6, v6, 16, v13                              // 0000009A7604: D6560006 04352106
	v_mov_b32_e32 v19, v149                                    // 0000009A760C: 7E260395
	v_lshl_or_b32 v18, v18, 16, v24                            // 0000009A7610: D6560012 04612112
	v_dot2acc_f32_f16 v74, v14, v3                             // 0000009A7618: 0494070E
	v_dual_dot2acc_f32_f16 v10, v7, v3 :: v_dual_mov_b32 v27, v140// 0000009A761C: CB100707 0A1A018C
	v_dual_mov_b32 v56, v98 :: v_dual_add_nc_u32 v3, v89, v88  // 0000009A7624: CA200162 3802B159
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A762C: BF870234
	v_pk_fma_f16 v18, v18, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A7630: CC0E0012 0BFC1112 0000C931
	v_pk_fma_f16 v1, v1, s8, 0xc931 op_sel_hi:[1,0,0]          // 0000009A763C: CC0E0001 0BFC1101 0000C931
	v_pk_fma_f16 v2, v6, s8, 0xc931 op_sel_hi:[1,0,0]          // 0000009A7648: CC0E0002 0BFC1106 0000C931
	v_cmp_eq_u32_e32 vcc_lo, 21, v3                            // 0000009A7654: 7C940695
	v_mov_b32_e32 v7, v142                                     // 0000009A7658: 7E0E038E
	v_dot2acc_f32_f16 v75, v18, v4                             // 0000009A765C: 04960912
	v_dot2acc_f32_f16 v74, v1, v4                              // 0000009A7660: 04940901
	v_dot2acc_f32_f16 v10, v2, v4                              // 0000009A7664: 04140902
	v_mov_b32_e32 v8, v134                                     // 0000009A7668: 7E100386
	v_dual_mov_b32 v6, v111 :: v_dual_mov_b32 v13, v146        // 0000009A766C: CA10016F 060C0192
	v_mov_b32_e32 v14, v138                                    // 0000009A7674: 7E1C038A
	v_dual_mov_b32 v11, v130 :: v_dual_mov_b32 v12, v112       // 0000009A7678: CA100182 0B0C0170
	v_mov_b32_e32 v20, v141                                    // 0000009A7680: 7E28038D
	v_dual_mov_b32 v18, v113 :: v_dual_mov_b32 v23, v152       // 0000009A7684: CA100171 12160198
	v_mov_b32_e32 v24, v145                                    // 0000009A768C: 7E300391
	v_dual_mov_b32 v21, v137 :: v_dual_mov_b32 v22, v114       // 0000009A7690: CA100189 15160172
	v_mov_b32_e32 v30, v148                                    // 0000009A7698: 7E3C0394
	v_dual_mov_b32 v28, v115 :: v_dual_mov_b32 v33, v156       // 0000009A769C: CA100173 1C20019C
	v_dual_mov_b32 v60, v99 :: v_dual_mov_b32 v31, v144        // 0000009A76A4: CA100163 3C1E0190
	v_dual_mov_b32 v70, v131 :: v_dual_mov_b32 v37, v157       // 0000009A76AC: CA100183 4624019D
	v_dual_mov_b32 v66, v128 :: v_dual_mov_b32 v41, v158       // 0000009A76B4: CA100180 4228019E
	v_dual_mov_b32 v68, v101 :: v_dual_mov_b32 v39, v150       // 0000009A76BC: CA100165 44260196
	v_mov_b32_e32 v4, v135                                     // 0000009A76C4: 7E080387
	v_mov_b32_e32 v43, v103                                    // 0000009A76C8: 7E560367
	v_mov_b32_e32 v59, v109                                    // 0000009A76CC: 7E76036D
	v_mov_b32_e32 v65, v136                                    // 0000009A76D0: 7E820388
	v_mov_b32_e32 v63, v120                                    // 0000009A76D4: 7E7E0378
	v_mov_b32_e32 v69, v139                                    // 0000009A76D8: 7E8A038B
	v_mov_b32_e32 v67, v123                                    // 0000009A76DC: 7E86037B
	v_mov_b32_e32 v3, v143                                     // 0000009A76E0: 7E06038F
	v_dual_mov_b32 v1, v127 :: v_dual_mov_b32 v2, v102         // 0000009A76E4: CA10017F 01020166
	s_or_b32 s0, vcc_lo, s0                                    // 0000009A76EC: 8C00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009A76F0: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 0000009A76F4: 917E007E
	s_cbranch_execz 157                                        // 0000009A76F8: BFA5009D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4b70>
	s_mov_b32 s9, exec_lo                                      // 0000009A76FC: BE89007E
	.long 0xd4c9007e                                           // 0000009A7700: D4C9007E
	v_cndmask_b32_e32 v1, v88, v73, vcc_lo                     // 0000009A7704: 02029358
	s_cbranch_execz 63685                                      // 0000009A7708: BFA5F8C5 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2c20>
	v_mad_u64_u32 v[95:96], null, 0x600, v88, s[2:3]           // 0000009A770C: D6FE7C5F 000AB0FF 00000600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A7718: BF870091
	.long 0xd7006a85                                           // 0000009A771C: D7006A85
	v_cndmask_b32_e32 v1, v95, v15, vcc_lo                     // 0000009A7720: 02021F5F
	v_add_co_ci_u32_e64 v134, null, v96, v16, vcc_lo           // 0000009A7724: D5207C86 01AA2160
	.long 0xd7006a8d                                           // 0000009A772C: D7006A8D
	v_cndmask_b32_e32 v1, v95, v93, vcc_lo                     // 0000009A7730: 0202BB5F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009A7734: BF8700A1
	v_add_co_ci_u32_e64 v142, null, 0, v96, vcc_lo             // 0000009A7738: D5207C8E 01AAC080
	.long 0xd7006a9c                                           // 0000009A7740: D7006A9C
	v_cndmask_b32_e32 v1, v95, v25, vcc_lo                     // 0000009A7744: 0202335F
	v_add_co_ci_u32_e64 v157, null, v96, v26, vcc_lo           // 0000009A7748: D5207C9D 01AA3560
	.long 0xd7006a9f                                           // 0000009A7750: D7006A9F
	v_cndmask_b32_e32 v1, v95, v94, vcc_lo                     // 0000009A7754: 0202BD5F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A7758: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v96, vcc_lo             // 0000009A775C: D5207CA0 01AAC080
	s_clause 0x1f                                              // 0000009A7764: BF85001F
	global_load_b32 v102, v[133:134], off                      // 0000009A7768: DC520000 667C0085
	global_load_b32 v101, v[133:134], off offset:96            // 0000009A7770: DC520060 657C0085
	global_load_b32 v100, v[133:134], off offset:192           // 0000009A7778: DC5200C0 647C0085
	global_load_b32 v99, v[133:134], off offset:288            // 0000009A7780: DC520120 637C0085
	global_load_b32 v98, v[133:134], off offset:384            // 0000009A7788: DC520180 627C0085
	global_load_b32 v97, v[133:134], off offset:480            // 0000009A7790: DC5201E0 617C0085
	global_load_b32 v96, v[133:134], off offset:576            // 0000009A7798: DC520240 607C0085
	global_load_b32 v95, v[133:134], off offset:672            // 0000009A77A0: DC5202A0 5F7C0085
	global_load_b32 v127, v[141:142], off                      // 0000009A77A8: DC520000 7F7C008D
	global_load_b32 v123, v[141:142], off offset:96            // 0000009A77B0: DC520060 7B7C008D
	global_load_b32 v120, v[141:142], off offset:192           // 0000009A77B8: DC5200C0 787C008D
	global_load_b32 v109, v[141:142], off offset:288           // 0000009A77C0: DC520120 6D7C008D
	global_load_b32 v107, v[141:142], off offset:384           // 0000009A77C8: DC520180 6B7C008D
	global_load_b32 v105, v[141:142], off offset:480           // 0000009A77D0: DC5201E0 697C008D
	global_load_b32 v104, v[141:142], off offset:576           // 0000009A77D8: DC520240 687C008D
	global_load_b32 v103, v[141:142], off offset:672           // 0000009A77E0: DC5202A0 677C008D
	global_load_b32 v135, v[156:157], off                      // 0000009A77E8: DC520000 877C009C
	global_load_b32 v131, v[156:157], off offset:96            // 0000009A77F0: DC520060 837C009C
	global_load_b32 v128, v[156:157], off offset:192           // 0000009A77F8: DC5200C0 807C009C
	global_load_b32 v124, v[156:157], off offset:288           // 0000009A7800: DC520120 7C7C009C
	global_load_b32 v121, v[156:157], off offset:384           // 0000009A7808: DC520180 797C009C
	global_load_b32 v110, v[156:157], off offset:480           // 0000009A7810: DC5201E0 6E7C009C
	global_load_b32 v108, v[156:157], off offset:576           // 0000009A7818: DC520240 6C7C009C
	global_load_b32 v106, v[156:157], off offset:672           // 0000009A7820: DC5202A0 6A7C009C
	global_load_b32 v143, v[159:160], off                      // 0000009A7828: DC520000 8F7C009F
	global_load_b32 v139, v[159:160], off offset:96            // 0000009A7830: DC520060 8B7C009F
	global_load_b32 v136, v[159:160], off offset:192           // 0000009A7838: DC5200C0 887C009F
	global_load_b32 v132, v[159:160], off offset:288           // 0000009A7840: DC520120 847C009F
	global_load_b32 v129, v[159:160], off offset:384           // 0000009A7848: DC520180 817C009F
	global_load_b32 v125, v[159:160], off offset:480           // 0000009A7850: DC5201E0 7D7C009F
	global_load_b32 v122, v[159:160], off offset:576           // 0000009A7858: DC520240 7A7C009F
	global_load_b32 v119, v[159:160], off offset:672           // 0000009A7860: DC5202A0 777C009F
	s_clause 0x1f                                              // 0000009A7868: BF85001F
	global_load_b32 v118, v[133:134], off offset:768           // 0000009A786C: DC520300 767C0085
	global_load_b32 v117, v[133:134], off offset:864           // 0000009A7874: DC520360 757C0085
	global_load_b32 v116, v[133:134], off offset:960           // 0000009A787C: DC5203C0 747C0085
	global_load_b32 v115, v[133:134], off offset:1056          // 0000009A7884: DC520420 737C0085
	global_load_b32 v114, v[133:134], off offset:1152          // 0000009A788C: DC520480 727C0085
	global_load_b32 v113, v[133:134], off offset:1248          // 0000009A7894: DC5204E0 717C0085
	global_load_b32 v112, v[133:134], off offset:1344          // 0000009A789C: DC520540 707C0085
	global_load_b32 v111, v[133:134], off offset:1440          // 0000009A78A4: DC5205A0 6F7C0085
	global_load_b32 v150, v[141:142], off offset:768           // 0000009A78AC: DC520300 967C008D
	global_load_b32 v147, v[141:142], off offset:864           // 0000009A78B4: DC520360 937C008D
	global_load_b32 v144, v[141:142], off offset:960           // 0000009A78BC: DC5203C0 907C008D
	global_load_b32 v140, v[141:142], off offset:1056          // 0000009A78C4: DC520420 8C7C008D
	global_load_b32 v137, v[141:142], off offset:1152          // 0000009A78CC: DC520480 897C008D
	global_load_b32 v133, v[141:142], off offset:1248          // 0000009A78D4: DC5204E0 857C008D
	global_load_b32 v130, v[141:142], off offset:1344          // 0000009A78DC: DC520540 827C008D
	global_load_b32 v126, v[141:142], off offset:1440          // 0000009A78E4: DC5205A0 7E7C008D
	global_load_b32 v155, v[156:157], off offset:768           // 0000009A78EC: DC520300 9B7C009C
	global_load_b32 v153, v[156:157], off offset:864           // 0000009A78F4: DC520360 997C009C
	global_load_b32 v151, v[156:157], off offset:960           // 0000009A78FC: DC5203C0 977C009C
	global_load_b32 v148, v[156:157], off offset:1056          // 0000009A7904: DC520420 947C009C
	global_load_b32 v145, v[156:157], off offset:1152          // 0000009A790C: DC520480 917C009C
	global_load_b32 v141, v[156:157], off offset:1248          // 0000009A7914: DC5204E0 8D7C009C
	global_load_b32 v138, v[156:157], off offset:1344          // 0000009A791C: DC520540 8A7C009C
	global_load_b32 v134, v[156:157], off offset:1440          // 0000009A7924: DC5205A0 867C009C
	global_load_b32 v158, v[159:160], off offset:768           // 0000009A792C: DC520300 9E7C009F
	global_load_b32 v157, v[159:160], off offset:864           // 0000009A7934: DC520360 9D7C009F
	global_load_b32 v156, v[159:160], off offset:960           // 0000009A793C: DC5203C0 9C7C009F
	global_load_b32 v154, v[159:160], off offset:1056          // 0000009A7944: DC520420 9A7C009F
	global_load_b32 v152, v[159:160], off offset:1152          // 0000009A794C: DC520480 987C009F
	global_load_b32 v149, v[159:160], off offset:1248          // 0000009A7954: DC5204E0 957C009F
	global_load_b32 v146, v[159:160], off offset:1344          // 0000009A795C: DC520540 927C009F
	global_load_b32 v142, v[159:160], off offset:1440          // 0000009A7964: DC5205A0 8E7C009F
	s_branch 63532                                             // 0000009A796C: BFA0F82C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2c20>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009A7970: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009A7974: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009A7978: 8C7E017E
	s_waitcnt vmcnt(17)                                        // 0000009A797C: BF8947F7
	v_dual_mov_b32 v6, v9 :: v_dual_mov_b32 v11, v87           // 0000009A7980: CA100109 060A0157
	s_waitcnt vmcnt(1)                                         // 0000009A7988: BF8907F7
	v_dual_mov_b32 v13, v86 :: v_dual_mov_b32 v2, v84          // 0000009A798C: CA100156 0D020154
	v_dual_mov_b32 v1, v85 :: v_dual_mov_b32 v4, v82           // 0000009A7994: CA100155 01040152
	v_dual_mov_b32 v3, v83 :: v_dual_mov_b32 v12, v78          // 0000009A799C: CA100153 030C014E
	v_dual_mov_b32 v5, v81 :: v_dual_mov_b32 v8, v79           // 0000009A79A4: CA100151 0508014F
	s_waitcnt vmcnt(0)                                         // 0000009A79AC: BF8903F7
	v_dual_mov_b32 v7, v80 :: v_dual_mov_b32 v14, v77          // 0000009A79B0: CA100150 070E014D
	v_dual_mov_b32 v15, v76 :: v_dual_mov_b32 v16, v75         // 0000009A79B8: CA10014C 0F10014B
	v_mov_b32_e32 v17, v74                                     // 0000009A79C0: 7E22034A
	v_mov_b32_e32 v18, v10                                     // 0000009A79C4: 7E24030A
	s_mov_b32 s0, 0x76543210                                   // 0000009A79C8: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009A79D0: BF870009
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000009A79D4: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 0000009A79E0: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 0000009A79EC: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 0000009A79F8: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 0000009A7A04: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 0000009A7A10: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 0000009A7A1C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 0000009A7A28: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 0000009A7A34: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 0000009A7A40: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 0000009A7A4C: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 0000009A7A58: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 0000009A7A64: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 0000009A7A70: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 0000009A7A7C: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 0000009A7A88: D65C0012 03FC0112 FEDCBA98
	.long 0xd44c0000                                           // 0000009A7A94: D44C0000
	v_cndmask_b32_e32 v1, 16, v72, vcc_lo                      // 0000009A7A98: 02029090
	s_barrier                                                  // 0000009A7A9C: BFBD0000
	buffer_gl0_inv                                             // 0000009A7AA0: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000009A7AA8: BE812000
	s_cbranch_execz 38                                         // 0000009A7AAC: BFA50026 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4d48>
	v_add_f32_e32 v10, v10, v18                                // 0000009A7AB0: 0614250A
	v_dual_add_f32 v6, v9, v6 :: v_dual_add_f32 v9, v87, v11   // 0000009A7AB4: C9080D09 06081757
	v_add_f32_e32 v11, v86, v13                                // 0000009A7ABC: 06161B56
	v_dual_add_f32 v2, v84, v2 :: v_dual_lshlrev_b32 v13, 2, v72// 0000009A7AC0: C9220554 020C9082
	v_dual_add_f32 v1, v85, v1 :: v_dual_add_f32 v4, v82, v4   // 0000009A7AC8: C9080355 01040952
	v_dual_add_f32 v3, v83, v3 :: v_dual_add_f32 v12, v78, v12 // 0000009A7AD0: C9080753 030C194E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009A7AD8: BF8701B3
	v_lshl_or_b32 v13, v71, 10, v13                            // 0000009A7ADC: D656000D 04351547
	v_dual_add_f32 v5, v81, v5 :: v_dual_add_f32 v8, v79, v8   // 0000009A7AE4: C9080B51 0508114F
	v_dual_add_f32 v7, v80, v7 :: v_dual_add_f32 v14, v77, v14 // 0000009A7AEC: C9080F50 070E1D4D
	v_dual_add_f32 v16, v75, v16 :: v_dual_add_nc_u32 v13, 0x2800, v13// 0000009A7AF4: C920214B 100C1AFF 00002800
	v_add_f32_e32 v15, v76, v15                                // 0000009A7B00: 061E1F4C
	v_add_f32_e32 v17, v74, v17                                // 0000009A7B04: 0622234A
	ds_store_2addr_b32 v13, v6, v9 offset1:16                  // 0000009A7B08: D8381000 0009060D
	ds_store_2addr_b32 v13, v11, v1 offset0:32 offset1:48      // 0000009A7B10: D8383020 00010B0D
	ds_store_2addr_b32 v13, v2, v3 offset0:64 offset1:80       // 0000009A7B18: D8385040 0003020D
	ds_store_2addr_b32 v13, v4, v5 offset0:96 offset1:112      // 0000009A7B20: D8387060 0005040D
	ds_store_2addr_b32 v13, v7, v8 offset0:128 offset1:144     // 0000009A7B28: D8389080 0008070D
	ds_store_2addr_b32 v13, v12, v14 offset0:160 offset1:176   // 0000009A7B30: D838B0A0 000E0C0D
	ds_store_2addr_b32 v13, v15, v16 offset0:192 offset1:208   // 0000009A7B38: D838D0C0 00100F0D
	ds_store_2addr_b32 v13, v17, v10 offset0:224 offset1:240   // 0000009A7B40: D838F0E0 000A110D
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009A7B48: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 0000009A7B4C: BF89FC07
	s_barrier                                                  // 0000009A7B50: BFBD0000
	buffer_gl0_inv                                             // 0000009A7B54: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 0000009A7B5C: BE81007E
	v_cmpx_eq_u32_e32 0, v71                                   // 0000009A7B60: 7D948E80
	s_cbranch_execz 1349                                       // 0000009A7B64: BFA50545 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x627c>
	v_and_b32_e32 v47, 15, v0                                  // 0000009A7B68: 365E008F
	s_mul_i32 s1, s4, 0xa00                                    // 0000009A7B6C: 9601FF04 00000A00
	s_mul_hi_i32 s2, s4, 0xa00                                 // 0000009A7B74: 9702FF04 00000A00
	s_add_u32 s1, s18, s1                                      // 0000009A7B7C: 80010112
	s_addc_u32 s7, s19, s2                                     // 0000009A7B80: 82070213
	v_lshlrev_b32_e32 v3, 2, v47                               // 0000009A7B84: 30065E82
	s_lshl_b32 s2, s5, 7                                       // 0000009A7B88: 84028705
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009A7B8C: BF870499
	s_ashr_i32 s3, s2, 31                                      // 0000009A7B90: 86039F02
	s_lshl_b64 s[12:13], s[2:3], 1                             // 0000009A7B94: 848C8102
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A7B98: BF870001
	v_add_nc_u32_e32 v48, 0x2800, v3                           // 0000009A7B9C: 4A6006FF 00002800
	v_add_nc_u32_e32 v51, 0x3400, v3                           // 0000009A7BA4: 4A6606FF 00003400
	v_add_nc_u32_e32 v52, 0x3800, v3                           // 0000009A7BAC: 4A6806FF 00003800
	v_add_nc_u32_e32 v53, 0x3c00, v3                           // 0000009A7BB4: 4A6A06FF 00003C00
	v_add_nc_u32_e32 v54, 0x4000, v3                           // 0000009A7BBC: 4A6C06FF 00004000
	ds_load_2addr_b32 v[1:2], v48 offset1:16                   // 0000009A7BC4: D8DC1000 01000030
	v_add_nc_u32_e32 v55, 0x4400, v3                           // 0000009A7BCC: 4A6E06FF 00004400
	s_add_u32 s6, s1, s12                                      // 0000009A7BD4: 80060C01
	s_addc_u32 s7, s7, s13                                     // 0000009A7BD8: 82070D07
	s_mul_i32 s1, s4, 0x500                                    // 0000009A7BDC: 9601FF04 00000500
	s_mul_hi_i32 s2, s4, 0x500                                 // 0000009A7BE4: 9702FF04 00000500
	s_add_u32 s1, s20, s1                                      // 0000009A7BEC: 80010114
	s_addc_u32 s2, s21, s2                                     // 0000009A7BF0: 82020215
	s_add_u32 s8, s1, s12                                      // 0000009A7BF4: 80080C01
	s_addc_u32 s9, s2, s13                                     // 0000009A7BF8: 82090D02
	s_waitcnt lgkmcnt(0)                                       // 0000009A7BFC: BF89FC07
	v_dual_add_f32 v2, 0, v2 :: v_dual_add_nc_u32 v49, 0x2c00, v3// 0000009A7C00: C9200480 023006FF 00002C00
	v_dual_add_f32 v1, 0, v1 :: v_dual_add_nc_u32 v50, 0x3000, v3// 0000009A7C0C: C9200280 013206FF 00003000
	ds_load_2addr_b32 v[3:4], v48 offset0:128 offset1:144      // 0000009A7C18: D8DC9080 03000030
	ds_load_2addr_b32 v[5:6], v49 offset1:16                   // 0000009A7C20: D8DC1000 05000031
	ds_load_2addr_b32 v[7:8], v49 offset0:128 offset1:144      // 0000009A7C28: D8DC9080 07000031
	ds_load_2addr_b32 v[9:10], v50 offset1:16                  // 0000009A7C30: D8DC1000 09000032
	ds_load_2addr_b32 v[11:12], v50 offset0:128 offset1:144    // 0000009A7C38: D8DC9080 0B000032
	ds_load_2addr_b32 v[13:14], v51 offset1:16                 // 0000009A7C40: D8DC1000 0D000033
	ds_load_2addr_b32 v[15:16], v51 offset0:128 offset1:144    // 0000009A7C48: D8DC9080 0F000033
	ds_load_2addr_b32 v[17:18], v52 offset1:16                 // 0000009A7C50: D8DC1000 11000034
	ds_load_2addr_b32 v[19:20], v52 offset0:128 offset1:144    // 0000009A7C58: D8DC9080 13000034
	ds_load_2addr_b32 v[21:22], v53 offset1:16                 // 0000009A7C60: D8DC1000 15000035
	ds_load_2addr_b32 v[23:24], v53 offset0:128 offset1:144    // 0000009A7C68: D8DC9080 17000035
	ds_load_2addr_b32 v[25:26], v54 offset1:16                 // 0000009A7C70: D8DC1000 19000036
	ds_load_2addr_b32 v[27:28], v54 offset0:128 offset1:144    // 0000009A7C78: D8DC9080 1B000036
	ds_load_2addr_b32 v[29:30], v55 offset1:16                 // 0000009A7C80: D8DC1000 1D000037
	ds_load_2addr_b32 v[31:32], v55 offset0:128 offset1:144    // 0000009A7C88: D8DC9080 1F000037
	ds_load_2addr_b32 v[33:34], v48 offset0:32 offset1:48      // 0000009A7C90: D8DC3020 21000030
	ds_load_2addr_b32 v[35:36], v48 offset0:160 offset1:176    // 0000009A7C98: D8DCB0A0 23000030
	ds_load_2addr_b32 v[37:38], v49 offset0:32 offset1:48      // 0000009A7CA0: D8DC3020 25000031
	s_waitcnt lgkmcnt(17)                                      // 0000009A7CA8: BF89FD17
	v_add_f32_e32 v56, 0, v4                                   // 0000009A7CAC: 06700880
	s_waitcnt lgkmcnt(16)                                      // 0000009A7CB0: BF89FD07
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v1, v1, v5     // 0000009A7CB4: C9080D02 02000B01
	ds_load_2addr_b32 v[39:40], v49 offset0:160 offset1:176    // 0000009A7CBC: D8DCB0A0 27000031
	ds_load_2addr_b32 v[41:42], v50 offset0:32 offset1:48      // 0000009A7CC4: D8DC3020 29000032
	ds_load_2addr_b32 v[43:44], v50 offset0:160 offset1:176    // 0000009A7CCC: D8DCB0A0 2B000032
	s_waitcnt lgkmcnt(18)                                      // 0000009A7CD4: BF89FD27
	v_add_f32_e32 v8, v56, v8                                  // 0000009A7CD8: 06101138
	s_waitcnt lgkmcnt(17)                                      // 0000009A7CDC: BF89FD17
	v_dual_add_f32 v2, v2, v10 :: v_dual_add_f32 v3, 0, v3     // 0000009A7CE0: C9081502 02020680
	v_add_f32_e32 v1, v1, v9                                   // 0000009A7CE8: 06021301
	ds_load_2addr_b32 v[45:46], v51 offset0:32 offset1:48      // 0000009A7CEC: D8DC3020 2D000033
	s_waitcnt lgkmcnt(17)                                      // 0000009A7CF4: BF89FD17
	v_add_f32_e32 v8, v8, v12                                  // 0000009A7CF8: 06101908
	s_waitcnt lgkmcnt(16)                                      // 0000009A7CFC: BF89FD07
	v_dual_add_f32 v2, v2, v14 :: v_dual_add_f32 v3, v3, v7    // 0000009A7D00: C9081D02 02020F03
	v_add_f32_e32 v1, v1, v13                                  // 0000009A7D08: 06021B01
	ds_load_2addr_b32 v[4:5], v51 offset0:160 offset1:176      // 0000009A7D0C: D8DCB0A0 04000033
	s_waitcnt lgkmcnt(16)                                      // 0000009A7D14: BF89FD07
	v_add_f32_e32 v8, v8, v16                                  // 0000009A7D18: 06102108
	s_waitcnt lgkmcnt(15)                                      // 0000009A7D1C: BF89FCF7
	v_dual_add_f32 v2, v2, v18 :: v_dual_add_f32 v3, v3, v11   // 0000009A7D20: C9082502 02021703
	s_waitcnt lgkmcnt(6)                                       // 0000009A7D28: BF89FC67
	v_dual_add_f32 v1, v1, v17 :: v_dual_add_f32 v12, 0, v35   // 0000009A7D2C: C9082301 010C4680
	v_add_f32_e32 v8, v8, v20                                  // 0000009A7D34: 06102908
	ds_load_2addr_b32 v[6:7], v52 offset0:32 offset1:48        // 0000009A7D38: D8DC3020 06000034
	v_add_f32_e32 v3, v3, v15                                  // 0000009A7D40: 06061F03
	v_add_f32_e32 v9, 0, v33                                   // 0000009A7D44: 06124280
	v_add_f32_e32 v15, v2, v22                                 // 0000009A7D48: 061E2D02
	v_dual_add_f32 v1, v1, v21 :: v_dual_add_f32 v16, v8, v24  // 0000009A7D4C: C9082B01 01103108
	s_waitcnt lgkmcnt(6)                                       // 0000009A7D54: BF89FC67
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A7D58: BF870003
	v_dual_add_f32 v3, v3, v19 :: v_dual_add_f32 v14, v9, v37  // 0000009A7D5C: C9082703 030E4B09
	ds_load_2addr_b32 v[10:11], v53 offset0:32 offset1:48      // 0000009A7D64: D8DC3020 0A000035
	v_dual_add_f32 v18, v15, v26 :: v_dual_add_f32 v1, v1, v25 // 0000009A7D6C: C908350F 12003301
	v_dual_add_f32 v16, v16, v28 :: v_dual_add_f32 v3, v3, v23 // 0000009A7D74: C9083910 10022F03
	s_waitcnt lgkmcnt(5)                                       // 0000009A7D7C: BF89FC57
	v_add_f32_e32 v14, v14, v41                                // 0000009A7D80: 061C530E
	ds_load_2addr_b32 v[8:9], v52 offset0:160 offset1:176      // 0000009A7D84: D8DCB0A0 08000034
	v_dual_add_f32 v56, v1, v29 :: v_dual_lshlrev_b32 v1, 1, v47// 0000009A7D8C: C9223B01 38005E81
	s_waitcnt lgkmcnt(4)                                       // 0000009A7D94: BF89FC47
	v_dual_add_f32 v17, v3, v27 :: v_dual_add_f32 v20, v14, v45// 0000009A7D98: C9083703 11145B0E
	v_lshlrev_b32_e32 v47, 1, v0                               // 0000009A7DA0: 305E0081
	ds_load_2addr_b32 v[14:15], v54 offset0:32 offset1:48      // 0000009A7DA4: D8DC3020 0E000036
	ds_load_2addr_b32 v[24:25], v49 offset0:64 offset1:80      // 0000009A7DAC: D8DC5040 18000031
	ds_load_2addr_b32 v[26:27], v49 offset0:192 offset1:208    // 0000009A7DB4: D8DCD0C0 1A000031
	s_waitcnt lgkmcnt(5)                                       // 0000009A7DBC: BF89FC57
	v_dual_add_f32 v41, v17, v31 :: v_dual_add_f32 v6, v20, v6 // 0000009A7DC0: C9083F11 29060D14
	v_add_f32_e32 v3, v12, v39                                 // 0000009A7DC8: 06064F0C
	ds_load_2addr_b32 v[12:13], v53 offset0:160 offset1:176    // 0000009A7DCC: D8DCB0A0 0C000035
	ds_load_2addr_b32 v[20:21], v48 offset0:192 offset1:208    // 0000009A7DD4: D8DCD0C0 14000030
	ds_load_2addr_b32 v[22:23], v55 offset0:32 offset1:48      // 0000009A7DDC: D8DC3020 16000037
	global_load_d16_b16 v2, v1, s[6:7]                         // 0000009A7DE4: DC820000 02060001
	s_waitcnt lgkmcnt(7)                                       // 0000009A7DEC: BF89FC77
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v19, v3, v43  // 0000009A7DF0: C9081506 06125703
	v_add_f32_e32 v45, v16, v32                                // 0000009A7DF8: 065A4110
	ds_load_2addr_b32 v[16:17], v54 offset0:160 offset1:176    // 0000009A7DFC: D8DCB0A0 10000036
	v_dual_add_f32 v43, v18, v30 :: v_dual_add_f32 v10, 0, v36 // 0000009A7E04: C9083D12 2B0A4880
	v_add_f32_e32 v4, v19, v4                                  // 0000009A7E0C: 06080913
	ds_load_2addr_b32 v[18:19], v48 offset0:64 offset1:80      // 0000009A7E10: D8DC5040 12000030
	ds_load_2addr_b32 v[36:37], v52 offset0:192 offset1:208    // 0000009A7E18: D8DCD0C0 24000034
	ds_load_2addr_b32 v[28:29], v50 offset0:64 offset1:80      // 0000009A7E20: D8DC5040 1C000032
	ds_load_2addr_b32 v[30:31], v50 offset0:192 offset1:208    // 0000009A7E28: D8DCD0C0 1E000032
	ds_load_2addr_b32 v[32:33], v55 offset0:160 offset1:176    // 0000009A7E30: D8DCB0A0 20000037
	v_add_f32_e32 v10, v10, v40                                // 0000009A7E38: 0614510A
	s_waitcnt lgkmcnt(12)                                      // 0000009A7E3C: BF89FCC7
	v_add_f32_e32 v4, v4, v8                                   // 0000009A7E40: 06081104
	v_add_f32_e32 v8, 0, v34                                   // 0000009A7E44: 06104480
	ds_load_2addr_b32 v[34:35], v51 offset0:64 offset1:80      // 0000009A7E48: D8DC5040 22000033
	v_or_b32_e32 v39, 32, v47                                  // 0000009A7E50: 384E5EA0
	v_add_f32_e32 v8, v8, v38                                  // 0000009A7E54: 06104D08
	s_waitcnt lgkmcnt(9)                                       // 0000009A7E58: BF89FC97
	v_add_f32_e32 v4, v4, v12                                  // 0000009A7E5C: 06081904
	v_add_f32_e32 v12, v6, v14                                 // 0000009A7E60: 06181D06
	global_load_d16_b16 v3, v39, s[6:7]                        // 0000009A7E64: DC820000 03060027
	v_add_f32_e32 v6, v8, v42                                  // 0000009A7E6C: 060C5508
	v_add_f32_e32 v8, v10, v44                                 // 0000009A7E70: 0610590A
	s_waitcnt lgkmcnt(6)                                       // 0000009A7E74: BF89FC67
	v_add_f32_e32 v14, v4, v16                                 // 0000009A7E78: 061C2104
	v_add_f32_e32 v38, v12, v22                                // 0000009A7E7C: 064C2D0C
	s_waitcnt lgkmcnt(5)                                       // 0000009A7E80: BF89FC57
	v_add_f32_e32 v16, 0, v18                                  // 0000009A7E84: 06202480
	v_add_f32_e32 v8, v8, v5                                   // 0000009A7E88: 06100B08
	ds_load_2addr_b32 v[4:5], v51 offset0:192 offset1:208      // 0000009A7E8C: D8DCD0C0 04000033
	v_add_f32_e32 v6, v6, v46                                  // 0000009A7E94: 060C5D06
	v_add_f32_e32 v18, 0, v20                                  // 0000009A7E98: 06242880
	v_add_f32_e32 v12, v16, v24                                // 0000009A7E9C: 06183110
	v_add_f32_e32 v8, v8, v9                                   // 0000009A7EA0: 06101308
	s_waitcnt lgkmcnt(2)                                       // 0000009A7EA4: BF89FC27
	v_add_f32_e32 v40, v14, v32                                // 0000009A7EA8: 0650410E
	v_add_f32_e32 v10, v6, v7                                  // 0000009A7EAC: 06140F06
	ds_load_2addr_b32 v[6:7], v52 offset0:64 offset1:80        // 0000009A7EB0: D8DC5040 06000034
	v_dual_add_f32 v16, v18, v26 :: v_dual_add_f32 v13, v8, v13// 0000009A7EB8: C9083512 100C1B08
	ds_load_2addr_b32 v[8:9], v53 offset0:64 offset1:80        // 0000009A7EC0: D8DC5040 08000035
	v_add_f32_e32 v18, v10, v11                                // 0000009A7EC8: 0624170A
	v_add_f32_e32 v12, v12, v28                                // 0000009A7ECC: 0618390C
	v_add_f32_e32 v16, v16, v30                                // 0000009A7ED0: 06203D10
	v_add_f32_e32 v30, v13, v17                                // 0000009A7ED4: 063C230D
	v_add_f32_e32 v20, 0, v19                                  // 0000009A7ED8: 06282680
	v_add_f32_e32 v22, v18, v15                                // 0000009A7EDC: 062C1F12
	s_waitcnt lgkmcnt(3)                                       // 0000009A7EE0: BF89FC37
	v_add_f32_e32 v18, v12, v34                                // 0000009A7EE4: 0624450C
	ds_load_2addr_b32 v[12:13], v54 offset0:64 offset1:80      // 0000009A7EE8: D8DC5040 0C000036
	ds_load_2addr_b32 v[14:15], v54 offset0:192 offset1:208    // 0000009A7EF0: D8DCD0C0 0E000036
	v_add_f32_e32 v28, 0, v21                                  // 0000009A7EF8: 06382A80
	ds_load_2addr_b32 v[10:11], v53 offset0:192 offset1:208    // 0000009A7EFC: D8DCD0C0 0A000035
	v_add_f32_e32 v42, v22, v23                                // 0000009A7F04: 06542F16
	s_waitcnt lgkmcnt(5)                                       // 0000009A7F08: BF89FC57
	v_add_f32_e32 v4, v16, v4                                  // 0000009A7F0C: 06080910
	v_add_f32_e32 v32, v20, v25                                // 0000009A7F10: 06403314
	ds_load_2addr_b32 v[20:21], v48 offset0:96 offset1:112     // 0000009A7F14: D8DC7060 14000030
	ds_load_2addr_b32 v[24:25], v48 offset0:224 offset1:240    // 0000009A7F1C: D8DCF0E0 18000030
	ds_load_2addr_b32 v[22:23], v50 offset0:96 offset1:112     // 0000009A7F24: D8DC7060 16000032
	s_waitcnt lgkmcnt(7)                                       // 0000009A7F2C: BF89FC77
	v_add_f32_e32 v6, v18, v6                                  // 0000009A7F30: 060C0D12
	ds_load_2addr_b32 v[16:17], v55 offset0:64 offset1:80      // 0000009A7F34: D8DC5040 10000037
	ds_load_2addr_b32 v[18:19], v55 offset0:192 offset1:208    // 0000009A7F3C: D8DCD0C0 12000037
	v_add_f32_e32 v32, v32, v29                                // 0000009A7F44: 06403B20
	v_or_b32_e32 v46, 0x60, v47                                // 0000009A7F48: 385C5EFF 00000060
	s_waitcnt lgkmcnt(8)                                       // 0000009A7F50: BF89FC87
	v_add_f32_e32 v6, v6, v8                                   // 0000009A7F54: 060C1106
	v_add_f32_e32 v8, v28, v27                                 // 0000009A7F58: 0610371C
	s_waitcnt lgkmcnt(7)                                       // 0000009A7F5C: BF89FC77
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A7F60: BF870112
	v_add_f32_e32 v6, v6, v12                                  // 0000009A7F64: 060C1906
	v_add_f32_e32 v8, v8, v31                                  // 0000009A7F68: 06103F08
	v_add_f32_e32 v12, v32, v35                                // 0000009A7F6C: 06184720
	s_waitcnt lgkmcnt(4)                                       // 0000009A7F70: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000009A7F74: BF870132
	v_dual_add_f32 v5, v8, v5 :: v_dual_add_f32 v8, 0, v20     // 0000009A7F78: C9080B08 05082880
	s_waitcnt lgkmcnt(1)                                       // 0000009A7F80: BF89FC17
	v_add_f32_e32 v16, v6, v16                                 // 0000009A7F84: 06202106
	v_dual_add_f32 v6, v12, v7 :: v_dual_add_f32 v7, v5, v37   // 0000009A7F88: C9080F0C 06064B05
	v_add_f32_e32 v12, 0, v24                                  // 0000009A7F90: 06183080
	global_load_d16_b16 v5, v1, s[6:7] offset:1280             // 0000009A7F94: DC820500 05060001
	v_dual_add_f32 v44, v6, v9 :: v_dual_add_f32 v7, v7, v11   // 0000009A7F9C: C9081306 2C061707
	s_clause 0x1                                               // 0000009A7FA4: BF850001
	global_load_d16_b16 v6, v39, s[6:7] offset:1280            // 0000009A7FA8: DC820500 06060027
	global_load_d16_b16 v9, v46, s[6:7]                        // 0000009A7FB0: DC820000 0906002E
	v_add_f32_e32 v13, v44, v13                                // 0000009A7FB8: 061A1B2C
	v_add_f32_e32 v7, v7, v15                                  // 0000009A7FBC: 060E1F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009A7FC0: BF870122
	v_add_f32_e32 v13, v13, v17                                // 0000009A7FC4: 061A230D
	s_waitcnt lgkmcnt(0)                                       // 0000009A7FC8: BF89FC07
	v_dual_add_f32 v19, v7, v19 :: v_dual_add_f32 v26, v4, v36 // 0000009A7FCC: C9082707 131A4904
	ds_load_2addr_b32 v[34:35], v52 offset0:96 offset1:112     // 0000009A7FD4: D8DC7060 22000034
	ds_load_2addr_b32 v[36:37], v52 offset0:224 offset1:240    // 0000009A7FDC: D8DCF0E0 24000034
	global_load_d16_b16 v4, v1, s[6:7] offset:64               // 0000009A7FE4: DC820040 04060001
	v_add_f32_e32 v10, v26, v10                                // 0000009A7FEC: 0614151A
	ds_load_2addr_b32 v[26:27], v49 offset0:96 offset1:112     // 0000009A7FF0: D8DC7060 1A000031
	ds_load_2addr_b32 v[28:29], v49 offset0:224 offset1:240    // 0000009A7FF8: D8DCF0E0 1C000031
	v_add_f32_e32 v10, v10, v14                                // 0000009A8000: 06141D0A
	v_add_f32_e32 v14, v30, v33                                // 0000009A8004: 061C431E
	ds_load_2addr_b32 v[30:31], v51 offset0:96 offset1:112     // 0000009A8008: D8DC7060 1E000033
	ds_load_2addr_b32 v[32:33], v51 offset0:224 offset1:240    // 0000009A8010: D8DCF0E0 20000033
	v_add_f32_e32 v18, v10, v18                                // 0000009A8018: 0624250A
	ds_load_2addr_b32 v[10:11], v50 offset0:224 offset1:240    // 0000009A801C: D8DCF0E0 0A000032
	s_waitcnt lgkmcnt(4)                                       // 0000009A8024: BF89FC47
	v_add_f32_e32 v8, v8, v26                                  // 0000009A8028: 06103508
	s_waitcnt lgkmcnt(3)                                       // 0000009A802C: BF89FC37
	v_add_f32_e32 v12, v12, v28                                // 0000009A8030: 0618390C
	v_add_f32_e32 v26, 0, v21                                  // 0000009A8034: 06342A80
	v_add_f32_e32 v28, 0, v25                                  // 0000009A8038: 06383280
	ds_load_2addr_b32 v[20:21], v53 offset0:96 offset1:112     // 0000009A803C: D8DC7060 14000035
	ds_load_2addr_b32 v[24:25], v53 offset0:224 offset1:240    // 0000009A8044: D8DCF0E0 18000035
	v_add_f32_e32 v22, v8, v22                                 // 0000009A804C: 062C2D08
	global_load_d16_b16 v8, v39, s[8:9]                        // 0000009A8050: DC820000 08080027
	s_waitcnt lgkmcnt(4)                                       // 0000009A8058: BF89FC47
	v_dual_add_f32 v39, v28, v29 :: v_dual_add_f32 v30, v22, v30// 0000009A805C: C9083B1C 271E3D16
	s_waitcnt lgkmcnt(2)                                       // 0000009A8064: BF89FC27
	v_add_f32_e32 v10, v12, v10                                // 0000009A8068: 0614150C
	v_add_f32_e32 v12, v26, v27                                // 0000009A806C: 0618371A
	ds_load_2addr_b32 v[26:27], v54 offset0:96 offset1:112     // 0000009A8070: D8DC7060 1A000036
	ds_load_2addr_b32 v[28:29], v54 offset0:224 offset1:240    // 0000009A8078: D8DCF0E0 1C000036
	v_dual_add_f32 v39, v39, v11 :: v_dual_add_f32 v30, v30, v34// 0000009A8080: C9081727 271E451E
	v_add_f32_e32 v32, v10, v32                                // 0000009A8088: 0640410A
	v_add_f32_e32 v12, v12, v23                                // 0000009A808C: 06182F0C
	ds_load_2addr_b32 v[10:11], v55 offset0:96 offset1:112     // 0000009A8090: D8DC7060 0A000037
	ds_load_2addr_b32 v[22:23], v55 offset0:224 offset1:240    // 0000009A8098: D8DCF0E0 16000037
	v_add_f32_e32 v32, v32, v36                                // 0000009A80A0: 06404920
	v_dual_add_f32 v12, v12, v31 :: v_dual_add_f32 v31, v39, v33// 0000009A80A4: C9083F0C 0C1E4327
	s_waitcnt lgkmcnt(5)                                       // 0000009A80AC: BF89FC57
	v_add_f32_e32 v15, v30, v20                                // 0000009A80B0: 061E291E
	s_waitcnt lgkmcnt(4)                                       // 0000009A80B4: BF89FC47
	v_add_f32_e32 v20, v32, v24                                // 0000009A80B8: 06283120
	v_dual_add_f32 v12, v12, v35 :: v_dual_add_f32 v31, v31, v37// 0000009A80BC: C908470C 0C1E4B1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A80C4: BF870111
	v_dual_add_f32 v12, v12, v21 :: v_dual_and_b32 v37, 1, v0  // 0000009A80C8: C9242B0C 0C240081
	v_add_f32_e32 v21, v31, v25                                // 0000009A80D0: 062A331F
	s_waitcnt lgkmcnt(3)                                       // 0000009A80D4: BF89FC37
	v_add_f32_e32 v15, v15, v26                                // 0000009A80D8: 061E350F
	s_waitcnt lgkmcnt(2)                                       // 0000009A80DC: BF89FC27
	v_add_f32_e32 v17, v20, v28                                // 0000009A80E0: 06223914
	v_add_f32_e32 v25, v18, v19                                // 0000009A80E4: 06322712
	v_add_f32_e32 v12, v12, v27                                // 0000009A80E8: 0618370C
	s_waitcnt lgkmcnt(1)                                       // 0000009A80EC: BF89FC17
	v_dual_add_f32 v20, v21, v29 :: v_dual_add_f32 v7, v15, v10// 0000009A80F0: C9083B15 1406150F
	s_waitcnt lgkmcnt(0)                                       // 0000009A80F8: BF89FC07
	v_dual_add_f32 v10, v17, v22 :: v_dual_sub_f32 v17, v56, v43// 0000009A80FC: C90A2D11 0A105738
	v_add_f32_e32 v11, v12, v11                                // 0000009A8104: 0616170C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A8108: BF870003
	v_dual_add_f32 v12, v20, v23 :: v_dual_add_f32 v23, v41, v45// 0000009A810C: C9082F14 0C165B29
	v_add_f32_e32 v24, v40, v14                                // 0000009A8114: 06301D28
	.long 0xd44a0002                                           // 0000009A8118: D44A0002
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 0000009A811C: 02024A80
	v_sub_f32_e32 v37, v41, v45                                // 0000009A8120: 084A5B29
	v_sub_f32_e32 v21, v38, v42                                // 0000009A8124: 082A5526
	v_add_f32_e32 v27, v10, v12                                // 0000009A8128: 0636190A
	v_dual_add_f32 v30, v23, v24 :: v_dual_add_f32 v15, v56, v43// 0000009A812C: C9083117 1E0E5738
	v_add_f32_e32 v20, v38, v42                                // 0000009A8134: 06285526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A8138: BF870214
	v_add_f32_e32 v36, v17, v21                                // 0000009A813C: 06482B11
	v_add_f32_e32 v31, v25, v27                                // 0000009A8140: 063E3719
	v_dual_sub_f32 v18, v18, v19 :: v_dual_and_b32 v19, 2, v0  // 0000009A8144: C9642712 12120082
	v_sub_f32_e32 v17, v17, v21                                // 0000009A814C: 08222B11
	v_add_f32_e32 v29, v15, v20                                // 0000009A8150: 063A290F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A8154: BF870004
	v_add_f32_e32 v21, v30, v31                                // 0000009A8158: 062A3F1E
	v_sub_f32_e32 v10, v10, v12                                // 0000009A815C: 0814190A
	.long 0xd44a0003                                           // 0000009A8160: D44A0003
	v_cndmask_b32_e32 v1, 0, v19, vcc_lo                       // 0000009A8164: 02022680
	v_sub_f32_e32 v19, v23, v24                                // 0000009A8168: 08263117
	v_dual_sub_f32 v23, v25, v27 :: v_dual_add_f32 v22, v16, v13// 0000009A816C: C9483719 17161B10
	v_dual_sub_f32 v13, v16, v13 :: v_dual_add_f32 v16, v7, v11// 0000009A8174: C9481B10 0D101707
	v_sub_f32_e32 v11, v7, v11                                 // 0000009A817C: 08161707
	v_sub_f32_e32 v15, v15, v20                                // 0000009A8180: 081E290F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A8184: BF870214
	v_dual_add_f32 v27, v19, v23 :: v_dual_and_b32 v24, 4, v0  // 0000009A8188: C9242F13 1B180084
	v_add_f32_e32 v39, v22, v16                                // 0000009A8190: 064E2116
	v_sub_f32_e32 v16, v22, v16                                // 0000009A8194: 08202116
	v_mov_b32_dpp v22, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A8198: 7E2C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 0000009A81A0: D5010015 200A2B15
	.long 0xd44a0004                                           // 0000009A81A8: D44A0004
	v_cndmask_b32_e32 v1, 0, v24, vcc_lo                       // 0000009A81AC: 02023080
	v_mov_b32_dpp v24, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A81B0: 7E3002FA FF01611B
	v_and_b32_e32 v0, 8, v0                                    // 0000009A81B8: 36000088
	v_or_b32_e32 v28, 0xa0, v47                                // 0000009A81BC: 38385EFF 000000A0
	v_add_f32_e32 v12, v21, v22                                // 0000009A81C4: 06182D15
	v_add_f32_e32 v21, v13, v11                                // 0000009A81C8: 062A170D
	v_dual_sub_f32 v11, v13, v11 :: v_dual_sub_f32 v14, v40, v14// 0000009A81CC: C94A170D 0B0E1D28
	v_add_f32_e32 v40, v18, v10                                // 0000009A81D4: 06501512
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A81D8: BF870004
	v_mov_b32_dpp v41, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A81DC: 7E5202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 0000009A81E4: D501000C 200E190C
	.long 0xd44a0001                                           // 0000009A81EC: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000009A81F0: 02020080
	v_add_f32_e32 v22, v37, v14                                // 0000009A81F4: 062C1D25
	v_sub_f32_e32 v0, v37, v14                                 // 0000009A81F8: 08001D25
	v_sub_f32_e32 v10, v18, v10                                // 0000009A81FC: 08141512
	v_add_f32_e32 v12, v12, v41                                // 0000009A8200: 0618530C
	v_or_b32_e32 v20, 0xe0, v47                                // 0000009A8204: 38285EFF 000000E0
	v_add_f32_e32 v13, v22, v40                                // 0000009A820C: 061A5116
	s_clause 0x4                                               // 0000009A8210: BF850004
	global_load_d16_b16 v32, v28, s[6:7]                       // 0000009A8214: DC820000 2006001C
	global_load_d16_b16 v33, v1, s[6:7] offset:1344            // 0000009A821C: DC820540 21060001
	global_load_d16_b16 v7, v1, s[6:7] offset:1408             // 0000009A8224: DC820580 07060001
	global_load_d16_b16 v34, v1, s[6:7] offset:1472            // 0000009A822C: DC8205C0 22060001
	global_load_d16_b16 v35, v1, s[6:7] offset:192             // 0000009A8234: DC8200C0 23060001
	v_sub_f32_e32 v22, v22, v40                                // 0000009A823C: 082C5116
	v_mov_b32_dpp v41, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8240: 7E5202FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s4                       // 0000009A8248: D501000C 2012190C
	v_mov_b32_dpp v25, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A8250: 7E3202FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 0000009A8258: D501000D 200A1B0D
	global_load_d16_b16 v38, v20, s[6:7]                       // 0000009A8260: DC820000 26060014
	v_add_f32_e32 v43, v36, v21                                // 0000009A8268: 06562B24
	v_add_f32_e32 v12, v12, v41                                // 0000009A826C: 0618530C
	s_clause 0x3                                               // 0000009A8270: BF850003
	global_load_d16_b16 v37, v1, s[8:9]                        // 0000009A8274: DC820000 25080001
	global_load_d16_b16 v40, v1, s[8:9] offset:64              // 0000009A827C: DC820040 28080001
	global_load_d16_b16 v41, v1, s[8:9] offset:128             // 0000009A8284: DC820080 29080001
	global_load_d16_b16 v42, v1, s[8:9] offset:192             // 0000009A828C: DC8200C0 2A080001
	v_add_f32_e32 v13, v13, v25                                // 0000009A8294: 061A330D
	v_cndmask_b32_e64 v25, -v27, v27, s2                       // 0000009A8298: D5010019 200A371B
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A82A0: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 0000009A82A8: D501002B 200A572B
	v_mov_b32_dpp v47, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A82B0: 7E5E02FA FF016116
	v_mov_b32_dpp v27, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A82B8: 7E3602FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 0000009A82C0: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A82C8: BF8701A4
	v_dual_add_f32 v24, v25, v24 :: v_dual_add_f32 v43, v43, v45// 0000009A82CC: C9083119 182A5B2B
	v_cndmask_b32_e64 v22, -v22, v22, s2                       // 0000009A82D4: D5010016 200A2D16
	v_add_f32_e32 v13, v13, v27                                // 0000009A82DC: 061A370D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A82E0: BF870003
	v_mov_b32_dpp v14, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A82E4: 7E1C02FA FF016218
	v_cndmask_b32_e64 v18, -v24, v24, s3                       // 0000009A82EC: D5010012 200E3118
	v_sub_f32_e32 v24, v30, v31                                // 0000009A82F4: 08303F1E
	global_load_d16_b16 v27, v46, s[6:7] offset:1280           // 0000009A82F8: DC820500 1B06002E
	v_mov_b32_dpp v25, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8300: 7E3202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 0000009A8308: D501000D 20121B0D
	v_add_f32_e32 v14, v18, v14                                // 0000009A8310: 061C1D12
	v_dual_sub_f32 v18, v19, v23 :: v_dual_add_f32 v19, v0, v10// 0000009A8314: C9482F13 12121500
	v_mov_b32_dpp v23, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A831C: 7E2E02FA FF01680C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A8324: BF870214
	v_add_f32_e32 v13, v13, v25                                // 0000009A8328: 061A330D
	v_mov_b32_dpp v25, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A832C: 7E3202FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 0000009A8334: D501000E 20121D0E
	v_mov_b32_dpp v30, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A833C: 7E3C02FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 0000009A8344: D5010013 200A2713
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 0000009A834C: D501000C 2006190C
	v_mov_b32_dpp v31, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8354: 7E3E02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 0000009A835C: D501000D 20061B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A8364: BF870234
	v_dual_add_f32 v14, v14, v25 :: v_dual_add_f32 v19, v19, v30// 0000009A8368: C908330E 0E123D13
	v_sub_f32_e32 v0, v0, v10                                  // 0000009A8370: 08001500
	v_add_f32_e32 v10, v12, v23                                // 0000009A8374: 06142F0C
	v_add_f32_e32 v12, v13, v31                                // 0000009A8378: 06183F0D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A837C: BF870004
	v_mov_b32_dpp v13, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8380: 7E1A02FA FF01680E
	v_mov_b32_dpp v23, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8388: 7E2E02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 0000009A8390: D5010013 200E2713
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 0000009A8398: D501000E 20061D0E
	v_mov_b32_dpp v25, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A83A0: 7E3202FA FF016118
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 0000009A83A8: D5010018 200A3118
	v_add_f32_e32 v31, v29, v39                                // 0000009A83B0: 063E4F1D
	v_add_f32_e32 v19, v19, v23                                // 0000009A83B4: 06262F13
	v_add_f32_e32 v13, v14, v13                                // 0000009A83B8: 061A1B0E
	global_load_d16_b16 v23, v28, s[6:7] offset:1280           // 0000009A83BC: DC820500 1706001C
	v_add_f32_e32 v14, v24, v25                                // 0000009A83C4: 061C3318
	s_clause 0x1                                               // 0000009A83C8: BF850001
	global_load_d16_b16 v25, v20, s[6:7] offset:1280           // 0000009A83CC: DC820500 19060014
	global_load_d16_b16 v26, v1, s[6:7] offset:128             // 0000009A83D4: DC820080 1A060001
	v_mov_b32_dpp v24, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A83DC: 7E3002FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s4                       // 0000009A83E4: D5010013 20122713
	s_clause 0x1                                               // 0000009A83EC: BF850001
	global_load_d16_b16 v28, v28, s[8:9]                       // 0000009A83F0: DC820000 1C08001C
	global_load_d16_b16 v20, v20, s[8:9]                       // 0000009A83F8: DC820000 14080014
	v_mov_b32_dpp v30, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8400: 7E3C02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 0000009A8408: D501000E 200E1D0E
	v_add_f32_e32 v19, v19, v24                                // 0000009A8410: 06263113
	global_load_d16_b16 v24, v46, s[8:9]                       // 0000009A8414: DC820000 1808002E
	v_add_f32_e32 v22, v22, v47                                // 0000009A841C: 062C5F16
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 0000009A8420: 101414FF 3DB504F3
	v_add_f32_e32 v14, v14, v30                                // 0000009A8428: 061C3D0E
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A842C: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 0000009A8434: D501001F 200A3F1F
	v_mov_b32_dpp v44, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A843C: 7E5802FA FF016813
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 0000009A8444: D5010013 20062713
	v_dual_sub_f32 v29, v29, v39 :: v_dual_mul_f32 v12, 0x3db504f3, v12// 0000009A844C: C9464F1D 1D0C18FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A8458: BF870004
	v_add_f32_e32 v30, v31, v30                                // 0000009A845C: 063C3D1F
	v_mov_b32_dpp v31, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8460: 7E3E02FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 0000009A8468: D501000E 20121D0E
	v_add_f32_e32 v19, v19, v44                                // 0000009A8470: 06265913
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 0000009A8474: 101A1AFF 3DB504F3
	v_mov_b32_dpp v46, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A847C: 7E5C02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 0000009A8484: D501001E 200E3D1E
	v_add_f32_e32 v14, v14, v31                                // 0000009A848C: 061C3F0E
	v_mov_b32_dpp v31, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8490: 7E3E02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 0000009A8498: D501002B 200E572B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A84A0: BF870234
	v_dual_mul_f32 v19, 0x3db504f3, v19 :: v_dual_add_f32 v30, v30, v46// 0000009A84A4: C8C826FF 131E5D1E 3DB504F3
	v_mov_b32_dpp v46, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A84B0: 7E5C02FA FF016216
	v_cndmask_b32_e64 v22, -v22, v22, s3                       // 0000009A84B8: D5010016 200E2D16
	v_add_f32_e32 v31, v43, v31                                // 0000009A84C0: 063E3F2B
	v_mov_b32_dpp v43, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A84C4: 7E5602FA FF01680E
	v_mov_b32_dpp v45, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A84CC: 7E5A02FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 0000009A84D4: D501001E 20123D1E
	v_add_f32_e32 v22, v22, v46                                // 0000009A84DC: 062C5D16
	v_mov_b32_dpp v44, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A84E0: 7E5802FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 0000009A84E8: D501001F 20123F1F
	v_mov_b32_dpp v46, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A84F0: 7E5C02FA FF016112
	v_add_f32_e32 v30, v30, v45                                // 0000009A84F8: 063C5B1E
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 0000009A84FC: D5010012 200A2512
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 0000009A8504: D501000E 20061D0E
	v_add_f32_e32 v31, v31, v44                                // 0000009A850C: 063E591F
	v_mov_b32_dpp v44, v22 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8510: 7E5802FA FF016416
	v_mov_b32_dpp v45, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8518: 7E5A02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 0000009A8520: D501001E 20063D1E
	v_add_f32_e32 v18, v18, v46                                // 0000009A8528: 06245D12
	v_cndmask_b32_e64 v22, -v22, v22, s4                       // 0000009A852C: D5010016 20122D16
	v_add_f32_e32 v14, v14, v43                                // 0000009A8534: 061C570E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A8538: BF870004
	v_add_f32_e32 v30, v30, v45                                // 0000009A853C: 063C5B1E
	v_mov_b32_dpp v45, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8540: 7E5A02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 0000009A8548: D501001F 20063F1F
	v_mov_b32_dpp v46, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8550: 7E5C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 0000009A8558: D5010012 200E2512
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 0000009A8560: 103C3CFF 3DB504F3
	v_add_f32_e32 v22, v22, v44                                // 0000009A8568: 062C5916
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A856C: BF8701A3
	v_add_f32_e32 v18, v18, v46                                // 0000009A8570: 06245D12
	s_waitcnt vmcnt(23)                                        // 0000009A8574: BF895FF7
	v_fma_mix_f32 v2, v2, v30, neg(0) op_sel_hi:[1,0,0]        // 0000009A8578: CC200002 8A023D02
	v_add_f32_e32 v30, v31, v45                                // 0000009A8580: 063C5B1F
	v_mov_b32_dpp v31, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8584: 7E3E02FA FF016816
	v_cndmask_b32_e64 v22, -v22, v22, s1                       // 0000009A858C: D5010016 20062D16
	v_mov_b32_dpp v44, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8594: 7E5802FA FF016412
	v_mul_f32_e32 v43, 0xbfb8aa3b, v2                          // 0000009A859C: 105604FF BFB8AA3B
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 0000009A85A4: 103C3CFF 3DB504F3
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 0000009A85AC: D5010012 20122512
	v_dual_add_f32 v22, v22, v31 :: v_dual_add_f32 v31, v15, v16// 0000009A85B4: C9083F16 161E210F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A85BC: BF870004
	v_exp_f32_e32 v43, v43                                     // 0000009A85C0: 7E564B2B
	s_waitcnt vmcnt(22)                                        // 0000009A85C4: BF895BF7
	v_fma_mix_f32 v3, v3, v30, neg(0) op_sel_hi:[1,0,0]        // 0000009A85C8: CC200003 8A023D03
	v_add_f32_e32 v18, v18, v44                                // 0000009A85D0: 06245912
	v_mov_b32_dpp v44, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A85D4: 7E5802FA FF016100
	v_cndmask_b32_e64 v0, -v0, v0, s2                          // 0000009A85DC: D5010000 200A0100
	v_mov_b32_dpp v45, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A85E4: 7E5A02FA FF01611F
	v_mul_f32_e32 v30, 0xbfb8aa3b, v3                          // 0000009A85EC: 103C06FF BFB8AA3B
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 0000009A85F4: D501001F 200A3F1F
	v_mul_f32_e32 v22, 0x3db504f3, v22                         // 0000009A85FC: 102C2CFF 3DB504F3
	v_dual_add_f32 v0, v0, v44 :: v_dual_add_f32 v43, 1.0, v43 // 0000009A8604: C9085900 002A56F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A860C: BF870194
	v_exp_f32_e32 v30, v30                                     // 0000009A8610: 7E3C4B1E
	v_add_f32_e32 v31, v31, v45                                // 0000009A8614: 063E5B1F
	v_mov_b32_dpp v44, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8618: 7E5802FA FF016812
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A8620: BF870003
	v_mov_b32_dpp v45, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8624: 7E5A02FA FF016200
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 0000009A862C: D5010000 200E0100
	v_div_scale_f32 v46, null, v43, v43, v2                    // 0000009A8634: D6FC7C2E 040A572B
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 0000009A863C: D5010012 20062512
	v_mov_b32_dpp v48, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8644: 7E6002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 0000009A864C: D501001F 200E3F1F
	v_add_f32_e32 v0, v0, v45                                  // 0000009A8654: 06005B00
	v_add_f32_e32 v30, 1.0, v30                                // 0000009A8658: 063C3CF2
	v_rcp_f32_e32 v47, v46                                     // 0000009A865C: 7E5E552E
	v_add_f32_e32 v18, v18, v44                                // 0000009A8660: 06245912
	v_add_f32_e32 v31, v31, v48                                // 0000009A8664: 063E611F
	v_mov_b32_dpp v44, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8668: 7E5802FA FF016400
	v_div_scale_f32 v45, null, v30, v30, v3                    // 0000009A8670: D6FC7C2D 040E3D1E
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 0000009A8678: D5010000 20120100
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 0000009A8680: 102424FF 3DB504F3
	v_mov_b32_dpp v50, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8688: 7E6402FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 0000009A8690: D501001F 20123F1F
	v_rcp_f32_e32 v48, v45                                     // 0000009A8698: 7E60552D
	v_add_f32_e32 v0, v0, v44                                  // 0000009A869C: 06005900
	v_add_f32_e32 v44, v17, v11                                // 0000009A86A0: 06581711
	v_fma_f32 v49, -v46, v47, 1.0                              // 0000009A86A4: D6130031 23CA5F2E
	v_add_f32_e32 v31, v31, v50                                // 0000009A86AC: 063E651F
	v_sub_f32_e32 v11, v17, v11                                // 0000009A86B0: 08161711
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A86B4: BF870004
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A86B8: 7E6602FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 0000009A86C0: D501002C 200A592C
	v_fmac_f32_e32 v47, v49, v47                               // 0000009A86C8: 565E5F31
	v_div_scale_f32 v49, vcc_lo, v2, v43, v2                   // 0000009A86CC: D6FC6A31 040A5702
	v_fma_f32 v50, -v45, v48, 1.0                              // 0000009A86D4: D6130032 23CA612D
	v_mov_b32_dpp v52, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A86DC: 7E6802FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 0000009A86E4: D501001F 20063F1F
	v_add_f32_e32 v44, v44, v51                                // 0000009A86EC: 0658672C
	v_mov_b32_dpp v51, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A86F0: 7E6602FA FF016800
	v_fmac_f32_e32 v48, v50, v48                               // 0000009A86F8: 56606132
	v_div_scale_f32 v50, s5, v3, v30, v3                       // 0000009A86FC: D6FC0532 040E3D03
	v_dual_add_f32 v31, v31, v52 :: v_dual_mul_f32 v52, v49, v47// 0000009A8704: C906691F 1F345F31
	v_mov_b32_dpp v54, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A870C: 7E6C02FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 0000009A8714: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A871C: BF870214
	v_mul_f32_e32 v53, v50, v48                                // 0000009A8720: 106A6132
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 0000009A8724: 103E3EFF 3DB504F3
	v_fma_f32 v55, -v46, v52, v49                              // 0000009A872C: D6130037 24C6692E
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 0000009A8734: D5010000 20060100
	v_add_f32_e32 v44, v44, v54                                // 0000009A873C: 06586D2C
	v_fma_f32 v56, -v45, v53, v50                              // 0000009A8740: D6130038 24CA6B2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A8748: BF870214
	v_fmac_f32_e32 v52, v55, v47                               // 0000009A874C: 56685F37
	v_add_f32_e32 v0, v0, v51                                  // 0000009A8750: 06006700
	s_waitcnt vmcnt(21)                                        // 0000009A8754: BF8957F7
	v_fma_mix_f32 v5, v5, v10, neg(0) op_sel_hi:[1,0,0]        // 0000009A8758: CC200005 8A021505
	v_fmac_f32_e32 v53, v56, v48                               // 0000009A8760: 566A6138
	s_waitcnt vmcnt(20)                                        // 0000009A8764: BF8953F7
	v_fma_mix_f32 v6, v6, v12, neg(0) op_sel_hi:[1,0,0]        // 0000009A8768: CC200006 8A021906
	v_fma_f32 v46, -v46, v52, v49                              // 0000009A8770: D613002E 24C6692E
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000009A8778: 100000FF 3DB504F3
	v_fma_f32 v45, -v45, v53, v50                              // 0000009A8780: D613002D 24CA6B2D
	s_waitcnt vmcnt(18)                                        // 0000009A8788: BF894BF7
	v_fma_mix_f32 v4, v4, v31, neg(0) op_sel_hi:[1,0,0]        // 0000009A878C: CC200004 8A023F04
	v_mov_b32_dpp v31, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8794: 7E3E02FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s4                       // 0000009A879C: D501002C 2012592C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A87A4: BF8701A3
	v_mul_f32_e32 v51, 0xbfb8aa3b, v4                          // 0000009A87A8: 106608FF BFB8AA3B
	v_sub_f32_e32 v21, v36, v21                                // 0000009A87B0: 082A2B24
	v_add_f32_e32 v31, v44, v31                                // 0000009A87B4: 063E3F2C
	v_div_fmas_f32 v44, v46, v47, v52                          // 0000009A87B8: D637002C 04D25F2E
	s_mov_b32 vcc_lo, s5                                       // 0000009A87C0: BEEA0005
	v_exp_f32_e32 v49, v51                                     // 0000009A87C4: 7E624B33
	v_div_fmas_f32 v45, v45, v48, v53                          // 0000009A87C8: D637002D 04D6612D
	v_mov_b32_dpp v46, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A87D0: 7E5C02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 0000009A87D8: D501001F 20063F1F
	v_div_fixup_f32 v2, v44, v43, v2                           // 0000009A87E0: D6270002 040A572C
	v_mov_b32_dpp v36, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A87E8: 7E4802FA FF016115
	v_div_fixup_f32 v3, v45, v30, v3                           // 0000009A87F0: D6270003 040E3D2D
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 0000009A87F8: D5010015 200A2B15
	v_add_f32_e32 v10, v31, v46                                // 0000009A8800: 06145D1F
	v_mov_b32_dpp v31, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A8804: 7E3E02FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 0000009A880C: D501001D 200A3B1D
	v_dual_add_f32 v47, 1.0, v49 :: v_dual_mul_f32 v2, v5, v2  // 0000009A8814: C90662F2 2F020505
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A881C: BF870194
	v_dual_mul_f32 v10, 0x3db504f3, v10 :: v_dual_sub_f32 v15, v15, v16// 0000009A8820: C8CA14FF 0A0E210F 3DB504F3
	v_add_f32_e32 v5, v29, v31                                 // 0000009A882C: 060A3F1D
	v_mul_f32_e32 v3, v6, v3                                   // 0000009A8830: 10060706
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A8834: BF870214
	v_div_scale_f32 v30, null, v47, v47, v4                    // 0000009A8838: D6FC7C1E 04125F2F
	v_fma_mix_f32 v6, v9, v10, neg(0) op_sel_hi:[1,0,0]        // 0000009A8840: CC200006 8A021509
	v_add_f32_e32 v9, v21, v36                                 // 0000009A8848: 06124915
	v_mov_b32_dpp v21, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A884C: 7E2A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 0000009A8854: D5010005 200E0B05
	v_mov_b32_dpp v16, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A885C: 7E2002FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 0000009A8864: D501000F 200A1F0F
	v_mov_b32_dpp v29, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A886C: 7E3A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000009A8874: D5010009 200E1309
	v_add_f32_e32 v5, v5, v21                                  // 0000009A887C: 060A2B05
	s_waitcnt vmcnt(17)                                        // 0000009A8880: BF8947F7
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel_hi:[1,0,0]         // 0000009A8884: CC200003 8A020708
	v_add_f32_e32 v15, v15, v16                                // 0000009A888C: 061E210F
	v_mov_b32_dpp v16, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A8890: 7E2002FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 0000009A8898: D501000B 200A170B
	v_add_f32_e32 v9, v9, v29                                  // 0000009A88A0: 06123B09
	v_mov_b32_dpp v17, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A88A4: 7E2202FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 0000009A88AC: D5010005 20120B05
	v_mov_b32_dpp v29, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A88B4: 7E3A02FA FF01620F
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 0000009A88BC: D501000F 200E1F0F
	v_dual_add_f32 v11, v11, v16 :: v_dual_mul_f32 v8, 0xbfb8aa3b, v6// 0000009A88C4: C906210B 0B080CFF BFB8AA3B
	v_mov_b32_dpp v21, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A88D0: 7E2A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 0000009A88D8: D5010009 20121309
	v_add_f32_e32 v5, v5, v17                                  // 0000009A88E0: 060A2305
	v_add_f32_e32 v15, v15, v29                                // 0000009A88E4: 061E3B0F
	v_mov_b32_dpp v16, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A88E8: 7E2002FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 0000009A88F0: D501000B 200E170B
	v_exp_f32_e32 v8, v8                                       // 0000009A88F8: 7E104B08
	v_add_f32_e32 v9, v9, v21                                  // 0000009A88FC: 06122B09
	v_mov_b32_dpp v17, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8900: 7E2202FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 0000009A8908: D5010005 20060B05
	v_mov_b32_dpp v21, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8910: 7E2A02FA FF01640F
	v_cndmask_b32_e64 v15, -v15, v15, s4                       // 0000009A8918: D501000F 20121F0F
	v_add_f32_e32 v11, v11, v16                                // 0000009A8920: 0616210B
	v_rcp_f32_e32 v12, v30                                     // 0000009A8924: 7E18551E
	v_mov_b32_dpp v16, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8928: 7E2002FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000009A8930: D5010009 20061309
	v_add_f32_e32 v5, v5, v17                                  // 0000009A8938: 060A2305
	v_add_f32_e32 v15, v15, v21                                // 0000009A893C: 061E2B0F
	v_mov_b32_dpp v17, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8940: 7E2202FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 0000009A8948: D501000B 2012170B
	v_add_f32_e32 v8, 1.0, v8                                  // 0000009A8950: 061010F2
	v_add_f32_e32 v9, v9, v16                                  // 0000009A8954: 06122109
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8958: 7E2002FA FF01680F
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 0000009A8960: D501000F 20061F0F
	v_add_f32_e32 v11, v11, v17                                // 0000009A8968: 0616230B
	v_fma_f32 v10, -v30, v12, 1.0                              // 0000009A896C: D613000A 23CA191E
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 0000009A8974: 100A0AFF 3DB504F3
	v_div_scale_f32 v17, null, v8, v8, v6                      // 0000009A897C: D6FC7C11 041A1108
	v_add_f32_e32 v15, v15, v16                                // 0000009A8984: 061E210F
	v_mov_b32_dpp v16, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8988: 7E2002FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000009A8990: D501000B 2006170B
	v_fmac_f32_e32 v12, v10, v12                               // 0000009A8998: 5618190A
	v_div_scale_f32 v10, vcc_lo, v4, v47, v4                   // 0000009A899C: D6FC6A0A 04125F04
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 0000009A89A4: 101212FF 3DB504F3
	v_rcp_f32_e32 v21, v17                                     // 0000009A89AC: 7E2A5511
	v_add_f32_e32 v11, v11, v16                                // 0000009A89B0: 0616210B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A89B4: BF870113
	v_dual_mul_f32 v15, 0x3db504f3, v15 :: v_dual_mul_f32 v16, v10, v12// 0000009A89B8: C8C61EFF 0F10190A 3DB504F3
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 0000009A89C4: 101616FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A89CC: BF870092
	v_fma_f32 v31, -v30, v16, v10                              // 0000009A89D0: D613001F 242A211E
	v_fmac_f32_e32 v16, v31, v12                               // 0000009A89D8: 5620191F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A89DC: BF870091
	v_fma_f32 v10, -v30, v16, v10                              // 0000009A89E0: D613000A 242A211E
	v_div_fmas_f32 v10, v10, v12, v16                          // 0000009A89E8: D637000A 0442190A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A89F0: BF870001
	v_div_fixup_f32 v4, v10, v47, v4                           // 0000009A89F4: D6270004 04125F0A
	s_waitcnt vmcnt(16)                                        // 0000009A89FC: BF8943F7
	v_fma_mix_f32 v9, v32, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009A8A00: CC200009 8A021320
	v_fma_f32 v32, -v17, v21, 1.0                              // 0000009A8A08: D6130020 23CA2B11
	s_waitcnt vmcnt(15)                                        // 0000009A8A10: BF893FF7
	v_fma_mix_f32 v13, v33, v13, neg(0) op_sel_hi:[1,0,0]      // 0000009A8A14: CC20000D 8A021B21
	s_waitcnt vmcnt(12)                                        // 0000009A8A1C: BF8933F7
	v_fma_mix_f32 v15, v35, v15, neg(0) op_sel_hi:[1,0,0]      // 0000009A8A20: CC20000F 8A021F23
	v_mul_f32_e32 v29, 0xbfb8aa3b, v9                          // 0000009A8A28: 103A12FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A8A30: BF870193
	v_dual_fmac_f32 v21, v32, v21 :: v_dual_mul_f32 v4, v13, v4// 0000009A8A34: C8062B20 1504090D
	v_mul_f32_e32 v35, 0xbfb8aa3b, v15                         // 0000009A8A3C: 10461EFF BFB8AA3B
	s_waitcnt vmcnt(11)                                        // 0000009A8A44: BF892FF7
	v_fma_mix_f32 v11, v38, v11, neg(0) op_sel_hi:[1,0,0]      // 0000009A8A48: CC20000B 8A021726
	v_exp_f32_e32 v29, v29                                     // 0000009A8A50: 7E3A4B1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A8A54: BF870092
	v_exp_f32_e32 v31, v35                                     // 0000009A8A58: 7E3E4B23
	v_mul_f32_e32 v32, 0xbfb8aa3b, v11                         // 0000009A8A5C: 104016FF BFB8AA3B
	v_div_scale_f32 v35, s5, v6, v8, v6                        // 0000009A8A64: D6FC0523 041A1106
	s_mov_b32 vcc_lo, s5                                       // 0000009A8A6C: BEEA0005
	v_exp_f32_e32 v30, v32                                     // 0000009A8A70: 7E3C4B20
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000009A8A74: BF870317
	v_add_f32_e32 v29, 1.0, v29                                // 0000009A8A78: 063A3AF2
	v_dual_mul_f32 v32, v35, v21 :: v_dual_add_f32 v31, 1.0, v31// 0000009A8A7C: C8C82B23 201E3EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A8A84: BF870112
	v_div_scale_f32 v39, null, v29, v29, v9                    // 0000009A8A88: D6FC7C27 04263B1D
	v_fma_f32 v16, -v17, v32, v35                              // 0000009A8A90: D6130010 248E4111
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000009A8A98: BF870293
	v_div_scale_f32 v12, null, v31, v31, v15                   // 0000009A8A9C: D6FC7C0C 043E3F1F
	v_add_f32_e32 v30, 1.0, v30                                // 0000009A8AA4: 063C3CF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A8AA8: BF870194
	v_rcp_f32_e32 v43, v39                                     // 0000009A8AAC: 7E565527
	v_fmac_f32_e32 v32, v16, v21                               // 0000009A8AB0: 56402B10
	s_waitcnt vmcnt(6)                                         // 0000009A8AB4: BF891BF7
	v_fma_mix_f32 v19, v27, v19, neg(0) op_sel_hi:[1,0,0]      // 0000009A8AB8: CC200013 8A02271B
	v_rcp_f32_e32 v45, v12                                     // 0000009A8AC0: 7E5A550C
	v_div_scale_f32 v33, null, v30, v30, v11                   // 0000009A8AC4: D6FC7C21 042E3D1E
	v_fma_f32 v17, -v17, v32, v35                              // 0000009A8ACC: D6130011 248E4111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A8AD4: BF870092
	v_rcp_f32_e32 v16, v33                                     // 0000009A8AD8: 7E205521
	v_div_fmas_f32 v17, v17, v21, v32                          // 0000009A8ADC: D6370011 04822B11
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A8AE4: BF870116
	v_fma_f32 v13, -v12, v45, 1.0                              // 0000009A8AE8: D613000D 23CA5B0C
	v_div_fixup_f32 v6, v17, v8, v6                            // 0000009A8AF0: D6270006 041A1111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000009A8AF8: BF870292
	v_fmac_f32_e32 v45, v13, v45                               // 0000009A8AFC: 565A5B0D
	v_fma_f32 v46, -v33, v16, 1.0                              // 0000009A8B00: D613002E 23CA2121
	v_div_scale_f32 v13, s8, v15, v31, v15                     // 0000009A8B08: D6FC080D 043E3F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A8B10: BF870194
	v_mul_f32_e32 v6, v19, v6                                  // 0000009A8B14: 100C0D13
	v_fmac_f32_e32 v16, v46, v16                               // 0000009A8B18: 5620212E
	v_div_scale_f32 v46, s5, v11, v30, v11                     // 0000009A8B1C: D6FC052E 042E3D0B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A8B24: BF870004
	v_mul_f32_e32 v47, v13, v45                                // 0000009A8B28: 105E5B0D
	s_waitcnt vmcnt(4)                                         // 0000009A8B2C: BF8913F7
	v_fma_mix_f32 v0, v25, v0, neg(0) op_sel_hi:[1,0,0]        // 0000009A8B30: CC200000 8A020119
	s_waitcnt vmcnt(3)                                         // 0000009A8B38: BF890FF7
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 0000009A8B3C: CC200005 8A020B1A
	v_fma_f32 v17, -v12, v47, v13                              // 0000009A8B44: D6130011 24365F0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A8B4C: BF870112
	v_mul_f32_e32 v26, 0xbfb8aa3b, v5                          // 0000009A8B50: 10340AFF BFB8AA3B
	v_fmac_f32_e32 v47, v17, v45                               // 0000009A8B58: 565E5B11
	s_waitcnt vmcnt(0)                                         // 0000009A8B5C: BF8903F7
	v_fma_mix_f32 v6, v24, v6, neg(0) op_sel_hi:[1,0,0]        // 0000009A8B60: CC200006 8A020D18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000009A8B68: BF870293
	v_exp_f32_e32 v26, v26                                     // 0000009A8B6C: 7E344B1A
	v_add_f32_e32 v26, 1.0, v26                                // 0000009A8B70: 063434F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 0000009A8B74: BF8702C1
	v_div_scale_f32 v36, null, v26, v26, v5                    // 0000009A8B78: D6FC7C24 0416351A
	v_div_scale_f32 v10, s6, v5, v26, v5                       // 0000009A8B80: D6FC060A 04163505
	s_mov_b32 vcc_lo, s6                                       // 0000009A8B88: BEEA0006
	v_rcp_f32_e32 v38, v36                                     // 0000009A8B8C: 7E4C5524
	v_fma_f32 v44, -v36, v38, 1.0                              // 0000009A8B90: D613002C 23CA4D24
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009A8B98: BF870121
	v_fmac_f32_e32 v38, v44, v38                               // 0000009A8B9C: 564C4D2C
	v_fma_f32 v44, -v39, v43, 1.0                              // 0000009A8BA0: D613002C 23CA5727
	v_mul_f32_e32 v35, v10, v38                                // 0000009A8BA8: 10464D0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A8BAC: BF8701A2
	v_fmac_f32_e32 v43, v44, v43                               // 0000009A8BB0: 5656572C
	v_div_scale_f32 v44, s7, v9, v29, v9                       // 0000009A8BB4: D6FC072C 04263B09
	v_fma_f32 v21, -v36, v35, v10                              // 0000009A8BBC: D6130015 242A4724
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009A8BC4: BF870121
	v_dual_mul_f32 v32, v44, v43 :: v_dual_fmac_f32 v35, v21, v38// 0000009A8BC8: C8C0572C 20224D15
	v_mul_f32_e32 v21, v46, v16                                // 0000009A8BD0: 102A212E
	v_fma_f32 v8, -v39, v32, v44                               // 0000009A8BD4: D6130008 24B24127
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A8BDC: BF870113
	v_fma_f32 v10, -v36, v35, v10                              // 0000009A8BE0: D613000A 242A4724
	v_fmac_f32_e32 v32, v8, v43                                // 0000009A8BE8: 56405708
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A8BEC: BF870194
	v_fma_f32 v8, -v33, v21, v46                               // 0000009A8BF0: D6130008 24BA2B21
	v_div_fmas_f32 v10, v10, v38, v35                          // 0000009A8BF8: D637000A 048E4D0A
	s_mov_b32 vcc_lo, s7                                       // 0000009A8C00: BEEA0007
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A8C04: BF870193
	v_fma_f32 v17, -v39, v32, v44                              // 0000009A8C08: D6130011 24B24127
	v_fmac_f32_e32 v21, v8, v16                                // 0000009A8C10: 562A2108
	v_fma_f32 v8, -v12, v47, v13                               // 0000009A8C14: D6130008 24365F0C
	v_div_fixup_f32 v5, v10, v26, v5                           // 0000009A8C1C: D6270005 0416350A
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 0000009A8C24: 101C1CFF 3DB504F3
	v_div_fmas_f32 v12, v17, v43, v32                          // 0000009A8C2C: D637000C 04825711
	v_fma_f32 v13, -v33, v21, v46                              // 0000009A8C34: D613000D 24BA2B21
	s_mov_b32 vcc_lo, s8                                       // 0000009A8C3C: BEEA0008
	v_fma_mix_f32 v10, v34, v18, neg(0) op_sel_hi:[1,0,0]      // 0000009A8C40: CC20000A 8A022522
	v_div_fmas_f32 v8, v8, v45, v47                            // 0000009A8C48: D6370008 04BE5B08
	s_mov_b32 vcc_lo, s5                                       // 0000009A8C50: BEEA0005
	v_div_fixup_f32 v9, v12, v29, v9                           // 0000009A8C54: D6270009 04263B0C
	v_div_fmas_f32 v13, v13, v16, v21                          // 0000009A8C5C: D637000D 0456210D
	v_fma_mix_f32 v12, v23, v22, neg(0) op_sel_hi:[1,0,0]      // 0000009A8C64: CC20000C 8A022D17
	v_fma_mix_f32 v7, v7, v14, neg(0) op_sel_hi:[1,0,0]        // 0000009A8C6C: CC200007 8A021D07
	v_div_fixup_f32 v8, v8, v31, v15                           // 0000009A8C74: D6270008 043E3F08
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A8C7C: BF870214
	v_div_fixup_f32 v11, v13, v30, v11                         // 0000009A8C80: D627000B 042E3D0D
	v_mul_f32_e32 v9, v12, v9                                  // 0000009A8C88: 1012130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009A8C8C: BF870223
	v_dual_mul_f32 v5, v7, v5 :: v_dual_mul_f32 v8, v10, v8    // 0000009A8C90: C8C60B07 0508110A
	v_fma_mix_f32 v10, v4, v40, v6 op_sel_hi:[0,1,0]           // 0000009A8C98: CC20000A 141A5104
	v_mul_f32_e32 v0, v0, v11                                  // 0000009A8CA0: 10001700
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A8CA4: BF870004
	v_fma_mix_f32 v7, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009A8CA8: CC200007 8A02131C
	v_fma_mix_f32 v9, v2, v37, v3 op_sel_hi:[0,1,0]            // 0000009A8CB0: CC200009 140E4B02
	v_fma_mix_f32 v2, v2, v37, -v3 op_sel_hi:[0,1,0]           // 0000009A8CB8: CC200002 940E4B02
	v_fma_mix_f32 v3, v4, v40, -v6 op_sel_hi:[0,1,0]           // 0000009A8CC0: CC200003 941A5104
	v_fma_mix_f32 v0, v20, v0, neg(0) op_sel_hi:[1,0,0]        // 0000009A8CC8: CC200000 8A020114
	v_fma_mix_f32 v11, v5, v41, v7 op_sel_hi:[0,1,0]           // 0000009A8CD0: CC20000B 141E5305
	v_fma_mix_f32 v4, v5, v41, -v7 op_sel_hi:[0,1,0]           // 0000009A8CD8: CC200004 941E5305
	v_add_f32_e32 v5, v9, v10                                  // 0000009A8CE0: 060A1509
	v_sub_f32_e32 v7, v9, v10                                  // 0000009A8CE4: 080E1509
	v_fma_mix_f32 v12, v8, v42, v0 op_sel_hi:[0,1,0]           // 0000009A8CE8: CC20000C 14025508
	v_fma_mix_f32 v0, v8, v42, -v0 op_sel_hi:[0,1,0]           // 0000009A8CF0: CC200000 94025508
	v_add_f32_e32 v8, v2, v3                                   // 0000009A8CF8: 06100702
	v_sub_f32_e32 v2, v2, v3                                   // 0000009A8CFC: 08040702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009A8D00: BF8701B4
	v_add_f32_e32 v6, v11, v12                                 // 0000009A8D04: 060C190B
	v_sub_f32_e32 v9, v11, v12                                 // 0000009A8D08: 0812190B
	v_add_f32_e32 v10, v4, v0                                  // 0000009A8D0C: 06140104
	v_dual_sub_f32 v0, v4, v0 :: v_dual_add_f32 v3, v5, v6     // 0000009A8D10: C9480104 00020D05
	v_sub_f32_e32 v4, v5, v6                                   // 0000009A8D18: 08080D05
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A8D1C: BF870003
	v_add_f32_e32 v6, v8, v10                                  // 0000009A8D20: 060C1508
	v_sub_f32_e32 v8, v8, v10                                  // 0000009A8D24: 08101508
	v_add_f32_e32 v10, v7, v9                                  // 0000009A8D28: 06141307
	v_mov_b32_dpp v5, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A8D2C: 7E0A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 0000009A8D34: D5010003 200A0703
	v_sub_f32_e32 v7, v7, v9                                   // 0000009A8D3C: 080E1307
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A8D40: 7E1C02FA FF016104
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A8D48: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 0000009A8D50: D501000A 200A150A
	v_add_f32_e32 v3, v3, v5                                   // 0000009A8D58: 06060B03
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A8D5C: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 0000009A8D64: D5010006 200A0D06
	v_cndmask_b32_e64 v15, -v4, v4, s2                         // 0000009A8D6C: D501000F 200A0904
	v_add_f32_e32 v9, v10, v9                                  // 0000009A8D74: 0612130A
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8D78: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 0000009A8D80: D5010003 200E0703
	v_add_f32_e32 v5, v6, v5                                   // 0000009A8D88: 060A0B06
	v_add_f32_e32 v6, v2, v0                                   // 0000009A8D8C: 060C0102
	v_sub_f32_e32 v10, v2, v0                                  // 0000009A8D90: 08140102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A8D94: BF870214
	v_add_f32_e32 v0, v3, v11                                  // 0000009A8D98: 06001703
	v_mov_b32_dpp v2, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8D9C: 7E0402FA FF016205
	v_cndmask_b32_e64 v3, -v5, v5, s3                          // 0000009A8DA4: D5010003 200E0B05
	v_mov_b32_dpp v5, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8DAC: 7E0A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000009A8DB4: D5010009 200E1309
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A8DBC: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 0000009A8DC4: D5010006 200A0D06
	v_add_f32_e32 v2, v3, v2                                   // 0000009A8DCC: 06040503
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A8DD0: 7E2002FA FF01610A
	v_add_f32_e32 v5, v9, v5                                   // 0000009A8DD8: 060A0B09
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 0000009A8DDC: D501000A 200A150A
	v_add_f32_e32 v6, v6, v11                                  // 0000009A8DE4: 060C1706
	v_mov_b32_dpp v9, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8DE8: 7E1202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 0000009A8DF0: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8DF8: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 0000009A8E00: D5010005 20120B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8E08: 7E1802FA FF016206
	v_cndmask_b32_e64 v13, -v6, v6, s3                         // 0000009A8E10: D501000D 200E0D06
	v_add_f32_e32 v4, v2, v9                                   // 0000009A8E18: 06081302
	v_add_f32_e32 v10, v10, v16                                // 0000009A8E1C: 0614210A
	v_dual_add_f32 v6, v5, v11 :: v_dual_add_f32 v11, v15, v14 // 0000009A8E20: C9081705 060A1D0F
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A8E28: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 0000009A8E30: D5010008 200A1108
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A8E38: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 0000009A8E40: D5010007 200A0F07
	v_add_f32_e32 v9, v13, v12                                 // 0000009A8E48: 0612190D
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8E4C: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 0000009A8E54: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A8E5C: BF870234
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v7, v15   // 0000009A8E60: C9081D08 08061F07
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8E68: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 0000009A8E70: D501000A 200E150A
	v_add_f32_e32 v11, v11, v13                                // 0000009A8E78: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A8E7C: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8E80: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000009A8E88: D5010008 200E1108
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A8E90: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 0000009A8E98: D5010007 200E0F07
	v_add_f32_e32 v10, v10, v15                                // 0000009A8EA0: 06141F0A
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8EA4: 7E0602FA FF016400
	v_add_f32_e32 v8, v8, v13                                  // 0000009A8EAC: 06101B08
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 0000009A8EB0: D5010000 20120100
	v_add_f32_e32 v7, v7, v14                                  // 0000009A8EB8: 060E1D07
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8EBC: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 0000009A8EC4: D5010009 20121309
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8ECC: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 0000009A8ED4: D501000B 2012170B
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8EDC: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 0000009A8EE4: D5010008 20121108
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8EEC: 7E1E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 0000009A8EF4: D5010007 20120F07
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A8EFC: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s4                       // 0000009A8F04: D5010011 2012150A
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v9, v12    // 0000009A8F0C: C9080700 00081909
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v8, v14// 0000009A8F14: C9081B0B 0A0A1D08
	v_add_f32_e32 v13, v7, v15                                 // 0000009A8F1C: 061A1F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A8F20: BF870214
	v_add_f32_e32 v15, v17, v16                                // 0000009A8F24: 061E2111
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8F28: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8F30: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8F38: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8F40: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8F48: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8F50: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8F58: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A8F60: 7E2002FA FF01680F
	s_mov_b32 s2, 0x3db504f3                                   // 0000009A8F68: BE8200FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s0                             // 0000009A8F70: 8B7E007E
	s_cbranch_execz 65                                         // 0000009A8F74: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x627c>
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 0000009A8F78: D501000F 20061F0F
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 0000009A8F80: D5010000 20060100
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000009A8F88: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000009A8F90: D5010006 20060D06
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000009A8F98: D5010009 20061309
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 0000009A8FA0: D501000D 20061B0D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009A8FA8: D501000A 2006150A
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000009A8FB0: D501000B 2006170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 0000009A8FB8: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 0000009A8FC0: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 0000009A8FC4: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 0000009A8FC8: 060E0F09
	s_mul_i32 s0, s10, 0x500                                   // 0000009A8FCC: 9600FF0A 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 0000009A8FD4: C9081D0D 0D08110A
	s_mul_hi_i32 s1, s10, 0x500                                // 0000009A8FDC: 9701FF0A 00000500
	v_add_f32_e32 v11, v11, v12                                // 0000009A8FE4: 0616190B
	s_add_u32 s0, s22, s0                                      // 0000009A8FE8: 80000016
	v_fma_mixlo_f16 v0, v0, s2, 0                              // 0000009A8FEC: CC210000 02000500
	s_addc_u32 s1, s23, s1                                     // 0000009A8FF4: 82010117
	v_fma_mixhi_f16 v0, v3, s2, 0                              // 0000009A8FF8: CC220000 02000503
	s_add_u32 s0, s0, s12                                      // 0000009A9000: 80000C00
	v_fma_mixlo_f16 v2, v5, s2, 0                              // 0000009A9004: CC210002 02000505
	s_addc_u32 s1, s1, s13                                     // 0000009A900C: 82010D01
	v_fma_mixhi_f16 v2, v7, s2, 0                              // 0000009A9010: CC220002 02000507
	v_fma_mixlo_f16 v3, v8, s2, 0                              // 0000009A9018: CC210003 02000508
	v_fma_mixhi_f16 v3, v11, s2, 0                             // 0000009A9020: CC220003 0200050B
	v_fma_mixlo_f16 v4, v13, s2, 0                             // 0000009A9028: CC210004 0200050D
	v_fma_mixhi_f16 v4, v15, s2, 0                             // 0000009A9030: CC220004 0200050F
	s_clause 0x7                                               // 0000009A9038: BF850007
	global_store_b16 v1, v0, s[0:1]                            // 0000009A903C: DC660000 00000001
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 0000009A9044: DC960020 00000001
	global_store_b16 v1, v2, s[0:1] offset:64                  // 0000009A904C: DC660040 00000201
	global_store_d16_hi_b16 v1, v2, s[0:1] offset:96           // 0000009A9054: DC960060 00000201
	global_store_b16 v1, v3, s[0:1] offset:128                 // 0000009A905C: DC660080 00000301
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:160          // 0000009A9064: DC9600A0 00000301
	global_store_b16 v1, v4, s[0:1] offset:192                 // 0000009A906C: DC6600C0 00000401
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:224          // 0000009A9074: DC9600E0 00000401
	s_nop 0                                                    // 0000009A907C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000009A9080: BFB60003
	s_endpgm                                                   // 0000009A9084: BFB00000
		...

