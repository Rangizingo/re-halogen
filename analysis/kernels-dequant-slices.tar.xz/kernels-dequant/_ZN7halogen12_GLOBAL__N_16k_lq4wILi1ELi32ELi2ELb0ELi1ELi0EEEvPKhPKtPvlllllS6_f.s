00000000007b9b00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007B9B00: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 0000007B9B08: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007B9B10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000007B9B14: 86039F02
	v_lshrrev_b32_e32 v14, 6, v0                               // 0000007B9B18: 321C0086
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000007B9B1C: 84948202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007B9B20: BF8701A9
	v_dual_mov_b32 v4, s21 :: v_dual_lshlrev_b32 v1, 2, v1     // 0000007B9B24: CA220015 04000282
	v_and_b32_e32 v2, 60, v2                                   // 0000007B9B2C: 360404BC
	v_or_b32_e32 v3, s20, v14                                  // 0000007B9B30: 38061C14
	v_bfe_u32 v15, v0, 5, 1                                    // 0000007B9B34: D610000F 02050B00
	.long 0x7f0e3880                                           // 0000007B9B3C: 7F0E3880
	v_mov_b32_e32 v17, 0                                       // 0000007B9B40: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 0000007B9B44: BF89FC07
	s_clause 0x1                                               // 0000007B9B48: BF850001
	global_load_b32 v5, v1, s[4:5]                             // 0000007B9B4C: DC520000 05040001
	global_load_b32 v6, v2, s[4:5]                             // 0000007B9B54: DC520000 06040002
	s_add_u32 s2, s4, s14                                      // 0000007B9B5C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000007B9B60: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 0000007B9B64: 850E9F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[3:4]                  // 0000007B9B68: 7CA8060C
	s_add_u32 s14, s10, s14                                    // 0000007B9B6C: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 0000007B9B70: 820F800B
	s_ashr_i32 s22, s11, 31                                    // 0000007B9B74: 86169F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000007B9B78: 868E810E
	s_lshr_b32 s22, s22, 27                                    // 0000007B9B7C: 85169B16
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_and_b32 v16, 31, v0 // 0000007B9B80: CA640680 0310009F
	s_add_u32 s10, s10, s22                                    // 0000007B9B88: 800A160A
	s_addc_u32 s11, s11, 0                                     // 0000007B9B8C: 820B800B
	v_cndmask_b32_e64 v4, 0, s21, vcc_lo                       // 0000007B9B90: D5010004 01A82A80
	s_lshr_b64 s[10:11], s[10:11], 5                           // 0000007B9B98: 858A850A
	.long 0xd72c0008                                           // 0000007B9B9C: D72C0008
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 0000007B9BA0: 02020613
	s_add_i32 s11, s10, 1                                      // 0000007B9BA4: 810B810A
	v_mad_u64_u32 v[9:10], null, v3, s14, s[2:3]               // 0000007B9BA8: D6FE7C09 00081D03
	s_lshr_b32 s19, s11, 31                                    // 0000007B9BB0: 85139F0B
	.long 0xd72c0015                                           // 0000007B9BB4: D72C0015
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 0000007B9BB8: 02001D04
	s_add_i32 s11, s11, s19                                    // 0000007B9BBC: 810B130B
	.long 0xd72c0016                                           // 0000007B9BC0: D72C0016
	v_cndmask_b32_e32 v1, s18, v4, vcc_lo                      // 0000007B9BC4: 02020812
	s_ashr_i32 s11, s11, 1                                     // 0000007B9BC8: 860B810B
	s_add_u32 s2, s4, s16                                      // 0000007B9BCC: 80021004
	.long 0xd72c0013                                           // 0000007B9BD0: D72C0013
	v_cndmask_b32_e32 v1, s11, v15, vcc_lo                     // 0000007B9BD4: 02021E0B
	s_addc_u32 s3, s5, s17                                     // 0000007B9BD8: 82031105
	.long 0xd72c000d                                           // 0000007B9BDC: D72C000D
	v_cndmask_b32_e32 v0, v3, v15, vcc_lo                      // 0000007B9BE0: 02001F03
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000007B9BE4: CA100080 01020080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007B9BEC: BF870223
	v_add_nc_u32_e32 v4, s11, v19                              // 0000007B9BF0: 4A08260B
	v_add_nc_u32_e32 v19, v19, v16                             // 0000007B9BF4: 4A262113
	v_add3_u32 v10, v21, v10, v13                              // 0000007B9BF8: D655000A 04361515
	s_waitcnt vmcnt(1)                                         // 0000007B9C00: BF8907F7
	v_bfe_u32 v11, v5, 16, 1                                   // 0000007B9C04: D610000B 02052105
	s_waitcnt vmcnt(0)                                         // 0000007B9C0C: BF8903F7
	v_bfe_u32 v20, v6, 16, 1                                   // 0000007B9C10: D6100014 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007B9C18: BF8701A2
	v_add3_u32 v5, v5, v11, 0x7fff                             // 0000007B9C1C: D6550005 03FE1705 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v3, s[2:3]              // 0000007B9C28: D6FE7C0B 000A0612
	v_add3_u32 v6, v6, v20, 0x7fff                             // 0000007B9C30: D6550006 03FE2906 00007FFF
	v_mov_b32_e32 v3, 0                                        // 0000007B9C3C: 7E060280
	v_min_i32_e32 v20, s10, v4                                 // 0000007B9C40: 2228080A
	.long 0x7e0e3985                                           // 0000007B9C44: 7E0E3985
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v5, 2, v0       // 0000007B9C48: CA220080 04040082
	v_add3_u32 v21, v8, v12, v22                               // 0000007B9C50: D6550015 045A1908
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007B9C58: BF870003
	v_and_or_b32 v6, 0xffff0000, v6, v7                        // 0000007B9C5C: D6570006 041E0CFF FFFF0000
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 0000007B9C68: 7C822913
	ds_store_b32 v5, v6                                        // 0000007B9C6C: D8340000 00000605
	s_waitcnt lgkmcnt(0)                                       // 0000007B9C74: BF89FC07
	s_barrier                                                  // 0000007B9C78: BFBD0000
	buffer_gl0_inv                                             // 0000007B9C7C: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 0000007B9C84: BE83206A
	s_cbranch_execz 21                                         // 0000007B9C88: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x1e0>
	v_lshlrev_b32_e32 v1, 1, v19                               // 0000007B9C8C: 30022681
	v_lshlrev_b32_e32 v3, 4, v19                               // 0000007B9C90: 30062684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007B9C94: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007B9C98: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007B9C9C: 3408069F
	.long 0xd7000201                                           // 0000007B9CA0: D7000201
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000007B9CA4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B9CA8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s2                  // 0000007B9CAC: D5207C02 000A0515
	.long 0xd7000203                                           // 0000007B9CB4: D7000203
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000007B9CB8: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s2                  // 0000007B9CBC: D5207C04 000A090A
	s_clause 0x1                                               // 0000007B9CC4: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 0000007B9CC8: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000007B9CD0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000007B9CD8: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 0000007B9CDC: 7E241705
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007B9CE0: 8C7E037E
	s_and_saveexec_b32 s3, vcc_lo                              // 0000007B9CE4: BE83206A
	s_cbranch_execz 207                                        // 0000007B9CE8: BFA500CF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x528>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007B9CEC: BF870131
	v_dual_mov_b32 v24, v18 :: v_dual_add_nc_u32 v5, 32, v19   // 0000007B9CF0: CA200112 180426A0
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v12, 5, v19    // 0000007B9CF8: CA220080 110C2685
	s_mov_b32 s4, 0                                            // 0000007B9D00: BE840080
	v_lshlrev_b32_e32 v22, 4, v5                               // 0000007B9D04: 302C0A84
	v_lshlrev_b32_e32 v23, 1, v5                               // 0000007B9D08: 302E0A81
	s_branch 166                                               // 0000007B9D0C: BFA000A6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x4a8>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007B9D10: 8C7E057E
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000007B9D14: 341A189F
	v_lshrrev_b32_e32 v41, 6, v1                               // 0000007B9D18: 32520286
	v_lshrrev_b32_e32 v42, 14, v1                              // 0000007B9D1C: 3254028E
	v_and_b32_e32 v43, 0xff, v2                                // 0000007B9D20: 365604FF 000000FF
	v_lshrrev_b32_e32 v44, 6, v2                               // 0000007B9D28: 32580486
	.long 0xd73c0019                                           // 0000007B9D2C: D73C0019
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000007B9D30: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 0000007B9D34: 361A02FF 000000FF
	v_and_b32_e32 v41, 0x3fc, v41                              // 0000007B9D3C: 365252FF 000003FC
	v_and_b32_e32 v42, 0x3fc, v42                              // 0000007B9D44: 365454FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000007B9D4C: 32020296
	v_lshrrev_b32_e32 v45, 14, v2                              // 0000007B9D50: 325A048E
	.long 0xd7000225                                           // 0000007B9D54: D7000225
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 0000007B9D58: 02023206
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B9D5C: BF870001
	v_add_co_ci_u32_e64 v38, null, s7, v26, s2                 // 0000007B9D60: D5207C26 000A3407
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000007B9D68: 301A1A82
	ds_load_b32 v41, v41                                       // 0000007B9D6C: D8D80000 29000029
	ds_load_b32 v42, v42                                       // 0000007B9D74: D8D80000 2A00002A
	s_clause 0x3                                               // 0000007B9D7C: BF850003
	global_load_b128 v[25:28], v[37:38], off                   // 0000007B9D80: DC5E0000 197C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000007B9D88: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000007B9D90: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000007B9D98: DC5E0030 257C0025
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000007B9DA0: 32040496
	ds_load_b32 v13, v13                                       // 0000007B9DA4: D8D80000 0D00000D
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007B9DAC: 360202FF 000003FC
	v_lshlrev_b32_e32 v43, 2, v43                              // 0000007B9DB4: 30565682
	v_and_b32_e32 v44, 0x3fc, v44                              // 0000007B9DB8: 365858FF 000003FC
	v_and_b32_e32 v45, 0x3fc, v45                              // 0000007B9DC0: 365A5AFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000007B9DC8: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000007B9DD0: D8D80000 01000001
	ds_load_b32 v43, v43                                       // 0000007B9DD8: D8D80000 2B00002B
	ds_load_b32 v44, v44                                       // 0000007B9DE0: D8D80000 2C00002C
	ds_load_b32 v45, v45                                       // 0000007B9DE8: D8D80000 2D00002D
	ds_load_b32 v2, v2                                         // 0000007B9DF0: D8D80000 02000002
	v_add_nc_u32_e32 v22, 0x200, v22                           // 0000007B9DF8: 4A2C2CFF 00000200
	v_add_nc_u32_e32 v23, 64, v23                              // 0000007B9E00: 4A2E2EC0
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000007B9E04: 4A1818FF 00000400
	s_and_b32 s2, exec_lo, vcc_lo                              // 0000007B9E0C: 8B026A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007B9E10: BF870149
	s_or_b32 s4, s2, s4                                        // 0000007B9E14: 8C040402
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 0000007B9E18: BF890C57
	v_dot2_f32_bf16 v13, v25, v13, 0                           // 0000007B9E1C: CC1A400D 1A021B19
	v_and_b32_e32 v25, 0xff, v3                                // 0000007B9E24: 363206FF 000000FF
	v_dot2_f32_bf16 v13, v26, v41, v13                         // 0000007B9E2C: CC1A400D 1C36531A
	v_lshrrev_b32_e32 v26, 6, v3                               // 0000007B9E34: 32340686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007B9E38: BF8701A2
	v_dot2_f32_bf16 v13, v27, v42, v13                         // 0000007B9E3C: CC1A400D 1C36551B
	v_lshrrev_b32_e32 v27, 14, v3                              // 0000007B9E44: 3236068E
	v_and_b32_e32 v26, 0x3fc, v26                              // 0000007B9E48: 363434FF 000003FC
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000007B9E50: 32060696
	s_waitcnt lgkmcnt(4)                                       // 0000007B9E54: BF89FC47
	v_dot2_f32_bf16 v1, v28, v1, v13                           // 0000007B9E58: CC1A4001 1C36031C
	v_lshlrev_b32_e32 v13, 2, v25                              // 0000007B9E60: 301A3282
	v_and_b32_e32 v27, 0x3fc, v27                              // 0000007B9E64: 363636FF 000003FC
	v_and_b32_e32 v25, 0xff, v4                                // 0000007B9E6C: 363208FF 000000FF
	v_lshrrev_b32_e32 v28, 6, v4                               // 0000007B9E74: 32380886
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000007B9E78: BF890837
	v_dot2_f32_bf16 v1, v29, v43, v1                           // 0000007B9E7C: CC1A4001 1C06571D
	ds_load_b32 v13, v13                                       // 0000007B9E84: D8D80000 0D00000D
	ds_load_b32 v26, v26                                       // 0000007B9E8C: D8D80000 1A00001A
	ds_load_b32 v27, v27                                       // 0000007B9E94: D8D80000 1B00001B
	v_lshrrev_b32_e32 v29, 14, v4                              // 0000007B9E9C: 323A088E
	s_waitcnt lgkmcnt(5)                                       // 0000007B9EA0: BF89FC57
	v_dot2_f32_bf16 v1, v30, v44, v1                           // 0000007B9EA4: CC1A4001 1C06591E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007B9EAC: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000007B9EB0: 360606FF 000003FC
	v_lshlrev_b32_e32 v25, 2, v25                              // 0000007B9EB8: 30323282
	v_and_b32_e32 v28, 0x3fc, v28                              // 0000007B9EBC: 363838FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000007B9EC4: BF89FC47
	v_dot2_f32_bf16 v1, v31, v45, v1                           // 0000007B9EC8: CC1A4001 1C065B1F
	v_and_b32_e32 v29, 0x3fc, v29                              // 0000007B9ED0: 363A3AFF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007B9ED8: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007B9EE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007B9EE4: BF870003
	v_dot2_f32_bf16 v1, v32, v2, v1                            // 0000007B9EE8: CC1A4001 1C060520
	ds_load_b32 v2, v3                                         // 0000007B9EF0: D8D80000 02000003
	ds_load_b32 v3, v25                                        // 0000007B9EF8: D8D80000 03000019
	ds_load_b32 v25, v28                                       // 0000007B9F00: D8D80000 1900001C
	ds_load_b32 v28, v29                                       // 0000007B9F08: D8D80000 1C00001D
	ds_load_b32 v29, v4                                        // 0000007B9F10: D8D80000 1D000004
	v_mov_b32_e32 v4, v8                                       // 0000007B9F18: 7E080308
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007B9F1C: BF890477
	v_dot2_f32_bf16 v1, v33, v13, v1                           // 0000007B9F20: CC1A4001 1C061B21
	s_waitcnt lgkmcnt(6)                                       // 0000007B9F28: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B9F2C: BF8700A1
	v_dot2_f32_bf16 v1, v34, v26, v1                           // 0000007B9F30: CC1A4001 1C063522
	s_waitcnt lgkmcnt(5)                                       // 0000007B9F38: BF89FC57
	v_dot2_f32_bf16 v1, v35, v27, v1                           // 0000007B9F3C: CC1A4001 1C063723
	s_waitcnt lgkmcnt(4)                                       // 0000007B9F44: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007B9F48: BF870131
	v_dot2_f32_bf16 v1, v36, v2, v1                            // 0000007B9F4C: CC1A4001 1C060524
	v_mov_b32_e32 v2, v6                                       // 0000007B9F54: 7E040306
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007B9F58: BF890037
	v_dot2_f32_bf16 v1, v37, v3, v1                            // 0000007B9F5C: CC1A4001 1C060725
	v_mov_b32_e32 v3, v7                                       // 0000007B9F64: 7E060307
	s_waitcnt lgkmcnt(2)                                       // 0000007B9F68: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B9F6C: BF8700A2
	v_dot2_f32_bf16 v1, v38, v25, v1                           // 0000007B9F70: CC1A4001 1C063326
	s_waitcnt lgkmcnt(1)                                       // 0000007B9F78: BF89FC17
	v_dot2_f32_bf16 v1, v39, v28, v1                           // 0000007B9F7C: CC1A4001 1C063927
	s_waitcnt lgkmcnt(0)                                       // 0000007B9F84: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007B9F88: BF870121
	v_dot2_f32_bf16 v8, v40, v29, v1                           // 0000007B9F8C: CC1A4008 1C063B28
	v_mov_b32_e32 v1, v5                                       // 0000007B9F94: 7E020305
	v_dual_fmac_f32 v17, v18, v8 :: v_dual_mov_b32 v18, v24    // 0000007B9F98: C8101112 11120118
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000007B9FA0: 917E047E
	s_cbranch_execz 31                                         // 0000007B9FA4: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x524>
	s_waitcnt vmcnt(0)                                         // 0000007B9FA8: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v19, 32, v19    // 0000007B9FAC: CA200102 061226A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000007B9FB4: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000007B9FBC: 7E0E0303
	s_mov_b32 s5, exec_lo                                      // 0000007B9FC0: BE85007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007B9FC4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 0000007B9FC8: 7C8C2913
	.long 0xd4c1007e                                           // 0000007B9FCC: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 0000007B9FD0: 02022913
	s_cbranch_execz 65358                                      // 0000007B9FD4: BFA5FF4E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x210>
	v_ashrrev_i32_e32 v6, 31, v23                              // 0000007B9FD8: 340C2E9F
	v_ashrrev_i32_e32 v8, 31, v22                              // 0000007B9FDC: 34102C9F
	.long 0xd7000205                                           // 0000007B9FE0: D7000205
	v_cndmask_b32_e32 v1, v11, v23, vcc_lo                     // 0000007B9FE4: 02022F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B9FE8: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s2                  // 0000007B9FEC: D5207C06 000A0D15
	.long 0xd7000207                                           // 0000007B9FF4: D7000207
	v_cndmask_b32_e32 v1, v9, v22, vcc_lo                      // 0000007B9FF8: 02022D09
	v_add_co_ci_u32_e64 v8, null, v10, v8, s2                  // 0000007B9FFC: D5207C08 000A110A
	s_clause 0x1                                               // 0000007BA004: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 0000007BA008: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000007BA010: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000007BA018: BF8907F7
	v_cvt_f32_f16_e32 v24, v13                                 // 0000007BA01C: 7E30170D
	s_branch 65339                                             // 0000007BA020: BFA0FF3B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x210>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BA024: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000007BA028: BF8700C9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007BA02C: 8C7E037E
	s_waitcnt vmcnt(0)                                         // 0000007BA030: BF8903F7
	.long 0xd71f0001                                           // 0000007BA034: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007BA038: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000007BA03C: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007BA040: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 0000007BA044: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 0000007BA048: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007BA04C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007BA050: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007BA054: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007BA058: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 0000007BA05C: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007BA060: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007BA064: 02080901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007BA068: BF870211
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007BA06C: 30080882
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007BA070: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007BA074: 30040482
	ds_bpermute_b32 v2, v2, v17                                // 0000007BA078: DACC0000 02001102
	s_waitcnt lgkmcnt(0)                                       // 0000007BA080: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 0000007BA084: 06040511
	ds_bpermute_b32 v3, v3, v2                                 // 0000007BA088: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 0000007BA090: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000007BA094: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000007BA098: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 0000007BA0A0: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BA0A4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007BA0A8: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007BA0AC: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007BA0B0: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000007BA0B4: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000007BA0B8: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000007BA0BC: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 0000007BA0C4: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007BA0C8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007BA0CC: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 0000007BA0D0: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 0000007BA0D4: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 0000007BA0DC: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 0000007BA0E0: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v16                                   // 0000007BA0E8: 7D942080
	s_cbranch_execz 8                                          // 0000007BA0EC: BFA50008 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x610>
	v_lshlrev_b32_e32 v3, 2, v15                               // 0000007BA0F0: 30061E82
	s_waitcnt lgkmcnt(0)                                       // 0000007BA0F4: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000007BA0F8: 06020501
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BA0FC: BF870002
	v_lshl_or_b32 v3, v14, 3, v3                               // 0000007BA100: D6560003 040D070E
	ds_store_b32 v3, v1 offset:1024                            // 0000007BA108: D8340400 00000103
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007BA110: 8C7E027E
	v_or_b32_e32 v1, s20, v0                                   // 0000007BA114: 38020014
	s_waitcnt lgkmcnt(0)                                       // 0000007BA118: BF89FC07
	v_mov_b32_e32 v2, s21                                      // 0000007BA11C: 7E040215
	.long 0xd44c0002                                           // 0000007BA120: D44C0002
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 0000007BA124: 02020084
	s_barrier                                                  // 0000007BA128: BFBD0000
	buffer_gl0_inv                                             // 0000007BA12C: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007BA134: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000007BA138: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007BA13C: BF870009
	s_and_saveexec_b32 s3, s2                                  // 0000007BA140: BE832002
	s_cbranch_execz 62                                         // 0000007BA144: BFA5003E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x740>
	v_lshlrev_b32_e32 v0, 3, v0                                // 0000007BA148: 30000083
	s_load_b32 s0, s[0:1], 0x48                                // 0000007BA14C: F4000000 F8000048
	ds_load_b64 v[3:4], v0 offset:1024                         // 0000007BA154: D9D80400 03000000
	s_waitcnt lgkmcnt(0)                                       // 0000007BA15C: BF89FC07
	v_add_f32_e32 v0, 0, v3                                    // 0000007BA160: 06000680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BA164: BF870091
	v_add_f32_e32 v0, v0, v4                                   // 0000007BA168: 06000900
	v_bfe_u32 v3, v0, 16, 1                                    // 0000007BA16C: D6100003 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BA174: BF870091
	v_add3_u32 v0, v0, v3, 0x7fff                              // 0000007BA178: D6550000 03FE0700 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007BA184: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BA18C: BF870091
	v_mul_f32_e32 v0, s0, v0                                   // 0000007BA190: 10000000
	v_mul_f32_e32 v3, 0xbfb8aa3b, v0                           // 0000007BA194: 100600FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007BA19C: BF870291
	v_exp_f32_e32 v3, v3                                       // 0000007BA1A0: 7E064B03
	v_add_f32_e32 v3, 1.0, v3                                  // 0000007BA1A4: 060606F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BA1A8: BF870121
	v_div_scale_f32 v4, null, v3, v3, v0                       // 0000007BA1AC: D6FC7C04 04020703
	v_div_scale_f32 v7, vcc_lo, v0, v3, v0                     // 0000007BA1B4: D6FC6A07 04020700
	v_rcp_f32_e32 v5, v4                                       // 0000007BA1BC: 7E0A5504
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BA1C0: BF870095
	v_fma_f32 v6, -v4, v5, 1.0                                 // 0000007BA1C4: D6130006 23CA0B04
	v_fmac_f32_e32 v5, v6, v5                                  // 0000007BA1CC: 560A0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BA1D0: BF870091
	v_mul_f32_e32 v6, v7, v5                                   // 0000007BA1D4: 100C0B07
	v_fma_f32 v8, -v4, v6, v7                                  // 0000007BA1D8: D6130008 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BA1E0: BF870091
	v_fmac_f32_e32 v6, v8, v5                                  // 0000007BA1E4: 560C0B08
	v_fma_f32 v4, -v4, v6, v7                                  // 0000007BA1E8: D6130004 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BA1F0: BF870091
	v_div_fmas_f32 v4, v4, v5, v6                              // 0000007BA1F4: D6370004 041A0B04
	v_div_fixup_f32 v3, v4, v3, v0                             // 0000007BA1FC: D6270003 04020704
	.long 0xd73c0000                                           // 0000007BA204: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007BA208: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BA20C: BF870112
	v_bfe_u32 v4, v3, 16, 1                                    // 0000007BA210: D6100004 02052103
	.long 0xd7006a00                                           // 0000007BA218: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007BA21C: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BA220: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007BA224: D5207C01 01AA0209
	v_add3_u32 v2, v3, v4, 0x7fff                              // 0000007BA22C: D6550002 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007BA238: DC960000 007C0200
	s_endpgm                                                   // 0000007BA240: BFB00000
		...

