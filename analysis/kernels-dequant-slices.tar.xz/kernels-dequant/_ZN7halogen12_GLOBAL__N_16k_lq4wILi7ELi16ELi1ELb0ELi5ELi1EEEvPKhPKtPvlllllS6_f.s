00000000008dbf00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000008DBF00: F4100200 F8000000
	v_and_b32_e32 v30, 15, v0                                  // 0000008DBF08: 363C008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000008DBF0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000008DBF10: 86039F02
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000008DBF14: 300E0082
	s_lshl_b64 s[2:3], s[2:3], 4                               // 0000008DBF18: 84828402
	v_lshlrev_b32_e32 v2, 2, v30                               // 0000008DBF1C: 30043C82
	v_dual_mov_b32 v24, s3 :: v_dual_lshlrev_b32 v3, 2, v1     // 0000008DBF20: CA220003 18020282
	v_or_b32_e32 v23, s2, v1                                   // 0000008DBF28: 382E0202
	.long 0x7f0c3880                                           // 0000008DBF2C: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 0000008DBF30: BF89FC07
	s_clause 0x1                                               // 0000008DBF34: BF850001
	global_load_b32 v4, v2, s[8:9]                             // 0000008DBF38: DC520000 04080002
	global_load_b32 v3, v3, s[8:9]                             // 0000008DBF40: DC520000 03080003
	.long 0xd4540002                                           // 0000008DBF48: D4540002
	v_cndmask_b32_e32 v1, s16, v23, vcc_lo                     // 0000008DBF4C: 02022E10
	s_add_u32 s24, s8, s20                                     // 0000008DBF50: 80181408
	s_addc_u32 s25, s9, s21                                    // 0000008DBF54: 82191509
	s_ashr_i32 s4, s15, 31                                     // 0000008DBF58: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008DBF5C: BF870159
	s_lshr_b32 s4, s4, 27                                      // 0000008DBF60: 85049B04
	v_cndmask_b32_e64 v2, 0, v23, s2                           // 0000008DBF64: D5010002 000A2E80
	v_cndmask_b32_e64 v5, 0, s3, s2                            // 0000008DBF6C: D5010005 00080680
	s_add_u32 s4, s14, s4                                      // 0000008DBF74: 8004040E
	s_addc_u32 s5, s15, 0                                      // 0000008DBF78: 8205800F
	.long 0xd72c0008                                           // 0000008DBF7C: D72C0008
	v_cndmask_b32_e32 v1, s23, v2, vcc_lo                      // 0000008DBF80: 02020417
	v_mad_u64_u32 v[0:1], null, s22, v2, 0                     // 0000008DBF84: D6FE7C00 02020416
	s_lshr_b64 s[6:7], s[4:5], 5                               // 0000008DBF8C: 85868504
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000008DBF90: BF8704D9
	s_cmpk_lt_i32 s6, 0x81                                     // 0000008DBF94: B3860081
	.long 0xd4440004                                           // 0000008DBF98: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008DBF9C: 02023C06
	s_cselect_b32 s3, -1, 0                                    // 0000008DBFA0: 980380C1
	s_cmpk_gt_i32 s6, 0x80                                     // 0000008DBFA4: B2860080
	s_cselect_b32 s7, -1, 0                                    // 0000008DBFA8: 980780C1
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000008DBFAC: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000008DBFB0: BF8907F7
	v_bfe_u32 v9, v4, 16, 1                                    // 0000008DBFB4: D6100009 02052104
	s_waitcnt vmcnt(0)                                         // 0000008DBFBC: BF8903F7
	v_bfe_u32 v10, v3, 16, 1                                   // 0000008DBFC0: D610000A 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008DBFC8: BF8701A2
	v_add3_u32 v4, v4, v9, 0x7fff                              // 0000008DBFCC: D6550004 03FE1304 00007FFF
	.long 0xd72c0009                                           // 0000008DBFD8: D72C0009
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000008DBFDC: 02020A16
	v_add3_u32 v3, v3, v10, 0x7fff                             // 0000008DBFE0: D6550003 03FE1503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008DBFEC: BF870193
	.long 0x7e0c3984                                           // 0000008DBFF0: 7E0C3984
	v_add3_u32 v1, v1, v9, v8                                  // 0000008DBFF4: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DBFFC: BF8700A2
	v_and_or_b32 v6, 0xffff0000, v3, v6                        // 0000008DC000: D6570006 041A06FF FFFF0000
	.long 0xd7000503                                           // 0000008DC00C: D7000503
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 0000008DC010: 02020018
	v_add_co_ci_u32_e64 v4, null, s25, v1, s5                  // 0000008DC014: D5207C04 00160219
	ds_store_b32 v7, v6                                        // 0000008DC01C: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 0000008DC024: BF89FC07
	s_barrier                                                  // 0000008DC028: BFBD0000
	buffer_gl0_inv                                             // 0000008DC02C: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 0000008DC034: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 0000008DC038: CA100080 08060080
	s_and_saveexec_b32 s5, s4                                  // 0000008DC040: BE852004
	s_cbranch_execz 10                                         // 0000008DC044: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x170>
	v_lshlrev_b32_e32 v6, 1, v30                               // 0000008DC048: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC04C: BF870091
	.long 0xd7006a06                                           // 0000008DC050: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008DC054: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000008DC058: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 0000008DC060: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000008DC068: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 0000008DC06C: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008DC070: 8C7E057E
	v_or_b32_e32 v6, 16, v30                                   // 0000008DC074: 380C3C90
	s_mov_b32 s4, exec_lo                                      // 0000008DC078: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DC07C: BF870001
	.long 0xd4c4007e                                           // 0000008DC080: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008DC084: 02020C06
	s_cbranch_execz 10                                         // 0000008DC088: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1b4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008DC08C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC090: BF870091
	.long 0xd7006a08                                           // 0000008DC094: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008DC098: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 0000008DC09C: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 0000008DC0A4: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 0000008DC0AC: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 0000008DC0B0: 7E101706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008DC0B4: 8C7E047E
	v_or_b32_e32 v6, 32, v30                                   // 0000008DC0B8: 380C3CA0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000008DC0BC: CA100080 0A080080
	s_mov_b32 s4, exec_lo                                      // 0000008DC0C4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008DC0C8: BF870002
	.long 0xd4c4007e                                           // 0000008DC0CC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008DC0D0: 02020C06
	s_cbranch_execz 10                                         // 0000008DC0D4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x200>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008DC0D8: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC0DC: BF870091
	.long 0xd7006a0b                                           // 0000008DC0E0: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008DC0E4: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 0000008DC0E8: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 0000008DC0F0: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 0000008DC0F8: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 0000008DC0FC: 7E121706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008DC100: 8C7E047E
	v_or_b32_e32 v6, 48, v30                                   // 0000008DC104: 380C3CB0
	s_mov_b32 s4, exec_lo                                      // 0000008DC108: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DC10C: BF870001
	.long 0xd4c4007e                                           // 0000008DC110: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008DC114: 02020C06
	s_cbranch_execz 10                                         // 0000008DC118: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x244>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008DC11C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC120: BF870091
	.long 0xd7006a0a                                           // 0000008DC124: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008DC128: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 0000008DC12C: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 0000008DC134: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000008DC13C: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 0000008DC140: 7E141706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008DC144: 8C7E047E
	v_or_b32_e32 v6, 64, v30                                   // 0000008DC148: 380C3CC0
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 0000008DC14C: CA100080 0C0A0080
	s_mov_b32 s4, exec_lo                                      // 0000008DC154: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008DC158: BF870002
	.long 0xd4c4007e                                           // 0000008DC15C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008DC160: 02020C06
	s_cbranch_execz 10                                         // 0000008DC164: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x290>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008DC168: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC16C: BF870091
	.long 0xd7006a0d                                           // 0000008DC170: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008DC174: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 0000008DC178: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 0000008DC180: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 0000008DC188: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 0000008DC18C: 7E161706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008DC190: 8C7E047E
	v_or_b32_e32 v6, 0x50, v30                                 // 0000008DC194: 380C3CFF 00000050
	s_mov_b32 s4, exec_lo                                      // 0000008DC19C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DC1A0: BF870001
	.long 0xd4c4007e                                           // 0000008DC1A4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008DC1A8: 02020C06
	s_cbranch_execz 10                                         // 0000008DC1AC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2d8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008DC1B0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC1B4: BF870091
	.long 0xd7006a0c                                           // 0000008DC1B8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008DC1BC: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 0000008DC1C0: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 0000008DC1C8: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 0000008DC1D0: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 0000008DC1D4: 7E181706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008DC1D8: 8C7E047E
	v_or_b32_e32 v6, 0x60, v30                                 // 0000008DC1DC: 380C3CFF 00000060
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 0000008DC1E4: CA100080 0E0C0080
	s_mov_b32 s4, exec_lo                                      // 0000008DC1EC: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008DC1F0: BF870002
	.long 0xd4c4007e                                           // 0000008DC1F4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008DC1F8: 02020C06
	s_cbranch_execz 10                                         // 0000008DC1FC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x328>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008DC200: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC204: BF870091
	.long 0xd7006a0f                                           // 0000008DC208: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008DC20C: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 0000008DC210: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 0000008DC218: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 0000008DC220: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 0000008DC224: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008DC228: 8C7E047E
	v_or_b32_e32 v6, 0x70, v30                                 // 0000008DC22C: 380C3CFF 00000070
	s_mov_b32 s4, exec_lo                                      // 0000008DC234: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DC238: BF870001
	.long 0xd4c4007e                                           // 0000008DC23C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008DC240: 02020C06
	s_cbranch_execz 10                                         // 0000008DC244: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x370>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008DC248: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC24C: BF870091
	.long 0xd7006a0e                                           // 0000008DC250: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008DC254: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 0000008DC258: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 0000008DC260: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 0000008DC268: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 0000008DC26C: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008DC270: 8C7E047E
	s_branch 9                                                 // 0000008DC274: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x39c>
	v_mov_b32_e32 v7, 0                                        // 0000008DC278: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DC27C: BF870001
	v_mov_b32_e32 v8, v7                                       // 0000008DC280: 7E100307
	v_mov_b32_e32 v9, v7                                       // 0000008DC284: 7E120307
	v_mov_b32_e32 v10, v7                                      // 0000008DC288: 7E140307
	v_mov_b32_e32 v11, v7                                      // 0000008DC28C: 7E160307
	v_mov_b32_e32 v12, v7                                      // 0000008DC290: 7E180307
	v_mov_b32_e32 v13, v7                                      // 0000008DC294: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 0000008DC298: 7E1C0307
	s_add_u32 s4, s8, s18                                      // 0000008DC29C: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000008DC2A0: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000008DC2A4: 85129F0F
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v32, 0             // 0000008DC2A8: CA100080 13200080
	s_add_u32 s18, s14, s18                                    // 0000008DC2B0: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000008DC2B4: 8213800F
	v_cndmask_b32_e64 v31, 0, 1, s7                            // 0000008DC2B8: D501001F 001D0280
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008DC2C0: 86928112
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v20, 0             // 0000008DC2C4: CA100080 2B140080
	v_mad_u64_u32 v[25:26], null, v2, s18, s[4:5]              // 0000008DC2CC: D6FE7C19 00102502
	.long 0xd72c0002                                           // 0000008DC2D4: D72C0002
	v_cndmask_b32_e32 v0, v2, v19, vcc_lo                      // 0000008DC2D8: 02002702
	.long 0xd72c0005                                           // 0000008DC2DC: D72C0005
	v_cndmask_b32_e32 v0, v5, v18, vcc_lo                      // 0000008DC2E0: 02002505
	.long 0xd4440004                                           // 0000008DC2E4: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008DC2E8: 02023C06
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 0000008DC2EC: CA100080 15160080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008DC2F4: BF870003
	v_add3_u32 v33, v5, v26, v2                                // 0000008DC2F8: D6550021 040A3505
	s_and_saveexec_b32 s5, s4                                  // 0000008DC300: BE852004
	s_cbranch_execz 21                                         // 0000008DC304: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 0000008DC308: CA220080 2B023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC310: BF870091
	.long 0xd7006a05                                           // 0000008DC314: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 0000008DC318: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 0000008DC31C: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000008DC324: 916A077E
	global_load_b128 v[19:22], v[5:6], off                     // 0000008DC328: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 0000008DC330: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 1, v30                               // 0000008DC334: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC338: BF870091
	.long 0xd7006a02                                           // 0000008DC33C: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 0000008DC340: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 0000008DC344: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 0000008DC34C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000008DC354: BF8903F7
	v_cvt_f32_f16_e32 v43, v2                                  // 0000008DC358: 7E561702
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008DC35C: 8C7E057E
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0             // 0000008DC360: CA100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0             // 0000008DC368: CA100080 25240080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0             // 0000008DC370: CA100080 27260080
	s_and_saveexec_b32 s5, s4                                  // 0000008DC378: BE852004
	s_cbranch_execz 627                                        // 0000008DC37C: BFA50273 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xe4c>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 0000008DC380: CA220080 1B023C81
	.long 0xd7006a00                                           // 0000008DC388: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 0000008DC38C: 02020014
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008DC390: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 0000008DC394: D5207C01 01AA0215
	v_dual_mov_b32 v41, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 0000008DC39C: CA22011E 291A3C85
	.long 0xd7006a00                                           // 0000008DC3A4: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 0000008DC3A8: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008DC3AC: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000008DC3B0: D5207C01 01AA0280
	v_lshl_or_b32 v40, v30, 4, 0x100                           // 0000008DC3B8: D6560028 03FD091E 00000100
	.long 0xd7006a00                                           // 0000008DC3C4: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000008DC3C8: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008DC3CC: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000008DC3D0: D5207C01 01AA0209
	v_mov_b32_e32 v38, v27                                     // 0000008DC3D8: 7E4C031B
	.long 0xd7006a1c                                           // 0000008DC3DC: D7006A1C
	v_cndmask_b32_e32 v0, v0, v160, vcc_lo                     // 0000008DC3E0: 02014100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DC3E4: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 0000008DC3E8: D5207C1D 01AA0280
	v_mov_b32_e32 v39, v27                                     // 0000008DC3F0: 7E4E031B
	v_mov_b32_e32 v36, v27                                     // 0000008DC3F4: 7E48031B
	v_mov_b32_e32 v37, v27                                     // 0000008DC3F8: 7E4A031B
	v_mov_b32_e32 v34, v27                                     // 0000008DC3FC: 7E44031B
	v_mov_b32_e32 v35, v27                                     // 0000008DC400: 7E46031B
	v_mov_b32_e32 v32, v27                                     // 0000008DC404: 7E40031B
	v_mov_b32_e32 v42, v43                                     // 0000008DC408: 7E54032B
	s_mul_i32 s4, s15, 6                                       // 0000008DC40C: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 0000008DC410: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 0000008DC414: 8492820E
	s_add_i32 s7, s7, s4                                       // 0000008DC418: 81070407
	s_mul_i32 s21, s14, 6                                      // 0000008DC41C: 9615860E
	s_mov_b32 s20, 0                                           // 0000008DC420: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000008DC424: 8488810E
	s_branch 555                                               // 0000008DC428: BFA0022B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xdd8>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000008DC42C: 8C7E0E7E
	v_cndmask_b32_e64 v53, v43, v7, s3                         // 0000008DC430: D5010035 000E0F2B
	v_cndmask_b32_e64 v1, v8, v9, s3                           // 0000008DC438: D5010001 000E1308
	v_cndmask_b32_e64 v0, v7, v8, s3                           // 0000008DC440: D5010000 000E1107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 0000008DC448: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s3                         // 0000008DC454: D5010006 000E1D0D
	v_cndmask_b32_e64 v5, v12, v13, s3                         // 0000008DC45C: D5010005 000E1B0C
	v_cndmask_b32_e64 v4, v11, v12, s3                         // 0000008DC464: D5010004 000E190B
	v_cndmask_b32_e64 v3, v10, v11, s3                         // 0000008DC46C: D5010003 000E170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008DC474: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s3                          // 0000008DC478: D5010002 000E1509
	v_add_nc_u32_e32 v40, 0x100, v40                           // 0000008DC480: 4A5050FF 00000100
	s_and_b32 s4, exec_lo, s4                                  // 0000008DC488: 8B04047E
	ds_load_b32 v14, v8                                        // 0000008DC48C: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 0000008DC494: 32102686
	s_or_b32 s20, s4, s20                                      // 0000008DC498: 8C141404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DC49C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008DC4A0: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 0000008DC4A8: D8D80000 36000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 0000008DC4B0: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008DC4B4: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 0000008DC4BC: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 0000008DC4C4: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DC4C8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008DC4CC: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 0000008DC4D4: D8D80000 38000008
	v_and_b32_e32 v8, 0xff, v20                                // 0000008DC4DC: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008DC4E4: 30101082
	ds_load_b32 v57, v8                                        // 0000008DC4E8: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 0000008DC4F0: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DC4F4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008DC4F8: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 0000008DC500: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 0000008DC508: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008DC50C: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 0000008DC514: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 0000008DC51C: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DC520: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008DC524: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 0000008DC52C: D8D80000 3C000008
	v_and_b32_e32 v8, 0xff, v21                                // 0000008DC534: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008DC53C: 30101082
	ds_load_b32 v61, v8                                        // 0000008DC540: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 0000008DC548: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DC54C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008DC550: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 0000008DC558: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 0000008DC560: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008DC564: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 0000008DC56C: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 0000008DC574: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DC578: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008DC57C: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 0000008DC584: D8D80000 40000008
	v_and_b32_e32 v8, 0xff, v22                                // 0000008DC58C: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008DC594: 30101082
	ds_load_b32 v65, v8                                        // 0000008DC598: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 0000008DC5A0: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DC5A4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008DC5A8: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 0000008DC5B0: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 0000008DC5B8: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008DC5BC: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 0000008DC5C4: D8D80000 43000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 0000008DC5CC: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008DC5D0: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008DC5D4: 361010FF 000003FC
	ds_load_b32 v68, v8                                        // 0000008DC5DC: D8D80000 44000008
	.long 0xd73c0008                                           // 0000008DC5E4: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008DC5E8: 02023481
	v_add_nc_u32_e32 v26, 0x200, v26                           // 0000008DC5EC: 4A3434FF 00000200
	.long 0xd7006a0c                                           // 0000008DC5F4: D7006A0C
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 0000008DC5F8: 0202100A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DC5FC: BF870001
	v_add_co_ci_u32_e64 v13, null, s11, v9, vcc_lo             // 0000008DC600: D5207C0D 01AA120B
	s_clause 0x3                                               // 0000008DC608: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008DC60C: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008DC614: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 0000008DC61C: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 0000008DC624: DC5E0030 2F7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000008DC62C: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000008DC630: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 0000008DC638: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DC63C: BF8700A1
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000008DC640: CC1A4008 1C226D09
	s_waitcnt lgkmcnt(13)                                      // 0000008DC648: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000008DC64C: CC1A4008 1C226F0A
	s_waitcnt lgkmcnt(12)                                      // 0000008DC654: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DC658: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000008DC65C: CC1A4008 1C22710B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000008DC664: BF8908B7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000008DC668: CC1A4008 1C227313
	s_waitcnt lgkmcnt(10)                                      // 0000008DC670: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DC674: BF8700A1
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000008DC678: CC1A4008 1C227514
	s_waitcnt lgkmcnt(9)                                       // 0000008DC680: BF89FC97
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000008DC684: CC1A4008 1C227715
	s_waitcnt lgkmcnt(8)                                       // 0000008DC68C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DC690: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000008DC694: CC1A4008 1C227916
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008DC69C: BF890477
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008DC6A0: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(6)                                       // 0000008DC6A8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DC6AC: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008DC6B0: CC1A4008 1C227D2C
	s_waitcnt lgkmcnt(5)                                       // 0000008DC6B8: BF89FC57
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008DC6BC: CC1A4008 1C227F2D
	s_waitcnt lgkmcnt(4)                                       // 0000008DC6C4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DC6C8: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008DC6CC: CC1A4008 1C22812E
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008DC6D4: BF890037
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008DC6D8: CC1A4008 1C22832F
	.long 0xd7006a2f                                           // 0000008DC6E0: D7006A2F
	v_cndmask_b32_e32 v0, v12, v8, vcc_lo                      // 0000008DC6E4: 0200110C
	s_waitcnt lgkmcnt(2)                                       // 0000008DC6E8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008DC6EC: BF8701C2
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008DC6F0: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v48, null, s9, v13, vcc_lo             // 0000008DC6F8: D5207C30 01AA1A09
	.long 0xd7006a33                                           // 0000008DC700: D7006A33
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 0000008DC704: 0200250C
	s_waitcnt lgkmcnt(1)                                       // 0000008DC708: BF89FC17
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008DC70C: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v52, null, s19, v13, vcc_lo            // 0000008DC714: D5207C34 01AA1A13
	.long 0xd7006a0c                                           // 0000008DC71C: D7006A0C
	v_cndmask_b32_e32 v0, v12, v21, vcc_lo                     // 0000008DC720: 02002B0C
	s_waitcnt lgkmcnt(0)                                       // 0000008DC724: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008DC728: BF870123
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000008DC72C: CC1A4008 1C228932
	v_add_co_ci_u32_e64 v13, null, s7, v13, vcc_lo             // 0000008DC734: D5207C0D 01AA1A07
	v_fmac_f32_e32 v38, v53, v8                                // 0000008DC73C: 564C1135
	s_clause 0x3                                               // 0000008DC740: BF850003
	global_load_b128 v[8:11], v[47:48], off                    // 0000008DC744: DC5E0000 087C002F
	global_load_b128 v[19:22], v[47:48], off offset:16         // 0000008DC74C: DC5E0010 137C002F
	global_load_b128 v[43:46], v[47:48], off offset:32         // 0000008DC754: DC5E0020 2B7C002F
	global_load_b128 v[47:50], v[47:48], off offset:48         // 0000008DC75C: DC5E0030 2F7C002F
	s_waitcnt vmcnt(3)                                         // 0000008DC764: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000008DC768: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC770: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000008DC774: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000008DC77C: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DC784: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000008DC788: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 0000008DC790: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000008DC794: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC79C: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000008DC7A0: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000008DC7A8: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DC7B0: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000008DC7B4: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 0000008DC7BC: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008DC7C0: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC7C8: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008DC7CC: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008DC7D4: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DC7DC: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008DC7E0: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000008DC7E8: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008DC7EC: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC7F4: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008DC7F8: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008DC800: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC808: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000008DC80C: CC1A4008 1C228932
	v_fmac_f32_e32 v39, v53, v8                                // 0000008DC814: 564E1135
	s_clause 0x3                                               // 0000008DC818: BF850003
	global_load_b128 v[8:11], v[51:52], off                    // 0000008DC81C: DC5E0000 087C0033
	global_load_b128 v[19:22], v[51:52], off offset:16         // 0000008DC824: DC5E0010 137C0033
	global_load_b128 v[43:46], v[51:52], off offset:32         // 0000008DC82C: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[51:52], off offset:48         // 0000008DC834: DC5E0030 2F7C0033
	.long 0xd7006a33                                           // 0000008DC83C: D7006A33
	v_cndmask_b32_e32 v0, v51, v18, vcc_lo                     // 0000008DC840: 02002533
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DC844: BF8700B1
	v_add_co_ci_u32_e64 v52, null, s19, v52, vcc_lo            // 0000008DC848: D5207C34 01AA6813
	s_waitcnt vmcnt(3)                                         // 0000008DC850: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000008DC854: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000008DC85C: CC1A4008 1C226D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC864: BF870091
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000008DC868: CC1A4008 1C226F0A
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000008DC870: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 0000008DC878: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC87C: BF870091
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000008DC880: CC1A4008 1C227313
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000008DC888: CC1A4008 1C227514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC890: BF870091
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000008DC894: CC1A4008 1C227715
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000008DC89C: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 0000008DC8A4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC8A8: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008DC8AC: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008DC8B4: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC8BC: BF870091
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008DC8C0: CC1A4008 1C227F2D
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008DC8C8: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000008DC8D0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC8D4: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008DC8D8: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008DC8E0: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC8E8: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008DC8EC: CC1A4008 1C228731
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000008DC8F4: CC1A4008 1C228932
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DC8FC: BF870001
	v_fmac_f32_e32 v36, v53, v8                                // 0000008DC900: 56481135
	s_clause 0x3                                               // 0000008DC904: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008DC908: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008DC910: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 0000008DC918: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 0000008DC920: DC5E0030 2F7C000C
	.long 0xd7006a0c                                           // 0000008DC928: D7006A0C
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 0000008DC92C: 0200250C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DC930: BF8700B1
	v_add_co_ci_u32_e64 v13, null, s19, v13, vcc_lo            // 0000008DC934: D5207C0D 01AA1A13
	s_waitcnt vmcnt(3)                                         // 0000008DC93C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000008DC940: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000008DC948: CC1A4008 1C226D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC950: BF870091
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000008DC954: CC1A4008 1C226F0A
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000008DC95C: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 0000008DC964: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC968: BF870091
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000008DC96C: CC1A4008 1C227313
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000008DC974: CC1A4008 1C227514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC97C: BF870091
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000008DC980: CC1A4008 1C227715
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000008DC988: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 0000008DC990: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC994: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008DC998: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008DC9A0: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC9A8: BF870091
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008DC9AC: CC1A4008 1C227F2D
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008DC9B4: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000008DC9BC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC9C0: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008DC9C4: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008DC9CC: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DC9D4: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008DC9D8: CC1A4008 1C228731
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000008DC9E0: CC1A4008 1C228932
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DC9E8: BF870001
	v_fmac_f32_e32 v37, v53, v8                                // 0000008DC9EC: 564A1135
	s_clause 0x3                                               // 0000008DC9F0: BF850003
	global_load_b128 v[8:11], v[51:52], off                    // 0000008DC9F4: DC5E0000 087C0033
	global_load_b128 v[19:22], v[51:52], off offset:16         // 0000008DC9FC: DC5E0010 137C0033
	global_load_b128 v[43:46], v[51:52], off offset:32         // 0000008DCA04: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[51:52], off offset:48         // 0000008DCA0C: DC5E0030 2F7C0033
	s_waitcnt vmcnt(3)                                         // 0000008DCA14: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000008DCA18: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCA20: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000008DCA24: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000008DCA2C: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DCA34: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000008DCA38: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 0000008DCA40: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000008DCA44: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCA4C: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000008DCA50: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000008DCA58: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DCA60: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000008DCA64: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 0000008DCA6C: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008DCA70: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCA78: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008DCA7C: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008DCA84: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DCA8C: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008DCA90: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000008DCA98: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008DCA9C: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCAA4: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008DCAA8: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008DCAB0: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCAB8: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000008DCABC: CC1A4008 1C228932
	v_fmac_f32_e32 v34, v53, v8                                // 0000008DCAC4: 56441135
	s_clause 0x3                                               // 0000008DCAC8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008DCACC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008DCAD4: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 0000008DCADC: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 0000008DCAE4: DC5E0030 2F7C000C
	.long 0xd7006a0c                                           // 0000008DCAEC: D7006A0C
	v_cndmask_b32_e32 v0, v51, v18, vcc_lo                     // 0000008DCAF0: 02002533
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DCAF4: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s19, v52, vcc_lo            // 0000008DCAF8: D5207C0D 01AA6813
	.long 0xd7006a1c                                           // 0000008DCB00: D7006A1C
	v_cndmask_b32_e32 v0, v28, v160, vcc_lo                    // 0000008DCB04: 0201411C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 0000008DCB08: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 0000008DCB10: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000008DCB14: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCB1C: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000008DCB20: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000008DCB28: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DCB30: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000008DCB34: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 0000008DCB3C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000008DCB40: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCB48: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000008DCB4C: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000008DCB54: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DCB5C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000008DCB60: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 0000008DCB68: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008DCB6C: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCB74: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008DCB78: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008DCB80: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DCB88: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008DCB8C: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000008DCB94: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008DCB98: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCBA0: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008DCBA4: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008DCBAC: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCBB4: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000008DCBB8: CC1A4008 1C228932
	v_fmac_f32_e32 v35, v53, v8                                // 0000008DCBC0: 56461135
	s_clause 0x3                                               // 0000008DCBC4: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008DCBC8: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008DCBD0: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 0000008DCBD8: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 0000008DCBE0: DC5E0030 2F7C000C
	s_waitcnt vmcnt(3)                                         // 0000008DCBE8: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000008DCBEC: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCBF4: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000008DCBF8: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000008DCC00: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DCC08: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000008DCC0C: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 0000008DCC14: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000008DCC18: CC1A4008 1C227313
	v_mov_b32_e32 v19, v15                                     // 0000008DCC20: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008DCC24: BF870122
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000008DCC28: CC1A4008 1C227514
	v_mov_b32_e32 v20, v16                                     // 0000008DCC30: 7E280310
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000008DCC34: CC1A4008 1C227715
	v_mov_b32_e32 v21, v17                                     // 0000008DCC3C: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008DCC40: BF870132
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000008DCC44: CC1A4008 1C227916
	v_mov_b32_e32 v22, v18                                     // 0000008DCC4C: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 0000008DCC50: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008DCC54: CC1A4008 1C227B2B
	v_mov_b32_e32 v43, v42                                     // 0000008DCC5C: 7E56032A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCC60: BF870092
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008DCC64: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008DCC6C: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DCC74: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008DCC78: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000008DCC80: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008DCC84: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCC8C: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008DCC90: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008DCC98: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCCA0: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000008DCCA4: CC1A4008 1C228932
	v_fmac_f32_e32 v32, v53, v8                                // 0000008DCCAC: 56401135
	v_mov_b32_e32 v14, v7                                      // 0000008DCCB0: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 0000008DCCB4: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 0000008DCCBC: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 0000008DCCC4: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 0000008DCCCC: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000008DCCD0: 917E147E
	s_cbranch_execz 28                                         // 0000008DCCD4: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xe48>
	s_waitcnt vmcnt(0)                                         // 0000008DCCD8: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v41, 16, v41  // 0000008DCCDC: CA200114 10285290
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 0000008DCCE4: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 0000008DCCEC: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008DCCF0: BF870003
	.long 0xd4430004                                           // 0000008DCCF4: D4430004
	v_cndmask_b32_e32 v1, s6, v41, vcc_lo                      // 0000008DCCF8: 02025206
	s_mov_b32 s14, exec_lo                                     // 0000008DCCFC: BE8E007E
	.long 0xd4c4007e                                           // 0000008DCD00: D4C4007E
	v_cndmask_b32_e32 v1, s6, v41, vcc_lo                      // 0000008DCD04: 02025206
	s_cbranch_execz 64968                                      // 0000008DCD08: BFA5FDC8 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x52c>
	.long 0xd7006a00                                           // 0000008DCD0C: D7006A00
	v_cndmask_b32_e32 v1, v25, v40, vcc_lo                     // 0000008DCD10: 02025119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DCD14: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 0000008DCD18: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 0000008DCD20: 7C9A3E81
	v_mov_b32_e32 v42, v43                                     // 0000008DCD24: 7E54032B
	global_load_b128 v[15:18], v[0:1], off                     // 0000008DCD28: DC5E0000 0F7C0000
	s_cbranch_vccnz 64958                                      // 0000008DCD30: BFA4FDBE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x52c>
	global_load_d16_b16 v0, v[28:29], off                      // 0000008DCD34: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 0000008DCD3C: BF8903F7
	v_cvt_f32_f16_e32 v42, v0                                  // 0000008DCD40: 7E541700
	s_branch 64953                                             // 0000008DCD44: BFA0FDB9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x52c>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000008DCD48: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DCD4C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008DCD50: 8C7E057E
	.long 0xd71f0000                                           // 0000008DCD54: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008DCD58: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 0000008DCD5C: 3A020088
	v_xor_b32_e32 v8, 4, v0                                    // 0000008DCD60: 3A100084
	v_xor_b32_e32 v15, 2, v0                                   // 0000008DCD64: 3A1E0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008DCD68: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000008DCD6C: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000008DCD70: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000008DCD74: 7C9810A0
	v_cndmask_b32_e32 v8, v0, v8, vcc_lo                       // 0000008DCD78: 02101100
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 0000008DCD7C: 7C981EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008DCD80: BF870002
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008DCD84: 30101082
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008DCD88: 30020282
	ds_bpermute_b32 v2, v1, v32                                // 0000008DCD8C: DACC0000 02002001
	s_waitcnt lgkmcnt(0)                                       // 0000008DCD94: BF89FC07
	v_add_f32_e32 v2, v32, v2                                  // 0000008DCD98: 06040520
	ds_bpermute_b32 v4, v1, v38                                // 0000008DCD9C: DACC0000 04002601
	ds_bpermute_b32 v5, v1, v37                                // 0000008DCDA4: DACC0000 05002501
	ds_bpermute_b32 v6, v1, v36                                // 0000008DCDAC: DACC0000 06002401
	ds_bpermute_b32 v7, v1, v35                                // 0000008DCDB4: DACC0000 07002301
	ds_bpermute_b32 v3, v1, v39                                // 0000008DCDBC: DACC0000 03002701
	ds_bpermute_b32 v1, v1, v34                                // 0000008DCDC4: DACC0000 01002201
	ds_bpermute_b32 v9, v8, v2                                 // 0000008DCDCC: DACC0000 09000208
	s_waitcnt lgkmcnt(6)                                       // 0000008DCDD4: BF89FC67
	v_dual_cndmask_b32 v15, v0, v15 :: v_dual_add_f32 v4, v38, v4// 0000008DCDD8: CA481F00 0F040926
	s_waitcnt lgkmcnt(4)                                       // 0000008DCDE0: BF89FC47
	v_dual_add_f32 v5, v37, v5 :: v_dual_add_f32 v6, v36, v6   // 0000008DCDE4: C9080B25 05060D24
	s_waitcnt lgkmcnt(3)                                       // 0000008DCDEC: BF89FC37
	v_add_f32_e32 v7, v35, v7                                  // 0000008DCDF0: 060E0F23
	s_waitcnt lgkmcnt(2)                                       // 0000008DCDF4: BF89FC27
	v_add_f32_e32 v3, v39, v3                                  // 0000008DCDF8: 06060727
	ds_bpermute_b32 v11, v8, v4                                // 0000008DCDFC: DACC0000 0B000408
	ds_bpermute_b32 v12, v8, v5                                // 0000008DCE04: DACC0000 0C000508
	ds_bpermute_b32 v13, v8, v6                                // 0000008DCE0C: DACC0000 0D000608
	s_waitcnt lgkmcnt(4)                                       // 0000008DCE14: BF89FC47
	v_add_f32_e32 v1, v34, v1                                  // 0000008DCE18: 06020322
	ds_bpermute_b32 v10, v8, v3                                // 0000008DCE1C: DACC0000 0A000308
	ds_bpermute_b32 v14, v8, v7                                // 0000008DCE24: DACC0000 0E000708
	s_waitcnt lgkmcnt(5)                                       // 0000008DCE2C: BF89FC57
	v_dual_add_f32 v2, v2, v9 :: v_dual_lshlrev_b32 v15, 2, v15// 0000008DCE30: C9221302 020E1E82
	s_waitcnt lgkmcnt(4)                                       // 0000008DCE38: BF89FC47
	v_add_f32_e32 v4, v4, v11                                  // 0000008DCE3C: 06081704
	ds_bpermute_b32 v8, v8, v1                                 // 0000008DCE40: DACC0000 08000108
	s_waitcnt lgkmcnt(3)                                       // 0000008DCE48: BF89FC37
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v13   // 0000008DCE4C: C9081905 05061B06
	ds_bpermute_b32 v9, v15, v4                                // 0000008DCE54: DACC0000 0900040F
	s_waitcnt lgkmcnt(2)                                       // 0000008DCE5C: BF89FC27
	v_add_f32_e32 v7, v7, v14                                  // 0000008DCE60: 060E1D07
	ds_bpermute_b32 v12, v15, v5                               // 0000008DCE64: DACC0000 0C00050F
	v_add_f32_e32 v3, v3, v10                                  // 0000008DCE6C: 06061503
	v_xor_b32_e32 v10, 1, v0                                   // 0000008DCE70: 3A140081
	ds_bpermute_b32 v13, v15, v6                               // 0000008DCE74: DACC0000 0D00060F
	ds_bpermute_b32 v14, v15, v7                               // 0000008DCE7C: DACC0000 0E00070F
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000008DCE84: 7C9814A0
	v_cndmask_b32_e32 v0, v0, v10, vcc_lo                      // 0000008DCE88: 02001500
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 0000008DCE8C: 7C943C80
	s_waitcnt lgkmcnt(4)                                       // 0000008DCE90: BF89FC47
	v_add_f32_e32 v1, v1, v8                                   // 0000008DCE94: 06021101
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008DCE98: BF870003
	v_lshlrev_b32_e32 v17, 2, v0                               // 0000008DCE9C: 30220082
	s_waitcnt lgkmcnt(3)                                       // 0000008DCEA0: BF89FC37
	v_add_f32_e32 v11, v4, v9                                  // 0000008DCEA4: 06161304
	ds_bpermute_b32 v16, v15, v1                               // 0000008DCEA8: DACC0000 1000010F
	s_waitcnt lgkmcnt(3)                                       // 0000008DCEB0: BF89FC37
	v_add_f32_e32 v4, v5, v12                                  // 0000008DCEB4: 06081905
	ds_bpermute_b32 v8, v15, v3                                // 0000008DCEB8: DACC0000 0800030F
	ds_bpermute_b32 v15, v15, v2                               // 0000008DCEC0: DACC0000 0F00020F
	s_and_b32 s2, vcc_lo, s2                                   // 0000008DCEC8: 8B02026A
	s_waitcnt lgkmcnt(4)                                       // 0000008DCECC: BF89FC47
	v_add_f32_e32 v5, v6, v13                                  // 0000008DCED0: 060A1B06
	ds_bpermute_b32 v13, v17, v11                              // 0000008DCED4: DACC0000 0D000B11
	ds_bpermute_b32 v6, v17, v5                                // 0000008DCEDC: DACC0000 06000511
	s_waitcnt lgkmcnt(3)                                       // 0000008DCEE4: BF89FC37
	v_add_f32_e32 v10, v3, v8                                  // 0000008DCEE8: 06141103
	s_waitcnt lgkmcnt(2)                                       // 0000008DCEEC: BF89FC27
	v_add_f32_e32 v8, v2, v15                                  // 0000008DCEF0: 06101F02
	v_dual_add_f32 v0, v7, v14 :: v_dual_add_f32 v1, v1, v16   // 0000008DCEF4: C9081D07 00002101
	ds_bpermute_b32 v7, v17, v4                                // 0000008DCEFC: DACC0000 07000411
	ds_bpermute_b32 v12, v17, v10                              // 0000008DCF04: DACC0000 0C000A11
	ds_bpermute_b32 v9, v17, v8                                // 0000008DCF0C: DACC0000 09000811
	ds_bpermute_b32 v3, v17, v0                                // 0000008DCF14: DACC0000 03000011
	ds_bpermute_b32 v2, v17, v1                                // 0000008DCF1C: DACC0000 02000111
	s_and_saveexec_b32 s3, s2                                  // 0000008DCF24: BE832002
	s_cbranch_execz 142                                        // 0000008DCF28: BFA5008E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1264>
	v_ashrrev_i32_e32 v14, 31, v24                             // 0000008DCF2C: 341C309F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008DCF30: F4040080 F8000040
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000008DCF38: BF890007
	v_dual_mov_b32 v18, s12 :: v_dual_add_f32 v19, v11, v13    // 0000008DCF3C: CA08000C 12121B0B
	s_lshr_b32 s0, s17, 31                                     // 0000008DCF44: 85009F11
	v_lshrrev_b32_e32 v14, 23, v14                             // 0000008DCF48: 321C1C97
	s_add_u32 s4, s16, s0                                      // 0000008DCF4C: 80040010
	.long 0x7f283880                                           // 0000008DCF50: 7F283880
	.long 0x7e2a3993                                           // 0000008DCF54: 7E2A3993
	s_addc_u32 s5, s17, 0                                      // 0000008DCF58: 82058011
	.long 0xd7006a0e                                           // 0000008DCF5C: D7006A0E
	v_cndmask_b32_e32 v1, v23, v14, vcc_lo                     // 0000008DCF60: 02021D17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008DCF64: BF8701A1
	v_add_co_ci_u32_e64 v15, null, 0, v24, vcc_lo              // 0000008DCF68: D5207C0F 01AA3080
	.long 0x7f2a3994                                           // 0000008DCF70: 7F2A3994
	v_dual_mov_b32 v17, s13 :: v_dual_and_b32 v16, 0xfffffe00, v14// 0000008DCF74: CA24000D 11101CFF FFFFFE00
	v_add_f32_e32 v8, v8, v9                                   // 0000008DCF80: 06101308
	.long 0x7f123994                                           // 0000008DCF84: 7F123994
	v_add_f32_e32 v6, v5, v6                                   // 0000008DCF88: 060C0D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DCF8C: BF870094
	.long 0xd7016a0d                                           // 0000008DCF90: D7016A0D
	v_cndmask_b32_e32 v1, v23, v16, vcc_lo                     // 0000008DCF94: 02022117
	v_sub_co_ci_u32_e64 v14, null, v24, v15, vcc_lo            // 0000008DCF98: D5217C0E 01AA1F18
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008DCFA0: BF8701A3
	.long 0x7e123986                                           // 0000008DCFA4: 7E123986
	v_add_f32_e32 v7, v4, v7                                   // 0000008DCFA8: 060E0F04
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[13:14]                   // 0000008DCFAC: 7CA81AFF 00000100
	v_add_f32_e32 v12, v10, v12                                // 0000008DCFB4: 0618190A
	.long 0xd700000a                                           // 0000008DCFB8: D700000A
	v_cndmask_b32_e32 v1, 0xffffff00, v13, vcc_lo              // 0000008DCFBC: 02021AFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008DCFC4: BF8701A1
	v_add_co_ci_u32_e64 v11, null, -1, v14, s0                 // 0000008DCFC8: D5207C0B 00021CC1
	v_cndmask_b32_e32 v17, s3, v17, vcc_lo                     // 0000008DCFD0: 02222203
	v_cndmask_b32_e32 v10, v10, v13, vcc_lo                    // 0000008DCFD4: 02141B0A
	.long 0x7e28398c                                           // 0000008DCFD8: 7E28398C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008DCFDC: BF8701B4
	v_cndmask_b32_e32 v11, v11, v14, vcc_lo                    // 0000008DCFE0: 02161D0B
	v_dual_cndmask_b32 v13, s2, v18 :: v_dual_and_b32 v18, 1, v21// 0000008DCFE4: CA642402 0D122A81
	s_and_b32 s0, s4, -2                                       // 0000008DCFEC: 8B00C204
	v_and_b32_e32 v14, 1, v20                                  // 0000008DCFF0: 361C2881
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008DCFF4: BF870193
	.long 0xd73c000a                                           // 0000008DCFF8: D73C000A
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 0000008DCFFC: 02021481
	.long 0xd7006a0d                                           // 0000008DD000: D7006A0D
	v_cndmask_b32_e32 v1, v13, v16, vcc_lo                     // 0000008DD004: 0202210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008DD008: BF870211
	v_add_co_ci_u32_e64 v15, null, v17, v15, vcc_lo            // 0000008DD00C: D5207C0F 01AA1F11
	v_add3_u32 v14, v12, v14, 0x7fff                           // 0000008DD014: D655000E 03FE1D0C 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DD020: BF870093
	.long 0xd7006a0a                                           // 0000008DD024: D7006A0A
	v_cndmask_b32_e32 v1, v13, v10, vcc_lo                     // 0000008DD028: 0202150D
	v_add_co_ci_u32_e64 v11, null, v15, v11, vcc_lo            // 0000008DD02C: D5207C0B 01AA170F
	v_add3_u32 v15, v19, v18, 0x7fff                           // 0000008DD034: D655000F 03FE2513 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DD040: BF870093
	.long 0xd7006a0c                                           // 0000008DD044: D7006A0C
	v_cndmask_b32_e32 v0, v10, v0, vcc_lo                      // 0000008DD048: 0200010A
	v_add_co_ci_u32_e64 v13, null, s5, v11, vcc_lo             // 0000008DD04C: D5207C0D 01AA1605
	s_clause 0x1                                               // 0000008DD054: BF850001
	global_store_d16_hi_b16 v[10:11], v15, off                 // 0000008DD058: DC960000 007C0F0A
	global_store_d16_hi_b16 v[12:13], v14, off                 // 0000008DD060: DC960000 007C0E0C
	.long 0x7e283987                                           // 0000008DD068: 7E283987
	v_add_f32_e32 v13, v1, v2                                  // 0000008DD06C: 061A0501
	s_ashr_i64 s[0:1], s[4:5], 1                               // 0000008DD070: 86808104
	v_dual_add_f32 v12, v0, v3 :: v_dual_and_b32 v3, 1, v9     // 0000008DD074: C9240700 0C021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008DD07C: BF870193
	v_and_b32_e32 v2, 1, v20                                   // 0000008DD080: 36042881
	.long 0x7e12398d                                           // 0000008DD084: 7E12398D
	v_mad_u64_u32 v[0:1], null, s0, 6, v[10:11]                // 0000008DD088: D6FE7C00 04290C00
	s_lshl_b64 s[2:3], s[0:1], 2                               // 0000008DD090: 84828200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008DD094: BF870009
	.long 0xd7006a04                                           // 0000008DD098: D7006A04
	v_cndmask_b32_e32 v0, v10, v2, vcc_lo                      // 0000008DD09C: 0200050A
	v_add3_u32 v10, v7, v2, 0x7fff                             // 0000008DD0A0: D655000A 03FE0507 00007FFF
	v_and_b32_e32 v7, 1, v9                                    // 0000008DD0AC: 360E1281
	.long 0x7e28398c                                           // 0000008DD0B0: 7E28398C
	v_add_co_ci_u32_e64 v5, null, s3, v11, vcc_lo              // 0000008DD0B4: D5207C05 01AA1603
	v_mad_u64_u32 v[1:2], null, s1, 6, v[1:2]                  // 0000008DD0BC: D6FE7C01 04050C01
	v_add3_u32 v11, v6, v3, 0x7fff                             // 0000008DD0C4: D655000B 03FE0706 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000008DD0D0: BF870244
	v_and_b32_e32 v6, 1, v20                                   // 0000008DD0D4: 360C2881
	.long 0xd7006a02                                           // 0000008DD0D8: D7006A02
	v_cndmask_b32_e32 v0, v4, v2, vcc_lo                       // 0000008DD0DC: 02000504
	v_bfe_u32 v9, v8, 16, 1                                    // 0000008DD0E0: D6100009 02052108
	v_add_co_ci_u32_e64 v3, null, s3, v5, vcc_lo               // 0000008DD0E8: D5207C03 01AA0A03
	v_add3_u32 v12, v12, v6, 0x7fff                            // 0000008DD0F0: D655000C 03FE0D0C 00007FFF
	.long 0xd7006a06                                           // 0000008DD0FC: D7006A06
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000008DD100: 02000500
	v_add3_u32 v13, v13, v7, 0x7fff                            // 0000008DD104: D655000D 03FE0F0D 00007FFF
	v_add_co_ci_u32_e64 v7, null, s3, v1, vcc_lo               // 0000008DD110: D5207C07 01AA0203
	v_add3_u32 v14, v8, v9, 0x7fff                             // 0000008DD118: D655000E 03FE1308 00007FFF
	.long 0xd7006a08                                           // 0000008DD124: D7006A08
	v_cndmask_b32_e32 v0, v2, v2, vcc_lo                       // 0000008DD128: 02000502
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DD12C: BF870001
	v_add_co_ci_u32_e64 v9, null, s3, v3, vcc_lo               // 0000008DD130: D5207C09 01AA0603
	s_clause 0x4                                               // 0000008DD138: BF850004
	global_store_d16_hi_b16 v[4:5], v11, off                   // 0000008DD13C: DC960000 007C0B04
	global_store_d16_hi_b16 v[0:1], v10, off                   // 0000008DD144: DC960000 007C0A00
	global_store_d16_hi_b16 v[2:3], v13, off                   // 0000008DD14C: DC960000 007C0D02
	global_store_d16_hi_b16 v[6:7], v12, off                   // 0000008DD154: DC960000 007C0C06
	global_store_d16_hi_b16 v[8:9], v14, off                   // 0000008DD15C: DC960000 007C0E08
	s_endpgm                                                   // 0000008DD164: BFB00000
		...

