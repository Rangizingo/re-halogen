00000000007bc900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000007BC900: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007BC908: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007BC90C: 32040082
	v_lshrrev_b32_e32 v22, 5, v0                               // 0000007BC910: 322C0085
	v_and_b32_e32 v23, 31, v0                                  // 0000007BC914: 362E009F
	.long 0x7f0a3880                                           // 0000007BC918: 7F0A3880
	v_lshlrev_b32_e32 v21, 2, v0                               // 0000007BC91C: 302A0082
	s_waitcnt lgkmcnt(0)                                       // 0000007BC920: BF89FC07
	.long 0xd4510004                                           // 0000007BC924: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000007BC928: 02002002
	s_and_b32 s4, s4, exec_lo                                  // 0000007BC92C: 8B047E04
	s_cselect_b32 s6, s3, 0                                    // 0000007BC930: 98068003
	s_cselect_b32 s7, s2, 0                                    // 0000007BC934: 98078002
	s_add_u32 s4, s8, s20                                      // 0000007BC938: 80041408
	s_addc_u32 s5, s9, s21                                     // 0000007BC93C: 82051509
	v_and_b32_e32 v1, 15, v0                                   // 0000007BC940: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 0000007BC944: 360404BC
	s_ashr_i32 s20, s15, 31                                    // 0000007BC948: 86149F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BC94C: BF870119
	s_lshr_b32 s20, s20, 27                                    // 0000007BC950: 85149B14
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007BC954: 30020282
	s_add_u32 s20, s14, s20                                    // 0000007BC958: 8014140E
	s_clause 0x1                                               // 0000007BC95C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 0000007BC960: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 0000007BC968: DC520000 04080002
	s_addc_u32 s21, s15, 0                                     // 0000007BC970: 8215800F
	v_mov_b32_e32 v1, s4                                       // 0000007BC974: 7E020204
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000007BC978: 85948514
	v_mov_b32_e32 v2, s5                                       // 0000007BC97C: 7E040205
	s_add_i32 s21, s20, 7                                      // 0000007BC980: 81158714
	s_mul_i32 s5, s23, s7                                      // 0000007BC984: 96050717
	s_ashr_i32 s24, s21, 31                                    // 0000007BC988: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000007BC98C: BF8704B9
	s_lshr_b32 s4, s24, 29                                     // 0000007BC990: 85049D18
	v_mad_u64_u32 v[17:18], null, s22, s7, v[1:2]              // 0000007BC994: D6FE7C11 04040E16
	s_add_i32 s21, s21, s4                                     // 0000007BC99C: 81150415
	s_ashr_i32 s4, s21, 3                                      // 0000007BC9A0: 86048315
	s_cmpk_lt_i32 s20, 0x801                                   // 0000007BC9A4: B3940801
	.long 0xd72c0001                                           // 0000007BC9A8: D72C0001
	v_cndmask_b32_e32 v1, s4, v22, vcc_lo                      // 0000007BC9AC: 02022C04
	s_mul_i32 s21, s22, s6                                     // 0000007BC9B0: 96150616
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007BC9B4: BF870141
	v_add_nc_u32_e32 v7, s4, v1                                // 0000007BC9B8: 4A0E0204
	v_add_nc_u32_e32 v24, v1, v23                              // 0000007BC9BC: 4A302F01
	s_cselect_b32 s4, -1, 0                                    // 0000007BC9C0: 980480C1
	s_cmpk_gt_i32 s20, 0x800                                   // 0000007BC9C4: B2940800
	v_min_i32_e32 v25, s20, v7                                 // 0000007BC9C8: 22320E14
	s_cselect_b32 s20, -1, 0                                   // 0000007BC9CC: 981480C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007BC9D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s20                             // 0000007BC9D4: 8B6A147E
	s_waitcnt vmcnt(1)                                         // 0000007BC9D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 0000007BC9DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 0000007BC9E4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 0000007BC9E8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000007BC9F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s5, v18                               // 0000007BC9FC: 4A062405
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007BCA00: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 0000007BCA04: D6550004 03FE0D04 00007FFF
	.long 0xd4410005                                           // 0000007BCA10: D4410005
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007BCA14: 02023318
	.long 0x7e0a3982                                           // 0000007BCA18: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BCA1C: BF870114
	v_add_nc_u32_e32 v26, s21, v3                              // 0000007BCA20: 4A340615
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 0000007BCA24: D6570001 041608FF FFFF0000
	ds_store_b32 v21, v1                                       // 0000007BCA30: D8340000 00000115
	s_waitcnt lgkmcnt(0)                                       // 0000007BCA38: BF89FC07
	s_barrier                                                  // 0000007BCA3C: BFBD0000
	buffer_gl0_inv                                             // 0000007BCA40: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000007BCA48: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000007BCA4C: CA100080 02000080
	s_and_saveexec_b32 s21, s5                                 // 0000007BCA54: BE952005
	s_cbranch_execz 11                                         // 0000007BCA58: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v24                               // 0000007BCA5C: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BCA60: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 0000007BCA64: 3408029F
	.long 0xd7006a03                                           // 0000007BCA68: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000007BCA6C: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 0000007BCA70: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 0000007BCA78: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 0000007BCA80: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007BCA84: 7E021701
	s_or_b32 exec_lo, exec_lo, s21                             // 0000007BCA88: 8C7E157E
	v_add_nc_u32_e32 v3, 32, v24                               // 0000007BCA8C: 4A0630A0
	s_mov_b32 s5, exec_lo                                      // 0000007BCA90: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BCA94: BF870001
	.long 0xd4c1007e                                           // 0000007BCA98: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 0000007BCA9C: 02023303
	s_cbranch_execz 11                                         // 0000007BCAA0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000007BCAA4: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BCAA8: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000007BCAAC: 3406049F
	.long 0xd7006a02                                           // 0000007BCAB0: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000007BCAB4: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 0000007BCAB8: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 0000007BCAC0: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007BCAC8: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007BCACC: 7E041702
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BCAD0: 8C7E057E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 0000007BCAD4: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 0000007BCADC: 7E060280
	s_mov_b32 s5, exec_lo                                      // 0000007BCAE0: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BCAE4: BF870002
	.long 0xd4c1007e                                           // 0000007BCAE8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000007BCAEC: 02023305
	s_cbranch_execz 11                                         // 0000007BCAF0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v3, 1, v5                                // 0000007BCAF4: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BCAF8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 0000007BCAFC: 340C069F
	.long 0xd7006a05                                           // 0000007BCB00: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000007BCB04: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 0000007BCB08: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 0000007BCB10: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 0000007BCB18: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007BCB1C: 7E061703
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BCB20: 8C7E057E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 0000007BCB24: 4A0A30FF 00000060
	s_mov_b32 s5, exec_lo                                      // 0000007BCB2C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BCB30: BF870001
	.long 0xd4c1007e                                           // 0000007BCB34: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000007BCB38: 02023305
	s_cbranch_execz 11                                         // 0000007BCB3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v4, 1, v5                                // 0000007BCB40: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BCB44: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000007BCB48: 340A089F
	.long 0xd7006a04                                           // 0000007BCB4C: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 0000007BCB50: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 0000007BCB54: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 0000007BCB5C: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000007BCB64: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007BCB68: 7E081704
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BCB6C: 8C7E057E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 0000007BCB70: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 0000007BCB7C: 7E0A0280
	s_mov_b32 s5, exec_lo                                      // 0000007BCB80: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BCB84: BF870002
	.long 0xd4c1007e                                           // 0000007BCB88: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000007BCB8C: 02023307
	s_cbranch_execz 11                                         // 0000007BCB90: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000007BCB94: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BCB98: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000007BCB9C: 34100A9F
	.long 0xd7006a07                                           // 0000007BCBA0: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000007BCBA4: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 0000007BCBA8: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 0000007BCBB0: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000007BCBB8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007BCBBC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BCBC0: 8C7E057E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 0000007BCBC4: 4A0E30FF 000000A0
	s_mov_b32 s5, exec_lo                                      // 0000007BCBCC: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BCBD0: BF870001
	.long 0xd4c1007e                                           // 0000007BCBD4: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000007BCBD8: 02023307
	s_cbranch_execz 11                                         // 0000007BCBDC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000007BCBE0: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BCBE4: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000007BCBE8: 340E0C9F
	.long 0xd7006a06                                           // 0000007BCBEC: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000007BCBF0: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 0000007BCBF4: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 0000007BCBFC: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000007BCC04: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007BCC08: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BCC0C: 8C7E057E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 0xc0, v24    // 0000007BCC10: CA200080 080830FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 0000007BCC1C: 7E0E0280
	s_mov_b32 s5, exec_lo                                      // 0000007BCC20: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BCC24: BF870002
	.long 0xd4c1007e                                           // 0000007BCC28: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 0000007BCC2C: 02023309
	s_cbranch_execz 11                                         // 0000007BCC30: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v7, 1, v9                                // 0000007BCC34: 300E1281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BCC38: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v7                              // 0000007BCC3C: 34140E9F
	.long 0xd7006a09                                           // 0000007BCC40: D7006A09
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 0000007BCC44: 02020F11
	v_add_co_ci_u32_e64 v10, null, v26, v10, vcc_lo            // 0000007BCC48: D5207C0A 01AA151A
	global_load_d16_b16 v7, v[9:10], off                       // 0000007BCC50: DC820000 077C0009
	s_waitcnt vmcnt(0)                                         // 0000007BCC58: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007BCC5C: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BCC60: 8C7E057E
	v_add_nc_u32_e32 v9, 0xe0, v24                             // 0000007BCC64: 4A1230FF 000000E0
	s_mov_b32 s5, exec_lo                                      // 0000007BCC6C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BCC70: BF870001
	.long 0xd4c1007e                                           // 0000007BCC74: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 0000007BCC78: 02023309
	s_cbranch_execz 11                                         // 0000007BCC7C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v8, 1, v9                                // 0000007BCC80: 30101281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BCC84: BF8700A1
	v_ashrrev_i32_e32 v9, 31, v8                               // 0000007BCC88: 3412109F
	.long 0xd7006a08                                           // 0000007BCC8C: D7006A08
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 0000007BCC90: 02021111
	v_add_co_ci_u32_e64 v9, null, v26, v9, vcc_lo              // 0000007BCC94: D5207C09 01AA131A
	global_load_d16_b16 v8, v[8:9], off                        // 0000007BCC9C: DC820000 087C0008
	s_waitcnt vmcnt(0)                                         // 0000007BCCA4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000007BCCA8: 7E101708
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BCCAC: 8C7E057E
	s_branch 9                                                 // 0000007BCCB0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v1, 0                                        // 0000007BCCB4: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BCCB8: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000007BCCBC: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000007BCCC0: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000007BCCC4: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000007BCCC8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000007BCCCC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000007BCCD0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000007BCCD4: 7E100301
	s_add_u32 s8, s8, s18                                      // 0000007BCCD8: 80081208
	s_addc_u32 s9, s9, s19                                     // 0000007BCCDC: 82091309
	s_lshr_b32 s5, s15, 31                                     // 0000007BCCE0: 85059F0F
	v_dual_mov_b32 v9, s7 :: v_dual_mov_b32 v10, 0             // 0000007BCCE4: CA100007 090A0080
	s_add_u32 s18, s14, s5                                     // 0000007BCCEC: 8012050E
	s_addc_u32 s19, s15, 0                                     // 0000007BCCF0: 8213800F
	.long 0xd4410005                                           // 0000007BCCF4: D4410005
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007BCCF8: 02023318
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000007BCCFC: 86928112
	v_mov_b32_e32 v27, 0                                       // 0000007BCD00: 7E360280
	v_mad_u64_u32 v[18:19], null, v9, s18, s[8:9]              // 0000007BCD04: D6FE7C12 00202509
	.long 0xd72c000b                                           // 0000007BCD0C: D72C000B
	v_cndmask_b32_e32 v0, s7, v19, vcc_lo                      // 0000007BCD10: 02002607
	.long 0xd72c000c                                           // 0000007BCD14: D72C000C
	v_cndmask_b32_e32 v0, s6, v18, vcc_lo                      // 0000007BCD18: 02002406
	v_mov_b32_e32 v9, 0                                        // 0000007BCD1C: 7E120280
	v_cndmask_b32_e64 v28, 0, 1, s20                           // 0000007BCD20: D501001C 00510280
	v_mov_b32_e32 v31, 0                                       // 0000007BCD28: 7E3E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007BCD2C: BF870004
	v_add3_u32 v29, v12, v19, v11                              // 0000007BCD30: D655001D 042E270C
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 0000007BCD38: CA100080 0B0C0080
	s_and_saveexec_b32 s6, s5                                  // 0000007BCD40: BE862005
	s_cbranch_execz 22                                         // 0000007BCD44: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v9, 4, v24                               // 0000007BCD48: 30123084
	v_mov_b32_e32 v31, 0                                       // 0000007BCD4C: 7E3E0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BCD50: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000007BCD54: 3414129F
	.long 0xd7006a09                                           // 0000007BCD58: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 0000007BCD5C: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 0000007BCD60: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 0000007BCD68: 916A147E
	global_load_b128 v[9:12], v[9:10], off                     // 0000007BCD6C: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 0000007BCD74: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v13, 1, v24                              // 0000007BCD78: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BCD7C: BF870091
	.long 0xd7006a0d                                           // 0000007BCD80: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 0000007BCD84: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 0000007BCD88: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 0000007BCD90: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 0000007BCD98: BF8903F7
	v_cvt_f32_f16_e32 v31, v13                                 // 0000007BCD9C: 7E3E170D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000007BCDA0: 8C7E067E
	v_mov_b32_e32 v30, 0                                       // 0000007BCDA4: 7E3C0280
	s_and_saveexec_b32 s8, s5                                  // 0000007BCDA8: BE882005
	s_cbranch_execz 290                                        // 0000007BCDAC: BFA50122 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x938>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v13, 32, v24    // 0000007BCDB0: CA200080 1E0C30A0
	v_dual_mov_b32 v34, v31 :: v_dual_lshlrev_b32 v19, 5, v24  // 0000007BCDB8: CA22011F 22123085
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BCDC0: BF870002
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v32, 4, v13    // 0000007BCDC4: CA220080 1B201A84
	v_lshlrev_b32_e32 v33, 1, v13                              // 0000007BCDCC: 30421A81
	s_mov_b32 s9, 0                                            // 0000007BCDD0: BE890080
	s_lshl_b64 s[6:7], s[14:15], 1                             // 0000007BCDD4: 8486810E
	s_branch 243                                               // 0000007BCDD8: BFA000F3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x8a8>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007BCDDC: 8C7E0E7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000007BCDE0: 3428269F
	v_lshrrev_b32_e32 v67, 6, v9                               // 0000007BCDE4: 32861286
	v_lshrrev_b32_e32 v68, 14, v9                              // 0000007BCDE8: 3288128E
	v_and_b32_e32 v69, 0xff, v10                               // 0000007BCDEC: 368A14FF 000000FF
	v_lshrrev_b32_e32 v70, 6, v10                              // 0000007BCDF4: 328C1486
	.long 0xd73c0023                                           // 0000007BCDF8: D73C0023
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007BCDFC: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 0000007BCE00: 362812FF 000000FF
	v_and_b32_e32 v67, 0x3fc, v67                              // 0000007BCE08: 368686FF 000003FC
	v_and_b32_e32 v68, 0x3fc, v68                              // 0000007BCE10: 368888FF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007BCE18: 32121296
	v_lshrrev_b32_e32 v71, 14, v10                             // 0000007BCE1C: 328E148E
	.long 0xd7006a3b                                           // 0000007BCE20: D7006A3B
	v_cndmask_b32_e32 v1, s10, v35, vcc_lo                     // 0000007BCE24: 0202460A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BCE28: BF8701A1
	v_add_co_ci_u32_e64 v60, null, s11, v36, vcc_lo            // 0000007BCE2C: D5207C3C 01AA480B
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000007BCE34: 30282882
	.long 0xd7006a3f                                           // 0000007BCE38: D7006A3F
	v_cndmask_b32_e32 v0, v59, v6, vcc_lo                      // 0000007BCE3C: 02000D3B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BCE40: BF870001
	v_add_co_ci_u32_e64 v64, null, s7, v60, vcc_lo             // 0000007BCE44: D5207C40 01AA7807
	ds_load_b32 v20, v20                                       // 0000007BCE4C: D8D80000 14000014
	ds_load_b32 v67, v67                                       // 0000007BCE54: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 0000007BCE5C: D8D80000 44000044
	s_clause 0x7                                               // 0000007BCE64: BF850007
	global_load_b128 v[35:38], v[59:60], off                   // 0000007BCE68: DC5E0000 237C003B
	global_load_b128 v[39:42], v[63:64], off                   // 0000007BCE70: DC5E0000 277C003F
	global_load_b128 v[43:46], v[59:60], off offset:16         // 0000007BCE78: DC5E0010 2B7C003B
	global_load_b128 v[47:50], v[63:64], off offset:16         // 0000007BCE80: DC5E0010 2F7C003F
	global_load_b128 v[51:54], v[59:60], off offset:32         // 0000007BCE88: DC5E0020 337C003B
	global_load_b128 v[55:58], v[63:64], off offset:32         // 0000007BCE90: DC5E0020 377C003F
	global_load_b128 v[59:62], v[59:60], off offset:48         // 0000007BCE98: DC5E0030 3B7C003B
	global_load_b128 v[63:66], v[63:64], off offset:48         // 0000007BCEA0: DC5E0030 3F7C003F
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000007BCEA8: 32141496
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007BCEAC: 361212FF 000003FC
	v_lshlrev_b32_e32 v69, 2, v69                              // 0000007BCEB4: 308A8A82
	v_and_b32_e32 v70, 0x3fc, v70                              // 0000007BCEB8: 368C8CFF 000003FC
	v_and_b32_e32 v71, 0x3fc, v71                              // 0000007BCEC0: 368E8EFF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007BCEC8: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 0000007BCED0: D8D80000 09000009
	ds_load_b32 v69, v69                                       // 0000007BCED8: D8D80000 45000045
	ds_load_b32 v70, v70                                       // 0000007BCEE0: D8D80000 46000046
	ds_load_b32 v71, v71                                       // 0000007BCEE8: D8D80000 47000047
	ds_load_b32 v10, v10                                       // 0000007BCEF0: D8D80000 0A00000A
	v_add_nc_u32_e32 v32, 0x200, v32                           // 0000007BCEF8: 4A4040FF 00000200
	s_and_b32 s5, exec_lo, s5                                  // 0000007BCF00: 8B05057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007BCF04: BF870009
	s_or_b32 s9, s5, s9                                        // 0000007BCF08: 8C090905
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000007BCF0C: BF891C77
	v_dot2_f32_bf16 v35, v35, v20, 0                           // 0000007BCF10: CC1A4023 1A022923
	s_waitcnt vmcnt(6)                                         // 0000007BCF18: BF891BF7
	v_dot2_f32_bf16 v20, v39, v20, 0                           // 0000007BCF1C: CC1A4014 1A022927
	v_and_b32_e32 v39, 0xff, v11                               // 0000007BCF24: 364E16FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000007BCF2C: BF89FC67
	v_dot2_f32_bf16 v35, v36, v67, v35                         // 0000007BCF30: CC1A4023 1C8E8724
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BCF38: BF870003
	v_dot2_f32_bf16 v20, v40, v67, v20                         // 0000007BCF3C: CC1A4014 1C528728
	v_lshrrev_b32_e32 v36, 6, v11                              // 0000007BCF44: 32481686
	v_lshrrev_b32_e32 v40, 14, v11                             // 0000007BCF48: 3250168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007BCF4C: 32161696
	s_waitcnt lgkmcnt(5)                                       // 0000007BCF50: BF89FC57
	v_dot2_f32_bf16 v35, v37, v68, v35                         // 0000007BCF54: CC1A4023 1C8E8925
	v_dot2_f32_bf16 v20, v41, v68, v20                         // 0000007BCF5C: CC1A4014 1C528929
	v_and_b32_e32 v36, 0x3fc, v36                              // 0000007BCF64: 364848FF 000003FC
	v_lshrrev_b32_e32 v41, 6, v12                              // 0000007BCF6C: 32521886
	v_and_b32_e32 v37, 0xff, v12                               // 0000007BCF70: 364A18FF 000000FF
	s_waitcnt lgkmcnt(4)                                       // 0000007BCF78: BF89FC47
	v_dot2_f32_bf16 v35, v38, v9, v35                          // 0000007BCF7C: CC1A4023 1C8E1326
	v_dot2_f32_bf16 v9, v42, v9, v20                           // 0000007BCF84: CC1A4009 1C52132A
	v_lshlrev_b32_e32 v20, 2, v39                              // 0000007BCF8C: 30284E82
	v_and_b32_e32 v38, 0x3fc, v40                              // 0000007BCF90: 364C50FF 000003FC
	v_lshrrev_b32_e32 v67, 14, v12                             // 0000007BCF98: 3286188E
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000007BCF9C: BF891437
	v_dot2_f32_bf16 v35, v43, v69, v35                         // 0000007BCFA0: CC1A4023 1C8E8B2B
	s_waitcnt vmcnt(4)                                         // 0000007BCFA8: BF8913F7
	v_dot2_f32_bf16 v9, v47, v69, v9                           // 0000007BCFAC: CC1A4009 1C268B2F
	ds_load_b32 v20, v20                                       // 0000007BCFB4: D8D80000 14000014
	ds_load_b32 v36, v36                                       // 0000007BCFBC: D8D80000 24000024
	ds_load_b32 v38, v38                                       // 0000007BCFC4: D8D80000 26000026
	s_waitcnt lgkmcnt(5)                                       // 0000007BCFCC: BF89FC57
	v_dot2_f32_bf16 v35, v44, v70, v35                         // 0000007BCFD0: CC1A4023 1C8E8D2C
	v_dot2_f32_bf16 v9, v48, v70, v9                           // 0000007BCFD8: CC1A4009 1C268D30
	v_lshrrev_b32_e32 v12, 22, v12                             // 0000007BCFE0: 32181896
	v_and_b32_e32 v39, 0x3fc, v41                              // 0000007BCFE4: 364E52FF 000003FC
	v_cndmask_b32_e64 v41, v7, v8, s4                          // 0000007BCFEC: D5010029 00121107
	s_waitcnt lgkmcnt(4)                                       // 0000007BCFF4: BF89FC47
	v_dot2_f32_bf16 v35, v45, v71, v35                         // 0000007BCFF8: CC1A4023 1C8E8F2D
	v_dot2_f32_bf16 v9, v49, v71, v9                           // 0000007BD000: CC1A4009 1C268F31
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007BD008: 361616FF 000003FC
	v_lshlrev_b32_e32 v37, 2, v37                              // 0000007BD010: 304A4A82
	v_and_b32_e32 v40, 0x3fc, v67                              // 0000007BD014: 365086FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007BD01C: BF89FC37
	v_dot2_f32_bf16 v35, v46, v10, v35                         // 0000007BD020: CC1A4023 1C8E152E
	v_dot2_f32_bf16 v9, v50, v10, v9                           // 0000007BD028: CC1A4009 1C261532
	v_and_b32_e32 v12, 0x3fc, v12                              // 0000007BD030: 361818FF 000003FC
	ds_load_b32 v10, v11                                       // 0000007BD038: D8D80000 0A00000B
	ds_load_b32 v11, v37                                       // 0000007BD040: D8D80000 0B000025
	ds_load_b32 v42, v39                                       // 0000007BD048: D8D80000 2A000027
	ds_load_b32 v43, v40                                       // 0000007BD050: D8D80000 2B000028
	ds_load_b32 v44, v12                                       // 0000007BD058: D8D80000 2C00000C
	v_cndmask_b32_e64 v40, v6, v7, s4                          // 0000007BD060: D5010028 00120F06
	v_cndmask_b32_e64 v39, v5, v6, s4                          // 0000007BD068: D5010027 00120D05
	v_cndmask_b32_e64 v37, v3, v4, s4                          // 0000007BD070: D5010025 00120903
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000007BD078: BF890C77
	v_dot2_f32_bf16 v12, v51, v20, v35                         // 0000007BD07C: CC1A400C 1C8E2933
	s_waitcnt vmcnt(2)                                         // 0000007BD084: BF890BF7
	v_dot2_f32_bf16 v9, v55, v20, v9                           // 0000007BD088: CC1A4009 1C262937
	v_cndmask_b32_e64 v20, v31, v1, s4                         // 0000007BD090: D5010014 0012031F
	v_cndmask_b32_e64 v35, v1, v2, s4                          // 0000007BD098: D5010023 00120501
	v_mov_b32_e32 v31, v34                                     // 0000007BD0A0: 7E3E0322
	s_waitcnt lgkmcnt(6)                                       // 0000007BD0A4: BF89FC67
	v_dot2_f32_bf16 v12, v52, v36, v12                         // 0000007BD0A8: CC1A400C 1C324934
	v_dot2_f32_bf16 v9, v56, v36, v9                           // 0000007BD0B0: CC1A4009 1C264938
	v_cndmask_b32_e64 v36, v2, v3, s4                          // 0000007BD0B8: D5010024 00120702
	s_waitcnt lgkmcnt(5)                                       // 0000007BD0C0: BF89FC57
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BD0C4: BF870193
	v_dot2_f32_bf16 v12, v53, v38, v12                         // 0000007BD0C8: CC1A400C 1C324D35
	v_dot2_f32_bf16 v9, v57, v38, v9                           // 0000007BD0D0: CC1A4009 1C264D39
	v_cndmask_b32_e64 v38, v4, v5, s4                          // 0000007BD0D8: D5010026 00120B04
	s_waitcnt lgkmcnt(4)                                       // 0000007BD0E0: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BD0E4: BF870193
	v_dot2_f32_bf16 v12, v54, v10, v12                         // 0000007BD0E8: CC1A400C 1C321536
	v_dot2_f32_bf16 v9, v58, v10, v9                           // 0000007BD0F0: CC1A4009 1C26153A
	v_mov_b32_e32 v10, v14                                     // 0000007BD0F8: 7E14030E
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000007BD0FC: BF890437
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BD100: BF870003
	v_dot2_f32_bf16 v5, v59, v11, v12                          // 0000007BD104: CC1A4005 1C32173B
	s_waitcnt vmcnt(0)                                         // 0000007BD10C: BF8903F7
	v_dot2_f32_bf16 v6, v63, v11, v9                           // 0000007BD110: CC1A4006 1C26173F
	v_dual_mov_b32 v12, v16 :: v_dual_mov_b32 v11, v15         // 0000007BD118: CA100110 0C0A010F
	v_mov_b32_e32 v9, v13                                      // 0000007BD120: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 0000007BD124: BF89FC27
	v_dot2_f32_bf16 v1, v60, v42, v5                           // 0000007BD128: CC1A4001 1C16553C
	v_dot2_f32_bf16 v2, v64, v42, v6                           // 0000007BD130: CC1A4002 1C1A5540
	v_dual_mov_b32 v42, v8 :: v_dual_add_nc_u32 v33, 64, v33   // 0000007BD138: CA200108 2A2042C0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000007BD140: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 0000007BD148: BF89FC17
	v_dot2_f32_bf16 v1, v61, v43, v1                           // 0000007BD14C: CC1A4001 1C06573D
	v_dot2_f32_bf16 v2, v65, v43, v2                           // 0000007BD154: CC1A4002 1C0A5741
	s_waitcnt lgkmcnt(0)                                       // 0000007BD15C: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BD160: BF870112
	v_dot2_f32_bf16 v1, v62, v44, v1                           // 0000007BD164: CC1A4001 1C06593E
	v_dot2_f32_bf16 v2, v66, v44, v2                           // 0000007BD16C: CC1A4002 1C0A5942
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BD174: BF870112
	v_fmac_f32_e32 v30, v20, v1                                // 0000007BD178: 563C0314
	v_fmac_f32_e32 v27, v20, v2                                // 0000007BD17C: 56360514
	v_dual_mov_b32 v1, v35 :: v_dual_mov_b32 v2, v36           // 0000007BD180: CA100123 01020124
	v_dual_mov_b32 v3, v37 :: v_dual_mov_b32 v4, v38           // 0000007BD188: CA100125 03040126
	v_dual_mov_b32 v5, v39 :: v_dual_mov_b32 v6, v40           // 0000007BD190: CA100127 05060128
	v_dual_mov_b32 v7, v41 :: v_dual_mov_b32 v8, v42           // 0000007BD198: CA100129 0708012A
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000007BD1A0: 917E097E
	s_cbranch_execz 35                                         // 0000007BD1A4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x934>
	s_waitcnt vmcnt(0)                                         // 0000007BD1A8: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 0000007BD1AC: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 0000007BD1B4: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 0000007BD1BC: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BD1C0: BF870003
	.long 0xd4460005                                           // 0000007BD1C4: D4460005
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007BD1C8: 02023318
	s_mov_b32 s14, exec_lo                                     // 0000007BD1CC: BE8E007E
	.long 0xd4c1007e                                           // 0000007BD1D0: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007BD1D4: 02023318
	s_cbranch_execz 65280                                      // 0000007BD1D8: BFA5FF00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4dc>
	v_ashrrev_i32_e32 v14, 31, v32                             // 0000007BD1DC: 341C409F
	.long 0xd7006a0d                                           // 0000007BD1E0: D7006A0D
	v_cndmask_b32_e32 v1, v18, v32, vcc_lo                     // 0000007BD1E4: 02024112
	v_mov_b32_e32 v34, v31                                     // 0000007BD1E8: 7E44031F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BD1EC: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 0000007BD1F0: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 0000007BD1F8: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 0000007BD1FC: DC5E0000 0D7C000D
	s_cbranch_vccnz 65269                                      // 0000007BD204: BFA4FEF5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4dc>
	v_ashrrev_i32_e32 v20, 31, v33                             // 0000007BD208: 3428429F
	.long 0xd7006a22                                           // 0000007BD20C: D7006A22
	v_cndmask_b32_e32 v1, v17, v33, vcc_lo                     // 0000007BD210: 02024311
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BD214: BF870001
	v_add_co_ci_u32_e64 v35, null, v26, v20, vcc_lo            // 0000007BD218: D5207C23 01AA291A
	global_load_d16_b16 v20, v[34:35], off                     // 0000007BD220: DC820000 147C0022
	s_waitcnt vmcnt(0)                                         // 0000007BD228: BF8903F7
	v_cvt_f32_f16_e32 v34, v20                                 // 0000007BD22C: 7E441714
	s_branch 65258                                             // 0000007BD230: BFA0FEEA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4dc>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000007BD234: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007BD238: BF8700B9
	s_or_b32 exec_lo, exec_lo, s8                              // 0000007BD23C: 8C7E087E
	.long 0xd71f0001                                           // 0000007BD240: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007BD244: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000007BD248: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007BD24C: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 0000007BD250: 3A080288
	v_xor_b32_e32 v6, 4, v1                                    // 0000007BD254: 3A0C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007BD258: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007BD25C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007BD260: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007BD264: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BD268: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007BD26C: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007BD270: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007BD274: 7C980CA0
	ds_bpermute_b32 v3, v2, v30                                // 0000007BD278: DACC0000 03001E02
	s_waitcnt lgkmcnt(0)                                       // 0000007BD280: BF89FC07
	v_dual_add_f32 v3, v30, v3 :: v_dual_lshlrev_b32 v4, 2, v4 // 0000007BD284: C922071E 03040882
	ds_bpermute_b32 v5, v4, v3                                 // 0000007BD28C: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 0000007BD294: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 0000007BD298: 06060B03
	ds_bpermute_b32 v2, v2, v27                                // 0000007BD29C: DACC0000 02001B02
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000007BD2A4: 020C0D01
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BD2A8: BF870001
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000007BD2AC: 300C0C82
	s_waitcnt lgkmcnt(0)                                       // 0000007BD2B0: BF89FC07
	v_add_f32_e32 v2, v27, v2                                  // 0000007BD2B4: 0604051B
	ds_bpermute_b32 v4, v4, v2                                 // 0000007BD2B8: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 0000007BD2C0: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000007BD2C4: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 0000007BD2C8: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 0000007BD2D0: DACC0000 05000206
	v_xor_b32_e32 v6, 2, v1                                    // 0000007BD2D8: 3A0C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007BD2DC: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007BD2E0: 7C980CA0
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000007BD2E4: 020C0D01
	s_waitcnt lgkmcnt(1)                                       // 0000007BD2E8: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v6  // 0000007BD2EC: C9220903 03060C82
	s_waitcnt lgkmcnt(0)                                       // 0000007BD2F4: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 0000007BD2F8: 06040B02
	ds_bpermute_b32 v4, v6, v3                                 // 0000007BD2FC: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 0000007BD304: DACC0000 05000206
	v_xor_b32_e32 v6, 1, v1                                    // 0000007BD30C: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007BD310: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007BD314: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 0000007BD318: 02020D01
	s_waitcnt lgkmcnt(1)                                       // 0000007BD31C: BF89FC17
	v_dual_add_f32 v1, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v1  // 0000007BD320: C9220903 01060282
	s_waitcnt lgkmcnt(0)                                       // 0000007BD328: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 0000007BD32C: 06040B02
	ds_bpermute_b32 v3, v6, v1                                 // 0000007BD330: DACC0000 03000106
	ds_bpermute_b32 v4, v6, v2                                 // 0000007BD338: DACC0000 04000206
	v_cmpx_eq_u32_e32 0, v23                                   // 0000007BD340: 7D942E80
	s_cbranch_execz 6                                          // 0000007BD344: BFA50006 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xa60>
	s_waitcnt lgkmcnt(0)                                       // 0000007BD348: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v5, 3, v22 // 0000007BD34C: C9220902 02042C83
	v_add_f32_e32 v1, v1, v3                                   // 0000007BD354: 06020701
	ds_store_b64 v5, v[1:2] offset:1024                        // 0000007BD358: D9340400 00000105
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BD360: 8C7E047E
	.long 0xd4510004                                           // 0000007BD364: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000007BD368: 02002002
	v_cmp_gt_u32_e32 vcc_lo, 2, v0                             // 0000007BD36C: 7C980082
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000007BD370: BF890007
	s_barrier                                                  // 0000007BD374: BFBD0000
	buffer_gl0_inv                                             // 0000007BD378: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000007BD380: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007BD384: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000007BD388: BE852004
	s_cbranch_execz 89                                         // 0000007BD38C: BFA50059 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xbf4>
	v_add_nc_u32_e32 v7, 0x400, v21                            // 0000007BD390: 4A0E2AFF 00000400
	s_load_b32 s0, s[0:1], 0x48                                // 0000007BD398: F4000000 F8000048
	ds_load_2addr_b32 v[1:2], v7 offset1:2                     // 0000007BD3A0: D8DC0200 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:4 offset1:6           // 0000007BD3A8: D8DC0604 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:8 offset1:10          // 0000007BD3B0: D8DC0A08 05000007
	s_waitcnt lgkmcnt(0)                                       // 0000007BD3B8: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 0000007BD3BC: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007BD3C0: BF8700B1
	v_add_f32_e32 v8, v1, v2                                   // 0000007BD3C4: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:12 offset1:14         // 0000007BD3C8: D8DC0E0C 01000007
	v_add_f32_e32 v3, v8, v3                                   // 0000007BD3D0: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 0000007BD3D4: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BD3D8: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000007BD3DC: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000007BD3E0: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000007BD3E4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BD3E8: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000007BD3EC: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000007BD3F0: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BD3F4: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 0000007BD3F8: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 0000007BD400: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BD40C: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007BD410: 360202FF FFFF0000
	v_mul_f32_e32 v4, s0, v1                                   // 0000007BD418: 10080200
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000007BD41C: 84808102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BD420: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v4                           // 0000007BD424: 100208FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000007BD42C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BD430: BF870095
	v_add_f32_e32 v5, 1.0, v1                                  // 0000007BD434: 060A02F2
	v_div_scale_f32 v3, null, v5, v5, v4                       // 0000007BD438: D6FC7C03 04120B05
	v_div_scale_f32 v7, vcc_lo, v4, v5, v4                     // 0000007BD440: D6FC6A07 04120B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007BD448: BF870292
	v_rcp_f32_e32 v6, v3                                       // 0000007BD44C: 7E0C5503
	v_fma_f32 v1, -v3, v6, 1.0                                 // 0000007BD450: D6130001 23CA0D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BD458: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 0000007BD45C: 560C0D01
	v_mad_u64_u32 v[1:2], null, s16, v0, 0                     // 0000007BD460: D6FE7C01 02020010
	v_mul_f32_e32 v8, v7, v6                                   // 0000007BD468: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BD46C: BF870091
	v_fma_f32 v9, -v3, v8, v7                                  // 0000007BD470: D6130009 241E1103
	v_fmac_f32_e32 v8, v9, v6                                  // 0000007BD478: 56100D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BD47C: BF870121
	v_fma_f32 v7, -v3, v8, v7                                  // 0000007BD480: D6130007 241E1103
	v_mad_u64_u32 v[2:3], null, s17, v0, v[2:3]                // 0000007BD488: D6FE7C02 040A0011
	v_div_fmas_f32 v0, v7, v6, v8                              // 0000007BD490: D6370000 04220D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BD498: BF870191
	v_div_fixup_f32 v3, v0, v5, v4                             // 0000007BD49C: D6270003 04120B00
	.long 0xd73c0000                                           // 0000007BD4A4: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007BD4A8: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BD4AC: BF870112
	v_bfe_u32 v2, v3, 16, 1                                    // 0000007BD4B0: D6100002 02052103
	.long 0xd7006a00                                           // 0000007BD4B8: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000007BD4BC: 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BD4C0: BF870191
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 0000007BD4C4: D5207C01 01AA020D
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000007BD4CC: D6550002 03FE0503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BD4D8: BF870093
	.long 0xd7006a00                                           // 0000007BD4DC: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007BD4E0: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000007BD4E4: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007BD4EC: DC960000 007C0200
	s_endpgm                                                   // 0000007BD4F4: BFB00000
		...

