0000000000844200 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 000000844200: F4100200 F8000000
	v_and_b32_e32 v23, 15, v0                                  // 000000844208: 362E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000084420C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000844210: 86039F02
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000844214: 30000082
	s_lshl_b64 s[2:3], s[2:3], 4                               // 000000844218: 84828402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000084421C: BF870009
	v_dual_mov_b32 v17, s3 :: v_dual_lshlrev_b32 v2, 2, v23    // 000000844220: CA220003 11022E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000844228: 30060282
	v_or_b32_e32 v16, s2, v1                                   // 00000084422C: 38200202
	.long 0x7f023880                                           // 000000844230: 7F023880
	s_waitcnt lgkmcnt(0)                                       // 000000844234: BF89FC07
	s_clause 0x1                                               // 000000844238: BF850001
	global_load_b32 v2, v2, s[8:9]                             // 00000084423C: DC520000 02080002
	global_load_b32 v3, v3, s[8:9]                             // 000000844244: DC520000 03080003
	.long 0xd4540002                                           // 00000084424C: D4540002
	v_cndmask_b32_e32 v1, s16, v16, vcc_lo                     // 000000844250: 02022010
	s_add_u32 s24, s8, s20                                     // 000000844254: 80181408
	s_addc_u32 s25, s9, s21                                    // 000000844258: 82191509
	s_ashr_i32 s4, s15, 31                                     // 00000084425C: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000844260: BF870159
	s_lshr_b32 s4, s4, 27                                      // 000000844264: 85049B04
	v_cndmask_b32_e64 v10, 0, v16, s2                          // 000000844268: D501000A 000A2080
	v_cndmask_b32_e64 v12, 0, s3, s2                           // 000000844270: D501000C 00080680
	s_add_u32 s4, s14, s4                                      // 000000844278: 8004040E
	s_addc_u32 s5, s15, 0                                      // 00000084427C: 8205800F
	.long 0xd72c0004                                           // 000000844280: D72C0004
	v_cndmask_b32_e32 v1, s23, v10, vcc_lo                     // 000000844284: 02021417
	v_mad_u64_u32 v[8:9], null, s22, v10, 0                    // 000000844288: D6FE7C08 02021416
	s_lshr_b64 s[6:7], s[4:5], 5                               // 000000844290: 85868504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000844294: BF870009
	s_cmpk_lt_i32 s6, 0x81                                     // 000000844298: B3860081
	.long 0xd4440004                                           // 00000084429C: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008442A0: 02022E06
	s_cselect_b32 s3, -1, 0                                    // 0000008442A4: 980380C1
	s_cmpk_gt_i32 s6, 0x80                                     // 0000008442A8: B2860080
	.long 0xd700050b                                           // 0000008442AC: D700050B
	v_cndmask_b32_e32 v1, s24, v8, vcc_lo                      // 0000008442B0: 02021018
	s_cselect_b32 s7, -1, 0                                    // 0000008442B4: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008442B8: BF870159
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000008442BC: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000008442C0: BF8907F7
	v_bfe_u32 v5, v2, 16, 1                                    // 0000008442C4: D6100005 02052102
	s_waitcnt vmcnt(0)                                         // 0000008442CC: BF8903F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000008442D0: D6100006 02052103
	v_add3_u32 v2, v2, v5, 0x7fff                              // 0000008442D8: D6550002 03FE0B02 00007FFF
	.long 0xd72c0005                                           // 0000008442E4: D72C0005
	v_cndmask_b32_e32 v1, s22, v12, vcc_lo                     // 0000008442E8: 02021816
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008442EC: BF870193
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000008442F0: D6550003 03FE0D03 00007FFF
	.long 0x7e023982                                           // 0000008442FC: 7E023982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000844300: BF870113
	v_add3_u32 v9, v9, v5, v4                                  // 000000844304: D6550009 04120B09
	v_and_or_b32 v1, 0xffff0000, v3, v1                        // 00000084430C: D6570001 040606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000844318: BF870002
	v_add_co_ci_u32_e64 v20, null, s25, v9, s5                 // 00000084431C: D5207C14 00161219
	ds_store_b32 v0, v1                                        // 000000844324: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 00000084432C: BF89FC07
	s_barrier                                                  // 000000844330: BFBD0000
	buffer_gl0_inv                                             // 000000844334: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 00000084433C: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x380>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 000000844340: CA100080 01000080
	s_and_saveexec_b32 s5, s4                                  // 000000844348: BE852004
	s_cbranch_execz 10                                         // 00000084434C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x178>
	v_lshlrev_b32_e32 v0, 1, v23                               // 000000844350: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844354: BF870091
	.long 0xd7006a02                                           // 000000844358: D7006A02
	v_cndmask_b32_e32 v1, v11, v0, vcc_lo                      // 00000084435C: 0202010B
	v_add_co_ci_u32_e64 v3, null, 0, v20, vcc_lo               // 000000844360: D5207C03 01AA2880
	global_load_d16_b16 v0, v[2:3], off                        // 000000844368: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 000000844370: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 000000844374: 7E001700
	s_or_b32 exec_lo, exec_lo, s5                              // 000000844378: 8C7E057E
	v_or_b32_e32 v2, 16, v23                                   // 00000084437C: 38042E90
	s_mov_b32 s4, exec_lo                                      // 000000844380: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000844384: BF870001
	.long 0xd4c4007e                                           // 000000844388: D4C4007E
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 00000084438C: 02020406
	s_cbranch_execz 10                                         // 000000844390: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1bc>
	v_lshlrev_b32_e32 v1, 1, v2                                // 000000844394: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844398: BF870091
	.long 0xd7006a01                                           // 00000084439C: D7006A01
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008443A0: 0202030B
	v_add_co_ci_u32_e64 v2, null, 0, v20, vcc_lo               // 0000008443A4: D5207C02 01AA2880
	global_load_d16_b16 v1, v[1:2], off                        // 0000008443AC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008443B4: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000008443B8: 7E021701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008443BC: 8C7E047E
	v_or_b32_e32 v4, 32, v23                                   // 0000008443C0: 38082EA0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000008443C4: CA100080 03020080
	s_mov_b32 s4, exec_lo                                      // 0000008443CC: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008443D0: BF870002
	.long 0xd4c4007e                                           // 0000008443D4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008443D8: 02020806
	s_cbranch_execz 10                                         // 0000008443DC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x208>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000008443E0: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008443E4: BF870091
	.long 0xd7006a04                                           // 0000008443E8: D7006A04
	v_cndmask_b32_e32 v1, v11, v2, vcc_lo                      // 0000008443EC: 0202050B
	v_add_co_ci_u32_e64 v5, null, 0, v20, vcc_lo               // 0000008443F0: D5207C05 01AA2880
	global_load_d16_b16 v2, v[4:5], off                        // 0000008443F8: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 000000844400: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000844404: 7E041702
	s_or_b32 exec_lo, exec_lo, s4                              // 000000844408: 8C7E047E
	v_or_b32_e32 v4, 48, v23                                   // 00000084440C: 38082EB0
	s_mov_b32 s4, exec_lo                                      // 000000844410: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000844414: BF870001
	.long 0xd4c4007e                                           // 000000844418: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000084441C: 02020806
	s_cbranch_execz 10                                         // 000000844420: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x24c>
	v_lshlrev_b32_e32 v3, 1, v4                                // 000000844424: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844428: BF870091
	.long 0xd7006a03                                           // 00000084442C: D7006A03
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 000000844430: 0202070B
	v_add_co_ci_u32_e64 v4, null, 0, v20, vcc_lo               // 000000844434: D5207C04 01AA2880
	global_load_d16_b16 v3, v[3:4], off                        // 00000084443C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000844444: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000844448: 7E061703
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084444C: 8C7E047E
	v_or_b32_e32 v6, 64, v23                                   // 000000844450: 380C2EC0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 000000844454: CA100080 05040080
	s_mov_b32 s4, exec_lo                                      // 00000084445C: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000844460: BF870002
	.long 0xd4c4007e                                           // 000000844464: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000844468: 02020C06
	s_cbranch_execz 10                                         // 00000084446C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x298>
	v_lshlrev_b32_e32 v4, 1, v6                                // 000000844470: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844474: BF870091
	.long 0xd7006a06                                           // 000000844478: D7006A06
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 00000084447C: 0202090B
	v_add_co_ci_u32_e64 v7, null, 0, v20, vcc_lo               // 000000844480: D5207C07 01AA2880
	global_load_d16_b16 v4, v[6:7], off                        // 000000844488: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 000000844490: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000844494: 7E081704
	s_or_b32 exec_lo, exec_lo, s4                              // 000000844498: 8C7E047E
	v_or_b32_e32 v6, 0x50, v23                                 // 00000084449C: 380C2EFF 00000050
	s_mov_b32 s4, exec_lo                                      // 0000008444A4: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008444A8: BF870001
	.long 0xd4c4007e                                           // 0000008444AC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008444B0: 02020C06
	s_cbranch_execz 10                                         // 0000008444B4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2e0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000008444B8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008444BC: BF870091
	.long 0xd7006a05                                           // 0000008444C0: D7006A05
	v_cndmask_b32_e32 v1, v11, v5, vcc_lo                      // 0000008444C4: 02020B0B
	v_add_co_ci_u32_e64 v6, null, 0, v20, vcc_lo               // 0000008444C8: D5207C06 01AA2880
	global_load_d16_b16 v5, v[5:6], off                        // 0000008444D0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000008444D8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000008444DC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008444E0: 8C7E047E
	v_or_b32_e32 v13, 0x60, v23                                // 0000008444E4: 381A2EFF 00000060
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000008444EC: CA100080 07060080
	s_mov_b32 s4, exec_lo                                      // 0000008444F4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008444F8: BF870002
	.long 0xd4c4007e                                           // 0000008444FC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v13, vcc_lo                      // 000000844500: 02021A06
	s_cbranch_execz 10                                         // 000000844504: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x330>
	v_lshlrev_b32_e32 v6, 1, v13                               // 000000844508: 300C1A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084450C: BF870091
	.long 0xd7006a0d                                           // 000000844510: D7006A0D
	v_cndmask_b32_e32 v1, v11, v6, vcc_lo                      // 000000844514: 02020D0B
	v_add_co_ci_u32_e64 v14, null, 0, v20, vcc_lo              // 000000844518: D5207C0E 01AA2880
	global_load_d16_b16 v6, v[13:14], off                      // 000000844520: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 000000844528: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 00000084452C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000844530: 8C7E047E
	v_or_b32_e32 v13, 0x70, v23                                // 000000844534: 381A2EFF 00000070
	s_mov_b32 s4, exec_lo                                      // 00000084453C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000844540: BF870001
	.long 0xd4c4007e                                           // 000000844544: D4C4007E
	v_cndmask_b32_e32 v1, s6, v13, vcc_lo                      // 000000844548: 02021A06
	s_cbranch_execz 10                                         // 00000084454C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_lshlrev_b32_e32 v7, 1, v13                               // 000000844550: 300E1A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844554: BF870091
	.long 0xd7006a0d                                           // 000000844558: D7006A0D
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                      // 00000084455C: 02020F0B
	v_add_co_ci_u32_e64 v14, null, 0, v20, vcc_lo              // 000000844560: D5207C0E 01AA2880
	global_load_d16_b16 v7, v[13:14], off                      // 000000844568: DC820000 077C000D
	s_waitcnt vmcnt(0)                                         // 000000844570: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000844574: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s4                              // 000000844578: 8C7E047E
	s_branch 9                                                 // 00000084457C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3a4>
	v_mov_b32_e32 v0, 0                                        // 000000844580: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000844584: BF870001
	v_mov_b32_e32 v1, v0                                       // 000000844588: 7E020300
	v_mov_b32_e32 v2, v0                                       // 00000084458C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 000000844590: 7E060300
	v_mov_b32_e32 v4, v0                                       // 000000844594: 7E080300
	v_mov_b32_e32 v5, v0                                       // 000000844598: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 00000084459C: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000008445A0: 7E0E0300
	s_add_u32 s4, s8, s18                                      // 0000008445A4: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000008445A8: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000008445AC: 85129F0F
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v13, 0             // 0000008445B0: CA100080 1A0C0080
	s_add_u32 s18, s14, s18                                    // 0000008445B8: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000008445BC: 8213800F
	v_cndmask_b32_e64 v24, 0, 1, s7                            // 0000008445C0: D5010018 001D0280
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008445C8: 86928112
	v_mov_b32_e32 v33, 0                                       // 0000008445CC: 7E420280
	v_mad_u64_u32 v[18:19], null, v10, s18, s[4:5]             // 0000008445D0: D6FE7C12 0010250A
	.long 0xd72c000a                                           // 0000008445D8: D72C000A
	v_cndmask_b32_e32 v0, v10, v19, vcc_lo                     // 0000008445DC: 0200270A
	.long 0xd72c000f                                           // 0000008445E0: D72C000F
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 0000008445E4: 0200250C
	.long 0xd4440004                                           // 0000008445E8: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008445EC: 02022E06
	v_mov_b32_e32 v12, 0                                       // 0000008445F0: 7E180280
	v_mov_b32_e32 v14, 0                                       // 0000008445F4: 7E1C0280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008445F8: BF870004
	v_add3_u32 v25, v15, v19, v10                              // 0000008445FC: D6550019 042A270F
	v_mov_b32_e32 v15, 0                                       // 000000844604: 7E1E0280
	s_and_saveexec_b32 s5, s4                                  // 000000844608: BE852004
	s_cbranch_execz 21                                         // 00000084460C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_dual_mov_b32 v33, 0 :: v_dual_lshlrev_b32 v10, 4, v23    // 000000844610: CA220080 210A2E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844618: BF870091
	.long 0xd7006a0c                                           // 00000084461C: D7006A0C
	v_cndmask_b32_e32 v1, v18, v10, vcc_lo                     // 000000844620: 02021512
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 000000844624: D5207C0D 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000084462C: 916A077E
	global_load_b128 v[12:15], v[12:13], off                   // 000000844630: DC5E0000 0C7C000C
	s_cbranch_vccnz 10                                         // 000000844638: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_lshlrev_b32_e32 v10, 1, v23                              // 00000084463C: 30142E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844640: BF870091
	.long 0xd7006a0a                                           // 000000844644: D7006A0A
	v_cndmask_b32_e32 v1, v11, v10, vcc_lo                     // 000000844648: 0202150B
	v_add_co_ci_u32_e64 v11, null, 0, v20, vcc_lo              // 00000084464C: D5207C0B 01AA2880
	global_load_d16_b16 v10, v[10:11], off                     // 000000844654: DC820000 0A7C000A
	s_waitcnt vmcnt(0)                                         // 00000084465C: BF8903F7
	v_cvt_f32_f16_e32 v33, v10                                 // 000000844660: 7E42170A
	s_or_b32 exec_lo, exec_lo, s5                              // 000000844664: 8C7E057E
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 000000844668: CA100080 1B1C0080
	v_mov_b32_e32 v29, 0                                       // 000000844670: 7E3A0280
	s_and_saveexec_b32 s5, s4                                  // 000000844674: BE852004
	s_cbranch_execz 447                                        // 000000844678: BFA501BF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xb78>
	v_dual_mov_b32 v31, v23 :: v_dual_lshlrev_b32 v10, 1, v23  // 00000084467C: CA220117 1F0A2E81
	.long 0xd7006a08                                           // 000000844684: D7006A08
	v_cndmask_b32_e32 v1, s20, v8, vcc_lo                      // 000000844688: 02021014
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084468C: BF8701A1
	v_add_co_ci_u32_e64 v9, null, s21, v9, vcc_lo              // 000000844690: D5207C09 01AA1215
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 000000844698: CA220080 14122E85
	.long 0xd7006a08                                           // 0000008446A0: D7006A08
	v_cndmask_b32_e32 v1, v8, v10, vcc_lo                      // 0000008446A4: 02021508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008446A8: BF8701A1
	v_add_co_ci_u32_e64 v9, null, 0, v9, vcc_lo                // 0000008446AC: D5207C09 01AA1280
	v_lshl_or_b32 v30, v23, 4, 0x100                           // 0000008446B4: D656001E 03FD0917 00000100
	.long 0xd7006a08                                           // 0000008446C0: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 0000008446C4: 02021008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008446C8: BF8701A1
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 0000008446CC: D5207C09 01AA1209
	v_dual_mov_b32 v29, v20 :: v_dual_mov_b32 v32, v33         // 0000008446D4: CA100114 1D200121
	.long 0xd7006a15                                           // 0000008446DC: D7006A15
	v_cndmask_b32_e32 v0, v8, v160, vcc_lo                     // 0000008446E0: 02014108
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008446E4: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v9, vcc_lo               // 0000008446E8: D5207C16 01AA1280
	v_mov_b32_e32 v28, v20                                     // 0000008446F0: 7E380314
	v_mov_b32_e32 v27, v20                                     // 0000008446F4: 7E360314
	v_mov_b32_e32 v26, v20                                     // 0000008446F8: 7E340314
	s_mul_i32 s4, s15, 6                                       // 0000008446FC: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 000000844700: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 000000844704: 8492820E
	s_add_i32 s7, s7, s4                                       // 000000844708: 81070407
	s_mul_i32 s21, s14, 6                                      // 00000084470C: 9615860E
	s_mov_b32 s20, 0                                           // 000000844710: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 000000844714: 8488810E
	s_branch 378                                               // 000000844718: BFA0017A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xb04>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000084471C: 8C7E0E7E
	v_cndmask_b32_e64 v33, v33, v0, s3                         // 000000844720: D5010021 000E0121
	v_cndmask_b32_e64 v34, v0, v1, s3                          // 000000844728: D5010022 000E0300
	v_dual_mov_b32 v41, v7 :: v_dual_and_b32 v0, 0xff, v12     // 000000844730: CA240107 290018FF 000000FF
	v_cndmask_b32_e64 v40, v6, v7, s3                          // 00000084473C: D5010028 000E0F06
	v_cndmask_b32_e64 v39, v5, v6, s3                          // 000000844744: D5010027 000E0D05
	v_cndmask_b32_e64 v38, v4, v5, s3                          // 00000084474C: D5010026 000E0B04
	v_cndmask_b32_e64 v37, v3, v4, s3                          // 000000844754: D5010025 000E0903
	v_lshlrev_b32_e32 v0, 2, v0                                // 00000084475C: 30000082
	v_cndmask_b32_e64 v36, v2, v3, s3                          // 000000844760: D5010024 000E0702
	v_cndmask_b32_e64 v35, v1, v2, s3                          // 000000844768: D5010023 000E0501
	s_and_b32 s4, exec_lo, s4                                  // 000000844770: 8B04047E
	v_add_nc_u32_e32 v30, 0x100, v30                           // 000000844774: 4A3C3CFF 00000100
	ds_load_b32 v48, v0                                        // 00000084477C: D8D80000 30000000
	v_lshrrev_b32_e32 v0, 6, v12                               // 000000844784: 32001886
	s_or_b32 s20, s4, s20                                      // 000000844788: 8C141404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084478C: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000844790: 360000FF 000003FC
	ds_load_b32 v49, v0                                        // 000000844798: D8D80000 31000000
	v_lshrrev_b32_e32 v0, 14, v12                              // 0000008447A0: 3200188E
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008447A4: 360000FF 000003FC
	ds_load_b32 v50, v0                                        // 0000008447AC: D8D80000 32000000
	v_lshrrev_b32_e32 v0, 22, v12                              // 0000008447B4: 32001896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008447B8: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008447BC: 360000FF 000003FC
	ds_load_b32 v51, v0                                        // 0000008447C4: D8D80000 33000000
	v_and_b32_e32 v0, 0xff, v13                                // 0000008447CC: 36001AFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000008447D4: 30000082
	ds_load_b32 v52, v0                                        // 0000008447D8: D8D80000 34000000
	v_lshrrev_b32_e32 v0, 6, v13                               // 0000008447E0: 32001A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008447E4: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008447E8: 360000FF 000003FC
	ds_load_b32 v53, v0                                        // 0000008447F0: D8D80000 35000000
	v_lshrrev_b32_e32 v0, 14, v13                              // 0000008447F8: 32001A8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008447FC: 360000FF 000003FC
	ds_load_b32 v54, v0                                        // 000000844804: D8D80000 36000000
	v_lshrrev_b32_e32 v0, 22, v13                              // 00000084480C: 32001A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000844810: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000844814: 360000FF 000003FC
	ds_load_b32 v55, v0                                        // 00000084481C: D8D80000 37000000
	v_and_b32_e32 v0, 0xff, v14                                // 000000844824: 36001CFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 00000084482C: 30000082
	ds_load_b32 v56, v0                                        // 000000844830: D8D80000 38000000
	v_lshrrev_b32_e32 v0, 6, v14                               // 000000844838: 32001C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084483C: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000844840: 360000FF 000003FC
	ds_load_b32 v57, v0                                        // 000000844848: D8D80000 39000000
	v_lshrrev_b32_e32 v0, 14, v14                              // 000000844850: 32001C8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000844854: 360000FF 000003FC
	ds_load_b32 v58, v0                                        // 00000084485C: D8D80000 3A000000
	v_lshrrev_b32_e32 v0, 22, v14                              // 000000844864: 32001C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000844868: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 00000084486C: 360000FF 000003FC
	ds_load_b32 v59, v0                                        // 000000844874: D8D80000 3B000000
	v_and_b32_e32 v0, 0xff, v15                                // 00000084487C: 36001EFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000844884: 30000082
	ds_load_b32 v60, v0                                        // 000000844888: D8D80000 3C000000
	v_lshrrev_b32_e32 v0, 6, v15                               // 000000844890: 32001E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000844894: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000844898: 360000FF 000003FC
	ds_load_b32 v61, v0                                        // 0000008448A0: D8D80000 3D000000
	v_lshrrev_b32_e32 v0, 14, v15                              // 0000008448A8: 32001E8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008448AC: 360000FF 000003FC
	ds_load_b32 v62, v0                                        // 0000008448B4: D8D80000 3E000000
	v_lshrrev_b32_e32 v0, 22, v15                              // 0000008448BC: 32001E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008448C0: BF870141
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008448C4: 360000FF 000003FC
	ds_load_b32 v63, v0                                        // 0000008448CC: D8D80000 3F000000
	.long 0xd73c0000                                           // 0000008448D4: D73C0000
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000008448D8: 02022681
	v_add_nc_u32_e32 v19, 0x200, v19                           // 0000008448DC: 4A2626FF 00000200
	.long 0xd7006a2e                                           // 0000008448E4: D7006A2E
	v_cndmask_b32_e32 v1, s10, v0, vcc_lo                      // 0000008448E8: 0202000A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008448EC: BF870001
	v_add_co_ci_u32_e64 v47, null, s11, v1, vcc_lo             // 0000008448F0: D5207C2F 01AA020B
	s_clause 0x3                                               // 0000008448F8: BF850003
	global_load_b128 v[0:3], v[46:47], off                     // 0000008448FC: DC5E0000 007C002E
	global_load_b128 v[4:7], v[46:47], off offset:16           // 000000844904: DC5E0010 047C002E
	global_load_b128 v[12:15], v[46:47], off offset:32         // 00000084490C: DC5E0020 0C7C002E
	global_load_b128 v[42:45], v[46:47], off offset:48         // 000000844914: DC5E0030 2A7C002E
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000084491C: BF890CF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 000000844920: CC1A4000 1A026100
	s_waitcnt lgkmcnt(14)                                      // 000000844928: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084492C: BF8700A1
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 000000844930: CC1A4000 1C026301
	s_waitcnt lgkmcnt(13)                                      // 000000844938: BF89FCD7
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 00000084493C: CC1A4000 1C026502
	s_waitcnt lgkmcnt(12)                                      // 000000844944: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000844948: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 00000084494C: CC1A4000 1C026703
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000844954: BF8908B7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 000000844958: CC1A4000 1C026904
	s_waitcnt lgkmcnt(10)                                      // 000000844960: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000844964: BF8700A1
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 000000844968: CC1A4000 1C026B05
	s_waitcnt lgkmcnt(9)                                       // 000000844970: BF89FC97
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 000000844974: CC1A4000 1C026D06
	s_waitcnt lgkmcnt(8)                                       // 00000084497C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000844980: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 000000844984: CC1A4000 1C026F07
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000084498C: BF890477
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 000000844990: CC1A4000 1C02710C
	s_waitcnt lgkmcnt(6)                                       // 000000844998: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084499C: BF8700A1
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 0000008449A0: CC1A4000 1C02730D
	s_waitcnt lgkmcnt(5)                                       // 0000008449A8: BF89FC57
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 0000008449AC: CC1A4000 1C02750E
	s_waitcnt lgkmcnt(4)                                       // 0000008449B4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008449B8: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 0000008449BC: CC1A4000 1C02770F
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008449C4: BF890037
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 0000008449C8: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 0000008449D0: D7006A2A
	v_cndmask_b32_e32 v0, v46, v8, vcc_lo                      // 0000008449D4: 0200112E
	s_waitcnt lgkmcnt(2)                                       // 0000008449D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008449DC: BF870132
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 0000008449E0: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s9, v47, vcc_lo             // 0000008449E8: D5207C2B 01AA5E09
	s_waitcnt lgkmcnt(1)                                       // 0000008449F0: BF89FC17
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 0000008449F4: CC1A4000 1C027D2C
	s_waitcnt lgkmcnt(0)                                       // 0000008449FC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844A00: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 000000844A04: CC1A4000 1C027F2D
	v_fmac_f32_e32 v29, v33, v0                                // 000000844A0C: 563A0121
	s_clause 0x3                                               // 000000844A10: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 000000844A14: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 000000844A1C: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 000000844A24: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 000000844A2C: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 000000844A34: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 000000844A38: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844A40: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 000000844A44: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 000000844A4C: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000844A54: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 000000844A58: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 000000844A60: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 000000844A64: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844A6C: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 000000844A70: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 000000844A78: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000844A80: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 000000844A84: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 000000844A8C: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 000000844A90: CC1A4000 1C02710C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844A98: BF870091
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 000000844A9C: CC1A4000 1C02730D
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 000000844AA4: CC1A4000 1C02750E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000844AAC: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 000000844AB0: CC1A4000 1C02770F
	s_waitcnt vmcnt(0)                                         // 000000844AB8: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 000000844ABC: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 000000844AC4: D7006A2A
	v_cndmask_b32_e32 v0, v46, v18, vcc_lo                     // 000000844AC8: 0200252E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000844ACC: BF870122
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 000000844AD0: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s19, v47, vcc_lo            // 000000844AD8: D5207C2B 01AA5E13
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 000000844AE0: CC1A4000 1C027D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844AE8: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 000000844AEC: CC1A4000 1C027F2D
	v_fmac_f32_e32 v28, v33, v0                                // 000000844AF4: 56380121
	s_clause 0x3                                               // 000000844AF8: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 000000844AFC: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 000000844B04: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 000000844B0C: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 000000844B14: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 000000844B1C: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 000000844B20: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844B28: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 000000844B2C: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 000000844B34: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000844B3C: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 000000844B40: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 000000844B48: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 000000844B4C: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844B54: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 000000844B58: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 000000844B60: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000844B68: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 000000844B6C: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 000000844B74: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 000000844B78: CC1A4000 1C02710C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844B80: BF870091
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 000000844B84: CC1A4000 1C02730D
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 000000844B8C: CC1A4000 1C02750E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000844B94: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 000000844B98: CC1A4000 1C02770F
	s_waitcnt vmcnt(0)                                         // 000000844BA0: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 000000844BA4: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 000000844BAC: D7006A2A
	v_cndmask_b32_e32 v0, v46, v21, vcc_lo                     // 000000844BB0: 02002B2E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000844BB4: BF8701B2
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 000000844BB8: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s7, v47, vcc_lo             // 000000844BC0: D5207C2B 01AA5E07
	.long 0xd7006a15                                           // 000000844BC8: D7006A15
	v_cndmask_b32_e32 v0, v21, v160, vcc_lo                    // 000000844BCC: 02014115
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 000000844BD0: CC1A4000 1C027D2C
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 000000844BD8: D5207C16 01AA2C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844BE0: BF870092
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 000000844BE4: CC1A4000 1C027F2D
	v_fmac_f32_e32 v27, v33, v0                                // 000000844BEC: 56360121
	s_clause 0x3                                               // 000000844BF0: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 000000844BF4: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 000000844BFC: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 000000844C04: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 000000844C0C: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 000000844C14: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 000000844C18: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844C20: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 000000844C24: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 000000844C2C: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000844C34: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 000000844C38: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 000000844C40: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 000000844C44: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844C4C: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 000000844C50: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 000000844C58: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000844C60: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 000000844C64: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 000000844C6C: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 000000844C70: CC1A4000 1C02710C
	v_mov_b32_e32 v12, v8                                      // 000000844C78: 7E180308
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000844C7C: BF870122
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 000000844C80: CC1A4000 1C02730D
	v_mov_b32_e32 v13, v9                                      // 000000844C88: 7E1A0309
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 000000844C8C: CC1A4000 1C02750E
	v_mov_b32_e32 v14, v10                                     // 000000844C94: 7E1C030A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000844C98: BF870132
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 000000844C9C: CC1A4000 1C02770F
	v_mov_b32_e32 v15, v11                                     // 000000844CA4: 7E1E030B
	s_waitcnt vmcnt(0)                                         // 000000844CA8: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 000000844CAC: CC1A4000 1C02792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844CB4: BF870091
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 000000844CB8: CC1A4000 1C027B2B
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 000000844CC0: CC1A4000 1C027D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000844CC8: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 000000844CCC: CC1A4000 1C027F2D
	v_fmac_f32_e32 v26, v33, v0                                // 000000844CD4: 56340121
	v_dual_mov_b32 v0, v34 :: v_dual_mov_b32 v33, v32          // 000000844CD8: CA100122 00200120
	v_dual_mov_b32 v1, v35 :: v_dual_mov_b32 v2, v36           // 000000844CE0: CA100123 01020124
	v_dual_mov_b32 v3, v37 :: v_dual_mov_b32 v4, v38           // 000000844CE8: CA100125 03040126
	v_dual_mov_b32 v5, v39 :: v_dual_mov_b32 v6, v40           // 000000844CF0: CA100127 05060128
	v_mov_b32_e32 v7, v41                                      // 000000844CF8: 7E0E0329
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 000000844CFC: 917E147E
	s_cbranch_execz 28                                         // 000000844D00: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xb74>
	s_waitcnt vmcnt(0)                                         // 000000844D04: BF8903F7
	v_dual_mov_b32 v8, v12 :: v_dual_add_nc_u32 v31, 16, v31   // 000000844D08: CA20010C 081E3E90
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v10, v14          // 000000844D10: CA10010D 090A010E
	v_mov_b32_e32 v11, v15                                     // 000000844D18: 7E16030F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000844D1C: BF870003
	.long 0xd4430004                                           // 000000844D20: D4430004
	v_cndmask_b32_e32 v1, s6, v31, vcc_lo                      // 000000844D24: 02023E06
	s_mov_b32 s14, exec_lo                                     // 000000844D28: BE8E007E
	.long 0xd4c4007e                                           // 000000844D2C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v31, vcc_lo                      // 000000844D30: 02023E06
	s_cbranch_execz 65145                                      // 000000844D34: BFA5FE79 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	.long 0xd7006a08                                           // 000000844D38: D7006A08
	v_cndmask_b32_e32 v1, v18, v30, vcc_lo                     // 000000844D3C: 02023D12
	s_delay_alu instid0(VALU_DEP_1)                            // 000000844D40: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 000000844D44: D5207C09 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 000000844D4C: 7C9A3081
	v_mov_b32_e32 v32, v33                                     // 000000844D50: 7E400321
	global_load_b128 v[8:11], v[8:9], off                      // 000000844D54: DC5E0000 087C0008
	s_cbranch_vccnz 65135                                      // 000000844D5C: BFA4FE6F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	global_load_d16_b16 v32, v[21:22], off                     // 000000844D60: DC820000 207C0015
	s_waitcnt vmcnt(0)                                         // 000000844D68: BF8903F7
	v_cvt_f32_f16_e32 v32, v32                                 // 000000844D6C: 7E401720
	s_branch 65130                                             // 000000844D70: BFA0FE6A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	s_or_b32 exec_lo, exec_lo, s20                             // 000000844D74: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000844D78: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 000000844D7C: 8C7E057E
	.long 0xd71f0000                                           // 000000844D80: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000844D84: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000844D88: 3A020088
	v_xor_b32_e32 v5, 4, v0                                    // 000000844D8C: 3A0A0084
	v_xor_b32_e32 v9, 2, v0                                    // 000000844D90: 3A120082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000844D94: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000844D98: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000844D9C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000844DA0: 7C980AA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000844DA4: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000844DA8: 30020282
	ds_bpermute_b32 v4, v1, v27                                // 000000844DAC: DACC0000 04001B01
	s_waitcnt lgkmcnt(0)                                       // 000000844DB4: BF89FC07
	v_add_f32_e32 v4, v27, v4                                  // 000000844DB8: 0608091B
	ds_bpermute_b32 v2, v1, v29                                // 000000844DBC: DACC0000 02001D01
	ds_bpermute_b32 v3, v1, v28                                // 000000844DC4: DACC0000 03001C01
	ds_bpermute_b32 v1, v1, v26                                // 000000844DCC: DACC0000 01001A01
	s_waitcnt lgkmcnt(2)                                       // 000000844DD4: BF89FC27
	v_dual_add_f32 v2, v29, v2 :: v_dual_cndmask_b32 v5, v0, v5// 000000844DD8: C912051D 02040B00
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 000000844DE0: 7C9812A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000844DE4: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000844DE8: 300A0A82
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 000000844DEC: 02121300
	ds_bpermute_b32 v8, v5, v4                                 // 000000844DF0: DACC0000 08000405
	s_waitcnt lgkmcnt(0)                                       // 000000844DF8: BF89FC07
	v_dual_add_f32 v4, v4, v8 :: v_dual_lshlrev_b32 v9, 2, v9  // 000000844DFC: C9221104 04081282
	ds_bpermute_b32 v6, v5, v2                                 // 000000844E04: DACC0000 06000205
	s_waitcnt lgkmcnt(0)                                       // 000000844E0C: BF89FC07
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v28, v3    // 000000844E10: C9080D02 0202071C
	ds_bpermute_b32 v7, v5, v3                                 // 000000844E18: DACC0000 07000305
	s_waitcnt lgkmcnt(0)                                       // 000000844E20: BF89FC07
	v_add_f32_e32 v3, v3, v7                                   // 000000844E24: 06060F03
	ds_bpermute_b32 v7, v9, v4                                 // 000000844E28: DACC0000 07000409
	v_add_f32_e32 v1, v26, v1                                  // 000000844E30: 0602031A
	ds_bpermute_b32 v6, v9, v3                                 // 000000844E34: DACC0000 06000309
	ds_bpermute_b32 v5, v5, v1                                 // 000000844E3C: DACC0000 05000105
	s_waitcnt lgkmcnt(0)                                       // 000000844E44: BF89FC07
	v_add_f32_e32 v5, v1, v5                                   // 000000844E48: 060A0B01
	ds_bpermute_b32 v1, v9, v2                                 // 000000844E4C: DACC0000 01000209
	ds_bpermute_b32 v8, v9, v5                                 // 000000844E54: DACC0000 08000509
	v_xor_b32_e32 v9, 1, v0                                    // 000000844E5C: 3A120081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000844E60: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 000000844E64: 7C9812A0
	v_cndmask_b32_e32 v0, v0, v9, vcc_lo                       // 000000844E68: 02001300
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 000000844E6C: 7C942E80
	s_waitcnt lgkmcnt(1)                                       // 000000844E70: BF89FC17
	v_dual_add_f32 v0, v2, v1 :: v_dual_lshlrev_b32 v9, 2, v0  // 000000844E74: C9220302 00080082
	v_dual_add_f32 v1, v3, v6 :: v_dual_add_f32 v2, v4, v7     // 000000844E7C: C9080D03 01020F04
	s_waitcnt lgkmcnt(0)                                       // 000000844E84: BF89FC07
	v_add_f32_e32 v3, v5, v8                                   // 000000844E88: 06061105
	s_and_b32 s2, vcc_lo, s2                                   // 000000844E8C: 8B02026A
	ds_bpermute_b32 v4, v9, v0                                 // 000000844E90: DACC0000 04000009
	ds_bpermute_b32 v5, v9, v1                                 // 000000844E98: DACC0000 05000109
	ds_bpermute_b32 v6, v9, v2                                 // 000000844EA0: DACC0000 06000209
	ds_bpermute_b32 v7, v9, v3                                 // 000000844EA8: DACC0000 07000309
	s_and_saveexec_b32 s3, s2                                  // 000000844EB0: BE832002
	s_cbranch_execz 183                                        // 000000844EB4: BFA500B7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xf94>
	s_load_b32 s0, s[0:1], 0x48                                // 000000844EB8: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 000000844EC0: BF89FC07
	v_dual_add_f32 v0, v0, v4 :: v_dual_add_f32 v1, v1, v5     // 000000844EC4: C9080900 00000B01
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v3, v7     // 000000844ECC: C9080D02 02020F03
	s_lshl_b64 s[4:5], s[16:17], 2                             // 000000844ED4: 84848210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000844ED8: BF870192
	v_bfe_u32 v4, v0, 16, 1                                    // 000000844EDC: D6100004 02052100
	v_bfe_u32 v5, v1, 16, 1                                    // 000000844EE4: D6100005 02052101
	s_delay_alu instid0(VALU_DEP_3)                            // 000000844EEC: BF870003
	v_bfe_u32 v6, v2, 16, 1                                    // 000000844EF0: D6100006 02052102
	v_bfe_u32 v7, v3, 16, 1                                    // 000000844EF8: D6100007 02052103
	s_lshl_b64 s[6:7], s[16:17], 3                             // 000000844F00: 84868310
	v_add3_u32 v0, v0, v4, 0x7fff                              // 000000844F04: D6550000 03FE0900 00007FFF
	v_add3_u32 v1, v1, v5, 0x7fff                              // 000000844F10: D6550001 03FE0B01 00007FFF
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000844F1C: D6550002 03FE0D02 00007FFF
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000844F28: D6550003 03FE0F03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000844F34: BF8701A3
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000844F38: 360202FF FFFF0000
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000844F40: 360000FF FFFF0000
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000844F48: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000844F50: BF870113
	v_dual_mul_f32 v1, s0, v1 :: v_dual_and_b32 v2, 0xffff0000, v2// 000000844F54: C8E40200 010204FF FFFF0000
	v_dual_mul_f32 v0, s0, v0 :: v_dual_mul_f32 v3, s0, v3     // 000000844F60: C8C60000 00020600
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000844F68: BF870112
	v_dual_mul_f32 v2, s0, v2 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v1// 000000844F6C: C8C60400 020002FF BFB8AA3B
	v_dual_mul_f32 v0, 0xbfb8aa3b, v0 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 000000844F78: C8C600FF 000206FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000844F84: BF870192
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 000000844F88: 100404FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 000000844F90: 7E024B01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000844F94: BF870112
	v_exp_f32_e32 v0, v0                                       // 000000844F98: 7E004B00
	v_exp_f32_e32 v3, v3                                       // 000000844F9C: 7E064B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 000000844FA0: BF870391
	v_exp_f32_e32 v2, v2                                       // 000000844FA4: 7E044B02
	v_dual_add_f32 v8, 1.0, v1 :: v_dual_add_f32 v7, 1.0, v0   // 000000844FA8: C90802F2 080600F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000844FB0: BF8701A5
	v_dual_add_f32 v9, 1.0, v3 :: v_dual_add_f32 v2, 1.0, v2   // 000000844FB4: C90806F2 090204F2
	.long 0xd73c0000                                           // 000000844FBC: D73C0000
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000844FC0: 02022082
	v_div_scale_f32 v11, null, v8, v8, 1.0                     // 000000844FC4: D6FC7C0B 03CA1108
	s_delay_alu instid0(VALU_DEP_4)                            // 000000844FCC: BF870004
	v_div_scale_f32 v10, null, v7, v7, 1.0                     // 000000844FD0: D6FC7C0A 03CA0F07
	s_waitcnt vmcnt(0)                                         // 000000844FD8: BF8903F7
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 000000844FDC: D6FC7C0D 03CA1309
	v_div_scale_f32 v12, null, v2, v2, 1.0                     // 000000844FE4: D6FC7C0C 03CA0502
	v_div_scale_f32 v16, vcc_lo, 1.0, v7, 1.0                  // 000000844FEC: D6FC6A10 03CA0EF2
	v_rcp_f32_e32 v15, v11                                     // 000000844FF4: 7E1E550B
	v_rcp_f32_e32 v14, v10                                     // 000000844FF8: 7E1C550A
	v_rcp_f32_e32 v19, v13                                     // 000000844FFC: 7E26550D
	v_rcp_f32_e32 v18, v12                                     // 000000845000: 7E24550C
	v_div_scale_f32 v17, s0, 1.0, v8, 1.0                      // 000000845004: D6FC0011 03CA10F2
	v_div_scale_f32 v20, s1, 1.0, v2, 1.0                      // 00000084500C: D6FC0114 03CA04F2
	v_div_scale_f32 v21, s2, 1.0, v9, 1.0                      // 000000845014: D6FC0215 03CA12F2
	v_fma_f32 v4, -v11, v15, 1.0                               // 00000084501C: D6130004 23CA1F0B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000845024: BF870317
	v_fma_f32 v3, -v10, v14, 1.0                               // 000000845028: D6130003 23CA1D0A
	v_fma_f32 v6, -v13, v19, 1.0                               // 000000845030: D6130006 23CA270D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000845038: BF870195
	v_fma_f32 v5, -v12, v18, 1.0                               // 00000084503C: D6130005 23CA250C
	v_dual_fmac_f32 v15, v4, v15 :: v_dual_fmac_f32 v14, v3, v14// 000000845044: C8001F04 0F0E1D03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084504C: BF8701A2
	v_dual_fmac_f32 v19, v6, v19 :: v_dual_fmac_f32 v18, v5, v18// 000000845050: C8002706 13122505
	.long 0xd7000303                                           // 000000845058: D7000303
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 00000084505C: 0202000C
	v_dual_mul_f32 v22, v16, v14 :: v_dual_mul_f32 v23, v17, v15// 000000845060: C8C61D10 16161F11
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000845068: BF8701A3
	v_dual_mul_f32 v24, v20, v18 :: v_dual_mul_f32 v25, v21, v19// 00000084506C: C8C62514 18182715
	v_add_co_ci_u32_e64 v4, null, s13, v1, s3                  // 000000845074: D5207C04 000E020D
	v_fma_f32 v0, -v10, v22, v16                               // 00000084507C: D6130000 24422D0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000845084: BF870214
	v_fma_f32 v1, -v11, v23, v17                               // 000000845088: D6130001 24462F0B
	v_fma_f32 v26, -v12, v24, v20                              // 000000845090: D613001A 2452310C
	v_fma_f32 v27, -v13, v25, v21                              // 000000845098: D613001B 2456330D
	.long 0xd7000305                                           // 0000008450A0: D7000305
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 0000008450A4: 02000903
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008450A8: BF870194
	v_dual_fmac_f32 v22, v0, v14 :: v_dual_fmac_f32 v23, v1, v15// 0000008450AC: C8001D00 16161F01
	v_dual_fmac_f32 v24, v26, v18 :: v_dual_fmac_f32 v25, v27, v19// 0000008450B4: C800251A 1818271B
	v_mad_u64_u32 v[0:1], null, s16, 12, v[3:4]                // 0000008450BC: D6FE7C00 040D1810
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008450C4: BF870213
	v_fma_f32 v10, -v10, v22, v16                              // 0000008450C8: D613000A 24422D0A
	v_fma_f32 v11, -v11, v23, v17                              // 0000008450D0: D613000B 24462F0B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008450D8: BF870004
	v_fma_f32 v12, -v12, v24, v20                              // 0000008450DC: D613000C 2452310C
	v_fma_f32 v13, -v13, v25, v21                              // 0000008450E4: D613000D 2456330D
	v_add_co_ci_u32_e64 v6, null, s5, v4, s3                   // 0000008450EC: D5207C06 000E0805
	v_div_fmas_f32 v10, v10, v14, v22                          // 0000008450F4: D637000A 045A1D0A
	s_mov_b32 vcc_lo, s0                                       // 0000008450FC: BEEA0000
	v_div_fmas_f32 v11, v11, v15, v23                          // 000000845100: D637000B 045E1F0B
	s_mov_b32 vcc_lo, s1                                       // 000000845108: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000084510C: BF8701D2
	v_div_fixup_f32 v7, v10, v7, 1.0                           // 000000845110: D6270007 03CA0F0A
	v_div_fmas_f32 v12, v12, v18, v24                          // 000000845118: D637000C 0462250C
	s_mov_b32 vcc_lo, s2                                       // 000000845120: BEEA0002
	v_div_fixup_f32 v8, v11, v8, 1.0                           // 000000845124: D6270008 03CA110B
	v_div_fmas_f32 v10, v13, v19, v25                          // 00000084512C: D637000A 0466270D
	v_div_fixup_f32 v11, v12, v2, 1.0                          // 000000845134: D627000B 03CA050C
	v_mad_u64_u32 v[1:2], null, s17, 12, v[1:2]                // 00000084513C: D6FE7C01 04051811
	s_delay_alu instid0(VALU_DEP_3)                            // 000000845144: BF870003
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 000000845148: D6270009 03CA130A
	v_add_f32_e32 v2, v7, v7                                   // 000000845150: 06040F07
	.long 0xd7006a07                                           // 000000845154: D7006A07
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 000000845158: 02000D03
	v_dual_add_f32 v10, v8, v8 :: v_dual_add_f32 v11, v11, v11 // 00000084515C: C9081108 0A0A170B
	v_add_co_ci_u32_e64 v8, null, s7, v4, vcc_lo               // 000000845164: D5207C08 01AA0807
	v_add_f32_e32 v9, v9, v9                                   // 00000084516C: 06121309
	s_clause 0x3                                               // 000000845170: BF850003
	global_store_b32 v[3:4], v2, off                           // 000000845174: DC6A0000 007C0203
	global_store_b32 v[5:6], v10, off                          // 00000084517C: DC6A0000 007C0A05
	global_store_b32 v[7:8], v11, off                          // 000000845184: DC6A0000 007C0B07
	global_store_b32 v[0:1], v9, off                           // 00000084518C: DC6A0000 007C0900
	s_endpgm                                                   // 000000845194: BFB00000
		...

