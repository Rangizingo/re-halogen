0000000000970100 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi():
	s_clause 0x1                                               // 000000970100: BF850001
	s_load_b32 s3, s[0:1], 0x88                                // 000000970104: F40000C0 F8000088
	s_load_b512 s[12:27], s[0:1], null                         // 00000097010C: F4100300 F8000000
	v_and_b32_e32 v72, 31, v0                                  // 000000970114: 3690009F
	v_lshrrev_b32_e32 v71, 5, v0                               // 000000970118: 328E0085
	s_mov_b32 s4, -1                                           // 00000097011C: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000970120: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000970124: BF040302
	s_cbranch_scc1 2424                                        // 000000970128: BFA20978 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x260c>
	s_load_b64 s[8:9], s[0:1], 0x7c                            // 00000097012C: F4040200 F800007C
	s_sub_i32 s3, s2, s3                                       // 000000970134: 81830302
	s_clause 0x1                                               // 000000970138: BF850001
	s_load_b256 s[44:51], s[0:1], 0x60                         // 00000097013C: F40C0B00 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 000000970144: F40C0900 F8000040
	s_mov_b32 s34, 0                                           // 00000097014C: BEA20080
	s_mov_b32 s33, exec_lo                                     // 000000970150: BEA1007E
	s_waitcnt lgkmcnt(0)                                       // 000000970154: BF89FC07
	s_abs_i32 s4, s9                                           // 000000970158: BE841509
	s_ashr_i32 s7, s9, 31                                      // 00000097015C: 86079F09
	s_cvt_f32_u32 s5, s4                                       // 000000970160: BE856504
	s_sub_i32 s6, 0, s4                                        // 000000970164: 81860480
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000970168: BF87029A
	v_rcp_iflag_f32_e32 v1, s5                                 // 00000097016C: 7E025605
	v_readfirstlane_b32 s5, v1                                 // 000000970170: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 000000970174: A205FF05 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000097017C: BF87059B
	s_cvt_u32_f32 s5, s5                                       // 000000970180: BE856705
	s_mul_i32 s6, s6, s5                                       // 000000970184: 96060506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000970188: BF870499
	s_mul_hi_u32 s6, s5, s6                                    // 00000097018C: 96860605
	s_add_i32 s5, s5, s6                                       // 000000970190: 81050605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000970194: BF870499
	s_mul_hi_u32 s5, s3, s5                                    // 000000970198: 96850503
	s_mul_i32 s6, s5, s4                                       // 00000097019C: 96060405
	s_add_i32 s10, s5, 1                                       // 0000009701A0: 810A8105
	s_sub_i32 s6, s3, s6                                       // 0000009701A4: 81860603
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009701A8: BF870009
	s_sub_i32 s11, s6, s4                                      // 0000009701AC: 818B0406
	s_cmp_ge_u32 s6, s4                                        // 0000009701B0: BF090406
	s_cselect_b32 s5, s10, s5                                  // 0000009701B4: 9805050A
	s_cselect_b32 s6, s11, s6                                  // 0000009701B8: 9806060B
	s_add_i32 s10, s5, 1                                       // 0000009701BC: 810A8105
	s_cmp_ge_u32 s6, s4                                        // 0000009701C0: BF090406
	s_cselect_b32 s4, s10, s5                                  // 0000009701C4: 9804050A
	s_ashr_i32 s11, s50, 31                                    // 0000009701C8: 860B9F32
	s_xor_b32 s4, s4, s7                                       // 0000009701CC: 8D040704
	s_lshr_b32 s1, s11, 25                                     // 0000009701D0: 8501990B
	s_sub_i32 s10, s4, s7                                      // 0000009701D4: 818A0704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009701D8: BF870499
	s_mul_i32 s0, s10, s9                                      // 0000009701DC: 9600090A
	s_sub_i32 s30, s3, s0                                      // 0000009701E0: 819E0003
	s_add_i32 s0, s50, s1                                      // 0000009701E4: 81000132
	s_mul_i32 s31, s30, s8                                     // 0000009701E8: 961F081E
	s_ashr_i32 s0, s0, 7                                       // 0000009701EC: 86008700
	s_add_i32 s1, s31, s8                                      // 0000009701F0: 8101081F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009701F4: BF870499
	s_min_i32 s0, s0, s1                                       // 0000009701F8: 89000100
	s_sub_i32 s29, s0, s31                                     // 0000009701FC: 819D1F00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000970200: BF870499
	s_lshl_b32 s28, s29, 1                                     // 000000970204: 841C811D
	.long 0xd4c4007e                                           // 000000970208: D4C4007E
	v_cndmask_b32_e32 v1, s28, v71, vcc_lo                     // 00000097020C: 02028E1C
	s_cbranch_execz 503                                        // 000000970210: BFA501F7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f0>
	s_add_i32 s35, s48, -1                                     // 000000970214: 8123C130
	s_cmp_lg_u64 s[40:41], 0                                   // 000000970218: BF118028
	v_dual_mov_b32 v8, v71 :: v_dual_and_b32 v1, 1, v0         // 00000097021C: CA240147 08000081
	s_cselect_b32 s51, -1, 0                                   // 000000970224: 983380C1
	s_abs_i32 s52, s29                                         // 000000970228: BEB4151D
	v_and_b32_e32 v2, 2, v0                                    // 00000097022C: 36040082
	s_cvt_f32_u32 s0, s52                                      // 000000970230: BE806534
	v_lshlrev_b32_e32 v6, 3, v72                               // 000000970234: 300C9083
	v_lshlrev_b32_e32 v7, 7, v71                               // 000000970238: 300E8E87
	v_and_b32_e32 v3, 4, v0                                    // 00000097023C: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 000000970240: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 000000970244: 360A0088
	.long 0xd44a0001                                           // 000000970248: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000097024C: 02020280
	.long 0xd44a0003                                           // 000000970250: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000970254: 02020480
	v_lshl_or_b32 v1, v71, 8, v6                               // 000000970258: D6560001 04191147
	v_lshl_add_u32 v2, s31, 7, v7                              // 000000970260: D6460002 041D0E1F
	s_ashr_i32 s54, s29, 31                                    // 000000970268: 86369F1D
	s_sub_i32 s56, 0, s52                                      // 00000097026C: 81B83480
	s_mul_i32 s8, s54, 0x1400                                  // 000000970270: 9608FF36 00001400
	.long 0xd44c0000                                           // 000000970278: D44C0000
	v_cndmask_b32_e32 v1, 16, v72, vcc_lo                      // 00000097027C: 02029090
	v_readfirstlane_b32 s5, v4                                 // 000000970280: 7E0A0504
	.long 0xd44a0004                                           // 000000970284: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000970288: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 00000097028C: 4E120208
	v_lshl_or_b32 v1, v72, 2, v2                               // 000000970290: D6560001 04090548
	s_lshl_b32 s6, s29, 7                                      // 000000970298: 8406871D
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 00000097029C: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 0000009702A4: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000009702A8: 02020A80
	s_mov_b32 s53, 0x76543210                                  // 0000009702AC: BEB500FF 76543210
	s_lshl_b32 s55, s29, 8                                     // 0000009702B4: 8437881D
	s_cvt_u32_f32 s7, s7                                       // 0000009702B8: BE876707
	s_mov_b32 s58, 0x3db504f3                                  // 0000009702BC: BEBA00FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009702C4: BF87049A
	s_mul_i32 s56, s56, s7                                     // 0000009702C8: 96380738
	s_mul_hi_u32 s8, s7, s56                                   // 0000009702CC: 96883807
	s_sub_i32 s56, 0, s6                                       // 0000009702D0: 81B80680
	s_add_i32 s57, s7, s8                                      // 0000009702D4: 81390807
	s_branch 164                                               // 0000009702D8: BFA000A4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x46c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009702DC: BF870091
	.long 0xd7006a02                                           // 0000009702E0: D7006A02
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 0000009702E4: 0202041A
	v_add_co_ci_u32_e64 v3, null, s27, v3, vcc_lo              // 0000009702E8: D5207C03 01AA061B
	v_sub_f32_e32 v4, v15, v13                                 // 0000009702F0: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 0000009702F4: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 0000009702FC: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000970304: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 000000970308: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 000000970310: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 000000970318: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000097031C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000970320: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000970324: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000970328: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000097032C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000970330: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000970334: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000097033C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000970344: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000097034C: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000970354: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 000000970358: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000097035C: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000970364: D5010007 20060F07
	.long 0xd72c0006                                           // 00000097036C: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 000000970370: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 000000970378: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000097037C: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000970384: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 00000097038C: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 000000970390: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000970394: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000097039C: D5010003 20060703
	.long 0xd72c0007                                           // 0000009703A4: D72C0007
	v_cndmask_b32_e32 v1, s55, v10, vcc_lo                     // 0000009703A8: 02021437
	v_add_f32_e32 v2, v2, v13                                  // 0000009703AC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009703B0: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 0000009703B8: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 0000009703C0: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009703C4: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009703C8: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 0000009703D0: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 0000009703D8: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009703DC: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 0000009703E4: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009703EC: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 0000009703F4: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 0000009703FC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000970400: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000970408: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000097040C: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 000000970414: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000970418: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000970420: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000970428: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000970430: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000970438: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000970440: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 000000970448: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 00000097044C: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 000000970450: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000970454: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 000000970458: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000097045C: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000970464: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000097046C: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000970470: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000970478: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000970480: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000970484: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 00000097048C: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000970494: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 00000097049C: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s28, v8                           // 0000009704A0: 7C86101C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009704A4: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 0000009704A8: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 0000009704B0: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009704B8: BF870234
	v_mov_b32_e32 v13, v2                                      // 0000009704BC: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 0000009704C0: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 0000009704C8: D5010004 20020904
	v_permlanex16_b32 v11, v11, s53, 0xfedcba98                // 0000009704D0: D65C000B 03FC6B0B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 0000009704DC: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 0000009704E0: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000009704E8: D5010003 20020703
	v_permlanex16_b32 v10, v10, s53, 0xfedcba98                // 0000009704F0: D65C000A 03FC6B0A FEDCBA98
	v_permlanex16_b32 v13, v13, s53, 0xfedcba98                // 0000009704FC: D65C000D 03FC6B0D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000970508: 060A1705
	v_permlanex16_b32 v12, v12, s53, 0xfedcba98                // 00000097050C: D65C000C 03FC6B0C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000970518: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 00000097051C: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000970528: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000097052C: BF870214
	v_fma_mixhi_f16 v2, v5, s58, 0                             // 000000970530: CC220002 02007505
	v_add_f32_e32 v10, v3, v12                                 // 000000970538: 06141903
	s_or_b32 s34, vcc_lo, s34                                  // 00000097053C: 8C22226A
	v_fma_mixlo_f16 v2, v4, s58, 0                             // 000000970540: CC210002 02007504
	v_fma_mixhi_f16 v3, v7, s58, 0                             // 000000970548: CC220003 02007507
	s_delay_alu instid0(VALU_DEP_3)                            // 000000970550: BF870003
	v_fma_mixlo_f16 v3, v10, s58, 0                            // 000000970554: CC210003 0200750A
	ds_store_b64 v6, v[2:3]                                    // 00000097055C: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s34                       // 000000970564: 917E227E
	s_cbranch_execz 289                                        // 000000970568: BFA50121 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f0>
	.long 0xd72d0002                                           // 00000097056C: D72D0002
	v_cndmask_b32_e32 v0, v8, v57, vcc_lo                      // 000000970570: 02007308
	s_mov_b32 s6, -1                                           // 000000970574: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000970578: BF870091
	.long 0xd72c0003                                           // 00000097057C: D72C0003
	v_cndmask_b32_e32 v0, v2, v52, vcc_lo                      // 000000970580: 02006902
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000970584: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000970588: BF870121
	v_subrev_nc_u32_e32 v5, s52, v3                            // 00000097058C: 4E0A0634
	v_cmp_le_u32_e32 vcc_lo, s52, v3                           // 000000970590: 7C960634
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000970594: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000097059C: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 0000009705A0: 02040902
	v_cmp_le_u32_e32 vcc_lo, s52, v3                           // 0000009705A4: 7C960634
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009705A8: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 0000009705AC: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 0000009705B0: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s51                        // 0000009705B4: 916A337E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009705B8: BF870091
	v_xor_b32_e32 v11, s54, v2                                 // 0000009705BC: 3A160436
	v_subrev_nc_u32_e32 v10, s54, v11                          // 0000009705C0: 4E141636
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009705C4: BF8700A1
	v_mad_u64_u32 v[6:7], null, s56, v10, v[1:2]               // 0000009705C8: D6FE7C06 04061438
	v_min_i32_e32 v2, s35, v10                                 // 0000009705D0: 22041423
	v_mad_i64_i32 v[4:5], null, v2, s50, 0                     // 0000009705D4: D6FF7C04 02006502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009705DC: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000009705E0: 340E0C9F
	.long 0xd73c0002                                           // 0000009705E4: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000009705E8: 02020C81
	s_cbranch_vccnz 212                                        // 0000009705EC: BFA400D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x840>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009705F0: BF870093
	.long 0xd7006a06                                           // 0000009705F4: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000009705F8: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 0000009705FC: D5207C07 01AA0F05
	.long 0x7f383880                                           // 000000970604: 7F383880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000970608: BF870112
	.long 0xd73c0006                                           // 00000097060C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000970610: 02020C81
	.long 0x7f3e399c                                           // 000000970614: 7F3E399C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000970618: BF870092
	.long 0xd7006a0c                                           // 00000097061C: D7006A0C
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 000000970620: 02020C26
	v_add_co_ci_u32_e64 v13, null, s39, v7, vcc_lo             // 000000970624: D5207C0D 01AA0E27
	.long 0xd7006a06                                           // 00000097062C: D7006A06
	v_cndmask_b32_e32 v1, s40, v6, vcc_lo                      // 000000970630: 02020C28
	s_delay_alu instid0(VALU_DEP_1)                            // 000000970634: BF870001
	v_add_co_ci_u32_e64 v7, null, s41, v7, vcc_lo              // 000000970638: D5207C07 01AA0E29
	global_load_b64 v[12:13], v[12:13], off                    // 000000970640: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 000000970648: D7006A0E
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 00000097064C: 0202041A
	global_load_b64 v[6:7], v[6:7], off                        // 000000970650: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s27, v3, vcc_lo             // 000000970658: D5207C0F 01AA061B
	s_clause 0x1                                               // 000000970660: BF850001
	global_load_b32 v16, v[14:15], off                         // 000000970664: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 00000097066C: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 000000970674: BF890FF7
	.long 0x7e1e390c                                           // 000000970678: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 00000097067C: BF890BF7
	v_and_b32_e32 v38, 0xffff0000, v6                          // 000000970680: 364C0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000970688: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000097068C: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000970690: 301E1E90
	v_mul_f32_e32 v19, 0xbfb8aa3b, v15                         // 000000970694: 10261EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000097069C: BF870291
	v_exp_f32_e32 v19, v19                                     // 0000009706A0: 7E264B13
	v_dual_add_f32 v19, 1.0, v19 :: v_dual_and_b32 v12, 0xffff0000, v12// 0000009706A4: C92426F2 130C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009706B0: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 0000009706B4: 102418FF BFB8AA3B
	v_div_scale_f32 v23, null, v19, v19, v15                   // 0000009706BC: D6FC7C17 043E2713
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009706C4: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 0000009706C8: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 0000009706CC: 30221A90
	v_div_scale_f32 v36, s7, v15, v19, v15                     // 0000009706D0: D6FC0724 043E270F
	v_rcp_f32_e32 v27, v23                                     // 0000009706D8: 7E365517
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009706DC: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 0000009706E0: 062424F2
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 0000009706E4: 102822FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009706EC: BF870195
	v_fma_f32 v35, -v23, v27, 1.0                              // 0000009706F0: D6130023 23CA3717
	v_div_scale_f32 v22, null, v18, v18, v12                   // 0000009706F8: D6FC7C16 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000970700: BF8701B3
	v_exp_f32_e32 v20, v20                                     // 000000970704: 7E284B14
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000970708: 361A1AFF FFFF0000
	v_div_scale_f32 v32, vcc_lo, v12, v18, v12                 // 000000970710: D6FC6A20 0432250C
	v_rcp_f32_e32 v25, v22                                     // 000000970718: 7E325516
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 00000097071C: BF870106
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_mul_f32 v21, 0xbfb8aa3b, v13// 000000970720: C90628F2 14141AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000097072C: BF870115
	v_fma_f32 v33, -v22, v25, 1.0                              // 000000970730: D6130021 23CA3316
	v_div_scale_f32 v24, null, v20, v20, v17                   // 000000970738: D6FC7C18 04462914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000970740: BF8701A3
	v_exp_f32_e32 v21, v21                                     // 000000970744: 7E2A4B15
	v_div_scale_f32 v34, s6, v17, v20, v17                     // 000000970748: D6FC0622 04462911
	v_fmac_f32_e32 v25, v33, v25                               // 000000970750: 56323321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000970754: BF870313
	v_rcp_f32_e32 v29, v24                                     // 000000970758: 7E3A5518
	v_add_f32_e32 v21, 1.0, v21                                // 00000097075C: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000970760: BF870115
	v_fma_f32 v37, -v24, v29, 1.0                              // 000000970764: D6130025 23CA3B18
	v_div_scale_f32 v26, null, v21, v21, v13                   // 00000097076C: D6FC7C1A 04362B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000970774: BF8701A2
	v_fmac_f32_e32 v29, v37, v29                               // 000000970778: 563A3B25
	v_mul_f32_e32 v37, v32, v25                                // 00000097077C: 104A3320
	v_rcp_f32_e32 v30, v26                                     // 000000970780: 7E3C551A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000970784: BF870091
	v_fma_f32 v40, -v22, v37, v32                              // 000000970788: D6130028 24824B16
	v_fmac_f32_e32 v37, v40, v25                               // 000000970790: 564A3328
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000970794: BF870115
	v_fma_f32 v33, -v26, v30, 1.0                              // 000000970798: D6130021 23CA3D1A
	v_fma_f32 v22, -v22, v37, v32                              // 0000009707A0: D6130016 24824B16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009707A8: BF870112
	v_fmac_f32_e32 v30, v33, v30                               // 0000009707AC: 563C3D21
	v_div_fmas_f32 v22, v22, v25, v37                          // 0000009707B0: D6370016 04963316
	s_mov_b32 vcc_lo, s7                                       // 0000009707B8: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009707BC: BF8701B1
	v_div_fixup_f32 v12, v22, v18, v12                         // 0000009707C0: D627000C 04322516
	v_fmac_f32_e32 v27, v35, v27                               // 0000009707C8: 56363723
	v_div_scale_f32 v35, s8, v13, v21, v13                     // 0000009707CC: D6FC0823 04362B0D
	v_mul_f32_e32 v12, v12, v38                                // 0000009707D4: 10184D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009707D8: BF870193
	v_mul_f32_e32 v33, v36, v27                                // 0000009707DC: 10423724
	v_mul_f32_e32 v41, v35, v30                                // 0000009707E0: 10523D23
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009707E4: BF870193
	.long 0x7e38398c                                           // 0000009707E8: 7E38398C
	v_fma_f32 v42, -v23, v33, v36                              // 0000009707EC: D613002A 24924317
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009707F4: BF870113
	v_fma_f32 v40, -v26, v41, v35                              // 0000009707F8: D6130028 248E531A
	v_fmac_f32_e32 v33, v42, v27                               // 000000970800: 5642372A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000970804: BF870112
	v_fmac_f32_e32 v41, v40, v30                               // 000000970808: 56523D28
	v_fma_f32 v23, -v23, v33, v36                              // 00000097080C: D6130017 24924317
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000970814: BF870112
	v_fma_f32 v22, -v26, v41, v35                              // 000000970818: D6130016 248E531A
	v_div_fmas_f32 v23, v23, v27, v33                          // 000000970820: D6370017 04863717
	s_mov_b32 vcc_lo, s6                                       // 000000970828: BEEA0006
	s_mov_b32 s6, 0                                            // 00000097082C: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000970830: BF870121
	v_div_fixup_f32 v15, v23, v19, v15                         // 000000970834: D627000F 043E2717
	v_lshlrev_b32_e32 v19, 16, v7                              // 00000097083C: 30260E90
	v_dual_mul_f32 v6, v15, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 000000970840: C8E40D0F 06060EFF FFFF0000
	v_mul_f32_e32 v39, v34, v29                                // 00000097084C: 104E3B22
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000970850: BF870112
	.long 0x7e3e3986                                           // 000000970854: 7E3E3986
	v_fma_f32 v43, -v24, v39, v34                              // 000000970858: D613002B 248A4F18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000970860: BF870091
	v_fmac_f32_e32 v39, v43, v29                               // 000000970864: 564E3B2B
	v_fma_f32 v24, -v24, v39, v34                              // 000000970868: D6130018 248A4F18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000970870: BF870131
	v_div_fmas_f32 v18, v24, v29, v39                          // 000000970874: D6370012 049E3B18
	s_mov_b32 vcc_lo, s8                                       // 00000097087C: BEEA0008
	v_div_fmas_f32 v15, v22, v30, v41                          // 000000970880: D637000F 04A63D16
	v_div_fixup_f32 v17, v18, v20, v17                         // 000000970888: D6270011 04462912
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000970890: BF8701A2
	v_div_fixup_f32 v13, v15, v21, v13                         // 000000970894: D627000D 04362B0F
	v_and_b32_e32 v15, 1, v28                                  // 00000097089C: 361E3881
	v_mul_f32_e32 v17, v17, v19                                // 0000009708A0: 10222711
	v_and_b32_e32 v19, 1, v31                                  // 0000009708A4: 36263E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009708A8: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 0000009708AC: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 0000009708B0: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009708BC: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 0000009708C0: D6100012 02052111
	v_add3_u32 v6, v6, v19, 0x7fff                             // 0000009708C8: D6550006 03FE2706 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009708D4: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 0000009708D8: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 0000009708E0: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009708E8: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 0000009708EC: D655000D 03FE2511 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000009708F8: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000970900: BF870194
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000970904: D6550007 03FE1F07 00007FFF
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000970910: 36221AFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000970918: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000097091C: CC20080D 8A021910
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000970924: CC20000F 8A020D10
	s_waitcnt vmcnt(0)                                         // 00000097092C: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000970930: CC20000C 8A02230E
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000970938: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000970940: 916A067E
	s_cbranch_vccnz 65125                                      // 000000970944: BFA4FE65 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000970948: BF870093
	.long 0xd73c0004                                           // 00000097094C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000970950: 02020881
	.long 0xd7006a04                                           // 000000970954: D7006A04
	v_cndmask_b32_e32 v1, s38, v4, vcc_lo                      // 000000970958: 02020826
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000097095C: BF870111
	v_add_co_ci_u32_e64 v5, null, s39, v5, vcc_lo              // 000000970960: D5207C05 01AA0A27
	.long 0xd7006a04                                           // 000000970968: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 00000097096C: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000970970: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000970974: D5207C05 01AA0705
	.long 0xd7006a06                                           // 00000097097C: D7006A06
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000970980: 0202041A
	v_add_co_ci_u32_e64 v7, null, s27, v3, vcc_lo              // 000000970984: D5207C07 01AA061B
	global_load_b64 v[4:5], v[4:5], off                        // 00000097098C: DC560000 047C0004
	s_clause 0x1                                               // 000000970994: BF850001
	global_load_b32 v14, v[6:7], off                           // 000000970998: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 0000009709A0: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 0000009709A8: BF890BF7
	.long 0x7e0e3904                                           // 0000009709AC: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000009709B0: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 0000009709B8: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009709BC: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000009709C0: 300E0E90
	s_waitcnt vmcnt(1)                                         // 0000009709C4: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000009709C8: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 0000009709D0: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 0000009709D4: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 0000009709DC: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 0000009709E4: 361C0AFF FFFF0000
	s_branch 65083                                             // 0000009709EC: BFA0FE3B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_or_b32 exec_lo, exec_lo, s33                             // 0000009709F0: 8C7E217E
	s_bfe_i32 s28, s29, 0x1001c                                // 0000009709F4: 939CFF1D 0001001C
	s_lshr_b32 s3, s11, 28                                     // 0000009709FC: 85039C0B
	s_lshr_b64 s[0:1], s[28:29], 29                            // 000000970A00: 85809D1C
	s_add_i32 s3, s50, s3                                      // 000000970A04: 81030332
	s_add_i32 s0, s0, 7                                        // 000000970A08: 81008700
	s_lshl_b32 s1, s29, 3                                      // 000000970A0C: 8401831D
	s_ashr_i32 s0, s0, 3                                       // 000000970A10: 86008300
	s_lshl_b32 s4, s31, 3                                      // 000000970A14: 8404831F
	.long 0xd72c0001                                           // 000000970A18: D72C0001
	v_cndmask_b32_e32 v1, s0, v71, vcc_lo                      // 000000970A1C: 02028E00
	v_lshlrev_b32_e32 v11, 2, v72                              // 000000970A20: 30169082
	s_waitcnt lgkmcnt(0)                                       // 000000970A24: BF89FC07
	s_barrier                                                  // 000000970A28: BFBD0000
	buffer_gl0_inv                                             // 000000970A2C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000970A34: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 000000970A38: 86008403
	s_ashr_i32 s3, s4, 31                                      // 000000970A3C: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 000000970A40: 9705000A
	s_mul_i32 s0, s10, s0                                      // 000000970A44: 9600000A
	v_min_i32_e32 v12, s1, v2                                  // 000000970A48: 22180401
	s_add_u32 s0, s0, s4                                       // 000000970A4C: 80000400
	s_addc_u32 s1, s5, s3                                      // 000000970A50: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000970A54: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 000000970A58: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v12                           // 000000970A5C: 7C821901
	s_add_u32 s1, s24, s4                                      // 000000970A60: 80010418
	s_addc_u32 s3, s25, s5                                     // 000000970A64: 82030519
	s_and_saveexec_b32 s4, vcc_lo                              // 000000970A68: BE84206A
	s_cbranch_execz 93                                         // 000000970A6C: BFA5005D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xae4>
	.long 0xd7010002                                           // 000000970A70: D7010002
	v_cndmask_b32_e32 v0, v72, v129, vcc_lo                    // 000000970A74: 02010348
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000970A78: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000970A7C: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000970A84: 3404029F
	.long 0xd44c0000                                           // 000000970A88: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000970A8C: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000970A90: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000970A94: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 000000970AA0: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000970AA8: BF870114
	.long 0xd73c0005                                           // 000000970AAC: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000970AB0: 0202028A
	.long 0xd73c0002                                           // 000000970AB4: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000970AB8: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000970ABC: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000970AC0: 30080E98
	v_bfe_i32 v8, v7, 7, 1                                     // 000000970AC4: D6110008 02050F07
	.long 0xd7000009                                           // 000000970ACC: D7000009
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000970AD0: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000970AD4: BF870211
	v_add_co_ci_u32_e64 v10, null, s3, v6, s0                  // 000000970AD8: D5207C0A 00020C03
	v_ashrrev_i32_e32 v4, 22, v4                               // 000000970AE0: 34080896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000970AE4: BF870093
	.long 0xd7000005                                           // 000000970AE8: D7000005
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 000000970AEC: 02020509
	v_add_co_ci_u32_e64 v6, null, v10, v3, s0                  // 000000970AF0: D5207C06 0002070A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000970AF8: BF870093
	.long 0xd7000007                                           // 000000970AFC: D7000007
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 000000970B00: 02020909
	v_add_co_ci_u32_e64 v8, null, v10, v8, s0                  // 000000970B04: D5207C08 0002110A
	.long 0xd7000009                                           // 000000970B0C: D7000009
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 000000970B10: 02021709
	s_delay_alu instid0(VALU_DEP_1)                            // 000000970B14: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v10, s0                  // 000000970B18: D5207C0A 00021480
	s_clause 0x17                                              // 000000970B20: BF850017
	global_load_b32 v4, v[5:6], off                            // 000000970B24: DC520000 047C0005
	global_load_b32 v2, v[5:6], off offset:128                 // 000000970B2C: DC520080 027C0005
	global_load_b32 v63, v[5:6], off offset:256                // 000000970B34: DC520100 3F7C0005
	global_load_b32 v60, v[5:6], off offset:384                // 000000970B3C: DC520180 3C7C0005
	global_load_b32 v57, v[5:6], off offset:512                // 000000970B44: DC520200 397C0005
	global_load_b32 v54, v[5:6], off offset:640                // 000000970B4C: DC520280 367C0005
	global_load_b32 v51, v[5:6], off offset:768                // 000000970B54: DC520300 337C0005
	global_load_b32 v33, v[5:6], off offset:896                // 000000970B5C: DC520380 217C0005
	global_load_b32 v6, v[7:8], off                            // 000000970B64: DC520000 067C0007
	global_load_b32 v3, v[7:8], off offset:128                 // 000000970B6C: DC520080 037C0007
	global_load_b32 v64, v[7:8], off offset:256                // 000000970B74: DC520100 407C0007
	global_load_b32 v61, v[7:8], off offset:384                // 000000970B7C: DC520180 3D7C0007
	global_load_b32 v58, v[7:8], off offset:512                // 000000970B84: DC520200 3A7C0007
	global_load_b32 v55, v[7:8], off offset:640                // 000000970B8C: DC520280 377C0007
	global_load_b32 v53, v[7:8], off offset:768                // 000000970B94: DC520300 357C0007
	global_load_b32 v34, v[7:8], off offset:896                // 000000970B9C: DC520380 227C0007
	global_load_b32 v5, v[9:10], off                           // 000000970BA4: DC520000 057C0009
	global_load_b32 v65, v[9:10], off offset:128               // 000000970BAC: DC520080 417C0009
	global_load_b32 v62, v[9:10], off offset:256               // 000000970BB4: DC520100 3E7C0009
	global_load_b32 v59, v[9:10], off offset:384               // 000000970BBC: DC520180 3B7C0009
	global_load_b32 v56, v[9:10], off offset:512               // 000000970BC4: DC520200 387C0009
	global_load_b32 v52, v[9:10], off offset:640               // 000000970BCC: DC520280 347C0009
	global_load_b32 v50, v[9:10], off offset:768               // 000000970BD4: DC520300 327C0009
	global_load_b32 v32, v[9:10], off offset:896               // 000000970BDC: DC520380 207C0009
	s_or_b32 exec_lo, exec_lo, s4                              // 000000970BE4: 8C7E047E
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v16, 0             // 000000970BE8: CA100080 0D100080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v18, 0             // 000000970BF0: CA100080 0F120080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 000000970BF8: CA100080 13140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000970C00: CA100080 16160080
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v17, 0             // 000000970C08: CA100080 0E100080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, 0             // 000000970C10: CA100080 18140080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 000000970C18: CA100080 1A1A0080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v28, 0             // 000000970C20: CA100080 191C0080
	s_ashr_i32 s11, s10, 31                                    // 000000970C28: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 000000970C2C: BE80206A
	s_cbranch_execz 1006                                       // 000000970C30: BFA503EE <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1aec>
	v_dual_mov_b32 v16, 0 :: v_dual_add_nc_u32 v7, -1, v0      // 000000970C34: CA200080 100600C1
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v30, 2, v72    // 000000970C3C: CA220080 0D1E9082
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v29, 16, v0        // 000000970C44: CA240080 121C0090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000970C4C: BF8701B3
	v_dual_mov_b32 v22, 0 :: v_dual_and_b32 v7, 31, v7         // 000000970C50: CA240080 16060E9F
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v20, 0             // 000000970C58: CA100080 0F140080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v14, 0             // 000000970C60: CA100080 130E0080
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v31, 2, v7     // 000000970C68: CA220080 181E0E82
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v26, 0             // 000000970C70: CA100080 171A0080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v28, 0             // 000000970C78: CA100080 111C0080
	v_mov_b32_e32 v21, 0                                       // 000000970C80: 7E2A0280
	v_mov_b32_e32 v27, 0                                       // 000000970C84: 7E360280
	v_mov_b32_e32 v25, 0                                       // 000000970C88: 7E320280
	s_mov_b32 s4, 0                                            // 000000970C8C: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000970C90: B0051EEE
	s_branch 922                                               // 000000970C94: BFA0039A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1a00>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000970C98: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 000000970C9C: BF893FF7
	v_alignbit_b32 v4, v4, v6, 16                              // 000000970CA0: D6160004 02420D04
	s_waitcnt vmcnt(7)                                         // 000000970CA8: BF891FF7
	v_bfe_u32 v66, v5, 12, 16                                  // 000000970CAC: D6100042 02411905
	v_bfe_u32 v67, v5, 8, 16                                   // 000000970CB4: D6100043 02411105
	v_bfe_u32 v68, v5, 4, 16                                   // 000000970CBC: D6100044 02410905
	v_lshl_or_b32 v1, v1, 5, v29                               // 000000970CC4: D6560001 04750B01
	v_and_b32_e32 v7, 0xffff, v4                               // 000000970CCC: 360E08FF 0000FFFF
	v_bfe_u32 v74, v4, 4, 16                                   // 000000970CD4: D610004A 02410904
	.long 0xd72c0042                                           // 000000970CDC: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000970CE0: 020284FF 83DCD12D
	.long 0xd72c0043                                           // 000000970CE8: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000970CEC: 020286FF 83DCD12D
	v_bfe_u32 v6, v4, 12, 16                                   // 000000970CF4: D6100006 02411904
	.long 0xd72c004c                                           // 000000970CFC: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 000000970D00: 02020EFF 83DCD12D
	.long 0xd72c004a                                           // 000000970D08: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000970D0C: 020294FF 83DCD12D
	v_alignbit_b32 v70, v2, v3, 16                             // 000000970D14: D6160046 02420702
	.long 0xd72c0044                                           // 000000970D1C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000970D20: 020288FF 83DCD12D
	.long 0xd72c0049                                           // 000000970D28: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 000000970D2C: 02020CFF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000970D34: D6220042 03FD0142 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000970D40: D6220043 03FD0143 00006400
	s_waitcnt vmcnt(6)                                         // 000000970D4C: BF891BF7
	v_bfe_u32 v77, v65, 4, 16                                  // 000000970D50: D610004D 02410941
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000970D58: D622004C 03FD014C 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000970D64: D622004A 03FD014A 00006400
	v_and_b32_e32 v66, 0xffff, v66                             // 000000970D70: 368484FF 0000FFFF
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000970D78: D6220044 03FD0144 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000970D84: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000970D90: 30989890
	v_alignbit_b32 v63, v63, v64, 16                           // 000000970D94: D616003F 0242813F
	v_lshl_or_b32 v66, v67, 16, v66                            // 000000970D9C: D6560042 05092143
	v_alignbit_b32 v60, v60, v61, 16                           // 000000970DA4: D616003C 02427B3C
	v_alignbit_b32 v57, v57, v58, 16                           // 000000970DAC: D6160039 02427539
	v_and_or_b32 v74, 0xffff, v74, v76                         // 000000970DB4: D657004A 053294FF 0000FFFF
	v_bfe_u32 v76, v65, 8, 16                                  // 000000970DC0: D610004C 02411141
	v_pk_fma_f16 v66, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000970DC8: CC0E0042 0BFC0B42 0000C931
	v_alignbit_b32 v54, v54, v55, 16                           // 000000970DD4: D6160036 02426F36
	v_alignbit_b32 v51, v51, v53, 16                           // 000000970DDC: D6160033 02426B33
	v_pk_fma_f16 v67, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000970DE4: CC0E0043 0BFC0B4A 0000C931
	v_and_b32_e32 v69, 0xffff, v5                              // 000000970DF0: 368A0AFF 0000FFFF
	v_bfe_u32 v5, v4, 8, 16                                    // 000000970DF8: D6100005 02411104
	v_bfe_u32 v74, v70, 12, 16                                 // 000000970E00: D610004A 02411946
	.long 0xd72c004c                                           // 000000970E08: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000970E0C: 020298FF 83DCD12D
	v_bfe_u32 v53, v51, 12, 16                                 // 000000970E14: D6100035 02411933
	v_alignbit_b32 v33, v33, v34, 16                           // 000000970E1C: D6160021 02424521
	.long 0xd72c004b                                           // 000000970E24: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000970E28: 02020AFF 83DCD12D
	ds_load_b128 v[5:8], v1                                    // 000000970E30: DBFC0000 05000001
	ds_load_b128 v[1:4], v1 offset:5120                        // 000000970E38: DBFC1400 01000001
	v_and_b32_e32 v73, 0xffff, v73                             // 000000970E40: 369292FF 0000FFFF
	.long 0xd72c004a                                           // 000000970E48: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000970E4C: 020294FF 83DCD12D
	.long 0xd72c0035                                           // 000000970E54: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000970E58: 02026AFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000970E60: D622004C 03FD014C 00006400
	v_cmp_eq_u32_e32 vcc_lo, v9, v12                           // 000000970E6C: 7C941909
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000970E70: D622004B 03FD014B 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000970E7C: D622004A 03FD014A 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000970E88: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000970E94: BF8701B3
	v_lshl_or_b32 v73, v75, 16, v73                            // 000000970E98: D6560049 0525214B
	v_bfe_u32 v75, v70, 8, 16                                  // 000000970EA0: D610004B 02411146
	s_or_b32 s4, vcc_lo, s4                                    // 000000970EA8: 8C04046A
	v_and_b32_e32 v53, 0xffff, v53                             // 000000970EAC: 366A6AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000970EB4: BF870193
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000970EB8: CC0E0049 0BFC0B49 0000C931
	.long 0xd72c004b                                           // 000000970EC4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000970EC8: 020296FF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 000000970ED0: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000970ED4: BF870242
	v_dot2acc_f32_f16 v28, v73, v5                             // 000000970ED8: 04380B49
	s_waitcnt lgkmcnt(0)                                       // 000000970EDC: BF89FC07
	v_dot2acc_f32_f16 v25, v73, v1                             // 000000970EE0: 04320349
	v_bfe_u32 v73, v65, 12, 16                                 // 000000970EE4: D6100049 02411941
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000970EEC: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v28, v67, v6                             // 000000970EF8: 04380D43
	.long 0xd72c0045                                           // 000000970EFC: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000970F00: 02028AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000970F08: BF8701C4
	.long 0xd72c0049                                           // 000000970F0C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000970F10: 020292FF 83DCD12D
	v_dot2acc_f32_f16 v25, v67, v2                             // 000000970F18: 04320543
	v_and_b32_e32 v74, 0xffff, v74                             // 000000970F1C: 369494FF 0000FFFF
	v_dot2acc_f32_f16 v28, v66, v7                             // 000000970F24: 04380F42
	v_dot2acc_f32_f16 v25, v66, v3                             // 000000970F28: 04320742
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000970F2C: D6220045 03FD0145 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000970F38: D6220049 03FD0149 00006400
	v_lshl_or_b32 v74, v75, 16, v74                            // 000000970F44: D656004A 0529214B
	.long 0xd72c004b                                           // 000000970F4C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000970F50: 02029AFF 83DCD12D
	v_bfe_u32 v66, v63, 4, 16                                  // 000000970F58: D6100042 0241093F
	v_lshlrev_b32_e32 v69, 16, v69                             // 000000970F60: 308A8A90
	v_and_b32_e32 v73, 0xffff, v73                             // 000000970F64: 369292FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000970F6C: BF870193
	.long 0xd72c0042                                           // 000000970F70: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000970F74: 020284FF 83DCD12D
	v_and_or_b32 v68, 0xffff, v68, v69                         // 000000970F7C: D6570044 051688FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000970F88: BF8701B1
	v_pk_fma_f16 v68, v68, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000970F8C: CC0E0044 0BFC0B44 0000C931
	v_and_b32_e32 v69, 0xffff, v70                             // 000000970F98: 368A8CFF 0000FFFF
	v_bfe_u32 v70, v70, 4, 16                                  // 000000970FA0: D6100046 02410946
	v_dot2acc_f32_f16 v28, v68, v8                             // 000000970FA8: 04381144
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000970FAC: BF870193
	.long 0xd72c0045                                           // 000000970FB0: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000970FB4: 02028AFF 83DCD12D
	.long 0xd72c0046                                           // 000000970FBC: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000970FC0: 02028CFF 83DCD12D
	v_dot2acc_f32_f16 v25, v68, v4                             // 000000970FC8: 04320944
	s_waitcnt vmcnt(5)                                         // 000000970FCC: BF8917F7
	v_bfe_u32 v68, v62, 8, 16                                  // 000000970FD0: D6100044 0241113E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000970FD8: BF870214
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000970FDC: D6220045 03FD0145 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000970FE8: D6220046 03FD0146 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000970FF4: BF870193
	.long 0xd72c0044                                           // 000000970FF8: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000970FFC: 020288FF 83DCD12D
	v_lshlrev_b32_e32 v69, 16, v69                             // 000000971004: 308A8A90
	s_delay_alu instid0(VALU_DEP_1)                            // 000000971008: BF870001
	v_and_or_b32 v67, 0xffff, v70, v69                         // 00000097100C: D6570043 05168CFF 0000FFFF
	v_pk_fma_f16 v69, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000971018: CC0E0045 0BFC0B4A 0000C931
	v_lshl_or_b32 v70, v76, 16, v73                            // 000000971024: D6560046 0525214C
	v_sad_u8 v73, v75, 0, 0x6400                               // 00000097102C: D6220049 03FD014B 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000971038: D6220044 03FD0144 00006400
	v_pk_fma_f16 v67, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000971044: CC0E0043 0BFC0B43 0000C931
	v_dot2acc_f32_f16 v26, v69, v1                             // 000000971050: 04340345
	v_dot2acc_f32_f16 v27, v69, v5                             // 000000971054: 04360B45
	v_pk_fma_f16 v69, v70, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000971058: CC0E0045 0BFC0B46 0000C931
	s_waitcnt vmcnt(4)                                         // 000000971064: BF8913F7
	v_bfe_u32 v70, v59, 4, 16                                  // 000000971068: D6100046 0241093B
	v_dual_dot2acc_f32_f16 v26, v67, v2 :: v_dual_and_b32 v65, 0xffff, v65// 000000971070: CB240543 1A4082FF 0000FFFF
	v_dot2acc_f32_f16 v27, v67, v6                             // 00000097107C: 04360D43
	v_bfe_u32 v67, v62, 12, 16                                 // 000000971080: D6100043 0241193E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000971088: BF870213
	v_dot2acc_f32_f16 v26, v69, v3                             // 00000097108C: 04340745
	.long 0xd72c0041                                           // 000000971090: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000971094: 020282FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000097109C: BF8701C4
	v_dot2acc_f32_f16 v27, v69, v7                             // 0000009710A0: 04360F45
	v_and_b32_e32 v69, 0xffff, v62                             // 0000009710A4: 368A7CFF 0000FFFF
	v_bfe_u32 v62, v62, 4, 16                                  // 0000009710AC: D610003E 0241093E
	.long 0xd72c0043                                           // 0000009710B4: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 0000009710B8: 020286FF 83DCD12D
	.long 0xd72c0045                                           // 0000009710C0: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000009710C4: 02028AFF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009710CC: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009710D8: BF870214
	.long 0xd72c003e                                           // 0000009710DC: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009710E0: 02027CFF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 0000009710E8: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009710F4: BF870113
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000009710F8: 30828290
	v_and_b32_e32 v67, 0xffff, v67                             // 0000009710FC: 368686FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000971104: BF8701A2
	v_and_or_b32 v65, 0xffff, v73, v65                         // 000000971108: D6570041 050692FF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000971114: D622003E 03FD013E 00006400
	v_lshl_or_b32 v61, v68, 16, v67                            // 000000971120: D656003D 050D2144
	s_delay_alu instid0(VALU_DEP_3)                            // 000000971128: BF870003
	v_pk_fma_f16 v64, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000097112C: CC0E0040 0BFC0B41 0000C931
	v_bfe_u32 v65, v63, 12, 16                                 // 000000971138: D6100041 0241193F
	v_bfe_u32 v67, v60, 8, 16                                  // 000000971140: D6100043 0241113C
	v_bfe_u32 v68, v59, 12, 16                                 // 000000971148: D6100044 0241193B
	v_pk_fma_f16 v61, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000971150: CC0E003D 0BFC0B3D 0000C931
	v_dot2acc_f32_f16 v27, v64, v8                             // 00000097115C: 04361140
	.long 0xd72c0041                                           // 000000971160: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000971164: 020282FF 83DCD12D
	v_dot2acc_f32_f16 v26, v64, v4                             // 00000097116C: 04340940
	v_bfe_u32 v64, v63, 8, 16                                  // 000000971170: D6100040 0241113F
	v_and_b32_e32 v63, 0xffff, v63                             // 000000971178: 367E7EFF 0000FFFF
	.long 0xd72c0043                                           // 000000971180: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000971184: 020286FF 83DCD12D
	.long 0xd72c0044                                           // 00000097118C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000971190: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000971198: BF870214
	.long 0xd72c0040                                           // 00000097119C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000009711A0: 020280FF 83DCD12D
	.long 0xd72c003f                                           // 0000009711A8: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000009711AC: 02027EFF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009711B4: D6220041 03FD0141 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 0000009711C0: D6220043 03FD0143 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000009711CC: D6220044 03FD0144 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000009711D8: BF870133
	v_and_b32_e32 v65, 0xffff, v65                             // 0000009711DC: 368282FF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009711E4: D6220040 03FD0140 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 0000009711F0: D622003F 03FD013F 00006400
	v_lshl_or_b32 v64, v64, 16, v65                            // 0000009711FC: D6560040 05052140
	v_sad_u8 v65, v66, 0, 0x6400                               // 000000971204: D6220041 03FD0142 00006400
	v_sad_u8 v66, v69, 0, 0x6400                               // 000000971210: D6220042 03FD0145 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000097121C: BF870004
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000971220: 307E7E90
	v_bfe_u32 v69, v59, 8, 16                                  // 000000971224: D6100045 0241113B
	v_pk_fma_f16 v64, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000097122C: CC0E0040 0BFC0B40 0000C931
	v_and_b32_e32 v59, 0xffff, v59                             // 000000971238: 367676FF 0000FFFF
	v_lshlrev_b32_e32 v66, 16, v66                             // 000000971240: 30848490
	v_and_or_b32 v63, 0xffff, v65, v63                         // 000000971244: D657003F 04FE82FF 0000FFFF
	v_bfe_u32 v65, v60, 12, 16                                 // 000000971250: D6100041 0241193C
	v_dot2acc_f32_f16 v21, v64, v5                             // 000000971258: 042A0B40
	v_dot2acc_f32_f16 v17, v64, v1                             // 00000097125C: 04220340
	v_and_or_b32 v62, 0xffff, v62, v66                         // 000000971260: D657003E 050A7CFF 0000FFFF
	v_and_b32_e32 v66, 0xffff, v60                             // 00000097126C: 368478FF 0000FFFF
	.long 0xd72c0041                                           // 000000971274: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000971278: 020282FF 83DCD12D
	v_bfe_u32 v60, v60, 4, 16                                  // 000000971280: D610003C 0241093C
	.long 0xd72c0045                                           // 000000971288: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 00000097128C: 02028AFF 83DCD12D
	.long 0xd72c003b                                           // 000000971294: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000971298: 020276FF 83DCD12D
	.long 0xd72c0042                                           // 0000009712A0: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 0000009712A4: 020284FF 83DCD12D
	v_pk_fma_f16 v63, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009712AC: CC0E003F 0BFC0B3F 0000C931
	.long 0xd72c003c                                           // 0000009712B8: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000009712BC: 020278FF 83DCD12D
	v_pk_fma_f16 v62, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009712C4: CC0E003E 0BFC0B3E 0000C931
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009712D0: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009712DC: BF870234
	v_dot2acc_f32_f16 v17, v63, v2                             // 0000009712E0: 0422053F
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009712E4: D622003B 03FD013B 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009712F0: D6220042 03FD0142 00006400
	v_and_b32_e32 v65, 0xffff, v65                             // 0000009712FC: 368282FF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000971304: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000971310: BF870214
	v_lshlrev_b32_e32 v59, 16, v59                             // 000000971314: 30767690
	v_lshlrev_b32_e32 v66, 16, v66                             // 000000971318: 30848490
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000097131C: BF870234
	v_lshl_or_b32 v65, v67, 16, v65                            // 000000971320: D6560041 05052143
	v_and_b32_e32 v67, 0xffff, v68                             // 000000971328: 368688FF 0000FFFF
	v_sad_u8 v68, v69, 0, 0x6400                               // 000000971330: D6220044 03FD0145 00006400
	v_and_or_b32 v60, 0xffff, v60, v66                         // 00000097133C: D657003C 050A78FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000971348: BF870224
	v_pk_fma_f16 v64, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000097134C: CC0E0040 0BFC0B41 0000C931
	.long 0xd72c0042                                           // 000000971358: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 00000097135C: 02028CFF 83DCD12D
	v_lshl_or_b32 v65, v68, 16, v67                            // 000000971364: D6560041 050D2144
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000097136C: BF870214
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000971370: CC0E003C 0BFC0B3C 0000C931
	v_dot2acc_f32_f16 v24, v64, v5                             // 00000097137C: 04300B40
	v_dot2acc_f32_f16 v23, v64, v1                             // 000000971380: 042E0340
	s_waitcnt vmcnt(2)                                         // 000000971384: BF890BF7
	v_bfe_u32 v64, v52, 4, 16                                  // 000000971388: D6100040 02410934
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000971390: D6220042 03FD0142 00006400
	v_dot2acc_f32_f16 v24, v60, v6                             // 00000097139C: 04300D3C
	v_dual_dot2acc_f32_f16 v23, v60, v2 :: v_dual_and_b32 v60, 0xffff, v57// 0000009713A0: CB24053C 173C72FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009713AC: BF870113
	v_and_or_b32 v59, 0xffff, v66, v59                         // 0000009713B0: D657003B 04EE84FF 0000FFFF
	.long 0xd72c003c                                           // 0000009713BC: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000009713C0: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009713C8: BF8701A2
	v_pk_fma_f16 v58, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009713CC: CC0E003A 0BFC0B3B 0000C931
	v_bfe_u32 v59, v57, 12, 16                                 // 0000009713D8: D610003B 02411939
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009713E0: D622003C 03FD013C 00006400
	v_dot2acc_f32_f16 v21, v63, v6                             // 0000009713EC: 042A0D3F
	v_pk_fma_f16 v63, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009713F0: CC0E003F 0BFC0B41 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009713FC: BF870214
	.long 0xd72c003b                                           // 000000971400: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000971404: 020276FF 83DCD12D
	v_dual_mov_b32 v65, v48 :: v_dual_lshlrev_b32 v60, 16, v60 // 00000097140C: CA220130 413C7890
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000971414: BF870214
	v_dot2acc_f32_f16 v21, v61, v7                             // 000000971418: 042A0F3D
	v_dot2acc_f32_f16 v24, v63, v7                             // 00000097141C: 04300F3F
	v_dot2acc_f32_f16 v23, v63, v3                             // 000000971420: 042E073F
	v_bfe_u32 v63, v56, 4, 16                                  // 000000971424: D610003F 02410938
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000097142C: D622003B 03FD013B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000971438: BF870214
	v_dot2acc_f32_f16 v24, v58, v8                             // 00000097143C: 0430113A
	v_dot2acc_f32_f16 v23, v58, v4                             // 000000971440: 042E093A
	v_bfe_u32 v58, v57, 8, 16                                  // 000000971444: D610003A 02411139
	v_bfe_u32 v57, v57, 4, 16                                  // 00000097144C: D6100039 02410939
	v_and_b32_e32 v59, 0xffff, v59                             // 000000971454: 367676FF 0000FFFF
	.long 0xd72c003f                                           // 00000097145C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000971460: 02027EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000971468: BF870214
	.long 0xd72c003a                                           // 00000097146C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000971470: 020274FF 83DCD12D
	.long 0xd72c0039                                           // 000000971478: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 00000097147C: 020272FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000971484: BF870193
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000971488: D622003F 03FD013F 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000971494: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009714A0: BF870113
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009714A4: D6220039 03FD0139 00006400
	v_lshl_or_b32 v58, v58, 16, v59                            // 0000009714B0: D656003A 04ED213A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009714B8: BF870232
	v_and_or_b32 v57, 0xffff, v57, v60                         // 0000009714BC: D6570039 04F272FF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v54                             // 0000009714C8: 36786CFF 0000FFFF
	v_bfe_u32 v59, v54, 12, 16                                 // 0000009714D0: D610003B 02411936
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009714D8: CC0E003A 0BFC0B3A 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009714E4: BF870214
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009714E8: CC0E0039 0BFC0B39 0000C931
	.long 0xd72c003c                                           // 0000009714F4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000009714F8: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000971500: BF870214
	.long 0xd72c003b                                           // 000000971504: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000971508: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v22, v58, v1                             // 000000971510: 042C033A
	v_dot2acc_f32_f16 v14, v58, v5                             // 000000971514: 041C0B3A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000971518: BF870194
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000097151C: D622003C 03FD013C 00006400
	v_dual_dot2acc_f32_f16 v22, v57, v2 :: v_dual_dot2acc_f32_f16 v21, v62, v8// 000000971528: CB180539 1614113E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000971530: BF870223
	v_dot2acc_f32_f16 v14, v57, v6                             // 000000971534: 041C0D39
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000971538: D622003B 03FD013B 00006400
	v_dual_dot2acc_f32_f16 v17, v61, v3 :: v_dual_lshlrev_b32 v60, 16, v60// 000000971544: CB22073D 113C7890
	v_bfe_u32 v61, v56, 12, 16                                 // 00000097154C: D610003D 02411938
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000971554: BF870193
	v_and_b32_e32 v59, 0xffff, v59                             // 000000971558: 367676FF 0000FFFF
	v_dot2acc_f32_f16 v17, v62, v4                             // 000000971560: 0422093E
	v_bfe_u32 v62, v56, 8, 16                                  // 000000971564: D610003E 02411138
	v_and_b32_e32 v56, 0xffff, v56                             // 00000097156C: 367070FF 0000FFFF
	.long 0xd72c003d                                           // 000000971574: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000971578: 02027AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000971580: BF870193
	.long 0xd72c003e                                           // 000000971584: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000971588: 02027CFF 83DCD12D
	.long 0xd72c0038                                           // 000000971590: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000971594: 020270FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000097159C: BF870193
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009715A0: D622003D 03FD013D 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009715AC: D622003E 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009715B8: BF870193
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009715BC: D6220038 03FD0138 00006400
	v_and_b32_e32 v61, 0xffff, v61                             // 0000009715C8: 367A7AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009715D0: BF870112
	v_lshlrev_b32_e32 v56, 16, v56                             // 0000009715D4: 30707090
	v_lshl_or_b32 v55, v62, 16, v61                            // 0000009715D8: D6560037 04F5213E
	v_bfe_u32 v61, v54, 8, 16                                  // 0000009715E0: D610003D 02411136
	v_bfe_u32 v54, v54, 4, 16                                  // 0000009715E8: D6100036 02410936
	v_bfe_u32 v62, v52, 12, 16                                 // 0000009715F0: D610003E 02411934
	v_and_or_b32 v56, 0xffff, v63, v56                         // 0000009715F8: D6570038 04E27EFF 0000FFFF
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000971604: CC0E0037 0BFC0B37 0000C931
	.long 0xd72c003d                                           // 000000971610: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000971614: 02027AFF 83DCD12D
	.long 0xd72c0036                                           // 00000097161C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000971620: 02026CFF 83DCD12D
	v_bfe_u32 v63, v52, 8, 16                                  // 000000971628: D610003F 02411134
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000971630: CC0E0038 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v14, v55, v7                             // 00000097163C: 041C0F37
	v_dot2acc_f32_f16 v22, v55, v3                             // 000000971640: 042C0737
	.long 0xd72c003e                                           // 000000971644: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000971648: 02027CFF 83DCD12D
	.long 0xd72c003f                                           // 000000971650: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000971654: 02027EFF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000097165C: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v14, v56, v8                             // 000000971668: 041C1138
	v_dot2acc_f32_f16 v22, v56, v4                             // 00000097166C: 042C0938
	s_waitcnt vmcnt(1)                                         // 000000971670: BF8907F7
	v_bfe_u32 v56, v50, 12, 16                                 // 000000971674: D6100038 02411932
	v_sad_u8 v54, v54, 0, 0x6400                               // 00000097167C: D6220036 03FD0136 00006400
	v_lshl_or_b32 v59, v61, 16, v59                            // 000000971688: D656003B 04ED213D
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000971690: D622003E 03FD013E 00006400
	v_and_b32_e32 v52, 0xffff, v52                             // 00000097169C: 366868FF 0000FFFF
	.long 0xd72c0038                                           // 0000009716A4: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009716A8: 020270FF 83DCD12D
	v_and_or_b32 v54, 0xffff, v54, v60                         // 0000009716B0: D6570036 04F26CFF 0000FFFF
	v_pk_fma_f16 v58, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009716BC: CC0E003A 0BFC0B3B 0000C931
	.long 0xd72c003c                                           // 0000009716C8: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000009716CC: 020280FF 83DCD12D
	.long 0xd72c0034                                           // 0000009716D4: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009716D8: 020268FF 83DCD12D
	v_mov_b32_e32 v64, v47                                     // 0000009716E0: 7E80032F
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009716E4: CC0E0036 0BFC0B36 0000C931
	v_dot2acc_f32_f16 v20, v58, v5                             // 0000009716F0: 04280B3A
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009716F4: D6220038 03FD0138 00006400
	v_dot2acc_f32_f16 v19, v58, v1                             // 000000971700: 0426033A
	v_bfe_u32 v58, v50, 4, 16                                  // 000000971704: D610003A 02410932
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000097170C: D622003C 03FD013C 00006400
	v_dot2acc_f32_f16 v20, v54, v6                             // 000000971718: 04280D36
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000097171C: BF8701C4
	v_dual_dot2acc_f32_f16 v19, v54, v2 :: v_dual_and_b32 v56, 0xffff, v56// 000000971720: CB240536 133870FF 0000FFFF
	v_bfe_u32 v54, v51, 8, 16                                  // 00000097172C: D6100036 02411133
	.long 0xd72c003a                                           // 000000971734: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000971738: 020274FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000971740: D6220034 03FD0134 00006400
	.long 0xd72c0036                                           // 00000097174C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000971750: 02026CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000971758: BF870212
	v_lshlrev_b32_e32 v52, 16, v52                             // 00000097175C: 30686890
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000971760: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000097176C: BF870212
	v_and_or_b32 v52, 0xffff, v60, v52                         // 000000971770: D6570034 04D278FF 0000FFFF
	v_sad_u8 v54, v54, 0, 0x6400                               // 00000097177C: D6220036 03FD0136 00006400
	v_mov_b32_e32 v60, v38                                     // 000000971788: 7E780326
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000097178C: BF870193
	v_pk_fma_f16 v52, v52, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000971790: CC0E0034 0BFC0B34 0000C931
	v_lshl_or_b32 v53, v54, 16, v53                            // 00000097179C: D6560035 04D52136
	v_bfe_u32 v54, v33, 12, 16                                 // 0000009717A4: D6100036 02411921
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009717AC: BF870232
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009717B0: CC0E0035 0BFC0B35 0000C931
	v_and_b32_e32 v61, 0xffff, v62                             // 0000009717BC: 367A7CFF 0000FFFF
	v_sad_u8 v62, v63, 0, 0x6400                               // 0000009717C4: D622003E 03FD013F 00006400
	.long 0xd72c0036                                           // 0000009717D0: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009717D4: 02026CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009717DC: BF870224
	v_dual_mov_b32 v63, v39 :: v_dual_dot2acc_f32_f16 v16, v53, v1// 0000009717E0: CA180127 3F100335
	v_and_b32_e32 v55, 0xffff, v51                             // 0000009717E8: 366E66FF 0000FFFF
	v_lshl_or_b32 v59, v62, 16, v61                            // 0000009717F0: D656003B 04F5213E
	v_bfe_u32 v51, v51, 4, 16                                  // 0000009717F8: D6100033 02410933
	v_dual_dot2acc_f32_f16 v18, v53, v5 :: v_dual_mov_b32 v61, v46// 000000971800: CB100B35 123C012E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000971808: BF870214
	.long 0xd72c0037                                           // 00000097180C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000971810: 02026EFF 83DCD12D
	v_pk_fma_f16 v57, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000971818: CC0E0039 0BFC0B3B 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000971824: BF870004
	.long 0xd72c0033                                           // 000000971828: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 00000097182C: 020266FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000971834: D6220036 03FD0136 00006400
	s_waitcnt vmcnt(0)                                         // 000000971840: BF8903F7
	v_bfe_u32 v59, v32, 4, 16                                  // 000000971844: D610003B 02410920
	v_mov_b32_e32 v62, v47                                     // 00000097184C: 7E7C032F
	v_dot2acc_f32_f16 v20, v57, v7                             // 000000971850: 04280F39
	v_dot2acc_f32_f16 v19, v57, v3                             // 000000971854: 04260739
	v_bfe_u32 v57, v50, 8, 16                                  // 000000971858: D6100039 02411132
	v_and_b32_e32 v50, 0xffff, v50                             // 000000971860: 366464FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000971868: D6220037 03FD0137 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000971874: D6220033 03FD0133 00006400
	v_and_b32_e32 v54, 0xffff, v54                             // 000000971880: 366C6CFF 0000FFFF
	.long 0xd72c0039                                           // 000000971888: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 00000097188C: 020272FF 83DCD12D
	.long 0xd72c0032                                           // 000000971894: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000971898: 020264FF 83DCD12D
	v_dot2acc_f32_f16 v20, v52, v8                             // 0000009718A0: 04281134
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009718A4: BF870193
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009718A8: D6220039 03FD0139 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009718B4: D6220032 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009718C0: BF870112
	v_lshl_or_b32 v34, v57, 16, v56                            // 0000009718C4: D6560022 04E12139
	v_lshlrev_b32_e32 v50, 16, v50                             // 0000009718CC: 30646490
	v_bfe_u32 v56, v33, 8, 16                                  // 0000009718D0: D6100038 02411121
	v_bfe_u32 v57, v32, 12, 16                                 // 0000009718D8: D6100039 02411920
	v_dot2acc_f32_f16 v19, v52, v4                             // 0000009718E0: 04260934
	v_pk_fma_f16 v34, v34, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009718E4: CC0E0022 0BFC0B22 0000C931
	v_and_or_b32 v50, 0xffff, v58, v50                         // 0000009718F0: D6570032 04CA74FF 0000FFFF
	.long 0xd72c0038                                           // 0000009718FC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000971900: 020270FF 83DCD12D
	v_bfe_u32 v58, v32, 8, 16                                  // 000000971908: D610003A 02411120
	.long 0xd72c0039                                           // 000000971910: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000971914: 020272FF 83DCD12D
	v_and_b32_e32 v32, 0xffff, v32                             // 00000097191C: 364040FF 0000FFFF
	v_pk_fma_f16 v50, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000971924: CC0E0032 0BFC0B32 0000C931
	v_lshlrev_b32_e32 v55, 16, v55                             // 000000971930: 306E6E90
	.long 0xd72c003a                                           // 000000971934: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000971938: 020274FF 83DCD12D
	v_mov_b32_e32 v52, v44                                     // 000000971940: 7E68032C
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000971944: D6220038 03FD0138 00006400
	.long 0xd72c0020                                           // 000000971950: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000971954: 020240FF 83DCD12D
	v_and_or_b32 v51, 0xffff, v51, v55                         // 00000097195C: D6570033 04DE66FF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000971968: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000971974: BF870194
	v_lshl_or_b32 v54, v56, 16, v54                            // 000000971978: D6560036 04D92138
	v_pk_fma_f16 v51, v51, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000971980: CC0E0033 0BFC0B33 0000C931
	v_sad_u8 v32, v32, 0, 0x6400                               // 00000097198C: D6220020 03FD0120 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000971998: BF870193
	v_pk_fma_f16 v53, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000097199C: CC0E0035 0BFC0B36 0000C931
	v_dual_dot2acc_f32_f16 v16, v51, v2 :: v_dual_and_b32 v55, 0xffff, v33// 0000009719A8: CB240533 103642FF 0000FFFF
	v_bfe_u32 v33, v33, 4, 16                                  // 0000009719B4: D6100021 02410921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009719BC: BF870193
	v_dual_dot2acc_f32_f16 v15, v53, v5 :: v_dual_lshlrev_b32 v32, 16, v32// 0000009719C0: CB220B35 0F204090
	v_dual_dot2acc_f32_f16 v13, v53, v1 :: v_dual_dot2acc_f32_f16 v16, v34, v3// 0000009719C8: CB180335 0D100722
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009719D0: BF870214
	.long 0xd72c0037                                           // 0000009719D4: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000009719D8: 02026EFF 83DCD12D
	.long 0xd72c0021                                           // 0000009719E0: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000009719E4: 020242FF 83DCD12D
	v_dot2acc_f32_f16 v18, v51, v6                             // 0000009719EC: 04240D33
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009719F0: BF870114
	v_dual_mov_b32 v51, v35 :: v_dual_dot2acc_f32_f16 v16, v50, v4// 0000009719F4: CA180123 33100932
	v_dual_mov_b32 v53, v43 :: v_dual_dot2acc_f32_f16 v18, v34, v7// 0000009719FC: CA18012B 35120F22
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000971A04: D6220037 03FD0137 00006400
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000971A10: D6220021 03FD0121 00006400
	v_mov_b32_e32 v34, v41                                     // 000000971A1C: 7E440329
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000971A20: BF870123
	v_dual_dot2acc_f32_f16 v18, v50, v8 :: v_dual_lshlrev_b32 v55, 16, v55// 000000971A24: CB221132 12366E90
	v_mov_b32_e32 v50, v43                                     // 000000971A2C: 7E64032B
	v_and_or_b32 v33, 0xffff, v33, v55                         // 000000971A30: D6570021 04DE42FF 0000FFFF
	.long 0xd72c0037                                           // 000000971A3C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000971A40: 020276FF 83DCD12D
	v_mov_b32_e32 v59, v46                                     // 000000971A48: 7E76032E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000971A4C: BF870003
	v_pk_fma_f16 v33, v33, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000971A50: CC0E0021 0BFC0B21 0000C931
	v_and_b32_e32 v56, 0xffff, v57                             // 000000971A5C: 367072FF 0000FFFF
	v_sad_u8 v57, v58, 0, 0x6400                               // 000000971A64: D6220039 03FD013A 00006400
	v_mov_b32_e32 v58, v45                                     // 000000971A70: 7E74032D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000971A74: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v15, v33, v6                             // 000000971A80: 041E0D21
	v_dot2acc_f32_f16 v13, v33, v2                             // 000000971A84: 041A0521
	v_lshl_or_b32 v54, v57, 16, v56                            // 000000971A88: D6560036 04E12139
	v_mov_b32_e32 v56, v45                                     // 000000971A90: 7E70032D
	v_and_or_b32 v5, 0xffff, v55, v32                          // 000000971A94: D6570005 04826EFF 0000FFFF
	v_mov_b32_e32 v55, v44                                     // 000000971AA0: 7E6E032C
	v_mov_b32_e32 v57, v37                                     // 000000971AA4: 7E720325
	v_pk_fma_f16 v1, v54, s5, 0xc931 op_sel_hi:[1,0,0]         // 000000971AA8: CC0E0001 0BFC0B36 0000C931
	v_mov_b32_e32 v54, v36                                     // 000000971AB4: 7E6C0324
	v_pk_fma_f16 v2, v5, s5, 0xc931 op_sel_hi:[1,0,0]          // 000000971AB8: CC0E0002 0BFC0B05 0000C931
	v_mov_b32_e32 v5, v49                                      // 000000971AC4: 7E0A0331
	v_mov_b32_e32 v6, v49                                      // 000000971AC8: 7E0C0331
	v_dot2acc_f32_f16 v15, v1, v7                              // 000000971ACC: 041E0F01
	v_dot2acc_f32_f16 v13, v1, v3                              // 000000971AD0: 041A0701
	v_dual_mov_b32 v3, v48 :: v_dual_mov_b32 v32, v41          // 000000971AD4: CA100130 03200129
	v_mov_b32_e32 v33, v10                                     // 000000971ADC: 7E42030A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000971AE0: BF870214
	v_dot2acc_f32_f16 v15, v2, v8                              // 000000971AE4: 041E1102
	v_dot2acc_f32_f16 v13, v2, v4                              // 000000971AE8: 041A0902
	v_mov_b32_e32 v2, v42                                      // 000000971AEC: 7E04032A
	v_dual_mov_b32 v4, v40 :: v_dual_mov_b32 v1, v9            // 000000971AF0: CA100128 04000109
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000971AF8: 917E047E
	s_cbranch_execz 58                                         // 000000971AFC: BFA5003A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1ae8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000971B00: BF8700A1
	v_add_nc_u32_e32 v9, 1, v1                                 // 000000971B04: 4A120281
	s_mov_b32 s6, exec_lo                                      // 000000971B08: BE86007E
	.long 0xd4c1007e                                           // 000000971B0C: D4C1007E
	v_cndmask_b32_e32 v1, v9, v12, vcc_lo                      // 000000971B10: 02021909
	s_cbranch_execz 64608                                      // 000000971B14: BFA5FC60 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xb98>
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000971B18: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000971B1C: BF870091
	.long 0xd73c0007                                           // 000000971B20: D73C0007
	v_cndmask_b32_e32 v1, 10, v9, vcc_lo                       // 000000971B24: 0202128A
	.long 0xd7006a0a                                           // 000000971B28: D7006A0A
	v_cndmask_b32_e32 v1, s1, v7, vcc_lo                       // 000000971B2C: 02020E01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000971B30: BF870111
	v_add_co_ci_u32_e64 v35, null, s3, v8, vcc_lo              // 000000971B34: D5207C23 01AA1003
	.long 0xd7006a07                                           // 000000971B3C: D7006A07
	v_cndmask_b32_e32 v1, v10, v31, vcc_lo                     // 000000971B40: 02023F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000971B44: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v35, vcc_lo               // 000000971B48: D5207C08 01AA4680
	.long 0xd7006a42                                           // 000000971B50: D7006A42
	v_cndmask_b32_e32 v1, v10, v30, vcc_lo                     // 000000971B54: 02023D0A
	v_add_co_ci_u32_e64 v67, null, 0, v35, vcc_lo              // 000000971B58: D5207C43 01AA4680
	s_clause 0xf                                               // 000000971B60: BF85000F
	global_load_b32 v40, v[7:8], off                           // 000000971B64: DC520000 287C0007
	global_load_b32 v42, v[7:8], off offset:128                // 000000971B6C: DC520080 2A7C0007
	global_load_b32 v39, v[7:8], off offset:256                // 000000971B74: DC520100 277C0007
	global_load_b32 v38, v[7:8], off offset:384                // 000000971B7C: DC520180 267C0007
	global_load_b32 v37, v[7:8], off offset:512                // 000000971B84: DC520200 257C0007
	global_load_b32 v36, v[7:8], off offset:640                // 000000971B8C: DC520280 247C0007
	global_load_b32 v35, v[7:8], off offset:768                // 000000971B94: DC520300 237C0007
	global_load_b32 v10, v[7:8], off offset:896                // 000000971B9C: DC520380 0A7C0007
	global_load_b32 v49, v[66:67], off                         // 000000971BA4: DC520000 317C0042
	global_load_b32 v48, v[66:67], off offset:128              // 000000971BAC: DC520080 307C0042
	global_load_b32 v47, v[66:67], off offset:256              // 000000971BB4: DC520100 2F7C0042
	global_load_b32 v46, v[66:67], off offset:384              // 000000971BBC: DC520180 2E7C0042
	global_load_b32 v45, v[66:67], off offset:512              // 000000971BC4: DC520200 2D7C0042
	global_load_b32 v44, v[66:67], off offset:640              // 000000971BCC: DC520280 2C7C0042
	global_load_b32 v43, v[66:67], off offset:768              // 000000971BD4: DC520300 2B7C0042
	global_load_b32 v41, v[66:67], off offset:896              // 000000971BDC: DC520380 297C0042
	s_branch 64556                                             // 000000971BE4: BFA0FC2C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xb98>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000971BE8: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000971BEC: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000971BF0: 8C7E007E
	s_waitcnt vmcnt(22)                                        // 000000971BF4: BF895BF7
	v_dual_mov_b32 v1, v28 :: v_dual_mov_b32 v2, v25           // 000000971BF8: CA10011C 01020119
	s_waitcnt vmcnt(14)                                        // 000000971C00: BF893BF7
	v_dual_mov_b32 v3, v27 :: v_dual_mov_b32 v6, v26           // 000000971C04: CA10011B 0306011A
	v_dual_mov_b32 v4, v21 :: v_dual_mov_b32 v9, v23           // 000000971C0C: CA100115 04080117
	s_waitcnt vmcnt(7)                                         // 000000971C14: BF891FF7
	v_dual_mov_b32 v5, v17 :: v_dual_mov_b32 v8, v24           // 000000971C18: CA100111 05080118
	v_dual_mov_b32 v7, v14 :: v_dual_mov_b32 v12, v20          // 000000971C20: CA10010E 070C0114
	v_dual_mov_b32 v10, v22 :: v_dual_mov_b32 v29, v19         // 000000971C28: CA100116 0A1C0113
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v31, v16         // 000000971C30: CA100112 1E1E0110
	s_waitcnt vmcnt(0)                                         // 000000971C38: BF8903F7
	v_dual_mov_b32 v32, v15 :: v_dual_mov_b32 v33, v13         // 000000971C3C: CA10010F 2020010D
	s_mov_b32 s0, 0x76543210                                   // 000000971C44: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000971C4C: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000971C50: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000971C5C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000971C68: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000971C74: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000971C80: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000971C8C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000971C98: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000971CA4: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000971CB0: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000971CBC: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000971CC8: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v29, v29, s0, 0xfedcba98                 // 000000971CD4: D65C001D 03FC011D FEDCBA98
	v_permlanex16_b32 v30, v30, s0, 0xfedcba98                 // 000000971CE0: D65C001E 03FC011E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 000000971CEC: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 000000971CF8: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 000000971D04: D65C0021 03FC0121 FEDCBA98
	.long 0xd44c0000                                           // 000000971D10: D44C0000
	v_cndmask_b32_e32 v1, 16, v72, vcc_lo                      // 000000971D14: 02029090
	s_barrier                                                  // 000000971D18: BFBD0000
	buffer_gl0_inv                                             // 000000971D1C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000971D24: BE812000
	s_cbranch_execz 34                                         // 000000971D28: BFA50022 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1cb4>
	v_dual_add_f32 v8, v24, v8 :: v_dual_add_f32 v3, v27, v3   // 000000971D2C: C9081118 0802071B
	v_dual_add_f32 v6, v26, v6 :: v_dual_add_f32 v1, v28, v1   // 000000971D34: C9080D1A 0600031C
	v_lshl_or_b32 v11, v71, 10, v11                            // 000000971D3C: D656000B 042D1547
	v_dual_add_f32 v2, v25, v2 :: v_dual_add_f32 v7, v14, v7   // 000000971D44: C9080519 02060F0E
	v_add_f32_e32 v4, v21, v4                                  // 000000971D4C: 06080915
	v_dual_add_f32 v10, v22, v10 :: v_dual_add_f32 v9, v23, v9 // 000000971D50: C9081516 0A081317
	v_add_f32_e32 v5, v17, v5                                  // 000000971D58: 060A0B11
	v_dual_add_f32 v19, v19, v29 :: v_dual_add_f32 v12, v20, v12// 000000971D5C: C9083B13 130C1914
	v_dual_add_f32 v13, v13, v33 :: v_dual_add_f32 v16, v16, v31// 000000971D64: C908430D 0D103F10
	v_dual_add_f32 v15, v15, v32 :: v_dual_add_f32 v18, v18, v30// 000000971D6C: C908410F 0F123D12
	ds_store_2addr_b32 v11, v1, v3 offset1:16                  // 000000971D74: D8381000 0003010B
	ds_store_2addr_b32 v11, v2, v6 offset0:128 offset1:144     // 000000971D7C: D8389080 0006020B
	ds_store_2addr_b32 v11, v4, v8 offset0:32 offset1:48       // 000000971D84: D8383020 0008040B
	ds_store_2addr_b32 v11, v5, v9 offset0:160 offset1:176     // 000000971D8C: D838B0A0 0009050B
	ds_store_2addr_b32 v11, v7, v12 offset0:64 offset1:80      // 000000971D94: D8385040 000C070B
	ds_store_2addr_b32 v11, v10, v19 offset0:192 offset1:208   // 000000971D9C: D838D0C0 00130A0B
	ds_store_2addr_b32 v11, v18, v15 offset0:96 offset1:112    // 000000971DA4: D8387060 000F120B
	ds_store_2addr_b32 v11, v16, v13 offset0:224 offset1:240   // 000000971DAC: D838F0E0 000D100B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000971DB4: 8C7E017E
	.long 0xd44c0001                                           // 000000971DB8: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000971DBC: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000971DC4: BF89FC07
	s_barrier                                                  // 000000971DC8: BFBD0000
	buffer_gl0_inv                                             // 000000971DCC: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000971DD4: BE832001
	s_cbranch_execnz 7                                         // 000000971DD8: BFA60007 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1cf8>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000971DDC: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000971DE0: BF048209
	s_mov_b32 s3, -1                                           // 000000971DE4: BE8300C1
	s_cbranch_scc0 33                                          // 000000971DE8: BFA10021 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d70>
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000971DEC: 8B6A037E
	s_cbranch_vccnz 200                                        // 000000971DF0: BFA400C8 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2014>
	s_branch 580                                               // 000000971DF4: BFA00244 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2608>
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000971DF8: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 000000971DFC: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 000000971E04: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 000000971E0C: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000971E14: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000971E18: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000971E1C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000971E20: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000971E24: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000971E28: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 000000971E2C: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000971E34: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000971E38: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000971E3C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000971E40: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000971E44: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000971E48: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000971E4C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000971E50: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000971E54: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 000000971E58: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s3                              // 000000971E60: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000971E64: BF048209
	s_mov_b32 s3, -1                                           // 000000971E68: BE8300C1
	s_cbranch_scc1 65503                                       // 000000971E6C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1cec>
	s_waitcnt lgkmcnt(0)                                       // 000000971E70: BF89FC07
	s_barrier                                                  // 000000971E74: BFBD0000
	buffer_gl0_inv                                             // 000000971E78: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000971E80: BE832001
	s_cbranch_execz 41                                         // 000000971E84: BFA50029 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1e2c>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000971E88: 32020087
	s_ashr_i32 s4, s49, 31                                     // 000000971E8C: 86049F31
	v_lshlrev_b32_e32 v4, 2, v0                                // 000000971E90: 30080082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000971E94: BF8704D2
	v_lshl_or_b32 v1, s30, 1, v1                               // 000000971E98: D6560001 0405021E
	ds_load_b32 v4, v4 offset:8192                             // 000000971EA0: D8D82000 04000004
	.long 0xd72c0003                                           // 000000971EA8: D72C0003
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000971EAC: 02000901
	v_mad_u64_u32 v[1:2], null, v1, s49, 0                     // 000000971EB0: D6FE7C01 02006301
	s_ashr_i32 s4, s30, 31                                     // 000000971EB8: 86049F1E
	s_mul_i32 s4, s4, s49                                      // 000000971EBC: 96043104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000971EC0: BF870149
	v_add3_u32 v2, v2, v3, s4                                  // 000000971EC4: D6550002 00120702
	s_lshl_b32 s4, s10, 7                                      // 000000971ECC: 8404870A
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000971ED0: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 000000971ED8: 86059F04
	.long 0xd73c0001                                           // 000000971EDC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000971EE0: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000971EE4: 84848204
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000971EE8: BF870132
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000971EEC: 30060682
	s_add_u32 s4, s44, s4                                      // 000000971EF0: 8004042C
	s_addc_u32 s5, s45, s5                                     // 000000971EF4: 8205052D
	.long 0xd7006a01                                           // 000000971EF8: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000971EFC: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000971F00: BF870111
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000971F04: D5207C02 01AA0405
	.long 0xd7006a01                                           // 000000971F0C: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000971F10: 02020701
	s_delay_alu instid0(VALU_DEP_1)                            // 000000971F14: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000971F18: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 000000971F20: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 000000971F24: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s3                              // 000000971F2C: 8C7E037E
	.long 0xd44a0003                                           // 000000971F30: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000971F34: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000971F38: BC7C0000
	buffer_gl1_inv                                             // 000000971F3C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000971F44: E0AC0000 00000000
	s_barrier                                                  // 000000971F4C: BFBD0000
	buffer_gl0_inv                                             // 000000971F50: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000971F58: BE842003
	s_cbranch_execz 29                                         // 000000971F5C: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1ed4>
	s_mov_b32 s6, exec_lo                                      // 000000971F60: BE86007E
	s_mov_b32 s5, exec_lo                                      // 000000971F64: BE85007E
	.long 0xd71f0001                                           // 000000971F68: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 000000971F6C: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000971F70: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000971F74: 7D940280
	s_cbranch_execz 9                                          // 000000971F78: BFA50009 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1ea0>
	s_lshl_b64 s[24:25], s[10:11], 2                           // 000000971F7C: 8498820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000971F80: BF8704B9
	s_add_u32 s24, s46, s24                                    // 000000971F84: 8018182E
	s_addc_u32 s25, s47, s25                                   // 000000971F88: 8219192F
	s_bcnt1_i32_b32 s6, s6                                     // 000000971F8C: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 000000971F90: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[24:25] glc             // 000000971F98: DCD64000 02180302
	s_or_b32 exec_lo, exec_lo, s5                              // 000000971FA0: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 000000971FA4: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 000000971FA8: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000971FAC: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 000000971FB0: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 000000971FB8: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000971FBC: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 000000971FC0: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000971FC4: D5010001 01A90280
	ds_store_b32 v2, v1 offset:18432                           // 000000971FCC: D8344800 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 000000971FD4: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 000000971FD8: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000971FDC: BF89FC07
	s_barrier                                                  // 000000971FE0: BFBD0000
	buffer_gl0_inv                                             // 000000971FE4: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:18432                            // 000000971FEC: D8D84800 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000971FF4: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000971FF8: 7C940280
	s_cbranch_vccnz 68                                         // 000000971FFC: BFA40044 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2010>
	buffer_gl1_inv                                             // 000000972000: E0B00000 00000000
	buffer_gl0_inv                                             // 000000972008: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 000000972010: BE842001
	s_cbranch_execz 50                                         // 000000972014: BFA50032 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1fe0>
	v_and_b32_e32 v2, 0x7f, v0                                 // 000000972018: 360400FF 0000007F
	s_lshl_b32 s6, s10, 7                                      // 000000972020: 8406870A
	s_ashr_i32 s1, s49, 31                                     // 000000972024: 86019F31
	s_ashr_i32 s7, s6, 31                                      // 000000972028: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000097202C: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 000000972030: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000972038: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000097203C: BF8700A9
	s_add_u32 s5, s44, s6                                      // 000000972040: 8005062C
	s_addc_u32 s6, s45, s7                                     // 000000972044: 8206072D
	.long 0xd7000503                                           // 000000972048: D7000503
	v_cndmask_b32_e32 v1, s5, v3, vcc_lo                       // 00000097204C: 02020605
	s_delay_alu instid0(VALU_DEP_1)                            // 000000972050: BF870001
	v_add_co_ci_u32_e64 v4, null, s6, 0, s5                    // 000000972054: D5207C04 00150006
	s_mov_b32 s5, s49                                          // 00000097205C: BE850031
	s_nop 0                                                    // 000000972060: BF800000
	s_nop 0                                                    // 000000972064: BF800000
	s_nop 0                                                    // 000000972068: BF800000
	s_nop 0                                                    // 00000097206C: BF800000
	s_nop 0                                                    // 000000972070: BF800000
	s_nop 0                                                    // 000000972074: BF800000
	s_nop 0                                                    // 000000972078: BF800000
	s_nop 0                                                    // 00000097207C: BF800000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000972080: BF8704A9
	v_mad_u64_u32 v[5:6], null, v1, s5, 0                      // 000000972084: D6FE7C05 02000B01
	s_add_i32 s9, s9, -1                                       // 00000097208C: 8109C109
	s_cmp_eq_u32 s9, 0                                         // 000000972090: BF068009
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 000000972094: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 00000097209C: 4A020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009720A0: BF870092
	.long 0xd73c0005                                           // 0000009720A4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000009720A8: 02020A82
	.long 0xd7006a05                                           // 0000009720AC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000009720B0: 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009720B4: BF870001
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 0000009720B8: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 0000009720C0: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000009720C8: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 0000009720CC: 06040B02
	s_cbranch_scc0 65515                                       // 0000009720D0: BFA1FFEB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1f80>
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000009720D4: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 0000009720D8: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s4                              // 0000009720E0: 8C7E047E
	s_and_saveexec_b32 s1, s3                                  // 0000009720E4: BE812003
	s_cbranch_execz 6                                          // 0000009720E8: BFA50006 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2004>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000009720EC: 8484820A
	v_mov_b32_e32 v1, 0                                        // 0000009720F0: 7E020280
	s_add_u32 s4, s46, s4                                      // 0000009720F4: 8004042E
	s_addc_u32 s5, s47, s5                                     // 0000009720F8: 8205052F
	global_store_b32 v1, v1, s[4:5]                            // 0000009720FC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000972104: 8C7E017E
	s_cbranch_execnz 2                                         // 000000972108: BFA60002 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2014>
	s_branch 382                                               // 00000097210C: BFA0017E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2608>
	s_branch 381                                               // 000000972110: BFA0017D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2608>
	v_cmp_gt_i32_e32 vcc_lo, s48, v71                          // 000000972114: 7C888E30
	.long 0xd44c0001                                           // 000000972118: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 00000097211C: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 000000972120: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000972124: BC7C0000
	s_barrier                                                  // 000000972128: BFBD0000
	buffer_gl0_inv                                             // 00000097212C: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 000000972134: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000972138: BF870009
	s_and_saveexec_b32 s3, s1                                  // 00000097213C: BE832001
	s_cbranch_execz 368                                        // 000000972140: BFA50170 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2604>
	v_and_b32_e32 v1, 15, v0                                   // 000000972144: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000972148: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000097214C: 30040282
	v_lshl_or_b32 v2, v71, 9, v2                               // 000000972150: D6560002 04091347
	s_delay_alu instid0(VALU_DEP_1)                            // 000000972158: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 00000097215C: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000972164: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000097216C: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000972174: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000097217C: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000972184: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000972188: 36160082
	s_waitcnt lgkmcnt(3)                                       // 00000097218C: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000972190: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000972198: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000097219C: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000009721A4: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000009721A8: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000009721B0: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000009721B4: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 0000009721BC: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 0000009721C4: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009721C8: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 0000009721CC: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 0000009721D4: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000009721DC: 7C941480
	.long 0xd44a0001                                           // 0000009721E0: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 0000009721E4: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 0000009721E8: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 0000009721F0: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 0000009721F4: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009721F8: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 0000009721FC: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000972200: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000972208: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000097220C: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000972210: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000972214: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000097221C: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000972224: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000097222C: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000972234: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000097223C: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000972244: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000097224C: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000972254: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000097225C: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000972264: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000097226C: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000972274: 7E2402FA FF016103
	v_cndmask_b32_e64 v19, -v3, v3, vcc_lo                     // 00000097227C: D5010013 21AA0703
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 000000972284: D5010015 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 00000097228C: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 000000972290: C9080D07 03082108
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000972298: 7E2802FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 0000009722A0: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009722A8: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009722AC: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000009722B4: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 0000009722BC: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009722C0: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000009722C8: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009722D0: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 0000009722D8: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009722DC: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000009722E4: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 0000009722EC: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000009722F0: D5010008 21AA1108
	v_add_f32_e32 v13, v21, v20                                // 0000009722F8: 061A2915
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009722FC: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 000000972304: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000972308: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000972310: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000972318: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 000000972320: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000972324: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000097232C: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 000000972334: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000972338: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000972340: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 000000972348: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000097234C: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000972354: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 00000097235C: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 000000972360: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 000000972364: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000097236C: 7E0402FA FF016402
	v_add_f32_e32 v6, v6, v11                                  // 000000972374: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000972378: 7E1602FA FF016408
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000972380: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000972388: BF870234
	v_add_f32_e32 v7, v7, v2                                   // 00000097238C: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000972390: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000972398: D5010004 20060904
	v_add_f32_e32 v14, v14, v11                                // 0000009723A0: 061C170E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009723A4: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009723AC: 7E0A02FA FF016807
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009723B4: 7E1002FA FF016806
	v_add_f32_e32 v4, v4, v10                                  // 0000009723BC: 06081504
	v_add_f32_e32 v10, v19, v18                                // 0000009723C0: 06142513
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009723C4: BF8700A1
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009723C8: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000009723D0: D501000A 21AA150A
	v_add_f32_e32 v10, v10, v12                                // 0000009723D8: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 0000009723DC: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009723E0: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000009723E8: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009723F0: BF870214
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009723F4: 7E1E02FA FF01640A
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009723FC: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000972404: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 00000097240C: D501000C 2006190C
	v_add_f32_e32 v16, v9, v13                                 // 000000972414: 06201B09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000972418: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000972420: BF870214
	v_add_f32_e32 v15, v10, v15                                // 000000972424: 061E1F0A
	v_add_f32_e32 v17, v12, v17                                // 000000972428: 0622230C
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000097242C: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000972434: 7E1602FA FF016810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000097243C: BF870214
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000972440: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000972448: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 000000972450: 8B7E007E
	s_cbranch_execz 171                                        // 000000972454: BFA500AB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2604>
	v_lshl_or_b32 v18, s10, 7, v1                              // 000000972458: D6560012 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 000000972460: 36020088
	.long 0x7f2c3880                                           // 000000972464: 7F2C3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000972468: BF870113
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000097246C: 3426249F
	.long 0x7f323996                                           // 000000972470: 7F323996
	.long 0x7f2e3996                                           // 000000972474: 7F2E3996
	.long 0x7f303996                                           // 000000972478: 7F303996
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000097247C: BF870094
	.long 0xd73c0012                                           // 000000972480: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000972484: 02022481
	.long 0xd7006a14                                           // 000000972488: D7006A14
	v_cndmask_b32_e32 v1, s36, v18, vcc_lo                     // 00000097248C: 02022424
	s_delay_alu instid0(VALU_DEP_1)                            // 000000972490: BF870001
	v_add_co_ci_u32_e64 v21, null, s37, v19, vcc_lo            // 000000972494: D5207C15 01AA2625
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000097249C: 7C940280
	s_clause 0x7                                               // 0000009724A0: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 0000009724A4: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 0000009724AC: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 0000009724B4: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 0000009724BC: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 0000009724C4: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 0000009724CC: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 0000009724D4: DC8200C0 1C7C0014
	global_load_d16_b16 v29, v[20:21], off offset:224          // 0000009724DC: DC8200E0 1D7C0014
	v_mad_i64_i32 v[20:21], null, s49, v71, 0                  // 0000009724E4: D6FF7C14 02028E31
	v_cndmask_b32_e64 v1, -v7, v7, vcc_lo                      // 0000009724EC: D5010001 21AA0F07
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000009724F4: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000009724FC: D501000E 21AA1D0E
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000972504: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000097250C: D501000F 21AA1F0F
	v_add_f32_e32 v1, v1, v5                                   // 000000972514: 06020B01
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 000000972518: D5010005 21AA0D06
	.long 0xd73c0014                                           // 000000972520: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000972524: 02022881
	v_cndmask_b32_e64 v6, -v16, v16, vcc_lo                    // 000000972528: D5010006 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000972530: D5010010 21AA2311
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000972538: BF8700B4
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 00000097253C: C9081304 04041105
	v_add_f32_e32 v8, v14, v10                                 // 000000972544: 0610150E
	.long 0xd7006a11                                           // 000000972548: D7006A11
	v_cndmask_b32_e32 v1, s42, v20, vcc_lo                     // 00000097254C: 0202282A
	v_add_co_ci_u32_e64 v20, null, s43, v21, vcc_lo            // 000000972550: D5207C14 01AA2A2B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000972558: BF8701C4
	v_dual_mul_f32 v21, 0x3db504f3, v1 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 00000097255C: C8C602FF 150408FF 3DB504F3
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v6, v6, v11    // 000000972568: C9080503 03061706
	v_dual_add_f32 v9, v15, v12 :: v_dual_add_f32 v10, v16, v13// 000000972570: C908190F 090A1B10
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000972578: 100A0AFF 3DB504F3
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000972580: C8C606FF 030810FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000097258C: BF870214
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000972590: 100C0CFF 3DB504F3
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000972598: 101414FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 0000009725A0: BF891FF7
	.long 0x7f0e3996                                           // 0000009725A4: 7F0E3996
	.long 0xd7006a01                                           // 0000009725A8: D7006A01
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000009725AC: 02022511
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009725B0: BF870001
	v_add_co_ci_u32_e64 v2, null, v20, v19, vcc_lo             // 0000009725B4: D5207C02 01AA2714
	v_fma_mix_f32 v11, v22, v21, neg(0) op_sel_hi:[1,0,0]      // 0000009725BC: CC20000B 8A022B16
	s_waitcnt vmcnt(6)                                         // 0000009725C4: BF891BF7
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 0000009725C8: CC200003 8A020717
	s_waitcnt vmcnt(5)                                         // 0000009725D0: BF8917F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 0000009725D4: CC200005 8A020B18
	s_waitcnt vmcnt(4)                                         // 0000009725DC: BF8913F7
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 0000009725E0: CC200004 8A020919
	s_waitcnt vmcnt(3)                                         // 0000009725E8: BF890FF7
	v_fma_mix_f32 v8, v26, v8, neg(0) op_sel_hi:[1,0,0]        // 0000009725EC: CC200008 8A02111A
	.long 0x7e2c398b                                           // 0000009725F4: 7E2C398B
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 0000009725F8: 101212FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 000000972600: BF890BF7
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 000000972604: CC200006 8A020D1B
	s_waitcnt vmcnt(0)                                         // 00000097260C: BF8903F7
	v_fma_mix_f32 v10, v29, v10, neg(0) op_sel_hi:[1,0,0]      // 000000972610: CC20000A 8A02151D
	.long 0x7e0e3983                                           // 000000972618: 7E0E3983
	v_and_b32_e32 v12, 1, v22                                  // 00000097261C: 36182C81
	.long 0x7e2c3984                                           // 000000972620: 7E2C3984
	v_fma_mix_f32 v9, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 000000972624: CC200009 8A02131C
	.long 0x7e2e3985                                           // 00000097262C: 7E2E3985
	.long 0x7e303988                                           // 000000972630: 7E303988
	v_and_b32_e32 v7, 1, v7                                    // 000000972634: 360E0E81
	v_and_b32_e32 v13, 1, v22                                  // 000000972638: 361A2C81
	.long 0x7e2c3986                                           // 00000097263C: 7E2C3986
	.long 0x7e323989                                           // 000000972640: 7E323989
	v_and_b32_e32 v14, 1, v23                                  // 000000972644: 361C2E81
	v_and_b32_e32 v15, 1, v24                                  // 000000972648: 361E3081
	v_add3_u32 v3, v3, v7, 0x7fff                              // 00000097264C: D6550003 03FE0F03 00007FFF
	v_and_b32_e32 v16, 1, v22                                  // 000000972658: 36202C81
	.long 0x7e2c398a                                           // 00000097265C: 7E2C398A
	v_and_b32_e32 v17, 1, v25                                  // 000000972660: 36223281
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000972664: D655000B 03FE190B 00007FFF
	v_add3_u32 v5, v5, v14, 0x7fff                             // 000000972670: D6550005 03FE1D05 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 00000097267C: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v7, 1, v22                                   // 000000972688: 360E2C81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 00000097268C: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000972698: D6550009 03FE2309 00007FFF
	v_add3_u32 v6, v6, v16, 0x7fff                             // 0000009726A4: D6550006 03FE2106 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009726B0: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 0000009726B4: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 0000009726C0: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 0000009726C4: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v11, off offset:32         // 0000009726CC: DC960020 007C0B01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 0000009726D4: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 0000009726DC: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 0000009726E4: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v6, off offset:160         // 0000009726EC: DC9600A0 007C0601
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 0000009726F4: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v7, off offset:224         // 0000009726FC: DC9600E0 007C0701
	s_or_b32 exec_lo, exec_lo, s3                              // 000000972704: 8C7E037E
	s_mov_b32 s4, 0                                            // 000000972708: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000097270C: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000972710: 8B6A047E
	s_cbranch_vccz 3749                                        // 000000972714: BFA30EA5 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x60ac>
	s_mul_hi_i32 s0, s2, 0x66666667                            // 000000972718: 9700FF02 66666667
	v_mov_b32_e32 v1, 0                                        // 000000972720: 7E020280
	s_lshr_b32 s1, s0, 31                                      // 000000972724: 85019F00
	s_ashr_i32 s0, s0, 1                                       // 000000972728: 86008100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000097272C: BF870499
	s_add_i32 s10, s0, s1                                      // 000000972730: 810A0100
	s_ashr_i32 s11, s10, 31                                    // 000000972734: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000972738: BF870499
	s_lshl_b64 s[0:1], s[10:11], 2                             // 00000097273C: 8480820A
	s_add_u32 s0, s16, s0                                      // 000000972740: 80000010
	s_addc_u32 s1, s17, s1                                     // 000000972744: 82010111
	global_load_b32 v1, v1, s[0:1]                             // 000000972748: DC520000 01000001
	s_mov_b32 s1, exec_lo                                      // 000000972750: BE81007E
	s_waitcnt vmcnt(0)                                         // 000000972754: BF8903F7
	v_readfirstlane_b32 s4, v1                                 // 000000972758: 7E080501
	v_cmpx_gt_u32_e32 0x140, v0                                // 00000097275C: 7D9800FF 00000140
	s_cbranch_execz 42                                         // 000000972764: BFA5002A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2710>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 000000972768: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000972770: 30080084
	s_lshr_b32 s3, s0, 31                                      // 000000972774: 85039F00
	s_ashr_i32 s0, s0, 4                                       // 000000972778: 86008400
	v_or_b32_e32 v3, 0xffffff00, v0                            // 00000097277C: 380600FF FFFFFF00
	s_add_i32 s0, s0, s3                                       // 000000972784: 81000300
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000972788: BF8700D9
	s_mul_i32 s3, s0, 0x1400                                   // 00000097278C: 9603FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 000000972794: 9700FF00 00001400
	s_add_u32 s3, s14, s3                                      // 00000097279C: 8003030E
	s_addc_u32 s0, s15, s0                                     // 0000009727A0: 8200000F
	.long 0xd7000301                                           // 0000009727A4: D7000301
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 0000009727A8: 02020803
	v_add_co_ci_u32_e64 v2, null, s0, 0, s3                    // 0000009727AC: D5207C02 000D0000
	s_mov_b32 s3, 0                                            // 0000009727B4: BE830080
	s_nop 0                                                    // 0000009727B8: BF800000
	s_nop 0                                                    // 0000009727BC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 0000009727C0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 0000009727C8: 4A0606FF 00000100
	.long 0xd7006a01                                           // 0000009727D0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 0000009727D4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009727DC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000009727E0: D5207C02 01AA0480
	.long 0xd4490000                                           // 0000009727E8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 0000009727EC: 020206BF
	s_or_b32 s3, s0, s3                                        // 0000009727F0: 8C030300
	s_waitcnt vmcnt(0)                                         // 0000009727F4: BF8903F7
	ds_store_b128 v4, v[5:8] offset:10240                      // 0000009727F8: DB7C2800 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 000000972800: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000972808: 917E037E
	s_cbranch_execnz 65516                                     // 00000097280C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x26c0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000972810: 8C7E017E
	v_mul_u32_u24_e32 v158, 20, v71                            // 000000972814: 173C8E94
	v_mad_u32_u24 v19, v72, 24, 0x2f0                          // 000000972818: D60B0013 03FD3148 000002F0
	v_cmp_eq_u32_e32 vcc_lo, 0, v72                            // 000000972824: 7C949080
	s_mul_i32 s5, s10, -5                                      // 000000972828: 9605C50A
	s_mul_i32 s1, s4, 0x12c000                                 // 00000097282C: 9601FF04 0012C000
	v_min_u32_e32 v1, 0x8c, v158                               // 000000972834: 26033CFF 0000008C
	v_lshrrev_b32_e32 v2, 5, v19                               // 00000097283C: 32042685
	s_mul_hi_i32 s0, s4, 0x12c000                              // 000000972840: 9700FF04 0012C000
	s_add_i32 s5, s5, s2                                       // 000000972848: 81050205
	s_add_u32 s1, s12, s1                                      // 00000097284C: 8001010C
	v_add_nc_u32_e32 v73, 20, v1                               // 000000972850: 4A920294
	v_subrev_nc_u32_e32 v1, 24, v2                             // 000000972854: 4E020498
	s_addc_u32 s3, s13, s0                                     // 000000972858: 8203000D
	s_mul_i32 s2, s5, 0x3c000                                  // 00000097285C: 9602FF05 0003C000
	v_add_nc_u32_e32 v20, 8, v19                               // 000000972864: 4A282688
	.long 0xd4490000                                           // 000000972868: D4490000
	v_cndmask_b32_e32 v1, v158, v73, vcc_lo                    // 00000097286C: 0202939E
	v_cndmask_b32_e64 v21, v1, 23, vcc_lo                      // 000000972870: D5010015 01A92F01
	s_mul_hi_i32 s6, s5, 0x3c000                               // 000000972878: 9706FF05 0003C000
	s_add_u32 s2, s1, s2                                       // 000000972880: 80020201
	s_addc_u32 s3, s3, s6                                      // 000000972884: 82030603
	s_waitcnt lgkmcnt(0)                                       // 000000972888: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000097288C: BC7C0000
	s_barrier                                                  // 000000972890: BFBD0000
	buffer_gl0_inv                                             // 000000972894: E0AC0000 00000000
	s_and_saveexec_b32 s6, s0                                  // 00000097289C: BE862000
	s_cbranch_execz 190                                        // 0000009728A0: BFA500BE <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2a9c>
	v_lshrrev_b32_e32 v1, 5, v20                               // 0000009728A4: 32022885
	.long 0xd4440001                                           // 0000009728A8: D4440001
	v_cndmask_b32_e32 v1, 23, v21, vcc_lo                      // 0000009728AC: 02022A97
	v_mul_u32_u24_e32 v6, 0x7800, v71                          // 0000009728B0: 160C8EFF 00007800
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009728B8: BF870193
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000009728BC: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 0000009728C0: D5010002 000502FF 000000E9
	v_mov_b32_e32 v22, 0                                       // 0000009728CC: 7E2C0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009728D0: BF870193
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 0000009728D4: D5010001 01A92F01
	v_add_nc_u32_e32 v5, v2, v21                               // 0000009728DC: 4A0A2B02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009728E0: BF870223
	.long 0xd73c0003                                           // 0000009728E4: D73C0003
	v_cndmask_b32_e32 v1, 2, v21, vcc_lo                       // 0000009728E8: 02022A82
	v_mov_b32_e32 v2, v22                                      // 0000009728EC: 7E040316
	.long 0xd4440001                                           // 0000009728F0: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 0000009728F4: 02020297
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009728F8: BF8701A4
	v_lshlrev_b32_e32 v7, 24, v5                               // 0000009728FC: 300E0A98
	v_bfe_i32 v10, v5, 7, 1                                    // 000000972900: D611000A 02050F05
	v_cndmask_b32_e64 v8, 0xe9, 1, s1                          // 000000972908: D5010008 000502FF 000000E9
	.long 0xd700010b                                           // 000000972914: D700010B
	v_cndmask_b32_e32 v1, s2, v6, vcc_lo                       // 000000972918: 02020C02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000097291C: BF870191
	v_add_co_ci_u32_e64 v12, null, s3, 0, s1                   // 000000972920: D5207C0C 00050003
	v_add_nc_u32_e32 v8, v8, v1                                // 000000972928: 4A100308
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000097292C: BF870233
	.long 0xd7000105                                           // 000000972930: D7000105
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 000000972934: 0202070B
	v_ashrrev_i32_e32 v7, 22, v7                               // 000000972938: 340E0E96
	.long 0xd73c0001                                           // 00000097293C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000972940: 02020282
	v_lshlrev_b32_e32 v3, 24, v8                               // 000000972944: 30061098
	v_add_co_ci_u32_e64 v6, null, v12, v4, s1                  // 000000972948: D5207C06 0006090C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000972950: BF870194
	.long 0xd7000109                                           // 000000972954: D7000109
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                      // 000000972958: 02020F0B
	v_ashrrev_i32_e32 v3, 22, v3                               // 00000097295C: 34060696
	v_bfe_i32 v4, v8, 7, 1                                     // 000000972960: D6110004 02050F08
	v_add_co_ci_u32_e64 v10, null, v12, v10, s1                // 000000972968: D5207C0A 0006150C
	.long 0xd700014a                                           // 000000972970: D700014A
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000972974: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000972978: BF8700A1
	v_add_co_ci_u32_e64 v75, null, v12, v2, s1                 // 00000097297C: D5207C4B 0006050C
	.long 0xd700014c                                           // 000000972984: D700014C
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 000000972988: 0202070B
	v_add_co_ci_u32_e64 v77, null, v12, v4, s1                 // 00000097298C: D5207C4D 0006090C
	s_clause 0x1f                                              // 000000972994: BF85001F
	global_load_b32 v68, v[5:6], off                           // 000000972998: DC520000 447C0005
	global_load_b32 v2, v[5:6], off offset:96                  // 0000009729A0: DC520060 027C0005
	global_load_b32 v64, v[5:6], off offset:192                // 0000009729A8: DC5200C0 407C0005
	global_load_b32 v60, v[5:6], off offset:288                // 0000009729B0: DC520120 3C7C0005
	global_load_b32 v56, v[5:6], off offset:384                // 0000009729B8: DC520180 387C0005
	global_load_b32 v52, v[5:6], off offset:480                // 0000009729C0: DC5201E0 347C0005
	global_load_b32 v48, v[5:6], off offset:576                // 0000009729C8: DC520240 307C0005
	global_load_b32 v46, v[5:6], off offset:672                // 0000009729D0: DC5202A0 2E7C0005
	global_load_b32 v67, v[9:10], off                          // 0000009729D8: DC520000 437C0009
	global_load_b32 v1, v[9:10], off offset:96                 // 0000009729E0: DC520060 017C0009
	global_load_b32 v63, v[9:10], off offset:192               // 0000009729E8: DC5200C0 3F7C0009
	global_load_b32 v59, v[9:10], off offset:288               // 0000009729F0: DC520120 3B7C0009
	global_load_b32 v55, v[9:10], off offset:384               // 0000009729F8: DC520180 377C0009
	global_load_b32 v51, v[9:10], off offset:480               // 000000972A00: DC5201E0 337C0009
	global_load_b32 v47, v[9:10], off offset:576               // 000000972A08: DC520240 2F7C0009
	global_load_b32 v45, v[9:10], off offset:672               // 000000972A10: DC5202A0 2D7C0009
	global_load_b32 v70, v[74:75], off                         // 000000972A18: DC520000 467C004A
	global_load_b32 v4, v[74:75], off offset:96                // 000000972A20: DC520060 047C004A
	global_load_b32 v66, v[74:75], off offset:192              // 000000972A28: DC5200C0 427C004A
	global_load_b32 v62, v[74:75], off offset:288              // 000000972A30: DC520120 3E7C004A
	global_load_b32 v58, v[74:75], off offset:384              // 000000972A38: DC520180 3A7C004A
	global_load_b32 v54, v[74:75], off offset:480              // 000000972A40: DC5201E0 367C004A
	global_load_b32 v50, v[74:75], off offset:576              // 000000972A48: DC520240 327C004A
	global_load_b32 v44, v[74:75], off offset:672              // 000000972A50: DC5202A0 2C7C004A
	global_load_b32 v69, v[76:77], off                         // 000000972A58: DC520000 457C004C
	global_load_b32 v3, v[76:77], off offset:96                // 000000972A60: DC520060 037C004C
	global_load_b32 v65, v[76:77], off offset:192              // 000000972A68: DC5200C0 417C004C
	global_load_b32 v61, v[76:77], off offset:288              // 000000972A70: DC520120 3D7C004C
	global_load_b32 v57, v[76:77], off offset:384              // 000000972A78: DC520180 397C004C
	global_load_b32 v53, v[76:77], off offset:480              // 000000972A80: DC5201E0 357C004C
	global_load_b32 v49, v[76:77], off offset:576              // 000000972A88: DC520240 317C004C
	global_load_b32 v43, v[76:77], off offset:672              // 000000972A90: DC5202A0 2B7C004C
	s_clause 0x1f                                              // 000000972A98: BF85001F
	global_load_b32 v40, v[5:6], off offset:768                // 000000972A9C: DC520300 287C0005
	global_load_b32 v36, v[5:6], off offset:864                // 000000972AA4: DC520360 247C0005
	global_load_b32 v32, v[5:6], off offset:960                // 000000972AAC: DC5203C0 207C0005
	global_load_b32 v28, v[5:6], off offset:1056               // 000000972AB4: DC520420 1C7C0005
	global_load_b32 v24, v[5:6], off offset:1152               // 000000972ABC: DC520480 187C0005
	global_load_b32 v16, v[5:6], off offset:1248               // 000000972AC4: DC5204E0 107C0005
	global_load_b32 v12, v[5:6], off offset:1344               // 000000972ACC: DC520540 0C7C0005
	global_load_b32 v8, v[5:6], off offset:1440                // 000000972AD4: DC5205A0 087C0005
	global_load_b32 v39, v[9:10], off offset:768               // 000000972ADC: DC520300 277C0009
	global_load_b32 v35, v[9:10], off offset:864               // 000000972AE4: DC520360 237C0009
	global_load_b32 v31, v[9:10], off offset:960               // 000000972AEC: DC5203C0 1F7C0009
	global_load_b32 v27, v[9:10], off offset:1056              // 000000972AF4: DC520420 1B7C0009
	global_load_b32 v23, v[9:10], off offset:1152              // 000000972AFC: DC520480 177C0009
	global_load_b32 v15, v[9:10], off offset:1248              // 000000972B04: DC5204E0 0F7C0009
	global_load_b32 v11, v[9:10], off offset:1344              // 000000972B0C: DC520540 0B7C0009
	global_load_b32 v7, v[9:10], off offset:1440               // 000000972B14: DC5205A0 077C0009
	global_load_b32 v42, v[74:75], off offset:768              // 000000972B1C: DC520300 2A7C004A
	global_load_b32 v38, v[74:75], off offset:864              // 000000972B24: DC520360 267C004A
	global_load_b32 v34, v[74:75], off offset:960              // 000000972B2C: DC5203C0 227C004A
	global_load_b32 v30, v[74:75], off offset:1056             // 000000972B34: DC520420 1E7C004A
	global_load_b32 v26, v[74:75], off offset:1152             // 000000972B3C: DC520480 1A7C004A
	global_load_b32 v18, v[74:75], off offset:1248             // 000000972B44: DC5204E0 127C004A
	global_load_b32 v14, v[74:75], off offset:1344             // 000000972B4C: DC520540 0E7C004A
	global_load_b32 v6, v[74:75], off offset:1440              // 000000972B54: DC5205A0 067C004A
	global_load_b32 v41, v[76:77], off offset:768              // 000000972B5C: DC520300 297C004C
	global_load_b32 v37, v[76:77], off offset:864              // 000000972B64: DC520360 257C004C
	global_load_b32 v33, v[76:77], off offset:960              // 000000972B6C: DC5203C0 217C004C
	global_load_b32 v29, v[76:77], off offset:1056             // 000000972B74: DC520420 1D7C004C
	global_load_b32 v25, v[76:77], off offset:1152             // 000000972B7C: DC520480 197C004C
	global_load_b32 v17, v[76:77], off offset:1248             // 000000972B84: DC5204E0 117C004C
	global_load_b32 v13, v[76:77], off offset:1344             // 000000972B8C: DC520540 0D7C004C
	global_load_b32 v5, v[76:77], off offset:1440              // 000000972B94: DC5205A0 057C004C
	s_or_b32 exec_lo, exec_lo, s6                              // 000000972B9C: 8C7E067E
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v75, 0             // 000000972BA0: CA100080 0A4A0080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v77, 0             // 000000972BA8: CA100080 4A4C0080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v79, 0             // 000000972BB0: CA100080 4C4E0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v81, 0             // 000000972BB8: CA100080 4E500080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v83, 0             // 000000972BC0: CA100080 50520080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v85, 0             // 000000972BC8: CA100080 52540080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v87, 0             // 000000972BD0: CA100080 54560080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v9, 0              // 000000972BD8: CA100080 56080080
	s_and_saveexec_b32 s1, s0                                  // 000000972BE0: BE812000
	s_cbranch_execz 1967                                       // 000000972BE4: BFA507AF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x49a4>
	v_lshrrev_b32_e32 v9, 5, v20                               // 000000972BE8: 32122885
	v_mul_i32_i24_e32 v20, 0xffffffe8, v72                     // 000000972BEC: 122890FF FFFFFFE8
	v_dual_mov_b32 v10, 0 :: v_dual_and_b32 v19, 0x7e0, v19    // 000000972BF4: CA240080 0A1226FF 000007E0
	v_ashrrev_i32_e32 v22, 31, v21                             // 000000972C00: 342C2A9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000972C04: BF870224
	v_subrev_nc_u32_e32 v9, 24, v9                             // 000000972C08: 4E121298
	.long 0xd4440000                                           // 000000972C0C: D4440000
	v_cndmask_b32_e32 v1, 23, v21, vcc_lo                      // 000000972C10: 02022A97
	v_add3_u32 v89, v20, v19, 0xfffffd34                       // 000000972C14: D6550059 03FE2714 FFFFFD34
	v_lshl_or_b32 v74, v72, 3, 4                               // 000000972C20: D656004A 02110748
	.long 0xd73c0013                                           // 000000972C28: D73C0013
	v_cndmask_b32_e32 v1, 2, v21, vcc_lo                       // 000000972C2C: 02022A82
	v_cndmask_b32_e64 v9, v9, 23, vcc_lo                       // 000000972C30: D5010009 01A92F09
	v_cndmask_b32_e64 v85, 0xe9, 1, s0                         // 000000972C38: D5010055 000102FF 000000E9
	v_and_or_b32 v88, v0, 16, 0x2800                           // 000000972C44: D6570058 03FD2100 00002800
	v_mad_u32_u24 v86, v74, 3, 0x2f0                           // 000000972C50: D60B0056 03FD074A 000002F0
	v_mul_i32_i24_e32 v90, -3, v74                             // 000000972C5C: 12B494C3
	.long 0xd7030016                                           // 000000972C60: D7030016
	v_cndmask_b32_e32 v0, v9, v129, vcc_lo                     // 000000972C64: 02010309
	v_dual_mov_b32 v74, v10 :: v_dual_add_nc_u32 v21, v85, v21 // 000000972C68: CA20010A 4A142B55
	v_mov_b32_e32 v75, v10                                     // 000000972C70: 7E96030A
	v_dual_mov_b32 v76, v10 :: v_dual_and_b32 v91, 0x7e0, v86  // 000000972C74: CA24010A 4C5AACFF 000007E0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000972C80: BF870214
	.long 0xd7624016                                           // 000000972C84: D7624016
	v_cndmask_b32_e32 v1, 0xff, v22, vcc_lo                    // 000000972C88: 02022CFF 000000FF
	v_dual_mov_b32 v79, v10 :: v_dual_and_b32 v92, 0xff, v21   // 000000972C90: CA24010A 4F5C2AFF 000000FF
	v_mov_b32_e32 v80, v10                                     // 000000972C9C: 7EA0030A
	v_mov_b32_e32 v81, v10                                     // 000000972CA0: 7EA2030A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000972CA4: BF870004
	v_cmp_ne_u16_e32 vcc_lo, 24, v150/*Invalid register, operand has 'VGPR_32_Lo128' register class*/// 000000972CA8: 7C7B2C98
	v_mov_b32_e32 v82, v10                                     // 000000972CAC: 7EA4030A
	v_mov_b32_e32 v83, v10                                     // 000000972CB0: 7EA6030A
	v_mov_b32_e32 v84, v10                                     // 000000972CB4: 7EA8030A
	v_mov_b32_e32 v85, v10                                     // 000000972CB8: 7EAA030A
	v_cndmask_b16 v22, 0, v22, vcc_lo                          // 000000972CBC: D65D0016 01AA2C80
	v_mov_b32_e32 v78, v10                                     // 000000972CC4: 7E9C030A
	v_mov_b32_e32 v86, v10                                     // 000000972CC8: 7EAC030A
	v_mov_b32_e32 v87, v10                                     // 000000972CCC: 7EAE030A
	v_add3_u32 v90, v90, v91, 0xfffffd34                       // 000000972CD0: D655005A 03FEB75A FFFFFD34
	v_and_b32_e32 v93, 0xff, v22                               // 000000972CDC: 36BA2CFF 000000FF
	.long 0xd73c0015                                           // 000000972CE4: D73C0015
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000972CE8: 02021282
	v_mov_b32_e32 v77, v10                                     // 000000972CEC: 7E9A030A
	v_lshlrev_b32_e32 v91, 2, v92                              // 000000972CF0: 30B6B882
	s_delay_alu instid0(VALU_DEP_4)                            // 000000972CF4: BF870004
	v_dual_mov_b32 v9, v10 :: v_dual_lshlrev_b32 v92, 2, v93   // 000000972CF8: CA22010A 095CBA82
	s_mov_b32 s0, 0                                            // 000000972D00: BE800080
	s_movk_i32 s6, 0x1eee                                      // 000000972D04: B0061EEE
	s_branch 1734                                              // 000000972D08: BFA006C6 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4724>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000972D0C: 8C7E077E
	s_waitcnt vmcnt(55)                                        // 000000972D10: BF89DFF7
	.long 0xd73d0043                                           // 000000972D14: D73D0043
	v_cndmask_b32_e32 v1, v89, v67, vcc_lo                     // 000000972D18: 02028759
	s_waitcnt vmcnt(39)                                        // 000000972D1C: BF899FF7
	.long 0xd73d0044                                           // 000000972D20: D73D0044
	v_cndmask_b32_e32 v1, v90, v69, vcc_lo                     // 000000972D24: 02028B5A
	.long 0xd73d0045                                           // 000000972D28: D73D0045
	v_cndmask_b32_e32 v1, v89, v1, vcc_lo                      // 000000972D2C: 02020359
	v_lshl_add_u32 v160, v158, 5, v88                          // 000000972D30: D64600A0 05610B9E
	s_waitcnt vmcnt(38)                                        // 000000972D38: BF899BF7
	.long 0xd73d009e                                           // 000000972D3C: D73D009E
	v_cndmask_b32_e32 v1, v90, v3, vcc_lo                      // 000000972D40: 0202075A
	.long 0xd73d003f                                           // 000000972D44: D73D003F
	v_cndmask_b32_e32 v1, v89, v63, vcc_lo                     // 000000972D48: 02027F59
	v_bfe_u32 v70, v67, 9, 16                                  // 000000972D4C: D6100046 02411343
	v_bfe_u32 v159, v67, 6, 16                                 // 000000972D54: D610009F 02410D43
	ds_load_b128 v[1:4], v160                                  // 000000972D5C: DBFC0000 010000A0
	v_bfe_u32 v160, v67, 3, 16                                 // 000000972D64: D61000A0 02410743
	v_and_b32_e32 v67, 0xffff, v67                             // 000000972D6C: 368686FF 0000FFFF
	.long 0xd72c0046                                           // 000000972D74: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000972D78: 02028CFF 83DCD12D
	.long 0xd72c009f                                           // 000000972D80: D72C009F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v159, vcc_lo             // 000000972D84: 02033EFF 83DCD12D
	v_bfe_u32 v161, v68, 9, 16                                 // 000000972D8C: D61000A1 02411344
	v_bfe_u32 v162, v68, 6, 16                                 // 000000972D94: D61000A2 02410D44
	.long 0xd72c0043                                           // 000000972D9C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000972DA0: 020286FF 83DCD12D
	v_bfe_u32 v163, v68, 3, 16                                 // 000000972DA8: D61000A3 02410744
	.long 0xd72c00a0                                           // 000000972DB0: D72C00A0
	v_cndmask_b32_e32 v1, 0x83dcd12d, v160, vcc_lo             // 000000972DB4: 020340FF 83DCD12D
	.long 0xd72c00a1                                           // 000000972DBC: D72C00A1
	v_cndmask_b32_e32 v1, 0x83dcd12d, v161, vcc_lo             // 000000972DC0: 020342FF 83DCD12D
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000972DC8: D6220046 03FD0146 00006400
	v_sad_u8 v159, v159, 0, 0x6400                             // 000000972DD4: D622009F 03FD019F 00006400
	.long 0xd72c00a2                                           // 000000972DE0: D72C00A2
	v_cndmask_b32_e32 v1, 0x83dcd12d, v162, vcc_lo             // 000000972DE4: 020344FF 83DCD12D
	.long 0xd72c00a3                                           // 000000972DEC: D72C00A3
	v_cndmask_b32_e32 v1, 0x83dcd12d, v163, vcc_lo             // 000000972DF0: 020346FF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000972DF8: D6220043 03FD0143 00006400
	v_and_b32_e32 v70, 0xffff, v70                             // 000000972E04: 368C8CFF 0000FFFF
	v_sad_u8 v160, v160, 0, 0x6400                             // 000000972E0C: D62200A0 03FD01A0 00006400
	v_sad_u8 v161, v161, 0, 0x6400                             // 000000972E18: D62200A1 03FD01A1 00006400
	s_waitcnt vmcnt(37)                                        // 000000972E24: BF8997F7
	.long 0xd73d0040                                           // 000000972E28: D73D0040
	v_cndmask_b32_e32 v1, v90, v65, vcc_lo                     // 000000972E2C: 0202835A
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000972E30: 30868690
	v_lshl_or_b32 v70, v159, 16, v70                           // 000000972E34: D6560046 0519219F
	v_sad_u8 v159, v162, 0, 0x6400                             // 000000972E3C: D622009F 03FD01A2 00006400
	v_and_b32_e32 v161, 0xffff, v161                           // 000000972E48: 374342FF 0000FFFF
	v_bfe_u32 v66, v63, 9, 16                                  // 000000972E50: D6100042 0241133F
	v_and_or_b32 v67, 0xffff, v160, v67                        // 000000972E58: D6570043 050F40FF 0000FFFF
	v_pk_fma_f16 v70, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000972E64: CC0E0046 0BFC0D46 0000C931
	v_and_b32_e32 v68, 0xffff, v68                             // 000000972E70: 368888FF 0000FFFF
	v_sad_u8 v160, v163, 0, 0x6400                             // 000000972E78: D62200A0 03FD01A3 00006400
	v_lshl_or_b32 v159, v159, 16, v161                         // 000000972E84: D656009F 0685219F
	v_pk_fma_f16 v67, v67, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000972E8C: CC0E0043 0BFC0D43 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000972E98: BF89FC07
	v_dot2acc_f32_f16 v9, v70, v1                              // 000000972E9C: 04120346
	.long 0xd72c0044                                           // 000000972EA0: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000972EA4: 020288FF 83DCD12D
	v_bfe_u32 v70, v69, 9, 16                                  // 000000972EAC: D6100046 02411345
	v_bfe_u32 v161, v69, 6, 16                                 // 000000972EB4: D61000A1 02410D45
	v_pk_fma_f16 v159, v159, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000972EBC: CC0E009F 0BFC0D9F 0000C931
	.long 0xd72c0042                                           // 000000972EC8: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000972ECC: 020284FF 83DCD12D
	.long 0xd73d003b                                           // 000000972ED4: D73D003B
	v_cndmask_b32_e32 v1, v89, v59, vcc_lo                     // 000000972ED8: 02027759
	s_waitcnt vmcnt(36)                                        // 000000972EDC: BF8993F7
	.long 0xd73d003c                                           // 000000972EE0: D73D003C
	v_cndmask_b32_e32 v1, v90, v61, vcc_lo                     // 000000972EE4: 02027B5A
	.long 0xd72c00a1                                           // 000000972EE8: D72C00A1
	v_cndmask_b32_e32 v1, 0x83dcd12d, v161, vcc_lo             // 000000972EEC: 020342FF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000972EF4: D6220044 03FD0144 00006400
	.long 0xd73d0037                                           // 000000972F00: D73D0037
	v_cndmask_b32_e32 v1, v89, v55, vcc_lo                     // 000000972F04: 02026F59
	.long 0xd73d0033                                           // 000000972F08: D73D0033
	v_cndmask_b32_e32 v1, v89, v51, vcc_lo                     // 000000972F0C: 02026759
	s_waitcnt vmcnt(34)                                        // 000000972F10: BF898BF7
	.long 0xd73d0034                                           // 000000972F14: D73D0034
	v_cndmask_b32_e32 v1, v90, v53, vcc_lo                     // 000000972F18: 02026B5A
	v_dual_dot2acc_f32_f16 v9, v67, v2 :: v_dual_lshlrev_b32 v68, 16, v68// 000000972F1C: CB220543 09448890
	.long 0xd72c0043                                           // 000000972F24: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000972F28: 02028CFF 83DCD12D
	v_bfe_u32 v70, v69, 3, 16                                  // 000000972F30: D6100046 02410745
	v_and_b32_e32 v69, 0xffff, v69                             // 000000972F38: 368A8AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000972F40: BF870004
	v_dot2acc_f32_f16 v9, v159, v3                             // 000000972F44: 0412079F
	v_and_or_b32 v68, 0xffff, v160, v68                        // 000000972F48: D6570044 051340FF 0000FFFF
	v_sad_u8 v161, v161, 0, 0x6400                             // 000000972F54: D62200A1 03FD01A1 00006400
	.long 0xd72c0046                                           // 000000972F60: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000972F64: 02028CFF 83DCD12D
	v_bfe_u32 v159, v158, 9, 16                                // 000000972F6C: D610009F 0241139E
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000972F74: D6220043 03FD0143 00006400
	v_pk_fma_f16 v68, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000972F80: CC0E0044 0BFC0D44 0000C931
	v_bfe_u32 v160, v158, 6, 16                                // 000000972F8C: D61000A0 02410D9E
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000972F94: D6220042 03FD0142 00006400
	.long 0xd72c009f                                           // 000000972FA0: D72C009F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v159, vcc_lo             // 000000972FA4: 02033EFF 83DCD12D
	v_and_b32_e32 v67, 0xffff, v67                             // 000000972FAC: 368686FF 0000FFFF
	v_dot2acc_f32_f16 v9, v68, v4                              // 000000972FB4: 04120944
	.long 0xd72c0044                                           // 000000972FB8: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000972FBC: 02028AFF 83DCD12D
	v_and_b32_e32 v69, 0xffff, v158                            // 000000972FC4: 368B3CFF 0000FFFF
	v_bfe_u32 v158, v158, 3, 16                                // 000000972FCC: D610009E 0241079E
	v_lshl_or_b32 v67, v161, 16, v67                           // 000000972FD4: D6560043 050D21A1
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000972FDC: D6220046 03FD0146 00006400
	.long 0xd72c00a0                                           // 000000972FE8: D72C00A0
	v_cndmask_b32_e32 v1, 0x83dcd12d, v160, vcc_lo             // 000000972FEC: 020340FF 83DCD12D
	.long 0xd72c0045                                           // 000000972FF4: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000972FF8: 02028AFF 83DCD12D
	.long 0xd72c009e                                           // 000000973000: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 000000973004: 02033CFF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 00000097300C: D6220044 03FD0144 00006400
	v_pk_fma_f16 v67, v67, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973018: CC0E0043 0BFC0D43 0000C931
	v_sad_u8 v159, v159, 0, 0x6400                             // 000000973024: D622009F 03FD019F 00006400
	v_bfe_u32 v54, v51, 9, 16                                  // 000000973030: D6100036 02411333
	.long 0xd73d002f                                           // 000000973038: D73D002F
	v_cndmask_b32_e32 v1, v89, v47, vcc_lo                     // 00000097303C: 02025F59
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000973040: BF870244
	v_dual_dot2acc_f32_f16 v87, v67, v1 :: v_dual_lshlrev_b32 v68, 16, v68// 000000973044: CB220343 57448890
	v_sad_u8 v69, v69, 0, 0x6400                               // 00000097304C: D6220045 03FD0145 00006400
	v_and_b32_e32 v159, 0xffff, v159                           // 000000973058: 373F3EFF 0000FFFF
	v_sad_u8 v160, v160, 0, 0x6400                             // 000000973060: D62200A0 03FD01A0 00006400
	v_and_or_b32 v68, 0xffff, v70, v68                         // 00000097306C: D6570044 05128CFF 0000FFFF
	v_sad_u8 v70, v158, 0, 0x6400                              // 000000973078: D6220046 03FD019E 00006400
	v_lshlrev_b32_e32 v69, 16, v69                             // 000000973084: 308A8A90
	.long 0xd72c0036                                           // 000000973088: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 00000097308C: 02026CFF 83DCD12D
	v_lshl_or_b32 v158, v160, 16, v159                         // 000000973094: D656009E 067D21A0
	v_pk_fma_f16 v68, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000097309C: CC0E0044 0BFC0D44 0000C931
	v_and_b32_e32 v159, 0xffff, v64                            // 0000009730A8: 373E80FF 0000FFFF
	v_and_or_b32 v69, 0xffff, v70, v69                         // 0000009730B0: D6570045 05168CFF 0000FFFF
	v_bfe_u32 v70, v63, 6, 16                                  // 0000009730BC: D6100046 02410D3F
	v_pk_fma_f16 v65, v158, s6, 0xc931 op_sel_hi:[1,0,0]       // 0000009730C4: CC0E0041 0BFC0D9E 0000C931
	v_dual_dot2acc_f32_f16 v87, v68, v2 :: v_dual_and_b32 v68, 0xffff, v63// 0000009730D0: CB240544 57447EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009730DC: BF870004
	v_pk_fma_f16 v67, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009730E0: CC0E0043 0BFC0D45 0000C931
	v_bfe_u32 v69, v64, 9, 16                                  // 0000009730EC: D6100045 02411340
	v_bfe_u32 v63, v63, 3, 16                                  // 0000009730F4: D610003F 0241073F
	v_bfe_u32 v158, v64, 6, 16                                 // 0000009730FC: D610009E 02410D40
	.long 0xd72c0044                                           // 000000973104: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000973108: 020288FF 83DCD12D
	.long 0xd72c0046                                           // 000000973110: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000973114: 02028CFF 83DCD12D
	.long 0xd72c0045                                           // 00000097311C: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000973120: 02028AFF 83DCD12D
	.long 0xd72c003f                                           // 000000973128: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 00000097312C: 02027EFF 83DCD12D
	.long 0xd72c009e                                           // 000000973134: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 000000973138: 02033CFF 83DCD12D
	v_bfe_u32 v64, v64, 3, 16                                  // 000000973140: D6100040 02410740
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000973148: D6220036 03FD0136 00006400
	s_waitcnt vmcnt(33)                                        // 000000973154: BF8987F7
	.long 0xd73d0030                                           // 000000973158: D73D0030
	v_cndmask_b32_e32 v1, v90, v49, vcc_lo                     // 00000097315C: 0202635A
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000973160: D6220044 03FD0144 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 00000097316C: D6220046 03FD0146 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000973178: D6220045 03FD0145 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000973184: D622003F 03FD013F 00006400
	v_sad_u8 v158, v158, 0, 0x6400                             // 000000973190: D622009E 03FD019E 00006400
	v_lshlrev_b32_e32 v68, 16, v68                             // 00000097319C: 30888890
	v_dual_dot2acc_f32_f16 v87, v65, v3 :: v_dual_and_b32 v66, 0xffff, v66// 0000009731A0: CB240741 574284FF 0000FFFF
	v_and_b32_e32 v69, 0xffff, v69                             // 0000009731AC: 368A8AFF 0000FFFF
	.long 0xd72c0040                                           // 0000009731B4: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000009731B8: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009731C0: BF870004
	v_and_or_b32 v63, 0xffff, v63, v68                         // 0000009731C4: D657003F 05127EFF 0000FFFF
	.long 0xd72c0044                                           // 0000009731D0: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v159, vcc_lo             // 0000009731D4: 02033EFF 83DCD12D
	v_lshl_or_b32 v66, v70, 16, v66                            // 0000009731DC: D6560042 05092146
	v_lshl_or_b32 v69, v158, 16, v69                           // 0000009731E4: D6560045 0515219E
	v_bfe_u32 v158, v60, 6, 16                                 // 0000009731EC: D610009E 02410D3C
	v_bfe_u32 v159, v60, 3, 16                                 // 0000009731F4: D610009F 0241073C
	v_pk_fma_f16 v63, v63, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009731FC: CC0E003F 0BFC0D3F 0000C931
	v_pk_fma_f16 v65, v66, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973208: CC0E0041 0BFC0D42 0000C931
	v_pk_fma_f16 v66, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973214: CC0E0042 0BFC0D45 0000C931
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000973220: D6220044 03FD0144 00006400
	v_bfe_u32 v69, v59, 9, 16                                  // 00000097322C: D6100045 0241133B
	.long 0xd72c009e                                           // 000000973234: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 000000973238: 02033CFF 83DCD12D
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000973240: D6220040 03FD0140 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000097324C: BF870214
	v_dual_dot2acc_f32_f16 v86, v65, v1 :: v_dual_lshlrev_b32 v61, 16, v68// 000000973250: CB220341 563C8890
	.long 0xd72c003e                                           // 000000973258: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 00000097325C: 02028AFF 83DCD12D
	v_bfe_u32 v68, v59, 6, 16                                  // 000000973264: D6100044 02410D3B
	v_and_b32_e32 v54, 0xffff, v54                             // 00000097326C: 366C6CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000973274: BF870004
	v_dot2acc_f32_f16 v86, v63, v2                             // 000000973278: 04AC053F
	v_and_or_b32 v61, 0xffff, v64, v61                         // 00000097327C: D657003D 04F680FF 0000FFFF
	.long 0xd72c0040                                           // 000000973288: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v159, vcc_lo             // 00000097328C: 02033EFF 83DCD12D
	.long 0xd72c0044                                           // 000000973294: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000973298: 020288FF 83DCD12D
	.long 0xd73d002d                                           // 0000009732A0: D73D002D
	v_cndmask_b32_e32 v1, v89, v45, vcc_lo                     // 0000009732A4: 02025B59
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009732A8: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v86, v66, v3                             // 0000009732B4: 04AC0742
	s_waitcnt vmcnt(32)                                        // 0000009732B8: BF8983F7
	.long 0xd73d002b                                           // 0000009732BC: D73D002B
	v_cndmask_b32_e32 v1, v90, v43, vcc_lo                     // 0000009732C0: 0202575A
	s_waitcnt vmcnt(23)                                        // 0000009732C4: BF895FF7
	.long 0xd73d0027                                           // 0000009732C8: D73D0027
	v_cndmask_b32_e32 v1, v89, v39, vcc_lo                     // 0000009732CC: 02024F59
	s_waitcnt vmcnt(22)                                        // 0000009732D0: BF895BF7
	.long 0xd73d0023                                           // 0000009732D4: D73D0023
	v_cndmask_b32_e32 v1, v89, v35, vcc_lo                     // 0000009732D8: 02024759
	v_and_b32_e32 v62, 0xffff, v62                             // 0000009732DC: 367C7CFF 0000FFFF
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000009732E4: D6220044 03FD0144 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009732F0: D6220040 03FD0140 00006400
	s_waitcnt vmcnt(21)                                        // 0000009732FC: BF8957F7
	.long 0xd73d001f                                           // 000000973300: D73D001F
	v_cndmask_b32_e32 v1, v89, v31, vcc_lo                     // 000000973304: 02023F59
	s_waitcnt vmcnt(20)                                        // 000000973308: BF8953F7
	.long 0xd73d001b                                           // 00000097330C: D73D001B
	v_cndmask_b32_e32 v1, v89, v27, vcc_lo                     // 000000973310: 02023759
	s_waitcnt vmcnt(19)                                        // 000000973314: BF894FF7
	.long 0xd73d0017                                           // 000000973318: D73D0017
	v_cndmask_b32_e32 v1, v89, v23, vcc_lo                     // 00000097331C: 02022F59
	v_lshl_or_b32 v62, v68, 16, v62                            // 000000973320: D656003E 04F92144
	s_waitcnt vmcnt(18)                                        // 000000973328: BF894BF7
	.long 0xd73d000f                                           // 00000097332C: D73D000F
	v_cndmask_b32_e32 v1, v89, v15, vcc_lo                     // 000000973330: 02021F59
	s_waitcnt vmcnt(17)                                        // 000000973334: BF8947F7
	.long 0xd73d000b                                           // 000000973338: D73D000B
	v_cndmask_b32_e32 v1, v89, v11, vcc_lo                     // 00000097333C: 02021759
	s_waitcnt vmcnt(1)                                         // 000000973340: BF8907F7
	.long 0xd73d000c                                           // 000000973344: D73D000C
	v_cndmask_b32_e32 v1, v90, v13, vcc_lo                     // 000000973348: 02021B5A
	.long 0xd73d0007                                           // 00000097334C: D73D0007
	v_cndmask_b32_e32 v1, v89, v7, vcc_lo                      // 000000973350: 02020F59
	v_pk_fma_f16 v62, v62, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973354: CC0E003E 0BFC0D3E 0000C931
	v_and_b32_e32 v70, 0xffff, v59                             // 000000973360: 368C76FF 0000FFFF
	v_bfe_u32 v59, v59, 3, 16                                  // 000000973368: D610003B 0241073B
	v_bfe_u32 v14, v11, 9, 16                                  // 000000973370: D610000E 0241130B
	s_waitcnt vmcnt(0)                                         // 000000973378: BF8903F7
	.long 0xd73d0005                                           // 00000097337C: D73D0005
	v_cndmask_b32_e32 v1, v90, v5, vcc_lo                      // 000000973380: 02020B5A
	v_dot2acc_f32_f16 v85, v62, v1                             // 000000973384: 04AA033E
	.long 0xd72c0045                                           // 000000973388: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 00000097338C: 02028CFF 83DCD12D
	.long 0xd72c003b                                           // 000000973394: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000973398: 020276FF 83DCD12D
	v_bfe_u32 v70, v60, 9, 16                                  // 0000009733A0: D6100046 0241133C
	.long 0xd72c000e                                           // 0000009733A8: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 0000009733AC: 02021CFF 83DCD12D
	v_cmp_eq_u32_e32 vcc_lo, v157, v73                         // 0000009733B4: 7C94939D
	v_dual_mov_b32 v66, v126 :: v_dual_dot2acc_f32_f16 v87, v67, v4// 0000009733B8: CA18017E 42560943
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009733C0: BF870004
	.long 0xd72c0046                                           // 0000009733C4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 0000009733C8: 02028CFF 83DCD12D
	v_sad_u8 v69, v69, 0, 0x6400                               // 0000009733D0: D6220045 03FD0145 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009733DC: D622003B 03FD013B 00006400
	s_or_b32 s0, vcc_lo, s0                                    // 0000009733E8: 8C00006A
	v_sad_u8 v14, v14, 0, 0x6400                               // 0000009733EC: D622000E 03FD010E 00006400
	v_mov_b32_e32 v67, v125                                    // 0000009733F8: 7E86037D
	v_lshlrev_b32_e32 v69, 16, v69                             // 0000009733FC: 308A8A90
	v_mov_b32_e32 v63, v118                                    // 000000973400: 7E7E0376
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000973404: D6220046 03FD0146 00006400
	v_and_b32_e32 v14, 0xffff, v14                             // 000000973410: 361C1CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000973418: BF870224
	v_and_or_b32 v59, 0xffff, v59, v69                         // 00000097341C: D657003B 051676FF 0000FFFF
	v_sad_u8 v69, v158, 0, 0x6400                              // 000000973428: D6220045 03FD019E 00006400
	v_and_b32_e32 v68, 0xffff, v70                             // 000000973434: 36888CFF 0000FFFF
	v_mov_b32_e32 v70, v133                                    // 00000097343C: 7E8C0385
	v_mov_b32_e32 v158, v157                                   // 000000973440: 7F3C039D
	v_pk_fma_f16 v59, v59, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973444: CC0E003B 0BFC0D3B 0000C931
	v_and_b32_e32 v60, 0xffff, v60                             // 000000973450: 367878FF 0000FFFF
	v_lshl_or_b32 v65, v69, 16, v68                            // 000000973458: D6560041 05112145
	v_dual_mov_b32 v69, v141 :: v_dual_mov_b32 v68, v100       // 000000973460: CA10018D 45440164
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000973468: BF870214
	v_dot2acc_f32_f16 v85, v59, v2                             // 00000097346C: 04AA053B
	.long 0xd72c003c                                           // 000000973470: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000973474: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000097347C: BF870244
	v_pk_fma_f16 v56, v65, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973480: CC0E0038 0BFC0D41 0000C931
	v_pk_fma_f16 v59, v61, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000097348C: CC0E003B 0BFC0D3D 0000C931
	v_bfe_u32 v61, v55, 9, 16                                  // 000000973498: D610003D 02411337
	v_mov_b32_e32 v65, v134                                    // 0000009734A0: 7E820386
	v_dot2acc_f32_f16 v85, v56, v3                             // 0000009734A4: 04AA0738
	.long 0xd73d0038                                           // 0000009734A8: D73D0038
	v_cndmask_b32_e32 v1, v90, v57, vcc_lo                     // 0000009734AC: 0202735A
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009734B0: D622003C 03FD013C 00006400
	.long 0xd72c0039                                           // 0000009734BC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000009734C0: 02027AFF 83DCD12D
	v_dot2acc_f32_f16 v86, v59, v4                             // 0000009734C8: 04AC093B
	v_bfe_u32 v58, v55, 6, 16                                  // 0000009734CC: D610003A 02410D37
	v_bfe_u32 v59, v55, 3, 16                                  // 0000009734D4: D610003B 02410737
	v_lshlrev_b32_e32 v60, 16, v60                             // 0000009734DC: 30787890
	v_and_b32_e32 v55, 0xffff, v55                             // 0000009734E0: 366E6EFF 0000FFFF
	v_bfe_u32 v61, v56, 6, 16                                  // 0000009734E8: D610003D 02410D38
	.long 0xd72c003a                                           // 0000009734F0: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009734F4: 020274FF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009734FC: D6220039 03FD0139 00006400
	v_and_or_b32 v60, 0xffff, v64, v60                         // 000000973508: D657003C 04F280FF 0000FFFF
	.long 0xd72c0037                                           // 000000973514: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000973518: 02026EFF 83DCD12D
	.long 0xd72c003b                                           // 000000973520: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000973524: 020276FF 83DCD12D
	.long 0xd72c003d                                           // 00000097352C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000973530: 02027AFF 83DCD12D
	v_and_b32_e32 v57, 0xffff, v57                             // 000000973538: 367272FF 0000FFFF
	v_pk_fma_f16 v60, v60, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973540: CC0E003C 0BFC0D3C 0000C931
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000097354C: D622003A 03FD013A 00006400
	v_mov_b32_e32 v64, v98                                     // 000000973558: 7E800362
	v_sad_u8 v55, v55, 0, 0x6400                               // 00000097355C: D6220037 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000973568: BF870004
	v_dot2acc_f32_f16 v85, v60, v4                             // 00000097356C: 04AA093C
	v_bfe_u32 v60, v56, 9, 16                                  // 000000973570: D610003C 02411338
	v_lshl_or_b32 v57, v58, 16, v57                            // 000000973578: D6560039 04E5213A
	v_sad_u8 v58, v59, 0, 0x6400                               // 000000973580: D622003A 03FD013B 00006400
	v_lshlrev_b32_e32 v55, 16, v55                             // 00000097358C: 306E6E90
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000973590: D622003D 03FD013D 00006400
	.long 0xd72c003c                                           // 00000097359C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000009735A0: 020278FF 83DCD12D
	v_pk_fma_f16 v57, v57, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009735A8: CC0E0039 0BFC0D39 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009735B4: BF870114
	v_and_or_b32 v55, 0xffff, v58, v55                         // 0000009735B8: D6570037 04DE74FF 0000FFFF
	v_dot2acc_f32_f16 v84, v57, v1                             // 0000009735C4: 04A80339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009735C8: BF870194
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009735CC: D622003C 03FD013C 00006400
	v_pk_fma_f16 v53, v55, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009735D8: CC0E0035 0BFC0D37 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009735E4: BF870112
	v_and_b32_e32 v60, 0xffff, v60                             // 0000009735E8: 367878FF 0000FFFF
	v_dot2acc_f32_f16 v84, v53, v2                             // 0000009735F0: 04A80535
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009735F4: BF8701B2
	v_lshl_or_b32 v58, v61, 16, v60                            // 0000009735F8: D656003A 04F1213D
	v_bfe_u32 v60, v51, 6, 16                                  // 000000973600: D610003C 02410D33
	v_bfe_u32 v61, v52, 6, 16                                  // 000000973608: D610003D 02410D34
	v_pk_fma_f16 v55, v58, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973610: CC0E0037 0BFC0D3A 0000C931
	v_and_b32_e32 v58, 0xffff, v51                             // 00000097361C: 367466FF 0000FFFF
	v_bfe_u32 v51, v51, 3, 16                                  // 000000973624: D6100033 02410733
	.long 0xd72c003c                                           // 00000097362C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000973630: 020278FF 83DCD12D
	.long 0xd72c0039                                           // 000000973638: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 00000097363C: 02027AFF 83DCD12D
	v_bfe_u32 v61, v52, 3, 16                                  // 000000973644: D610003D 02410734
	.long 0xd72c003a                                           // 00000097364C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000973650: 020274FF 83DCD12D
	.long 0xd72c0033                                           // 000000973658: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 00000097365C: 020266FF 83DCD12D
	v_dual_dot2acc_f32_f16 v84, v55, v3 :: v_dual_mov_b32 v55, v105// 000000973664: CB100737 54360169
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000097366C: D622003C 03FD013C 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000973678: D6220039 03FD0139 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000973684: D622003A 03FD013A 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000973690: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000097369C: BF870224
	v_lshl_or_b32 v54, v60, 16, v54                            // 0000009736A0: D6560036 04D9213C
	v_bfe_u32 v60, v48, 6, 16                                  // 0000009736A8: D610003C 02410D30
	v_lshlrev_b32_e32 v58, 16, v58                             // 0000009736B0: 30747490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009736B4: BF870193
	v_pk_fma_f16 v53, v54, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009736B8: CC0E0035 0BFC0D36 0000C931
	.long 0xd72c003c                                           // 0000009736C4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000009736C8: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009736D0: BF870223
	v_and_or_b32 v51, 0xffff, v51, v58                         // 0000009736D4: D6570033 04EA66FF 0000FFFF
	.long 0xd72c003a                                           // 0000009736E0: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000009736E4: 02027AFF 83DCD12D
	v_dot2acc_f32_f16 v83, v53, v1                             // 0000009736EC: 04A60335
	v_bfe_u32 v61, v48, 3, 16                                  // 0000009736F0: D610003D 02410730
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009736F8: BF870244
	v_pk_fma_f16 v51, v51, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009736FC: CC0E0033 0BFC0D33 0000C931
	v_and_b32_e32 v62, 0xffff, v56                             // 000000973708: 367C70FF 0000FFFF
	v_bfe_u32 v56, v56, 3, 16                                  // 000000973710: D6100038 02410738
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000973718: D622003A 03FD013A 00006400
	v_dot2acc_f32_f16 v83, v51, v2                             // 000000973724: 04A60533
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000973728: BF870214
	.long 0xd72c003e                                           // 00000097372C: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000973730: 02027CFF 83DCD12D
	.long 0xd72c0038                                           // 000000973738: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000097373C: 020270FF 83DCD12D
	v_mov_b32_e32 v51, v103                                    // 000000973744: 7E660367
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000973748: BF870193
	v_sad_u8 v59, v62, 0, 0x6400                               // 00000097374C: D622003B 03FD013E 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000973758: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000973764: BF870092
	v_dual_mov_b32 v62, v122 :: v_dual_lshlrev_b32 v59, 16, v59// 000000973768: CA22017A 3E3A7690
	v_and_or_b32 v56, 0xffff, v56, v59                         // 000000973770: D6570038 04EE70FF 0000FFFF
	v_bfe_u32 v59, v52, 9, 16                                  // 00000097377C: D610003B 02411334
	v_and_b32_e32 v52, 0xffff, v52                             // 000000973784: 366868FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000097378C: BF870193
	v_pk_fma_f16 v56, v56, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973790: CC0E0038 0BFC0D38 0000C931
	.long 0xd72c003b                                           // 00000097379C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009737A0: 020276FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009737A8: BF870193
	.long 0xd72c0034                                           // 0000009737AC: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009737B0: 020268FF 83DCD12D
	v_dot2acc_f32_f16 v84, v56, v4                             // 0000009737B8: 04A80938
	v_mov_b32_e32 v56, v96                                     // 0000009737BC: 7E700360
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009737C0: BF870214
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009737C4: D622003B 03FD013B 00006400
	v_sad_u8 v49, v52, 0, 0x6400                               // 0000009737D0: D6220031 03FD0134 00006400
	v_bfe_u32 v52, v47, 6, 16                                  // 0000009737DC: D6100034 02410D2F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009737E4: BF870193
	v_and_b32_e32 v59, 0xffff, v59                             // 0000009737E8: 367676FF 0000FFFF
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000009737F0: 30626290
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009737F4: BF870193
	.long 0xd72c0034                                           // 0000009737F8: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009737FC: 020268FF 83DCD12D
	v_lshl_or_b32 v57, v57, 16, v59                            // 000000973804: D6560039 04ED2139
	v_and_b32_e32 v59, 0xffff, v47                             // 00000097380C: 36765EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000973814: BF870224
	v_and_or_b32 v49, 0xffff, v58, v49                         // 000000973818: D6570031 04C674FF 0000FFFF
	v_mov_b32_e32 v58, v119                                    // 000000973824: 7E740377
	v_pk_fma_f16 v54, v57, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973828: CC0E0036 0BFC0D39 0000C931
	v_bfe_u32 v57, v47, 9, 16                                  // 000000973834: D6100039 0241132F
	v_bfe_u32 v47, v47, 3, 16                                  // 00000097383C: D610002F 0241072F
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000973844: D6220034 03FD0134 00006400
	v_pk_fma_f16 v46, v49, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973850: CC0E002E 0BFC0D31 0000C931
	v_dot2acc_f32_f16 v83, v54, v3                             // 00000097385C: 04A60736
	.long 0xd72c0032                                           // 000000973860: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000973864: 020272FF 83DCD12D
	.long 0xd72c0039                                           // 00000097386C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000973870: 020276FF 83DCD12D
	v_bfe_u32 v59, v48, 9, 16                                  // 000000973878: D610003B 02411330
	v_and_b32_e32 v48, 0xffff, v48                             // 000000973880: 366060FF 0000FFFF
	.long 0xd72c002f                                           // 000000973888: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000097388C: 02025EFF 83DCD12D
	v_dot2acc_f32_f16 v83, v46, v4                             // 000000973894: 04A6092E
	v_bfe_u32 v46, v45, 6, 16                                  // 000000973898: D610002E 02410D2D
	.long 0xd72c003b                                           // 0000009738A0: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009738A4: 020276FF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009738AC: D6220032 03FD0132 00006400
	.long 0xd72c0030                                           // 0000009738B8: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000009738BC: 020260FF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009738C4: D6220039 03FD0139 00006400
	.long 0xd72c002e                                           // 0000009738D0: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000009738D4: 02025CFF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009738DC: D622002F 03FD012F 00006400
	v_and_b32_e32 v50, 0xffff, v50                             // 0000009738E8: 366464FF 0000FFFF
	v_bfe_u32 v49, v43, 6, 16                                  // 0000009738F0: D6100031 02410D2B
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000009738F8: 30727290
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009738FC: D622003B 03FD013B 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000973908: D6220030 03FD0130 00006400
	v_lshl_or_b32 v50, v52, 16, v50                            // 000000973914: D6560032 04C92134
	.long 0xd72c0034                                           // 00000097391C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000973920: 02027AFF 83DCD12D
	v_and_or_b32 v47, 0xffff, v47, v57                         // 000000973928: D657002F 04E65EFF 0000FFFF
	v_and_b32_e32 v57, 0xffff, v59                             // 000000973934: 367276FF 0000FFFF
	v_sad_u8 v59, v60, 0, 0x6400                               // 00000097393C: D622003B 03FD013C 00006400
	v_pk_fma_f16 v50, v50, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973948: CC0E0032 0BFC0D32 0000C931
	v_lshlrev_b32_e32 v48, 16, v48                             // 000000973954: 30606090
	v_pk_fma_f16 v47, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973958: CC0E002F 0BFC0D2F 0000C931
	.long 0xd72c0031                                           // 000000973964: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000973968: 020262FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000973970: D6220034 03FD0134 00006400
	v_lshl_or_b32 v53, v59, 16, v57                            // 00000097397C: D6560035 04E5213B
	v_dot2acc_f32_f16 v82, v50, v1                             // 000000973984: 04A40332
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000973988: D622002E 03FD012E 00006400
	v_mov_b32_e32 v54, v108                                    // 000000973994: 7E6C036C
	v_and_or_b32 v48, 0xffff, v52, v48                         // 000000973998: D6570030 04C268FF 0000FFFF
	v_pk_fma_f16 v50, v53, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009739A4: CC0E0032 0BFC0D35 0000C931
	v_dot2acc_f32_f16 v82, v47, v2                             // 0000009739B0: 04A4052F
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009739B4: D6220031 03FD0131 00006400
	v_mov_b32_e32 v53, v123                                    // 0000009739C0: 7E6A037B
	v_pk_fma_f16 v47, v48, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009739C4: CC0E002F 0BFC0D30 0000C931
	v_bfe_u32 v48, v45, 9, 16                                  // 0000009739D0: D6100030 0241132D
	v_dot2acc_f32_f16 v82, v50, v3                             // 0000009739D8: 04A40732
	v_bfe_u32 v50, v43, 3, 16                                  // 0000009739DC: D6100032 0241072B
	v_mov_b32_e32 v52, v95                                     // 0000009739E4: 7E68035F
	v_mov_b32_e32 v57, v127                                    // 0000009739E8: 7E72037F
	.long 0xd72c002c                                           // 0000009739EC: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000009739F0: 020260FF 83DCD12D
	v_bfe_u32 v48, v43, 9, 16                                  // 0000009739F8: D6100030 0241132B
	v_dual_dot2acc_f32_f16 v82, v47, v4 :: v_dual_and_b32 v47, 0xffff, v45// 000000973A00: CB24092F 522E5AFF 0000FFFF
	v_bfe_u32 v45, v45, 3, 16                                  // 000000973A0C: D610002D 0241072D
	v_and_b32_e32 v43, 0xffff, v43                             // 000000973A14: 365656FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000973A1C: BF870004
	.long 0xd72c0030                                           // 000000973A20: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000973A24: 020260FF 83DCD12D
	v_mov_b32_e32 v59, v107                                    // 000000973A2C: 7E76036B
	.long 0xd72c002f                                           // 000000973A30: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000973A34: 02025EFF 83DCD12D
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000973A3C: D622002C 03FD012C 00006400
	.long 0xd72c002d                                           // 000000973A48: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000973A4C: 02025AFF 83DCD12D
	.long 0xd72c002b                                           // 000000973A54: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000973A58: 020256FF 83DCD12D
	v_dual_mov_b32 v60, v97 :: v_dual_mov_b32 v61, v130        // 000000973A60: CA100161 3C3C0182
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000973A68: BF870244
	v_and_b32_e32 v44, 0xffff, v44                             // 000000973A6C: 365858FF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000973A74: D6220030 03FD0130 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000973A80: D622002F 03FD012F 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000973A8C: D622002D 03FD012D 00006400
	v_lshl_or_b32 v44, v46, 16, v44                            // 000000973A98: D656002C 04B1212E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000973AA0: BF870004
	v_and_b32_e32 v46, 0xffff, v48                             // 000000973AA4: 365C60FF 0000FFFF
	.long 0xd72c0030                                           // 000000973AAC: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000973AB0: 020264FF 83DCD12D
	v_lshlrev_b32_e32 v47, 16, v47                             // 000000973AB8: 305E5E90
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000973ABC: D622002B 03FD012B 00006400
	v_pk_fma_f16 v44, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973AC8: CC0E002C 0BFC0D2C 0000C931
	v_lshl_or_b32 v40, v49, 16, v46                            // 000000973AD4: D6560028 04B92131
	v_and_b32_e32 v49, 0xffff, v39                             // 000000973ADC: 36624EFF 0000FFFF
	v_and_or_b32 v45, 0xffff, v45, v47                         // 000000973AE4: D657002D 04BE5AFF 0000FFFF
	v_lshlrev_b32_e32 v43, 16, v43                             // 000000973AF0: 30565690
	v_sad_u8 v46, v48, 0, 0x6400                               // 000000973AF4: D622002E 03FD0130 00006400
	v_bfe_u32 v47, v39, 9, 16                                  // 000000973B00: D610002F 02411327
	v_pk_fma_f16 v48, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973B08: CC0E0030 0BFC0D28 0000C931
	.long 0xd73d0028                                           // 000000973B14: D73D0028
	v_cndmask_b32_e32 v1, v90, v41, vcc_lo                     // 000000973B18: 0202535A
	v_pk_fma_f16 v45, v45, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973B1C: CC0E002D 0BFC0D2D 0000C931
	v_and_or_b32 v41, 0xffff, v46, v43                         // 000000973B28: D6570029 04AE5CFF 0000FFFF
	.long 0xd72c002a                                           // 000000973B34: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000973B38: 02025EFF 83DCD12D
	v_bfe_u32 v43, v39, 6, 16                                  // 000000973B40: D610002B 02410D27
	v_dot2acc_f32_f16 v81, v44, v1                             // 000000973B48: 04A2032C
	v_bfe_u32 v39, v39, 3, 16                                  // 000000973B4C: D6100027 02410727
	.long 0xd72c002e                                           // 000000973B54: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000973B58: 020262FF 83DCD12D
	v_bfe_u32 v47, v40, 9, 16                                  // 000000973B60: D610002F 02411328
	.long 0xd72c002b                                           // 000000973B68: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000973B6C: 020256FF 83DCD12D
	v_dot2acc_f32_f16 v81, v45, v2                             // 000000973B74: 04A2052D
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000973B78: D622002A 03FD012A 00006400
	.long 0xd72c0027                                           // 000000973B84: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000973B88: 02024EFF 83DCD12D
	v_bfe_u32 v49, v40, 6, 16                                  // 000000973B90: D6100031 02410D28
	.long 0xd72c002f                                           // 000000973B98: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000973B9C: 02025EFF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000973BA4: D622002E 03FD012E 00006400
	v_pk_fma_f16 v36, v41, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973BB0: CC0E0024 0BFC0D29 0000C931
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000973BBC: D622002B 03FD012B 00006400
	v_dual_dot2acc_f32_f16 v81, v48, v3 :: v_dual_and_b32 v42, 0xffff, v42// 000000973BC8: CB240730 512A54FF 0000FFFF
	.long 0xd72c0031                                           // 000000973BD4: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000973BD8: 020262FF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000973BE0: D6220027 03FD0127 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000973BEC: BF870213
	v_dual_dot2acc_f32_f16 v81, v36, v4 :: v_dual_lshlrev_b32 v46, 16, v46// 000000973BF0: CB220924 512E5C90
	v_lshl_or_b32 v42, v43, 16, v42                            // 000000973BF8: D656002A 04A9212B
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000973C00: D622002F 03FD012F 00006400
	v_bfe_u32 v50, v40, 3, 16                                  // 000000973C0C: D6100032 02410728
	v_and_b32_e32 v40, 0xffff, v40                             // 000000973C14: 365050FF 0000FFFF
	v_and_or_b32 v39, 0xffff, v39, v46                         // 000000973C1C: D6570027 04BA4EFF 0000FFFF
	v_pk_fma_f16 v42, v42, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973C28: CC0E002A 0BFC0D2A 0000C931
	v_and_b32_e32 v44, 0xffff, v47                             // 000000973C34: 36585EFF 0000FFFF
	v_sad_u8 v46, v49, 0, 0x6400                               // 000000973C3C: D622002E 03FD0131 00006400
	.long 0xd72c0028                                           // 000000973C48: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000973C4C: 020250FF 83DCD12D
	v_pk_fma_f16 v39, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973C54: CC0E0027 0BFC0D27 0000C931
	v_dot2acc_f32_f16 v80, v42, v1                             // 000000973C60: 04A0032A
	.long 0xd72c002b                                           // 000000973C64: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000973C68: 020264FF 83DCD12D
	v_lshl_or_b32 v44, v46, 16, v44                            // 000000973C70: D656002C 04B1212E
	.long 0xd73d0024                                           // 000000973C78: D73D0024
	v_cndmask_b32_e32 v1, v90, v37, vcc_lo                     // 000000973C7C: 02024B5A
	v_bfe_u32 v38, v35, 6, 16                                  // 000000973C80: D6100026 02410D23
	v_dot2acc_f32_f16 v80, v39, v2                             // 000000973C88: 04A00527
	v_bfe_u32 v39, v35, 9, 16                                  // 000000973C8C: D6100027 02411323
	v_pk_fma_f16 v41, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973C94: CC0E0029 0BFC0D2C 0000C931
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000973CA0: D6220028 03FD0128 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000973CAC: D622002B 03FD012B 00006400
	.long 0xd72c0026                                           // 000000973CB8: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000973CBC: 02024CFF 83DCD12D
	.long 0xd72c0025                                           // 000000973CC4: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000973CC8: 02024EFF 83DCD12D
	v_dot2acc_f32_f16 v80, v41, v3                             // 000000973CD0: 04A00729
	v_bfe_u32 v41, v36, 9, 16                                  // 000000973CD4: D6100029 02411324
	v_lshlrev_b32_e32 v40, 16, v40                             // 000000973CDC: 30505090
	v_and_b32_e32 v39, 0xffff, v35                             // 000000973CE0: 364E46FF 0000FFFF
	v_bfe_u32 v42, v36, 6, 16                                  // 000000973CE8: D610002A 02410D24
	v_bfe_u32 v35, v35, 3, 16                                  // 000000973CF0: D6100023 02410723
	.long 0xd72c0029                                           // 000000973CF8: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 000000973CFC: 020252FF 83DCD12D
	v_and_or_b32 v40, 0xffff, v43, v40                         // 000000973D04: D6570028 04A256FF 0000FFFF
	.long 0xd72c0027                                           // 000000973D10: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000973D14: 02024EFF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000973D1C: D6220025 03FD0125 00006400
	v_bfe_u32 v43, v36, 3, 16                                  // 000000973D28: D610002B 02410724
	v_and_b32_e32 v36, 0xffff, v36                             // 000000973D30: 364848FF 0000FFFF
	.long 0xd72c002a                                           // 000000973D38: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000973D3C: 020254FF 83DCD12D
	.long 0xd72c0023                                           // 000000973D44: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000973D48: 020246FF 83DCD12D
	v_and_b32_e32 v37, 0xffff, v37                             // 000000973D50: 364A4AFF 0000FFFF
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000973D58: D6220026 03FD0126 00006400
	.long 0xd72c0024                                           // 000000973D64: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000973D68: 020248FF 83DCD12D
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000973D70: D6220029 03FD0129 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000973D7C: D6220027 03FD0127 00006400
	v_pk_fma_f16 v40, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973D88: CC0E0028 0BFC0D28 0000C931
	v_lshl_or_b32 v37, v38, 16, v37                            // 000000973D94: D6560025 04952126
	.long 0xd72c0026                                           // 000000973D9C: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000973DA0: 020256FF 83DCD12D
	v_and_b32_e32 v41, 0xffff, v41                             // 000000973DA8: 365252FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000973DB0: D622002A 03FD012A 00006400
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000973DBC: D6220023 03FD0123 00006400
	v_lshlrev_b32_e32 v39, 16, v39                             // 000000973DC8: 304E4E90
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000973DCC: D6220024 03FD0124 00006400
	v_pk_fma_f16 v37, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973DD8: CC0E0025 0BFC0D25 0000C931
	v_lshl_or_b32 v32, v42, 16, v41                            // 000000973DE4: D6560020 04A5212A
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000973DEC: D6220026 03FD0126 00006400
	v_and_or_b32 v35, 0xffff, v35, v39                         // 000000973DF8: D6570023 049E46FF 0000FFFF
	v_lshlrev_b32_e32 v36, 16, v36                             // 000000973E04: 30484890
	v_bfe_u32 v39, v31, 9, 16                                  // 000000973E08: D6100027 0241131F
	v_pk_fma_f16 v41, v32, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973E10: CC0E0029 0BFC0D20 0000C931
	.long 0xd73d0020                                           // 000000973E1C: D73D0020
	v_cndmask_b32_e32 v1, v90, v33, vcc_lo                     // 000000973E20: 0202435A
	v_and_b32_e32 v34, 0xffff, v31                             // 000000973E24: 36443EFF 0000FFFF
	v_and_or_b32 v33, 0xffff, v38, v36                         // 000000973E2C: D6570021 04924CFF 0000FFFF
	.long 0xd72c0024                                           // 000000973E38: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000973E3C: 02024EFF 83DCD12D
	v_bfe_u32 v38, v31, 6, 16                                  // 000000973E44: D6100026 02410D1F
	v_bfe_u32 v31, v31, 3, 16                                  // 000000973E4C: D610001F 0241071F
	v_bfe_u32 v39, v32, 9, 16                                  // 000000973E54: D6100027 02411320
	.long 0xd72c0022                                           // 000000973E5C: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000973E60: 020244FF 83DCD12D
	v_bfe_u32 v42, v32, 6, 16                                  // 000000973E68: D610002A 02410D20
	.long 0xd72c0026                                           // 000000973E70: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000973E74: 02024CFF 83DCD12D
	.long 0xd72c001f                                           // 000000973E7C: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000973E80: 02023EFF 83DCD12D
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000973E88: D6220024 03FD0124 00006400
	.long 0xd72c0027                                           // 000000973E94: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000973E98: 02024EFF 83DCD12D
	v_bfe_u32 v43, v32, 3, 16                                  // 000000973EA0: D610002B 02410720
	v_and_b32_e32 v32, 0xffff, v32                             // 000000973EA8: 364040FF 0000FFFF
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000973EB0: D6220022 03FD0122 00006400
	v_and_b32_e32 v36, 0xffff, v36                             // 000000973EBC: 364848FF 0000FFFF
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000973EC4: D6220026 03FD0126 00006400
	.long 0xd72c002a                                           // 000000973ED0: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000973ED4: 020254FF 83DCD12D
	.long 0xd72c0020                                           // 000000973EDC: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000973EE0: 020240FF 83DCD12D
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000973EE8: D622001F 03FD011F 00006400
	v_lshlrev_b32_e32 v34, 16, v34                             // 000000973EF4: 30444490
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000973EF8: D6220027 03FD0127 00006400
	v_lshl_or_b32 v36, v38, 16, v36                            // 000000973F04: D6560024 04912126
	.long 0xd72c002b                                           // 000000973F0C: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000973F10: 020256FF 83DCD12D
	v_dot2acc_f32_f16 v79, v37, v1                             // 000000973F18: 049E0325
	v_and_or_b32 v31, 0xffff, v31, v34                         // 000000973F1C: D657001F 048A3EFF 0000FFFF
	v_and_b32_e32 v34, 0xffff, v39                             // 000000973F28: 36444EFF 0000FFFF
	v_sad_u8 v37, v42, 0, 0x6400                               // 000000973F30: D6220025 03FD012A 00006400
	v_pk_fma_f16 v36, v36, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973F3C: CC0E0024 0BFC0D24 0000C931
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000973F48: D6220020 03FD0120 00006400
	v_pk_fma_f16 v31, v31, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973F54: CC0E001F 0BFC0D1F 0000C931
	v_sad_u8 v38, v43, 0, 0x6400                               // 000000973F60: D6220026 03FD012B 00006400
	v_lshl_or_b32 v34, v37, 16, v34                            // 000000973F6C: D6560022 04892125
	v_dot2acc_f32_f16 v78, v36, v1                             // 000000973F74: 049C0324
	v_lshlrev_b32_e32 v32, 16, v32                             // 000000973F78: 30404090
	v_pk_fma_f16 v35, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973F7C: CC0E0023 0BFC0D23 0000C931
	v_mov_b32_e32 v39, v148                                    // 000000973F88: 7E4E0394
	v_pk_fma_f16 v28, v34, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973F8C: CC0E001C 0BFC0D22 0000C931
	v_dot2acc_f32_f16 v78, v31, v2                             // 000000973F98: 049C051F
	v_and_or_b32 v32, 0xffff, v38, v32                         // 000000973F9C: D6570020 04824CFF 0000FFFF
	v_pk_fma_f16 v31, v33, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973FA8: CC0E001F 0BFC0D21 0000C931
	v_bfe_u32 v33, v27, 9, 16                                  // 000000973FB4: D6100021 0241131B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000973FBC: BF870234
	v_dual_dot2acc_f32_f16 v79, v35, v2 :: v_dual_dot2acc_f32_f16 v78, v28, v3// 000000973FC0: CB180523 4F4E071C
	.long 0xd73d001c                                           // 000000973FC8: D73D001C
	v_cndmask_b32_e32 v1, v90, v29, vcc_lo                     // 000000973FCC: 02023B5A
	v_pk_fma_f16 v32, v32, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000973FD0: CC0E0020 0BFC0D20 0000C931
	.long 0xd72c001d                                           // 000000973FDC: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000973FE0: 020242FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000973FE8: BF870004
	v_dot2acc_f32_f16 v79, v41, v3                             // 000000973FEC: 049E0729
	v_and_b32_e32 v30, 0xffff, v27                             // 000000973FF0: 363C36FF 0000FFFF
	v_dot2acc_f32_f16 v80, v40, v4                             // 000000973FF8: 04A00928
	v_dot2acc_f32_f16 v78, v32, v4                             // 000000973FFC: 049C0920
	v_bfe_u32 v32, v28, 9, 16                                  // 000000974000: D6100020 0241131C
	v_bfe_u32 v33, v28, 6, 16                                  // 000000974008: D6100021 02410D1C
	v_dot2acc_f32_f16 v79, v31, v4                             // 000000974010: 049E091F
	v_bfe_u32 v31, v27, 6, 16                                  // 000000974014: D610001F 02410D1B
	v_bfe_u32 v27, v27, 3, 16                                  // 00000097401C: D610001B 0241071B
	.long 0xd72c0020                                           // 000000974024: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000974028: 020240FF 83DCD12D
	.long 0xd72c0021                                           // 000000974030: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000974034: 020242FF 83DCD12D
	.long 0xd72c001e                                           // 00000097403C: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000974040: 02023CFF 83DCD12D
	v_bfe_u32 v34, v28, 3, 16                                  // 000000974048: D6100022 0241071C
	.long 0xd72c001f                                           // 000000974050: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000974054: 02023EFF 83DCD12D
	.long 0xd72c001b                                           // 00000097405C: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 000000974060: 020236FF 83DCD12D
	v_sad_u8 v29, v29, 0, 0x6400                               // 000000974068: D622001D 03FD011D 00006400
	v_and_b32_e32 v28, 0xffff, v28                             // 000000974074: 363838FF 0000FFFF
	v_sad_u8 v32, v32, 0, 0x6400                               // 00000097407C: D6220020 03FD0120 00006400
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000974088: D6220021 03FD0121 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000974094: D622001E 03FD011E 00006400
	.long 0xd72c0022                                           // 0000009740A0: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 0000009740A4: 020244FF 83DCD12D
	v_and_b32_e32 v29, 0xffff, v29                             // 0000009740AC: 363A3AFF 0000FFFF
	v_and_b32_e32 v32, 0xffff, v32                             // 0000009740B4: 364040FF 0000FFFF
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000009740BC: D622001F 03FD011F 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000009740C8: D622001B 03FD011B 00006400
	v_lshlrev_b32_e32 v30, 16, v30                             // 0000009740D4: 303C3C90
	.long 0xd72c001c                                           // 0000009740D8: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 0000009740DC: 020238FF 83DCD12D
	v_lshl_or_b32 v24, v33, 16, v32                            // 0000009740E4: D6560018 04812121
	v_lshl_or_b32 v29, v31, 16, v29                            // 0000009740EC: D656001D 0475211F
	v_bfe_u32 v31, v23, 9, 16                                  // 0000009740F4: D610001F 02411317
	v_and_or_b32 v27, 0xffff, v27, v30                         // 0000009740FC: D657001B 047A36FF 0000FFFF
	v_sad_u8 v30, v34, 0, 0x6400                               // 000000974108: D622001E 03FD0122 00006400
	v_pk_fma_f16 v32, v24, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000974114: CC0E0020 0BFC0D18 0000C931
	.long 0xd73d0018                                           // 000000974120: D73D0018
	v_cndmask_b32_e32 v1, v90, v25, vcc_lo                     // 000000974124: 0202335A
	.long 0xd72c0019                                           // 000000974128: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 00000097412C: 02023EFF 83DCD12D
	v_sad_u8 v28, v28, 0, 0x6400                               // 000000974134: D622001C 03FD011C 00006400
	v_pk_fma_f16 v29, v29, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000974140: CC0E001D 0BFC0D1D 0000C931
	v_bfe_u32 v26, v23, 6, 16                                  // 00000097414C: D610001A 02410D17
	v_dual_mov_b32 v37, v155 :: v_dual_and_b32 v34, 0xffff, v24// 000000974154: CA24019B 252230FF 0000FFFF
	v_bfe_u32 v31, v24, 9, 16                                  // 000000974160: D610001F 02411318
	v_bfe_u32 v33, v24, 6, 16                                  // 000000974168: D6100021 02410D18
	v_bfe_u32 v24, v24, 3, 16                                  // 000000974170: D6100018 02410718
	v_lshlrev_b32_e32 v28, 16, v28                             // 000000974178: 30383890
	.long 0xd72c0022                                           // 00000097417C: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000974180: 020244FF 83DCD12D
	v_dot2acc_f32_f16 v77, v29, v1                             // 000000974188: 049A031D
	.long 0xd72c001a                                           // 00000097418C: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000974190: 020234FF 83DCD12D
	.long 0xd72c0018                                           // 000000974198: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 00000097419C: 020230FF 83DCD12D
	.long 0xd72c001f                                           // 0000009741A4: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 0000009741A8: 02023EFF 83DCD12D
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000009741B0: D6220019 03FD0119 00006400
	.long 0xd72c0021                                           // 0000009741BC: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000009741C0: 020242FF 83DCD12D
	v_mov_b32_e32 v35, v145                                    // 0000009741C8: 7E460391
	v_sad_u8 v29, v34, 0, 0x6400                               // 0000009741CC: D622001D 03FD0122 00006400
	v_pk_fma_f16 v27, v27, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009741D8: CC0E001B 0BFC0D1B 0000C931
	v_and_b32_e32 v25, 0xffff, v25                             // 0000009741E4: 363232FF 0000FFFF
	v_sad_u8 v16, v24, 0, 0x6400                               // 0000009741EC: D6220010 03FD0118 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000009741F8: D622001A 03FD011A 00006400
	v_dual_mov_b32 v29, v152 :: v_dual_lshlrev_b32 v24, 16, v29// 000000974204: CA220198 1D183A90
	v_and_or_b32 v28, 0xffff, v30, v28                         // 00000097420C: D657001C 04723CFF 0000FFFF
	v_and_b32_e32 v30, 0xffff, v23                             // 000000974218: 363C2EFF 0000FFFF
	v_bfe_u32 v23, v23, 3, 16                                  // 000000974220: D6100017 02410717
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000974228: D622001F 03FD011F 00006400
	v_lshl_or_b32 v25, v26, 16, v25                            // 000000974234: D6560019 0465211A
	v_and_or_b32 v24, 0xffff, v16, v24                         // 00000097423C: D6570018 046220FF 0000FFFF
	.long 0xd72c001e                                           // 000000974248: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 00000097424C: 02023CFF 83DCD12D
	.long 0xd72c0017                                           // 000000974254: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 000000974258: 02022EFF 83DCD12D
	v_dual_mov_b32 v31, v142 :: v_dual_and_b32 v26, 0xffff, v31// 000000974260: CA24018E 1F1A3EFF 0000FFFF
	v_pk_fma_f16 v25, v25, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000097426C: CC0E0019 0BFC0D19 0000C931
	.long 0xd73d0010                                           // 000000974278: D73D0010
	v_cndmask_b32_e32 v1, v90, v17, vcc_lo                     // 00000097427C: 0202235A
	v_pk_fma_f16 v18, v24, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000974280: CC0E0012 0BFC0D18 0000C931
	v_bfe_u32 v24, v15, 3, 16                                  // 00000097428C: D6100018 0241070F
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000974294: D622001E 03FD011E 00006400
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000009742A0: D6220017 03FD0117 00006400
	v_dual_dot2acc_f32_f16 v76, v25, v1 :: v_dual_dot2acc_f32_f16 v77, v27, v2// 0000009742AC: CB180319 4C4C051B
	v_and_b32_e32 v27, 0xffff, v16                             // 0000009742B4: 363620FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009742BC: BF870004
	v_lshlrev_b32_e32 v30, 16, v30                             // 0000009742C0: 303C3C90
	.long 0xd72c0018                                           // 0000009742C4: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 0000009742C8: 020230FF 83DCD12D
	v_pk_fma_f16 v28, v28, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009742D0: CC0E001C 0BFC0D1C 0000C931
	v_dot2acc_f32_f16 v77, v32, v3                             // 0000009742DC: 049A0720
	.long 0xd72c001b                                           // 0000009742E0: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 0000009742E4: 020236FF 83DCD12D
	v_and_or_b32 v23, 0xffff, v23, v30                         // 0000009742EC: D6570017 047A2EFF 0000FFFF
	v_sad_u8 v30, v33, 0, 0x6400                               // 0000009742F8: D622001E 03FD0121 00006400
	v_mov_b32_e32 v41, v156                                    // 000000974304: 7E52039C
	v_dot2acc_f32_f16 v77, v28, v4                             // 000000974308: 049A091C
	v_mov_b32_e32 v45, v101                                    // 00000097430C: 7E5A0365
	v_pk_fma_f16 v23, v23, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000974310: CC0E0017 0BFC0D17 0000C931
	v_lshl_or_b32 v26, v30, 16, v26                            // 00000097431C: D656001A 0469211E
	v_dual_mov_b32 v33, v154 :: v_dual_mov_b32 v38, v151       // 000000974324: CA10019A 21260197
	v_mov_b32_e32 v36, v115                                    // 00000097432C: 7E480373
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000974330: BF870214
	v_dot2acc_f32_f16 v76, v23, v2                             // 000000974334: 04980517
	v_pk_fma_f16 v25, v26, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000974338: CC0E0019 0BFC0D1A 0000C931
	v_bfe_u32 v26, v15, 9, 16                                  // 000000974344: D610001A 0241130F
	v_bfe_u32 v23, v15, 6, 16                                  // 00000097434C: D6100017 02410D0F
	v_dual_mov_b32 v42, v153 :: v_dual_and_b32 v15, 0xffff, v15// 000000974354: CA240199 2A0E1EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000974360: BF870214
	v_dot2acc_f32_f16 v76, v25, v3                             // 000000974364: 04980719
	.long 0xd72c0011                                           // 000000974368: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 00000097436C: 020234FF 83DCD12D
	v_bfe_u32 v25, v16, 9, 16                                  // 000000974374: D6100019 02411310
	.long 0xd72c0017                                           // 00000097437C: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 000000974380: 02022EFF 83DCD12D
	.long 0xd72c000f                                           // 000000974388: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 00000097438C: 02021EFF 83DCD12D
	v_bfe_u32 v26, v16, 6, 16                                  // 000000974394: D610001A 02410D10
	v_bfe_u32 v16, v16, 3, 16                                  // 00000097439C: D6100010 02410710
	.long 0xd72c0019                                           // 0000009743A4: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 0000009743A8: 020232FF 83DCD12D
	v_dot2acc_f32_f16 v76, v18, v4                             // 0000009743B0: 04980912
	v_sad_u8 v17, v17, 0, 0x6400                               // 0000009743B4: D6220011 03FD0111 00006400
	.long 0xd72c001a                                           // 0000009743C0: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 0000009743C4: 020234FF 83DCD12D
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000009743CC: D6220017 03FD0117 00006400
	v_sad_u8 v15, v15, 0, 0x6400                               // 0000009743D8: D622000F 03FD010F 00006400
	.long 0xd72c0010                                           // 0000009743E4: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 0000009743E8: 020220FF 83DCD12D
	v_and_b32_e32 v17, 0xffff, v17                             // 0000009743F0: 362222FF 0000FFFF
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000009743F8: D6220019 03FD0119 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000974404: BF870224
	v_dual_mov_b32 v18, v139 :: v_dual_lshlrev_b32 v15, 16, v15// 000000974408: CA22018B 120E1E90
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000974410: D622001A 03FD011A 00006400
	v_lshl_or_b32 v17, v23, 16, v17                            // 00000097441C: D6560011 04452117
	v_sad_u8 v23, v24, 0, 0x6400                               // 000000974424: D6220017 03FD0118 00006400
	v_sad_u8 v24, v27, 0, 0x6400                               // 000000974430: D6220018 03FD011B 00006400
	v_and_b32_e32 v25, 0xffff, v25                             // 00000097443C: 363232FF 0000FFFF
	v_sad_u8 v16, v16, 0, 0x6400                               // 000000974444: D6220010 03FD0110 00006400
	v_pk_fma_f16 v17, v17, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000974450: CC0E0011 0BFC0D11 0000C931
	v_and_or_b32 v15, 0xffff, v23, v15                         // 00000097445C: D657000F 043E2EFF 0000FFFF
	v_lshlrev_b32_e32 v24, 16, v24                             // 000000974468: 30303090
	v_lshl_or_b32 v23, v26, 16, v25                            // 00000097446C: D6560017 0465211A
	v_bfe_u32 v25, v11, 6, 16                                  // 000000974474: D6100019 02410D0B
	v_dot2acc_f32_f16 v75, v17, v1                             // 00000097447C: 04960311
	v_pk_fma_f16 v13, v15, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000974480: CC0E000D 0BFC0D0F 0000C931
	v_and_or_b32 v16, 0xffff, v16, v24                         // 00000097448C: D6570010 046220FF 0000FFFF
	v_pk_fma_f16 v15, v23, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000974498: CC0E000F 0BFC0D17 0000C931
	v_and_b32_e32 v23, 0xffff, v11                             // 0000009744A4: 362E16FF 0000FFFF
	v_bfe_u32 v24, v12, 9, 16                                  // 0000009744AC: D6100018 0241130C
	v_dot2acc_f32_f16 v75, v13, v2                             // 0000009744B4: 0496050D
	v_pk_fma_f16 v16, v16, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009744B8: CC0E0010 0BFC0D10 0000C931
	v_bfe_u32 v11, v11, 3, 16                                  // 0000009744C4: D610000B 0241070B
	v_bfe_u32 v26, v12, 6, 16                                  // 0000009744CC: D610001A 02410D0C
	.long 0xd72c0018                                           // 0000009744D4: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 0000009744D8: 020230FF 83DCD12D
	v_dot2acc_f32_f16 v75, v15, v3                             // 0000009744E0: 0496070F
	.long 0xd72c0019                                           // 0000009744E4: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 0000009744E8: 020232FF 83DCD12D
	.long 0xd72c000b                                           // 0000009744F0: D72C000B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v11, vcc_lo              // 0000009744F4: 020216FF 83DCD12D
	.long 0xd72c0011                                           // 0000009744FC: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000974500: 020234FF 83DCD12D
	v_bfe_u32 v26, v12, 3, 16                                  // 000000974508: D610001A 0241070C
	v_dual_dot2acc_f32_f16 v75, v16, v4 :: v_dual_mov_b32 v16, v111// 000000974510: CB100910 4B10016F
	.long 0xd72c0017                                           // 000000974518: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 00000097451C: 02022EFF 83DCD12D
	v_sad_u8 v24, v24, 0, 0x6400                               // 000000974524: D6220018 03FD0118 00006400
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000974530: D6220019 03FD0119 00006400
	v_sad_u8 v11, v11, 0, 0x6400                               // 00000097453C: D622000B 03FD010B 00006400
	v_and_b32_e32 v12, 0xffff, v12                             // 000000974548: 361818FF 0000FFFF
	v_sad_u8 v17, v17, 0, 0x6400                               // 000000974550: D6220011 03FD0111 00006400
	v_dual_mov_b32 v43, v117 :: v_dual_and_b32 v24, 0xffff, v24// 00000097455C: CA240175 2B1830FF 0000FFFF
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000974568: D6220017 03FD0117 00006400
	v_lshl_or_b32 v14, v25, 16, v14                            // 000000974574: D656000E 04392119
	.long 0xd72c0008                                           // 00000097457C: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v12, vcc_lo              // 000000974580: 020218FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000974588: BF870004
	v_lshl_or_b32 v17, v17, 16, v24                            // 00000097458C: D6560011 04612111
	v_bfe_u32 v24, v5, 9, 16                                   // 000000974594: D6100018 02411305
	v_lshlrev_b32_e32 v23, 16, v23                             // 00000097459C: 302E2E90
	v_pk_fma_f16 v12, v14, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009745A0: CC0E000C 0BFC0D0E 0000C931
	v_bfe_u32 v14, v7, 9, 16                                   // 0000009745AC: D610000E 02411307
	v_pk_fma_f16 v13, v17, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009745B4: CC0E000D 0BFC0D11 0000C931
	v_bfe_u32 v25, v5, 6, 16                                   // 0000009745C0: D6100019 02410D05
	v_and_or_b32 v11, 0xffff, v11, v23                         // 0000009745C8: D657000B 045E16FF 0000FFFF
	.long 0xd72c0017                                           // 0000009745D4: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 0000009745D8: 020234FF 83DCD12D
	v_sad_u8 v6, v8, 0, 0x6400                                 // 0000009745E0: D6220006 03FD0108 00006400
	.long 0xd72c0008                                           // 0000009745EC: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 0000009745F0: 02021CFF 83DCD12D
	v_bfe_u32 v14, v7, 6, 16                                   // 0000009745F8: D610000E 02410D07
	v_bfe_u32 v26, v5, 3, 16                                   // 000000974600: D610001A 02410705
	.long 0xd72c0018                                           // 000000974608: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 00000097460C: 020230FF 83DCD12D
	v_dual_mov_b32 v30, v146 :: v_dual_and_b32 v5, 0xffff, v5  // 000000974614: CA240192 1E040AFF 0000FFFF
	v_sad_u8 v17, v23, 0, 0x6400                               // 000000974620: D6220011 03FD0117 00006400
	v_and_b32_e32 v23, 0xffff, v7                              // 00000097462C: 362E0EFF 0000FFFF
	v_bfe_u32 v7, v7, 3, 16                                    // 000000974634: D6100007 02410707
	.long 0xd72c000e                                           // 00000097463C: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 000000974640: 02021CFF 83DCD12D
	v_sad_u8 v8, v8, 0, 0x6400                                 // 000000974648: D6220008 03FD0108 00006400
	.long 0xd72c0019                                           // 000000974654: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000974658: 020232FF 83DCD12D
	.long 0xd72c0017                                           // 000000974660: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 000000974664: 02022EFF 83DCD12D
	.long 0xd72c0007                                           // 00000097466C: D72C0007
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 000000974670: 02020EFF 83DCD12D
	.long 0xd72c0005                                           // 000000974678: D72C0005
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 00000097467C: 02020AFF 83DCD12D
	v_dual_mov_b32 v49, v120 :: v_dual_and_b32 v8, 0xffff, v8  // 000000974684: CA240178 310810FF 0000FFFF
	v_sad_u8 v14, v14, 0, 0x6400                               // 000000974690: D622000E 03FD010E 00006400
	v_sad_u8 v24, v24, 0, 0x6400                               // 00000097469C: D6220018 03FD0118 00006400
	v_mov_b32_e32 v28, v113                                    // 0000009746A8: 7E380371
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000009746AC: D6220017 03FD0117 00006400
	v_sad_u8 v7, v7, 0, 0x6400                                 // 0000009746B8: D6220007 03FD0107 00006400
	v_lshl_or_b32 v8, v14, 16, v8                              // 0000009746C4: D6560008 0421210E
	.long 0xd72c000e                                           // 0000009746CC: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 0000009746D0: 020234FF 83DCD12D
	v_sad_u8 v5, v5, 0, 0x6400                                 // 0000009746D8: D6220005 03FD0105 00006400
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000009746E4: 302E2E90
	v_pk_fma_f16 v11, v11, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009746E8: CC0E000B 0BFC0D0B 0000C931
	v_pk_fma_f16 v8, v8, s6, 0xc931 op_sel_hi:[1,0,0]          // 0000009746F4: CC0E0008 0BFC0D08 0000C931
	v_dual_mov_b32 v47, v102 :: v_dual_lshlrev_b32 v6, 16, v6  // 000000974700: CA220166 2F060C90
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000974708: BF870244
	v_and_or_b32 v7, 0xffff, v7, v23                           // 00000097470C: D6570007 045E0EFF 0000FFFF
	v_dual_mov_b32 v34, v149 :: v_dual_and_b32 v23, 0xffff, v24// 000000974718: CA240195 221630FF 0000FFFF
	v_sad_u8 v24, v25, 0, 0x6400                               // 000000974724: D6220018 03FD0119 00006400
	v_dot2acc_f32_f16 v74, v12, v1                             // 000000974730: 0494030C
	v_pk_fma_f16 v7, v7, s6, 0xc931 op_sel_hi:[1,0,0]          // 000000974734: CC0E0007 0BFC0D07 0000C931
	v_sad_u8 v14, v14, 0, 0x6400                               // 000000974740: D622000E 03FD010E 00006400
	v_dual_mov_b32 v32, v114 :: v_dual_lshlrev_b32 v5, 16, v5  // 00000097474C: CA220172 20040A90
	v_lshl_or_b32 v12, v24, 16, v23                            // 000000974754: D656000C 045D2118
	v_dot2acc_f32_f16 v10, v8, v1                              // 00000097475C: 04140308
	v_and_or_b32 v1, 0xffff, v17, v6                           // 000000974760: D6570001 041A22FF 0000FFFF
	v_dot2acc_f32_f16 v74, v11, v2                             // 00000097476C: 0494050B
	v_and_or_b32 v5, 0xffff, v14, v5                           // 000000974770: D6570005 04161CFF 0000FFFF
	v_pk_fma_f16 v6, v12, s6, 0xc931 op_sel_hi:[1,0,0]         // 00000097477C: CC0E0006 0BFC0D0C 0000C931
	v_dot2acc_f32_f16 v10, v7, v2                              // 000000974788: 04140507
	v_pk_fma_f16 v1, v1, s6, 0xc931 op_sel_hi:[1,0,0]          // 00000097478C: CC0E0001 0BFC0D01 0000C931
	v_dot2acc_f32_f16 v74, v13, v3                             // 000000974798: 0494070D
	v_pk_fma_f16 v2, v5, s6, 0xc931 op_sel_hi:[1,0,0]          // 00000097479C: CC0E0002 0BFC0D05 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009747A8: BF870224
	v_dual_mov_b32 v5, v140 :: v_dual_dot2acc_f32_f16 v10, v6, v3// 0000009747AC: CA18018C 050A0706
	v_mov_b32_e32 v6, v132                                     // 0000009747B4: 7E0C0384
	v_dual_dot2acc_f32_f16 v74, v1, v4 :: v_dual_mov_b32 v7, v124// 0000009747B8: CB100901 4A06017C
	v_mov_b32_e32 v8, v109                                     // 0000009747C0: 7E10036D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009747C4: BF870004
	v_dual_dot2acc_f32_f16 v10, v2, v4 :: v_dual_mov_b32 v13, v144// 0000009747C8: CB100902 0A0C0190
	v_mov_b32_e32 v14, v136                                    // 0000009747D0: 7E1C0388
	v_dual_mov_b32 v11, v128 :: v_dual_mov_b32 v12, v110       // 0000009747D4: CA100180 0B0C016E
	v_mov_b32_e32 v17, v147                                    // 0000009747DC: 7E220393
	v_mov_b32_e32 v15, v131                                    // 0000009747E0: 7E1E0383
	v_dual_mov_b32 v25, v150 :: v_dual_mov_b32 v26, v143       // 0000009747E4: CA100196 191A018F
	v_dual_mov_b32 v23, v135 :: v_dual_mov_b32 v24, v112       // 0000009747EC: CA100187 17180170
	v_dual_mov_b32 v27, v138 :: v_dual_mov_b32 v40, v116       // 0000009747F4: CA10018A 1B280174
	v_mov_b32_e32 v44, v104                                    // 0000009747FC: 7E580368
	v_mov_b32_e32 v46, v93                                     // 000000974800: 7E5C035D
	v_dual_mov_b32 v50, v106 :: v_dual_mov_b32 v3, v137        // 000000974804: CA10016A 32020189
	v_dual_mov_b32 v48, v94 :: v_dual_mov_b32 v1, v121         // 00000097480C: CA10015E 30000179
	v_mov_b32_e32 v4, v129                                     // 000000974814: 7E080381
	v_mov_b32_e32 v2, v99                                      // 000000974818: 7E040363
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 00000097481C: 917E007E
	s_cbranch_execz 159                                        // 000000974820: BFA5009F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x49a0>
	v_add_nc_u32_e32 v157, 1, v158                             // 000000974824: 4B3B3C81
	s_mov_b32 s7, exec_lo                                      // 000000974828: BE87007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000097482C: BF870001
	.long 0xd4c9007e                                           // 000000974830: D4C9007E
	v_cndmask_b32_e32 v1, v157, v73, vcc_lo                    // 000000974834: 0202939D
	s_cbranch_execz 63796                                      // 000000974838: BFA5F934 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2c0c>
	v_mad_u64_u32 v[93:94], null, 0x600, v157, s[2:3]          // 00000097483C: D6FE7C5D 000B3AFF 00000600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000974848: BF870091
	.long 0xd7006a83                                           // 00000097484C: D7006A83
	v_cndmask_b32_e32 v1, v93, v19, vcc_lo                     // 000000974850: 0202275D
	v_add_co_ci_u32_e64 v132, null, v94, v20, vcc_lo           // 000000974854: D5207C84 01AA295E
	.long 0xd7006a8b                                           // 00000097485C: D7006A8B
	v_cndmask_b32_e32 v1, v93, v91, vcc_lo                     // 000000974860: 0202B75D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000974864: BF8700A1
	v_add_co_ci_u32_e64 v140, null, 0, v94, vcc_lo             // 000000974868: D5207C8C 01AABC80
	.long 0xd7006a9a                                           // 000000974870: D7006A9A
	v_cndmask_b32_e32 v1, v93, v21, vcc_lo                     // 000000974874: 02022B5D
	v_add_co_ci_u32_e64 v155, null, v94, v22, vcc_lo           // 000000974878: D5207C9B 01AA2D5E
	.long 0xd7006a9f                                           // 000000974880: D7006A9F
	v_cndmask_b32_e32 v1, v93, v92, vcc_lo                     // 000000974884: 0202B95D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000974888: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v94, vcc_lo             // 00000097488C: D5207CA0 01AABC80
	s_clause 0x1f                                              // 000000974894: BF85001F
	global_load_b32 v100, v[131:132], off                      // 000000974898: DC520000 647C0083
	global_load_b32 v99, v[131:132], off offset:96             // 0000009748A0: DC520060 637C0083
	global_load_b32 v98, v[131:132], off offset:192            // 0000009748A8: DC5200C0 627C0083
	global_load_b32 v97, v[131:132], off offset:288            // 0000009748B0: DC520120 617C0083
	global_load_b32 v96, v[131:132], off offset:384            // 0000009748B8: DC520180 607C0083
	global_load_b32 v95, v[131:132], off offset:480            // 0000009748C0: DC5201E0 5F7C0083
	global_load_b32 v94, v[131:132], off offset:576            // 0000009748C8: DC520240 5E7C0083
	global_load_b32 v93, v[131:132], off offset:672            // 0000009748D0: DC5202A0 5D7C0083
	global_load_b32 v125, v[139:140], off                      // 0000009748D8: DC520000 7D7C008B
	global_load_b32 v121, v[139:140], off offset:96            // 0000009748E0: DC520060 797C008B
	global_load_b32 v118, v[139:140], off offset:192           // 0000009748E8: DC5200C0 767C008B
	global_load_b32 v107, v[139:140], off offset:288           // 0000009748F0: DC520120 6B7C008B
	global_load_b32 v105, v[139:140], off offset:384           // 0000009748F8: DC520180 697C008B
	global_load_b32 v103, v[139:140], off offset:480           // 000000974900: DC5201E0 677C008B
	global_load_b32 v102, v[139:140], off offset:576           // 000000974908: DC520240 667C008B
	global_load_b32 v101, v[139:140], off offset:672           // 000000974910: DC5202A0 657C008B
	global_load_b32 v133, v[154:155], off                      // 000000974918: DC520000 857C009A
	global_load_b32 v129, v[154:155], off offset:96            // 000000974920: DC520060 817C009A
	global_load_b32 v126, v[154:155], off offset:192           // 000000974928: DC5200C0 7E7C009A
	global_load_b32 v122, v[154:155], off offset:288           // 000000974930: DC520120 7A7C009A
	global_load_b32 v119, v[154:155], off offset:384           // 000000974938: DC520180 777C009A
	global_load_b32 v108, v[154:155], off offset:480           // 000000974940: DC5201E0 6C7C009A
	global_load_b32 v106, v[154:155], off offset:576           // 000000974948: DC520240 6A7C009A
	global_load_b32 v104, v[154:155], off offset:672           // 000000974950: DC5202A0 687C009A
	global_load_b32 v141, v[159:160], off                      // 000000974958: DC520000 8D7C009F
	global_load_b32 v137, v[159:160], off offset:96            // 000000974960: DC520060 897C009F
	global_load_b32 v134, v[159:160], off offset:192           // 000000974968: DC5200C0 867C009F
	global_load_b32 v130, v[159:160], off offset:288           // 000000974970: DC520120 827C009F
	global_load_b32 v127, v[159:160], off offset:384           // 000000974978: DC520180 7F7C009F
	global_load_b32 v123, v[159:160], off offset:480           // 000000974980: DC5201E0 7B7C009F
	global_load_b32 v120, v[159:160], off offset:576           // 000000974988: DC520240 787C009F
	global_load_b32 v117, v[159:160], off offset:672           // 000000974990: DC5202A0 757C009F
	s_clause 0x1f                                              // 000000974998: BF85001F
	global_load_b32 v116, v[131:132], off offset:768           // 00000097499C: DC520300 747C0083
	global_load_b32 v115, v[131:132], off offset:864           // 0000009749A4: DC520360 737C0083
	global_load_b32 v114, v[131:132], off offset:960           // 0000009749AC: DC5203C0 727C0083
	global_load_b32 v113, v[131:132], off offset:1056          // 0000009749B4: DC520420 717C0083
	global_load_b32 v112, v[131:132], off offset:1152          // 0000009749BC: DC520480 707C0083
	global_load_b32 v111, v[131:132], off offset:1248          // 0000009749C4: DC5204E0 6F7C0083
	global_load_b32 v110, v[131:132], off offset:1344          // 0000009749CC: DC520540 6E7C0083
	global_load_b32 v109, v[131:132], off offset:1440          // 0000009749D4: DC5205A0 6D7C0083
	global_load_b32 v148, v[139:140], off offset:768           // 0000009749DC: DC520300 947C008B
	global_load_b32 v145, v[139:140], off offset:864           // 0000009749E4: DC520360 917C008B
	global_load_b32 v142, v[139:140], off offset:960           // 0000009749EC: DC5203C0 8E7C008B
	global_load_b32 v138, v[139:140], off offset:1056          // 0000009749F4: DC520420 8A7C008B
	global_load_b32 v135, v[139:140], off offset:1152          // 0000009749FC: DC520480 877C008B
	global_load_b32 v131, v[139:140], off offset:1248          // 000000974A04: DC5204E0 837C008B
	global_load_b32 v128, v[139:140], off offset:1344          // 000000974A0C: DC520540 807C008B
	global_load_b32 v124, v[139:140], off offset:1440          // 000000974A14: DC5205A0 7C7C008B
	global_load_b32 v153, v[154:155], off offset:768           // 000000974A1C: DC520300 997C009A
	global_load_b32 v151, v[154:155], off offset:864           // 000000974A24: DC520360 977C009A
	global_load_b32 v149, v[154:155], off offset:960           // 000000974A2C: DC5203C0 957C009A
	global_load_b32 v146, v[154:155], off offset:1056          // 000000974A34: DC520420 927C009A
	global_load_b32 v143, v[154:155], off offset:1152          // 000000974A3C: DC520480 8F7C009A
	global_load_b32 v139, v[154:155], off offset:1248          // 000000974A44: DC5204E0 8B7C009A
	global_load_b32 v136, v[154:155], off offset:1344          // 000000974A4C: DC520540 887C009A
	global_load_b32 v132, v[154:155], off offset:1440          // 000000974A54: DC5205A0 847C009A
	global_load_b32 v156, v[159:160], off offset:768           // 000000974A5C: DC520300 9C7C009F
	global_load_b32 v155, v[159:160], off offset:864           // 000000974A64: DC520360 9B7C009F
	global_load_b32 v154, v[159:160], off offset:960           // 000000974A6C: DC5203C0 9A7C009F
	global_load_b32 v152, v[159:160], off offset:1056          // 000000974A74: DC520420 987C009F
	global_load_b32 v150, v[159:160], off offset:1152          // 000000974A7C: DC520480 967C009F
	global_load_b32 v147, v[159:160], off offset:1248          // 000000974A84: DC5204E0 937C009F
	global_load_b32 v144, v[159:160], off offset:1344          // 000000974A8C: DC520540 907C009F
	global_load_b32 v140, v[159:160], off offset:1440          // 000000974A94: DC5205A0 8C7C009F
	s_branch 63643                                             // 000000974A9C: BFA0F89B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2c0c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000974AA0: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000974AA4: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000974AA8: 8C7E017E
	s_waitcnt vmcnt(8)                                         // 000000974AAC: BF8923F7
	v_dual_mov_b32 v6, v9 :: v_dual_mov_b32 v11, v87           // 000000974AB0: CA100109 060A0157
	s_waitcnt vmcnt(1)                                         // 000000974AB8: BF8907F7
	v_dual_mov_b32 v13, v86 :: v_dual_mov_b32 v2, v84          // 000000974ABC: CA100156 0D020154
	v_dual_mov_b32 v1, v85 :: v_dual_mov_b32 v4, v82           // 000000974AC4: CA100155 01040152
	v_dual_mov_b32 v3, v83 :: v_dual_mov_b32 v12, v78          // 000000974ACC: CA100153 030C014E
	s_waitcnt vmcnt(0)                                         // 000000974AD4: BF8903F7
	v_dual_mov_b32 v5, v81 :: v_dual_mov_b32 v8, v79           // 000000974AD8: CA100151 0508014F
	v_dual_mov_b32 v7, v80 :: v_dual_mov_b32 v14, v77          // 000000974AE0: CA100150 070E014D
	v_dual_mov_b32 v15, v76 :: v_dual_mov_b32 v16, v75         // 000000974AE8: CA10014C 0F10014B
	v_mov_b32_e32 v17, v74                                     // 000000974AF0: 7E22034A
	v_mov_b32_e32 v18, v10                                     // 000000974AF4: 7E24030A
	s_mov_b32 s0, 0x76543210                                   // 000000974AF8: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000974B00: BF870009
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000974B04: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000974B10: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000974B1C: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000974B28: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000974B34: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000974B40: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000974B4C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000974B58: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000974B64: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000974B70: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000974B7C: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000974B88: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000974B94: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000974BA0: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000974BAC: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000974BB8: D65C0012 03FC0112 FEDCBA98
	.long 0xd44c0000                                           // 000000974BC4: D44C0000
	v_cndmask_b32_e32 v1, 16, v72, vcc_lo                      // 000000974BC8: 02029090
	s_barrier                                                  // 000000974BCC: BFBD0000
	buffer_gl0_inv                                             // 000000974BD0: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000974BD8: BE812000
	s_cbranch_execz 38                                         // 000000974BDC: BFA50026 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4b78>
	v_add_f32_e32 v10, v10, v18                                // 000000974BE0: 0614250A
	v_dual_add_f32 v6, v9, v6 :: v_dual_add_f32 v9, v87, v11   // 000000974BE4: C9080D09 06081757
	v_add_f32_e32 v11, v86, v13                                // 000000974BEC: 06161B56
	v_dual_add_f32 v2, v84, v2 :: v_dual_lshlrev_b32 v13, 2, v72// 000000974BF0: C9220554 020C9082
	v_dual_add_f32 v1, v85, v1 :: v_dual_add_f32 v4, v82, v4   // 000000974BF8: C9080355 01040952
	v_dual_add_f32 v3, v83, v3 :: v_dual_add_f32 v12, v78, v12 // 000000974C00: C9080753 030C194E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000974C08: BF8701B3
	v_lshl_or_b32 v13, v71, 10, v13                            // 000000974C0C: D656000D 04351547
	v_dual_add_f32 v5, v81, v5 :: v_dual_add_f32 v8, v79, v8   // 000000974C14: C9080B51 0508114F
	v_dual_add_f32 v7, v80, v7 :: v_dual_add_f32 v14, v77, v14 // 000000974C1C: C9080F50 070E1D4D
	v_dual_add_f32 v16, v75, v16 :: v_dual_add_nc_u32 v13, 0x2800, v13// 000000974C24: C920214B 100C1AFF 00002800
	v_add_f32_e32 v15, v76, v15                                // 000000974C30: 061E1F4C
	v_add_f32_e32 v17, v74, v17                                // 000000974C34: 0622234A
	ds_store_2addr_b32 v13, v6, v9 offset1:16                  // 000000974C38: D8381000 0009060D
	ds_store_2addr_b32 v13, v11, v1 offset0:32 offset1:48      // 000000974C40: D8383020 00010B0D
	ds_store_2addr_b32 v13, v2, v3 offset0:64 offset1:80       // 000000974C48: D8385040 0003020D
	ds_store_2addr_b32 v13, v4, v5 offset0:96 offset1:112      // 000000974C50: D8387060 0005040D
	ds_store_2addr_b32 v13, v7, v8 offset0:128 offset1:144     // 000000974C58: D8389080 0008070D
	ds_store_2addr_b32 v13, v12, v14 offset0:160 offset1:176   // 000000974C60: D838B0A0 000E0C0D
	ds_store_2addr_b32 v13, v15, v16 offset0:192 offset1:208   // 000000974C68: D838D0C0 00100F0D
	ds_store_2addr_b32 v13, v17, v10 offset0:224 offset1:240   // 000000974C70: D838F0E0 000A110D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000974C78: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 000000974C7C: BF89FC07
	s_barrier                                                  // 000000974C80: BFBD0000
	buffer_gl0_inv                                             // 000000974C84: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 000000974C8C: BE81007E
	v_cmpx_eq_u32_e32 0, v71                                   // 000000974C90: 7D948E80
	s_cbranch_execz 1349                                       // 000000974C94: BFA50545 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x60ac>
	v_and_b32_e32 v47, 15, v0                                  // 000000974C98: 365E008F
	s_mul_i32 s1, s4, 0xa00                                    // 000000974C9C: 9601FF04 00000A00
	s_mul_hi_i32 s2, s4, 0xa00                                 // 000000974CA4: 9702FF04 00000A00
	s_add_u32 s1, s18, s1                                      // 000000974CAC: 80010112
	s_addc_u32 s7, s19, s2                                     // 000000974CB0: 82070213
	v_lshlrev_b32_e32 v3, 2, v47                               // 000000974CB4: 30065E82
	s_lshl_b32 s2, s5, 7                                       // 000000974CB8: 84028705
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000974CBC: BF870499
	s_ashr_i32 s3, s2, 31                                      // 000000974CC0: 86039F02
	s_lshl_b64 s[12:13], s[2:3], 1                             // 000000974CC4: 848C8102
	s_delay_alu instid0(VALU_DEP_1)                            // 000000974CC8: BF870001
	v_add_nc_u32_e32 v48, 0x2800, v3                           // 000000974CCC: 4A6006FF 00002800
	v_add_nc_u32_e32 v51, 0x3400, v3                           // 000000974CD4: 4A6606FF 00003400
	v_add_nc_u32_e32 v52, 0x3800, v3                           // 000000974CDC: 4A6806FF 00003800
	v_add_nc_u32_e32 v53, 0x3c00, v3                           // 000000974CE4: 4A6A06FF 00003C00
	v_add_nc_u32_e32 v54, 0x4000, v3                           // 000000974CEC: 4A6C06FF 00004000
	ds_load_2addr_b32 v[1:2], v48 offset1:16                   // 000000974CF4: D8DC1000 01000030
	v_add_nc_u32_e32 v55, 0x4400, v3                           // 000000974CFC: 4A6E06FF 00004400
	s_add_u32 s6, s1, s12                                      // 000000974D04: 80060C01
	s_addc_u32 s7, s7, s13                                     // 000000974D08: 82070D07
	s_mul_i32 s1, s4, 0x500                                    // 000000974D0C: 9601FF04 00000500
	s_mul_hi_i32 s2, s4, 0x500                                 // 000000974D14: 9702FF04 00000500
	s_add_u32 s1, s20, s1                                      // 000000974D1C: 80010114
	s_addc_u32 s2, s21, s2                                     // 000000974D20: 82020215
	s_add_u32 s8, s1, s12                                      // 000000974D24: 80080C01
	s_addc_u32 s9, s2, s13                                     // 000000974D28: 82090D02
	s_waitcnt lgkmcnt(0)                                       // 000000974D2C: BF89FC07
	v_dual_add_f32 v2, 0, v2 :: v_dual_add_nc_u32 v49, 0x2c00, v3// 000000974D30: C9200480 023006FF 00002C00
	v_dual_add_f32 v1, 0, v1 :: v_dual_add_nc_u32 v50, 0x3000, v3// 000000974D3C: C9200280 013206FF 00003000
	ds_load_2addr_b32 v[3:4], v48 offset0:128 offset1:144      // 000000974D48: D8DC9080 03000030
	ds_load_2addr_b32 v[5:6], v49 offset1:16                   // 000000974D50: D8DC1000 05000031
	ds_load_2addr_b32 v[7:8], v49 offset0:128 offset1:144      // 000000974D58: D8DC9080 07000031
	ds_load_2addr_b32 v[9:10], v50 offset1:16                  // 000000974D60: D8DC1000 09000032
	ds_load_2addr_b32 v[11:12], v50 offset0:128 offset1:144    // 000000974D68: D8DC9080 0B000032
	ds_load_2addr_b32 v[13:14], v51 offset1:16                 // 000000974D70: D8DC1000 0D000033
	ds_load_2addr_b32 v[15:16], v51 offset0:128 offset1:144    // 000000974D78: D8DC9080 0F000033
	ds_load_2addr_b32 v[17:18], v52 offset1:16                 // 000000974D80: D8DC1000 11000034
	ds_load_2addr_b32 v[19:20], v52 offset0:128 offset1:144    // 000000974D88: D8DC9080 13000034
	ds_load_2addr_b32 v[21:22], v53 offset1:16                 // 000000974D90: D8DC1000 15000035
	ds_load_2addr_b32 v[23:24], v53 offset0:128 offset1:144    // 000000974D98: D8DC9080 17000035
	ds_load_2addr_b32 v[25:26], v54 offset1:16                 // 000000974DA0: D8DC1000 19000036
	ds_load_2addr_b32 v[27:28], v54 offset0:128 offset1:144    // 000000974DA8: D8DC9080 1B000036
	ds_load_2addr_b32 v[29:30], v55 offset1:16                 // 000000974DB0: D8DC1000 1D000037
	ds_load_2addr_b32 v[31:32], v55 offset0:128 offset1:144    // 000000974DB8: D8DC9080 1F000037
	ds_load_2addr_b32 v[33:34], v48 offset0:32 offset1:48      // 000000974DC0: D8DC3020 21000030
	ds_load_2addr_b32 v[35:36], v48 offset0:160 offset1:176    // 000000974DC8: D8DCB0A0 23000030
	ds_load_2addr_b32 v[37:38], v49 offset0:32 offset1:48      // 000000974DD0: D8DC3020 25000031
	s_waitcnt lgkmcnt(17)                                      // 000000974DD8: BF89FD17
	v_add_f32_e32 v56, 0, v4                                   // 000000974DDC: 06700880
	s_waitcnt lgkmcnt(16)                                      // 000000974DE0: BF89FD07
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v1, v1, v5     // 000000974DE4: C9080D02 02000B01
	ds_load_2addr_b32 v[39:40], v49 offset0:160 offset1:176    // 000000974DEC: D8DCB0A0 27000031
	ds_load_2addr_b32 v[41:42], v50 offset0:32 offset1:48      // 000000974DF4: D8DC3020 29000032
	ds_load_2addr_b32 v[43:44], v50 offset0:160 offset1:176    // 000000974DFC: D8DCB0A0 2B000032
	s_waitcnt lgkmcnt(18)                                      // 000000974E04: BF89FD27
	v_add_f32_e32 v8, v56, v8                                  // 000000974E08: 06101138
	s_waitcnt lgkmcnt(17)                                      // 000000974E0C: BF89FD17
	v_dual_add_f32 v2, v2, v10 :: v_dual_add_f32 v3, 0, v3     // 000000974E10: C9081502 02020680
	v_add_f32_e32 v1, v1, v9                                   // 000000974E18: 06021301
	ds_load_2addr_b32 v[45:46], v51 offset0:32 offset1:48      // 000000974E1C: D8DC3020 2D000033
	s_waitcnt lgkmcnt(17)                                      // 000000974E24: BF89FD17
	v_add_f32_e32 v8, v8, v12                                  // 000000974E28: 06101908
	s_waitcnt lgkmcnt(16)                                      // 000000974E2C: BF89FD07
	v_dual_add_f32 v2, v2, v14 :: v_dual_add_f32 v3, v3, v7    // 000000974E30: C9081D02 02020F03
	v_add_f32_e32 v1, v1, v13                                  // 000000974E38: 06021B01
	ds_load_2addr_b32 v[4:5], v51 offset0:160 offset1:176      // 000000974E3C: D8DCB0A0 04000033
	s_waitcnt lgkmcnt(16)                                      // 000000974E44: BF89FD07
	v_add_f32_e32 v8, v8, v16                                  // 000000974E48: 06102108
	s_waitcnt lgkmcnt(15)                                      // 000000974E4C: BF89FCF7
	v_dual_add_f32 v2, v2, v18 :: v_dual_add_f32 v3, v3, v11   // 000000974E50: C9082502 02021703
	s_waitcnt lgkmcnt(6)                                       // 000000974E58: BF89FC67
	v_dual_add_f32 v1, v1, v17 :: v_dual_add_f32 v12, 0, v35   // 000000974E5C: C9082301 010C4680
	v_add_f32_e32 v8, v8, v20                                  // 000000974E64: 06102908
	ds_load_2addr_b32 v[6:7], v52 offset0:32 offset1:48        // 000000974E68: D8DC3020 06000034
	v_add_f32_e32 v3, v3, v15                                  // 000000974E70: 06061F03
	v_add_f32_e32 v9, 0, v33                                   // 000000974E74: 06124280
	v_add_f32_e32 v15, v2, v22                                 // 000000974E78: 061E2D02
	v_dual_add_f32 v1, v1, v21 :: v_dual_add_f32 v16, v8, v24  // 000000974E7C: C9082B01 01103108
	s_waitcnt lgkmcnt(6)                                       // 000000974E84: BF89FC67
	s_delay_alu instid0(VALU_DEP_3)                            // 000000974E88: BF870003
	v_dual_add_f32 v3, v3, v19 :: v_dual_add_f32 v14, v9, v37  // 000000974E8C: C9082703 030E4B09
	ds_load_2addr_b32 v[10:11], v53 offset0:32 offset1:48      // 000000974E94: D8DC3020 0A000035
	v_dual_add_f32 v18, v15, v26 :: v_dual_add_f32 v1, v1, v25 // 000000974E9C: C908350F 12003301
	v_dual_add_f32 v16, v16, v28 :: v_dual_add_f32 v3, v3, v23 // 000000974EA4: C9083910 10022F03
	s_waitcnt lgkmcnt(5)                                       // 000000974EAC: BF89FC57
	v_add_f32_e32 v14, v14, v41                                // 000000974EB0: 061C530E
	ds_load_2addr_b32 v[8:9], v52 offset0:160 offset1:176      // 000000974EB4: D8DCB0A0 08000034
	v_dual_add_f32 v56, v1, v29 :: v_dual_lshlrev_b32 v1, 1, v47// 000000974EBC: C9223B01 38005E81
	s_waitcnt lgkmcnt(4)                                       // 000000974EC4: BF89FC47
	v_dual_add_f32 v17, v3, v27 :: v_dual_add_f32 v20, v14, v45// 000000974EC8: C9083703 11145B0E
	v_lshlrev_b32_e32 v47, 1, v0                               // 000000974ED0: 305E0081
	ds_load_2addr_b32 v[14:15], v54 offset0:32 offset1:48      // 000000974ED4: D8DC3020 0E000036
	ds_load_2addr_b32 v[24:25], v49 offset0:64 offset1:80      // 000000974EDC: D8DC5040 18000031
	ds_load_2addr_b32 v[26:27], v49 offset0:192 offset1:208    // 000000974EE4: D8DCD0C0 1A000031
	s_waitcnt lgkmcnt(5)                                       // 000000974EEC: BF89FC57
	v_dual_add_f32 v41, v17, v31 :: v_dual_add_f32 v6, v20, v6 // 000000974EF0: C9083F11 29060D14
	v_add_f32_e32 v3, v12, v39                                 // 000000974EF8: 06064F0C
	ds_load_2addr_b32 v[12:13], v53 offset0:160 offset1:176    // 000000974EFC: D8DCB0A0 0C000035
	ds_load_2addr_b32 v[20:21], v48 offset0:192 offset1:208    // 000000974F04: D8DCD0C0 14000030
	ds_load_2addr_b32 v[22:23], v55 offset0:32 offset1:48      // 000000974F0C: D8DC3020 16000037
	global_load_d16_b16 v2, v1, s[6:7]                         // 000000974F14: DC820000 02060001
	s_waitcnt lgkmcnt(7)                                       // 000000974F1C: BF89FC77
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v19, v3, v43  // 000000974F20: C9081506 06125703
	v_add_f32_e32 v45, v16, v32                                // 000000974F28: 065A4110
	ds_load_2addr_b32 v[16:17], v54 offset0:160 offset1:176    // 000000974F2C: D8DCB0A0 10000036
	v_dual_add_f32 v43, v18, v30 :: v_dual_add_f32 v10, 0, v36 // 000000974F34: C9083D12 2B0A4880
	v_add_f32_e32 v4, v19, v4                                  // 000000974F3C: 06080913
	ds_load_2addr_b32 v[18:19], v48 offset0:64 offset1:80      // 000000974F40: D8DC5040 12000030
	ds_load_2addr_b32 v[36:37], v52 offset0:192 offset1:208    // 000000974F48: D8DCD0C0 24000034
	ds_load_2addr_b32 v[28:29], v50 offset0:64 offset1:80      // 000000974F50: D8DC5040 1C000032
	ds_load_2addr_b32 v[30:31], v50 offset0:192 offset1:208    // 000000974F58: D8DCD0C0 1E000032
	ds_load_2addr_b32 v[32:33], v55 offset0:160 offset1:176    // 000000974F60: D8DCB0A0 20000037
	v_add_f32_e32 v10, v10, v40                                // 000000974F68: 0614510A
	s_waitcnt lgkmcnt(12)                                      // 000000974F6C: BF89FCC7
	v_add_f32_e32 v4, v4, v8                                   // 000000974F70: 06081104
	v_add_f32_e32 v8, 0, v34                                   // 000000974F74: 06104480
	ds_load_2addr_b32 v[34:35], v51 offset0:64 offset1:80      // 000000974F78: D8DC5040 22000033
	v_or_b32_e32 v39, 32, v47                                  // 000000974F80: 384E5EA0
	v_add_f32_e32 v8, v8, v38                                  // 000000974F84: 06104D08
	s_waitcnt lgkmcnt(9)                                       // 000000974F88: BF89FC97
	v_add_f32_e32 v4, v4, v12                                  // 000000974F8C: 06081904
	v_add_f32_e32 v12, v6, v14                                 // 000000974F90: 06181D06
	global_load_d16_b16 v3, v39, s[6:7]                        // 000000974F94: DC820000 03060027
	v_add_f32_e32 v6, v8, v42                                  // 000000974F9C: 060C5508
	v_add_f32_e32 v8, v10, v44                                 // 000000974FA0: 0610590A
	s_waitcnt lgkmcnt(6)                                       // 000000974FA4: BF89FC67
	v_add_f32_e32 v14, v4, v16                                 // 000000974FA8: 061C2104
	v_add_f32_e32 v38, v12, v22                                // 000000974FAC: 064C2D0C
	s_waitcnt lgkmcnt(5)                                       // 000000974FB0: BF89FC57
	v_add_f32_e32 v16, 0, v18                                  // 000000974FB4: 06202480
	v_add_f32_e32 v8, v8, v5                                   // 000000974FB8: 06100B08
	ds_load_2addr_b32 v[4:5], v51 offset0:192 offset1:208      // 000000974FBC: D8DCD0C0 04000033
	v_add_f32_e32 v6, v6, v46                                  // 000000974FC4: 060C5D06
	v_add_f32_e32 v18, 0, v20                                  // 000000974FC8: 06242880
	v_add_f32_e32 v12, v16, v24                                // 000000974FCC: 06183110
	v_add_f32_e32 v8, v8, v9                                   // 000000974FD0: 06101308
	s_waitcnt lgkmcnt(2)                                       // 000000974FD4: BF89FC27
	v_add_f32_e32 v40, v14, v32                                // 000000974FD8: 0650410E
	v_add_f32_e32 v10, v6, v7                                  // 000000974FDC: 06140F06
	ds_load_2addr_b32 v[6:7], v52 offset0:64 offset1:80        // 000000974FE0: D8DC5040 06000034
	v_dual_add_f32 v16, v18, v26 :: v_dual_add_f32 v13, v8, v13// 000000974FE8: C9083512 100C1B08
	ds_load_2addr_b32 v[8:9], v53 offset0:64 offset1:80        // 000000974FF0: D8DC5040 08000035
	v_add_f32_e32 v18, v10, v11                                // 000000974FF8: 0624170A
	v_add_f32_e32 v12, v12, v28                                // 000000974FFC: 0618390C
	v_add_f32_e32 v16, v16, v30                                // 000000975000: 06203D10
	v_add_f32_e32 v30, v13, v17                                // 000000975004: 063C230D
	v_add_f32_e32 v20, 0, v19                                  // 000000975008: 06282680
	v_add_f32_e32 v22, v18, v15                                // 00000097500C: 062C1F12
	s_waitcnt lgkmcnt(3)                                       // 000000975010: BF89FC37
	v_add_f32_e32 v18, v12, v34                                // 000000975014: 0624450C
	ds_load_2addr_b32 v[12:13], v54 offset0:64 offset1:80      // 000000975018: D8DC5040 0C000036
	ds_load_2addr_b32 v[14:15], v54 offset0:192 offset1:208    // 000000975020: D8DCD0C0 0E000036
	v_add_f32_e32 v28, 0, v21                                  // 000000975028: 06382A80
	ds_load_2addr_b32 v[10:11], v53 offset0:192 offset1:208    // 00000097502C: D8DCD0C0 0A000035
	v_add_f32_e32 v42, v22, v23                                // 000000975034: 06542F16
	s_waitcnt lgkmcnt(5)                                       // 000000975038: BF89FC57
	v_add_f32_e32 v4, v16, v4                                  // 00000097503C: 06080910
	v_add_f32_e32 v32, v20, v25                                // 000000975040: 06403314
	ds_load_2addr_b32 v[20:21], v48 offset0:96 offset1:112     // 000000975044: D8DC7060 14000030
	ds_load_2addr_b32 v[24:25], v48 offset0:224 offset1:240    // 00000097504C: D8DCF0E0 18000030
	ds_load_2addr_b32 v[22:23], v50 offset0:96 offset1:112     // 000000975054: D8DC7060 16000032
	s_waitcnt lgkmcnt(7)                                       // 00000097505C: BF89FC77
	v_add_f32_e32 v6, v18, v6                                  // 000000975060: 060C0D12
	ds_load_2addr_b32 v[16:17], v55 offset0:64 offset1:80      // 000000975064: D8DC5040 10000037
	ds_load_2addr_b32 v[18:19], v55 offset0:192 offset1:208    // 00000097506C: D8DCD0C0 12000037
	v_add_f32_e32 v32, v32, v29                                // 000000975074: 06403B20
	v_or_b32_e32 v46, 0x60, v47                                // 000000975078: 385C5EFF 00000060
	s_waitcnt lgkmcnt(8)                                       // 000000975080: BF89FC87
	v_add_f32_e32 v6, v6, v8                                   // 000000975084: 060C1106
	v_add_f32_e32 v8, v28, v27                                 // 000000975088: 0610371C
	s_waitcnt lgkmcnt(7)                                       // 00000097508C: BF89FC77
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000975090: BF870112
	v_add_f32_e32 v6, v6, v12                                  // 000000975094: 060C1906
	v_add_f32_e32 v8, v8, v31                                  // 000000975098: 06103F08
	v_add_f32_e32 v12, v32, v35                                // 00000097509C: 06184720
	s_waitcnt lgkmcnt(4)                                       // 0000009750A0: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000009750A4: BF870132
	v_dual_add_f32 v5, v8, v5 :: v_dual_add_f32 v8, 0, v20     // 0000009750A8: C9080B08 05082880
	s_waitcnt lgkmcnt(1)                                       // 0000009750B0: BF89FC17
	v_add_f32_e32 v16, v6, v16                                 // 0000009750B4: 06202106
	v_dual_add_f32 v6, v12, v7 :: v_dual_add_f32 v7, v5, v37   // 0000009750B8: C9080F0C 06064B05
	v_add_f32_e32 v12, 0, v24                                  // 0000009750C0: 06183080
	global_load_d16_b16 v5, v1, s[6:7] offset:1280             // 0000009750C4: DC820500 05060001
	v_dual_add_f32 v44, v6, v9 :: v_dual_add_f32 v7, v7, v11   // 0000009750CC: C9081306 2C061707
	s_clause 0x1                                               // 0000009750D4: BF850001
	global_load_d16_b16 v6, v39, s[6:7] offset:1280            // 0000009750D8: DC820500 06060027
	global_load_d16_b16 v9, v46, s[6:7]                        // 0000009750E0: DC820000 0906002E
	v_add_f32_e32 v13, v44, v13                                // 0000009750E8: 061A1B2C
	v_add_f32_e32 v7, v7, v15                                  // 0000009750EC: 060E1F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009750F0: BF870122
	v_add_f32_e32 v13, v13, v17                                // 0000009750F4: 061A230D
	s_waitcnt lgkmcnt(0)                                       // 0000009750F8: BF89FC07
	v_dual_add_f32 v19, v7, v19 :: v_dual_add_f32 v26, v4, v36 // 0000009750FC: C9082707 131A4904
	ds_load_2addr_b32 v[34:35], v52 offset0:96 offset1:112     // 000000975104: D8DC7060 22000034
	ds_load_2addr_b32 v[36:37], v52 offset0:224 offset1:240    // 00000097510C: D8DCF0E0 24000034
	global_load_d16_b16 v4, v1, s[6:7] offset:64               // 000000975114: DC820040 04060001
	v_add_f32_e32 v10, v26, v10                                // 00000097511C: 0614151A
	ds_load_2addr_b32 v[26:27], v49 offset0:96 offset1:112     // 000000975120: D8DC7060 1A000031
	ds_load_2addr_b32 v[28:29], v49 offset0:224 offset1:240    // 000000975128: D8DCF0E0 1C000031
	v_add_f32_e32 v10, v10, v14                                // 000000975130: 06141D0A
	v_add_f32_e32 v14, v30, v33                                // 000000975134: 061C431E
	ds_load_2addr_b32 v[30:31], v51 offset0:96 offset1:112     // 000000975138: D8DC7060 1E000033
	ds_load_2addr_b32 v[32:33], v51 offset0:224 offset1:240    // 000000975140: D8DCF0E0 20000033
	v_add_f32_e32 v18, v10, v18                                // 000000975148: 0624250A
	ds_load_2addr_b32 v[10:11], v50 offset0:224 offset1:240    // 00000097514C: D8DCF0E0 0A000032
	s_waitcnt lgkmcnt(4)                                       // 000000975154: BF89FC47
	v_add_f32_e32 v8, v8, v26                                  // 000000975158: 06103508
	s_waitcnt lgkmcnt(3)                                       // 00000097515C: BF89FC37
	v_add_f32_e32 v12, v12, v28                                // 000000975160: 0618390C
	v_add_f32_e32 v26, 0, v21                                  // 000000975164: 06342A80
	v_add_f32_e32 v28, 0, v25                                  // 000000975168: 06383280
	ds_load_2addr_b32 v[20:21], v53 offset0:96 offset1:112     // 00000097516C: D8DC7060 14000035
	ds_load_2addr_b32 v[24:25], v53 offset0:224 offset1:240    // 000000975174: D8DCF0E0 18000035
	v_add_f32_e32 v22, v8, v22                                 // 00000097517C: 062C2D08
	global_load_d16_b16 v8, v39, s[8:9]                        // 000000975180: DC820000 08080027
	s_waitcnt lgkmcnt(4)                                       // 000000975188: BF89FC47
	v_dual_add_f32 v39, v28, v29 :: v_dual_add_f32 v30, v22, v30// 00000097518C: C9083B1C 271E3D16
	s_waitcnt lgkmcnt(2)                                       // 000000975194: BF89FC27
	v_add_f32_e32 v10, v12, v10                                // 000000975198: 0614150C
	v_add_f32_e32 v12, v26, v27                                // 00000097519C: 0618371A
	ds_load_2addr_b32 v[26:27], v54 offset0:96 offset1:112     // 0000009751A0: D8DC7060 1A000036
	ds_load_2addr_b32 v[28:29], v54 offset0:224 offset1:240    // 0000009751A8: D8DCF0E0 1C000036
	v_dual_add_f32 v39, v39, v11 :: v_dual_add_f32 v30, v30, v34// 0000009751B0: C9081727 271E451E
	v_add_f32_e32 v32, v10, v32                                // 0000009751B8: 0640410A
	v_add_f32_e32 v12, v12, v23                                // 0000009751BC: 06182F0C
	ds_load_2addr_b32 v[10:11], v55 offset0:96 offset1:112     // 0000009751C0: D8DC7060 0A000037
	ds_load_2addr_b32 v[22:23], v55 offset0:224 offset1:240    // 0000009751C8: D8DCF0E0 16000037
	v_add_f32_e32 v32, v32, v36                                // 0000009751D0: 06404920
	v_dual_add_f32 v12, v12, v31 :: v_dual_add_f32 v31, v39, v33// 0000009751D4: C9083F0C 0C1E4327
	s_waitcnt lgkmcnt(5)                                       // 0000009751DC: BF89FC57
	v_add_f32_e32 v15, v30, v20                                // 0000009751E0: 061E291E
	s_waitcnt lgkmcnt(4)                                       // 0000009751E4: BF89FC47
	v_add_f32_e32 v20, v32, v24                                // 0000009751E8: 06283120
	v_dual_add_f32 v12, v12, v35 :: v_dual_add_f32 v31, v31, v37// 0000009751EC: C908470C 0C1E4B1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009751F4: BF870111
	v_dual_add_f32 v12, v12, v21 :: v_dual_and_b32 v37, 1, v0  // 0000009751F8: C9242B0C 0C240081
	v_add_f32_e32 v21, v31, v25                                // 000000975200: 062A331F
	s_waitcnt lgkmcnt(3)                                       // 000000975204: BF89FC37
	v_add_f32_e32 v15, v15, v26                                // 000000975208: 061E350F
	s_waitcnt lgkmcnt(2)                                       // 00000097520C: BF89FC27
	v_add_f32_e32 v17, v20, v28                                // 000000975210: 06223914
	v_add_f32_e32 v25, v18, v19                                // 000000975214: 06322712
	v_add_f32_e32 v12, v12, v27                                // 000000975218: 0618370C
	s_waitcnt lgkmcnt(1)                                       // 00000097521C: BF89FC17
	v_dual_add_f32 v20, v21, v29 :: v_dual_add_f32 v7, v15, v10// 000000975220: C9083B15 1406150F
	s_waitcnt lgkmcnt(0)                                       // 000000975228: BF89FC07
	v_dual_add_f32 v10, v17, v22 :: v_dual_sub_f32 v17, v56, v43// 00000097522C: C90A2D11 0A105738
	v_add_f32_e32 v11, v12, v11                                // 000000975234: 0616170C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000975238: BF870003
	v_dual_add_f32 v12, v20, v23 :: v_dual_add_f32 v23, v41, v45// 00000097523C: C9082F14 0C165B29
	v_add_f32_e32 v24, v40, v14                                // 000000975244: 06301D28
	.long 0xd44a0002                                           // 000000975248: D44A0002
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 00000097524C: 02024A80
	v_sub_f32_e32 v37, v41, v45                                // 000000975250: 084A5B29
	v_sub_f32_e32 v21, v38, v42                                // 000000975254: 082A5526
	v_add_f32_e32 v27, v10, v12                                // 000000975258: 0636190A
	v_dual_add_f32 v30, v23, v24 :: v_dual_add_f32 v15, v56, v43// 00000097525C: C9083117 1E0E5738
	v_add_f32_e32 v20, v38, v42                                // 000000975264: 06285526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000975268: BF870214
	v_add_f32_e32 v36, v17, v21                                // 00000097526C: 06482B11
	v_add_f32_e32 v31, v25, v27                                // 000000975270: 063E3719
	v_dual_sub_f32 v18, v18, v19 :: v_dual_and_b32 v19, 2, v0  // 000000975274: C9642712 12120082
	v_sub_f32_e32 v17, v17, v21                                // 00000097527C: 08222B11
	v_add_f32_e32 v29, v15, v20                                // 000000975280: 063A290F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000975284: BF870004
	v_add_f32_e32 v21, v30, v31                                // 000000975288: 062A3F1E
	v_sub_f32_e32 v10, v10, v12                                // 00000097528C: 0814190A
	.long 0xd44a0003                                           // 000000975290: D44A0003
	v_cndmask_b32_e32 v1, 0, v19, vcc_lo                       // 000000975294: 02022680
	v_sub_f32_e32 v19, v23, v24                                // 000000975298: 08263117
	v_dual_sub_f32 v23, v25, v27 :: v_dual_add_f32 v22, v16, v13// 00000097529C: C9483719 17161B10
	v_dual_sub_f32 v13, v16, v13 :: v_dual_add_f32 v16, v7, v11// 0000009752A4: C9481B10 0D101707
	v_sub_f32_e32 v11, v7, v11                                 // 0000009752AC: 08161707
	v_sub_f32_e32 v15, v15, v20                                // 0000009752B0: 081E290F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009752B4: BF870214
	v_dual_add_f32 v27, v19, v23 :: v_dual_and_b32 v24, 4, v0  // 0000009752B8: C9242F13 1B180084
	v_add_f32_e32 v39, v22, v16                                // 0000009752C0: 064E2116
	v_sub_f32_e32 v16, v22, v16                                // 0000009752C4: 08202116
	v_mov_b32_dpp v22, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009752C8: 7E2C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 0000009752D0: D5010015 200A2B15
	.long 0xd44a0004                                           // 0000009752D8: D44A0004
	v_cndmask_b32_e32 v1, 0, v24, vcc_lo                       // 0000009752DC: 02023080
	v_mov_b32_dpp v24, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009752E0: 7E3002FA FF01611B
	v_and_b32_e32 v0, 8, v0                                    // 0000009752E8: 36000088
	v_or_b32_e32 v28, 0xa0, v47                                // 0000009752EC: 38385EFF 000000A0
	v_add_f32_e32 v12, v21, v22                                // 0000009752F4: 06182D15
	v_add_f32_e32 v21, v13, v11                                // 0000009752F8: 062A170D
	v_dual_sub_f32 v11, v13, v11 :: v_dual_sub_f32 v14, v40, v14// 0000009752FC: C94A170D 0B0E1D28
	v_add_f32_e32 v40, v18, v10                                // 000000975304: 06501512
	s_delay_alu instid0(VALU_DEP_4)                            // 000000975308: BF870004
	v_mov_b32_dpp v41, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000097530C: 7E5202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000975314: D501000C 200E190C
	.long 0xd44a0001                                           // 00000097531C: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000975320: 02020080
	v_add_f32_e32 v22, v37, v14                                // 000000975324: 062C1D25
	v_sub_f32_e32 v0, v37, v14                                 // 000000975328: 08001D25
	v_sub_f32_e32 v10, v18, v10                                // 00000097532C: 08141512
	v_add_f32_e32 v12, v12, v41                                // 000000975330: 0618530C
	v_or_b32_e32 v20, 0xe0, v47                                // 000000975334: 38285EFF 000000E0
	v_add_f32_e32 v13, v22, v40                                // 00000097533C: 061A5116
	s_clause 0x4                                               // 000000975340: BF850004
	global_load_d16_b16 v32, v28, s[6:7]                       // 000000975344: DC820000 2006001C
	global_load_d16_b16 v33, v1, s[6:7] offset:1344            // 00000097534C: DC820540 21060001
	global_load_d16_b16 v7, v1, s[6:7] offset:1408             // 000000975354: DC820580 07060001
	global_load_d16_b16 v34, v1, s[6:7] offset:1472            // 00000097535C: DC8205C0 22060001
	global_load_d16_b16 v35, v1, s[6:7] offset:192             // 000000975364: DC8200C0 23060001
	v_sub_f32_e32 v22, v22, v40                                // 00000097536C: 082C5116
	v_mov_b32_dpp v41, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975370: 7E5202FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s4                       // 000000975378: D501000C 2012190C
	v_mov_b32_dpp v25, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975380: 7E3202FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000975388: D501000D 200A1B0D
	global_load_d16_b16 v38, v20, s[6:7]                       // 000000975390: DC820000 26060014
	v_add_f32_e32 v43, v36, v21                                // 000000975398: 06562B24
	v_add_f32_e32 v12, v12, v41                                // 00000097539C: 0618530C
	s_clause 0x3                                               // 0000009753A0: BF850003
	global_load_d16_b16 v37, v1, s[8:9]                        // 0000009753A4: DC820000 25080001
	global_load_d16_b16 v40, v1, s[8:9] offset:64              // 0000009753AC: DC820040 28080001
	global_load_d16_b16 v41, v1, s[8:9] offset:128             // 0000009753B4: DC820080 29080001
	global_load_d16_b16 v42, v1, s[8:9] offset:192             // 0000009753BC: DC8200C0 2A080001
	v_add_f32_e32 v13, v13, v25                                // 0000009753C4: 061A330D
	v_cndmask_b32_e64 v25, -v27, v27, s2                       // 0000009753C8: D5010019 200A371B
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009753D0: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 0000009753D8: D501002B 200A572B
	v_mov_b32_dpp v47, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009753E0: 7E5E02FA FF016116
	v_mov_b32_dpp v27, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009753E8: 7E3602FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 0000009753F0: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009753F8: BF8701A4
	v_dual_add_f32 v24, v25, v24 :: v_dual_add_f32 v43, v43, v45// 0000009753FC: C9083119 182A5B2B
	v_cndmask_b32_e64 v22, -v22, v22, s2                       // 000000975404: D5010016 200A2D16
	v_add_f32_e32 v13, v13, v27                                // 00000097540C: 061A370D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000975410: BF870003
	v_mov_b32_dpp v14, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975414: 7E1C02FA FF016218
	v_cndmask_b32_e64 v18, -v24, v24, s3                       // 00000097541C: D5010012 200E3118
	v_sub_f32_e32 v24, v30, v31                                // 000000975424: 08303F1E
	global_load_d16_b16 v27, v46, s[6:7] offset:1280           // 000000975428: DC820500 1B06002E
	v_mov_b32_dpp v25, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975430: 7E3202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000975438: D501000D 20121B0D
	v_add_f32_e32 v14, v18, v14                                // 000000975440: 061C1D12
	v_dual_sub_f32 v18, v19, v23 :: v_dual_add_f32 v19, v0, v10// 000000975444: C9482F13 12121500
	v_mov_b32_dpp v23, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000097544C: 7E2E02FA FF01680C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000975454: BF870214
	v_add_f32_e32 v13, v13, v25                                // 000000975458: 061A330D
	v_mov_b32_dpp v25, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000097545C: 7E3202FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000975464: D501000E 20121D0E
	v_mov_b32_dpp v30, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000097546C: 7E3C02FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000975474: D5010013 200A2713
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 00000097547C: D501000C 2006190C
	v_mov_b32_dpp v31, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000975484: 7E3E02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 00000097548C: D501000D 20061B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000975494: BF870234
	v_dual_add_f32 v14, v14, v25 :: v_dual_add_f32 v19, v19, v30// 000000975498: C908330E 0E123D13
	v_sub_f32_e32 v0, v0, v10                                  // 0000009754A0: 08001500
	v_add_f32_e32 v10, v12, v23                                // 0000009754A4: 06142F0C
	v_add_f32_e32 v12, v13, v31                                // 0000009754A8: 06183F0D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009754AC: BF870004
	v_mov_b32_dpp v13, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009754B0: 7E1A02FA FF01680E
	v_mov_b32_dpp v23, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009754B8: 7E2E02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 0000009754C0: D5010013 200E2713
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 0000009754C8: D501000E 20061D0E
	v_mov_b32_dpp v25, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009754D0: 7E3202FA FF016118
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 0000009754D8: D5010018 200A3118
	v_add_f32_e32 v31, v29, v39                                // 0000009754E0: 063E4F1D
	v_add_f32_e32 v19, v19, v23                                // 0000009754E4: 06262F13
	v_add_f32_e32 v13, v14, v13                                // 0000009754E8: 061A1B0E
	global_load_d16_b16 v23, v28, s[6:7] offset:1280           // 0000009754EC: DC820500 1706001C
	v_add_f32_e32 v14, v24, v25                                // 0000009754F4: 061C3318
	s_clause 0x1                                               // 0000009754F8: BF850001
	global_load_d16_b16 v25, v20, s[6:7] offset:1280           // 0000009754FC: DC820500 19060014
	global_load_d16_b16 v26, v1, s[6:7] offset:128             // 000000975504: DC820080 1A060001
	v_mov_b32_dpp v24, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000097550C: 7E3002FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s4                       // 000000975514: D5010013 20122713
	s_clause 0x1                                               // 00000097551C: BF850001
	global_load_d16_b16 v28, v28, s[8:9]                       // 000000975520: DC820000 1C08001C
	global_load_d16_b16 v20, v20, s[8:9]                       // 000000975528: DC820000 14080014
	v_mov_b32_dpp v30, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975530: 7E3C02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000975538: D501000E 200E1D0E
	v_add_f32_e32 v19, v19, v24                                // 000000975540: 06263113
	global_load_d16_b16 v24, v46, s[8:9]                       // 000000975544: DC820000 1808002E
	v_add_f32_e32 v22, v22, v47                                // 00000097554C: 062C5F16
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000975550: 101414FF 3DB504F3
	v_add_f32_e32 v14, v14, v30                                // 000000975558: 061C3D0E
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000097555C: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000975564: D501001F 200A3F1F
	v_mov_b32_dpp v44, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000097556C: 7E5802FA FF016813
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000975574: D5010013 20062713
	v_dual_sub_f32 v29, v29, v39 :: v_dual_mul_f32 v12, 0x3db504f3, v12// 00000097557C: C9464F1D 1D0C18FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 000000975588: BF870004
	v_add_f32_e32 v30, v31, v30                                // 00000097558C: 063C3D1F
	v_mov_b32_dpp v31, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975590: 7E3E02FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000975598: D501000E 20121D0E
	v_add_f32_e32 v19, v19, v44                                // 0000009755A0: 06265913
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 0000009755A4: 101A1AFF 3DB504F3
	v_mov_b32_dpp v46, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009755AC: 7E5C02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 0000009755B4: D501001E 200E3D1E
	v_add_f32_e32 v14, v14, v31                                // 0000009755BC: 061C3F0E
	v_mov_b32_dpp v31, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009755C0: 7E3E02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 0000009755C8: D501002B 200E572B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009755D0: BF870234
	v_dual_mul_f32 v19, 0x3db504f3, v19 :: v_dual_add_f32 v30, v30, v46// 0000009755D4: C8C826FF 131E5D1E 3DB504F3
	v_mov_b32_dpp v46, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009755E0: 7E5C02FA FF016216
	v_cndmask_b32_e64 v22, -v22, v22, s3                       // 0000009755E8: D5010016 200E2D16
	v_add_f32_e32 v31, v43, v31                                // 0000009755F0: 063E3F2B
	v_mov_b32_dpp v43, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009755F4: 7E5602FA FF01680E
	v_mov_b32_dpp v45, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009755FC: 7E5A02FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 000000975604: D501001E 20123D1E
	v_add_f32_e32 v22, v22, v46                                // 00000097560C: 062C5D16
	v_mov_b32_dpp v44, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975610: 7E5802FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000975618: D501001F 20123F1F
	v_mov_b32_dpp v46, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975620: 7E5C02FA FF016112
	v_add_f32_e32 v30, v30, v45                                // 000000975628: 063C5B1E
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 00000097562C: D5010012 200A2512
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000975634: D501000E 20061D0E
	v_add_f32_e32 v31, v31, v44                                // 00000097563C: 063E591F
	v_mov_b32_dpp v44, v22 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975640: 7E5802FA FF016416
	v_mov_b32_dpp v45, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000975648: 7E5A02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000975650: D501001E 20063D1E
	v_add_f32_e32 v18, v18, v46                                // 000000975658: 06245D12
	v_cndmask_b32_e64 v22, -v22, v22, s4                       // 00000097565C: D5010016 20122D16
	v_add_f32_e32 v14, v14, v43                                // 000000975664: 061C570E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000975668: BF870004
	v_add_f32_e32 v30, v30, v45                                // 00000097566C: 063C5B1E
	v_mov_b32_dpp v45, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000975670: 7E5A02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000975678: D501001F 20063F1F
	v_mov_b32_dpp v46, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975680: 7E5C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000975688: D5010012 200E2512
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000975690: 103C3CFF 3DB504F3
	v_add_f32_e32 v22, v22, v44                                // 000000975698: 062C5916
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000097569C: BF8701A3
	v_add_f32_e32 v18, v18, v46                                // 0000009756A0: 06245D12
	s_waitcnt vmcnt(23)                                        // 0000009756A4: BF895FF7
	v_fma_mix_f32 v2, v2, v30, neg(0) op_sel_hi:[1,0,0]        // 0000009756A8: CC200002 8A023D02
	v_add_f32_e32 v30, v31, v45                                // 0000009756B0: 063C5B1F
	v_mov_b32_dpp v31, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009756B4: 7E3E02FA FF016816
	v_cndmask_b32_e64 v22, -v22, v22, s1                       // 0000009756BC: D5010016 20062D16
	v_mov_b32_dpp v44, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009756C4: 7E5802FA FF016412
	v_mul_f32_e32 v43, 0xbfb8aa3b, v2                          // 0000009756CC: 105604FF BFB8AA3B
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 0000009756D4: 103C3CFF 3DB504F3
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 0000009756DC: D5010012 20122512
	v_dual_add_f32 v22, v22, v31 :: v_dual_add_f32 v31, v15, v16// 0000009756E4: C9083F16 161E210F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009756EC: BF870004
	v_exp_f32_e32 v43, v43                                     // 0000009756F0: 7E564B2B
	s_waitcnt vmcnt(22)                                        // 0000009756F4: BF895BF7
	v_fma_mix_f32 v3, v3, v30, neg(0) op_sel_hi:[1,0,0]        // 0000009756F8: CC200003 8A023D03
	v_add_f32_e32 v18, v18, v44                                // 000000975700: 06245912
	v_mov_b32_dpp v44, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975704: 7E5802FA FF016100
	v_cndmask_b32_e64 v0, -v0, v0, s2                          // 00000097570C: D5010000 200A0100
	v_mov_b32_dpp v45, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975714: 7E5A02FA FF01611F
	v_mul_f32_e32 v30, 0xbfb8aa3b, v3                          // 00000097571C: 103C06FF BFB8AA3B
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000975724: D501001F 200A3F1F
	v_mul_f32_e32 v22, 0x3db504f3, v22                         // 00000097572C: 102C2CFF 3DB504F3
	v_dual_add_f32 v0, v0, v44 :: v_dual_add_f32 v43, 1.0, v43 // 000000975734: C9085900 002A56F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000097573C: BF870194
	v_exp_f32_e32 v30, v30                                     // 000000975740: 7E3C4B1E
	v_add_f32_e32 v31, v31, v45                                // 000000975744: 063E5B1F
	v_mov_b32_dpp v44, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000975748: 7E5802FA FF016812
	s_delay_alu instid0(VALU_DEP_3)                            // 000000975750: BF870003
	v_mov_b32_dpp v45, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975754: 7E5A02FA FF016200
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 00000097575C: D5010000 200E0100
	v_div_scale_f32 v46, null, v43, v43, v2                    // 000000975764: D6FC7C2E 040A572B
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 00000097576C: D5010012 20062512
	v_mov_b32_dpp v48, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975774: 7E6002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 00000097577C: D501001F 200E3F1F
	v_add_f32_e32 v0, v0, v45                                  // 000000975784: 06005B00
	v_add_f32_e32 v30, 1.0, v30                                // 000000975788: 063C3CF2
	v_rcp_f32_e32 v47, v46                                     // 00000097578C: 7E5E552E
	v_add_f32_e32 v18, v18, v44                                // 000000975790: 06245912
	v_add_f32_e32 v31, v31, v48                                // 000000975794: 063E611F
	v_mov_b32_dpp v44, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975798: 7E5802FA FF016400
	v_div_scale_f32 v45, null, v30, v30, v3                    // 0000009757A0: D6FC7C2D 040E3D1E
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 0000009757A8: D5010000 20120100
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 0000009757B0: 102424FF 3DB504F3
	v_mov_b32_dpp v50, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009757B8: 7E6402FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 0000009757C0: D501001F 20123F1F
	v_rcp_f32_e32 v48, v45                                     // 0000009757C8: 7E60552D
	v_add_f32_e32 v0, v0, v44                                  // 0000009757CC: 06005900
	v_add_f32_e32 v44, v17, v11                                // 0000009757D0: 06581711
	v_fma_f32 v49, -v46, v47, 1.0                              // 0000009757D4: D6130031 23CA5F2E
	v_add_f32_e32 v31, v31, v50                                // 0000009757DC: 063E651F
	v_sub_f32_e32 v11, v17, v11                                // 0000009757E0: 08161711
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009757E4: BF870004
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009757E8: 7E6602FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 0000009757F0: D501002C 200A592C
	v_fmac_f32_e32 v47, v49, v47                               // 0000009757F8: 565E5F31
	v_div_scale_f32 v49, vcc_lo, v2, v43, v2                   // 0000009757FC: D6FC6A31 040A5702
	v_fma_f32 v50, -v45, v48, 1.0                              // 000000975804: D6130032 23CA612D
	v_mov_b32_dpp v52, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000097580C: 7E6802FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000975814: D501001F 20063F1F
	v_add_f32_e32 v44, v44, v51                                // 00000097581C: 0658672C
	v_mov_b32_dpp v51, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000975820: 7E6602FA FF016800
	v_fmac_f32_e32 v48, v50, v48                               // 000000975828: 56606132
	v_div_scale_f32 v50, s5, v3, v30, v3                       // 00000097582C: D6FC0532 040E3D03
	v_dual_add_f32 v31, v31, v52 :: v_dual_mul_f32 v52, v49, v47// 000000975834: C906691F 1F345F31
	v_mov_b32_dpp v54, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000097583C: 7E6C02FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000975844: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000097584C: BF870214
	v_mul_f32_e32 v53, v50, v48                                // 000000975850: 106A6132
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000975854: 103E3EFF 3DB504F3
	v_fma_f32 v55, -v46, v52, v49                              // 00000097585C: D6130037 24C6692E
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000975864: D5010000 20060100
	v_add_f32_e32 v44, v44, v54                                // 00000097586C: 06586D2C
	v_fma_f32 v56, -v45, v53, v50                              // 000000975870: D6130038 24CA6B2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000975878: BF870214
	v_fmac_f32_e32 v52, v55, v47                               // 00000097587C: 56685F37
	v_add_f32_e32 v0, v0, v51                                  // 000000975880: 06006700
	s_waitcnt vmcnt(21)                                        // 000000975884: BF8957F7
	v_fma_mix_f32 v5, v5, v10, neg(0) op_sel_hi:[1,0,0]        // 000000975888: CC200005 8A021505
	v_fmac_f32_e32 v53, v56, v48                               // 000000975890: 566A6138
	s_waitcnt vmcnt(20)                                        // 000000975894: BF8953F7
	v_fma_mix_f32 v6, v6, v12, neg(0) op_sel_hi:[1,0,0]        // 000000975898: CC200006 8A021906
	v_fma_f32 v46, -v46, v52, v49                              // 0000009758A0: D613002E 24C6692E
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000009758A8: 100000FF 3DB504F3
	v_fma_f32 v45, -v45, v53, v50                              // 0000009758B0: D613002D 24CA6B2D
	s_waitcnt vmcnt(18)                                        // 0000009758B8: BF894BF7
	v_fma_mix_f32 v4, v4, v31, neg(0) op_sel_hi:[1,0,0]        // 0000009758BC: CC200004 8A023F04
	v_mov_b32_dpp v31, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009758C4: 7E3E02FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s4                       // 0000009758CC: D501002C 2012592C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009758D4: BF8701A3
	v_mul_f32_e32 v51, 0xbfb8aa3b, v4                          // 0000009758D8: 106608FF BFB8AA3B
	v_sub_f32_e32 v21, v36, v21                                // 0000009758E0: 082A2B24
	v_add_f32_e32 v31, v44, v31                                // 0000009758E4: 063E3F2C
	v_div_fmas_f32 v44, v46, v47, v52                          // 0000009758E8: D637002C 04D25F2E
	s_mov_b32 vcc_lo, s5                                       // 0000009758F0: BEEA0005
	v_exp_f32_e32 v49, v51                                     // 0000009758F4: 7E624B33
	v_div_fmas_f32 v45, v45, v48, v53                          // 0000009758F8: D637002D 04D6612D
	v_mov_b32_dpp v46, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000975900: 7E5C02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000975908: D501001F 20063F1F
	v_div_fixup_f32 v2, v44, v43, v2                           // 000000975910: D6270002 040A572C
	v_mov_b32_dpp v36, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975918: 7E4802FA FF016115
	v_div_fixup_f32 v3, v45, v30, v3                           // 000000975920: D6270003 040E3D2D
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000975928: D5010015 200A2B15
	v_add_f32_e32 v10, v31, v46                                // 000000975930: 06145D1F
	v_mov_b32_dpp v31, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975934: 7E3E02FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 00000097593C: D501001D 200A3B1D
	v_dual_add_f32 v47, 1.0, v49 :: v_dual_mul_f32 v2, v5, v2  // 000000975944: C90662F2 2F020505
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000097594C: BF870194
	v_dual_mul_f32 v10, 0x3db504f3, v10 :: v_dual_sub_f32 v15, v15, v16// 000000975950: C8CA14FF 0A0E210F 3DB504F3
	v_add_f32_e32 v5, v29, v31                                 // 00000097595C: 060A3F1D
	v_mul_f32_e32 v3, v6, v3                                   // 000000975960: 10060706
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000975964: BF870214
	v_div_scale_f32 v30, null, v47, v47, v4                    // 000000975968: D6FC7C1E 04125F2F
	v_fma_mix_f32 v6, v9, v10, neg(0) op_sel_hi:[1,0,0]        // 000000975970: CC200006 8A021509
	v_add_f32_e32 v9, v21, v36                                 // 000000975978: 06124915
	v_mov_b32_dpp v21, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000097597C: 7E2A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000975984: D5010005 200E0B05
	v_mov_b32_dpp v16, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000097598C: 7E2002FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000975994: D501000F 200A1F0F
	v_mov_b32_dpp v29, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000097599C: 7E3A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000009759A4: D5010009 200E1309
	v_add_f32_e32 v5, v5, v21                                  // 0000009759AC: 060A2B05
	s_waitcnt vmcnt(17)                                        // 0000009759B0: BF8947F7
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel_hi:[1,0,0]         // 0000009759B4: CC200003 8A020708
	v_add_f32_e32 v15, v15, v16                                // 0000009759BC: 061E210F
	v_mov_b32_dpp v16, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009759C0: 7E2002FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 0000009759C8: D501000B 200A170B
	v_add_f32_e32 v9, v9, v29                                  // 0000009759D0: 06123B09
	v_mov_b32_dpp v17, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009759D4: 7E2202FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 0000009759DC: D5010005 20120B05
	v_mov_b32_dpp v29, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009759E4: 7E3A02FA FF01620F
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 0000009759EC: D501000F 200E1F0F
	v_dual_add_f32 v11, v11, v16 :: v_dual_mul_f32 v8, 0xbfb8aa3b, v6// 0000009759F4: C906210B 0B080CFF BFB8AA3B
	v_mov_b32_dpp v21, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975A00: 7E2A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000975A08: D5010009 20121309
	v_add_f32_e32 v5, v5, v17                                  // 000000975A10: 060A2305
	v_add_f32_e32 v15, v15, v29                                // 000000975A14: 061E3B0F
	v_mov_b32_dpp v16, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975A18: 7E2002FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000975A20: D501000B 200E170B
	v_exp_f32_e32 v8, v8                                       // 000000975A28: 7E104B08
	v_add_f32_e32 v9, v9, v21                                  // 000000975A2C: 06122B09
	v_mov_b32_dpp v17, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000975A30: 7E2202FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000975A38: D5010005 20060B05
	v_mov_b32_dpp v21, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975A40: 7E2A02FA FF01640F
	v_cndmask_b32_e64 v15, -v15, v15, s4                       // 000000975A48: D501000F 20121F0F
	v_add_f32_e32 v11, v11, v16                                // 000000975A50: 0616210B
	v_rcp_f32_e32 v12, v30                                     // 000000975A54: 7E18551E
	v_mov_b32_dpp v16, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000975A58: 7E2002FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000975A60: D5010009 20061309
	v_add_f32_e32 v5, v5, v17                                  // 000000975A68: 060A2305
	v_add_f32_e32 v15, v15, v21                                // 000000975A6C: 061E2B0F
	v_mov_b32_dpp v17, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975A70: 7E2202FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000975A78: D501000B 2012170B
	v_add_f32_e32 v8, 1.0, v8                                  // 000000975A80: 061010F2
	v_add_f32_e32 v9, v9, v16                                  // 000000975A84: 06122109
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000975A88: 7E2002FA FF01680F
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000975A90: D501000F 20061F0F
	v_add_f32_e32 v11, v11, v17                                // 000000975A98: 0616230B
	v_fma_f32 v10, -v30, v12, 1.0                              // 000000975A9C: D613000A 23CA191E
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000975AA4: 100A0AFF 3DB504F3
	v_div_scale_f32 v17, null, v8, v8, v6                      // 000000975AAC: D6FC7C11 041A1108
	v_add_f32_e32 v15, v15, v16                                // 000000975AB4: 061E210F
	v_mov_b32_dpp v16, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000975AB8: 7E2002FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000975AC0: D501000B 2006170B
	v_fmac_f32_e32 v12, v10, v12                               // 000000975AC8: 5618190A
	v_div_scale_f32 v10, vcc_lo, v4, v47, v4                   // 000000975ACC: D6FC6A0A 04125F04
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000975AD4: 101212FF 3DB504F3
	v_rcp_f32_e32 v21, v17                                     // 000000975ADC: 7E2A5511
	v_add_f32_e32 v11, v11, v16                                // 000000975AE0: 0616210B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000975AE4: BF870113
	v_dual_mul_f32 v15, 0x3db504f3, v15 :: v_dual_mul_f32 v16, v10, v12// 000000975AE8: C8C61EFF 0F10190A 3DB504F3
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000975AF4: 101616FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000975AFC: BF870092
	v_fma_f32 v31, -v30, v16, v10                              // 000000975B00: D613001F 242A211E
	v_fmac_f32_e32 v16, v31, v12                               // 000000975B08: 5620191F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000975B0C: BF870091
	v_fma_f32 v10, -v30, v16, v10                              // 000000975B10: D613000A 242A211E
	v_div_fmas_f32 v10, v10, v12, v16                          // 000000975B18: D637000A 0442190A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000975B20: BF870001
	v_div_fixup_f32 v4, v10, v47, v4                           // 000000975B24: D6270004 04125F0A
	s_waitcnt vmcnt(16)                                        // 000000975B2C: BF8943F7
	v_fma_mix_f32 v9, v32, v9, neg(0) op_sel_hi:[1,0,0]        // 000000975B30: CC200009 8A021320
	v_fma_f32 v32, -v17, v21, 1.0                              // 000000975B38: D6130020 23CA2B11
	s_waitcnt vmcnt(15)                                        // 000000975B40: BF893FF7
	v_fma_mix_f32 v13, v33, v13, neg(0) op_sel_hi:[1,0,0]      // 000000975B44: CC20000D 8A021B21
	s_waitcnt vmcnt(12)                                        // 000000975B4C: BF8933F7
	v_fma_mix_f32 v15, v35, v15, neg(0) op_sel_hi:[1,0,0]      // 000000975B50: CC20000F 8A021F23
	v_mul_f32_e32 v29, 0xbfb8aa3b, v9                          // 000000975B58: 103A12FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000975B60: BF870193
	v_dual_fmac_f32 v21, v32, v21 :: v_dual_mul_f32 v4, v13, v4// 000000975B64: C8062B20 1504090D
	v_mul_f32_e32 v35, 0xbfb8aa3b, v15                         // 000000975B6C: 10461EFF BFB8AA3B
	s_waitcnt vmcnt(11)                                        // 000000975B74: BF892FF7
	v_fma_mix_f32 v11, v38, v11, neg(0) op_sel_hi:[1,0,0]      // 000000975B78: CC20000B 8A021726
	v_exp_f32_e32 v29, v29                                     // 000000975B80: 7E3A4B1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000975B84: BF870092
	v_exp_f32_e32 v31, v35                                     // 000000975B88: 7E3E4B23
	v_mul_f32_e32 v32, 0xbfb8aa3b, v11                         // 000000975B8C: 104016FF BFB8AA3B
	v_div_scale_f32 v35, s5, v6, v8, v6                        // 000000975B94: D6FC0523 041A1106
	s_mov_b32 vcc_lo, s5                                       // 000000975B9C: BEEA0005
	v_exp_f32_e32 v30, v32                                     // 000000975BA0: 7E3C4B20
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000975BA4: BF870317
	v_add_f32_e32 v29, 1.0, v29                                // 000000975BA8: 063A3AF2
	v_dual_mul_f32 v32, v35, v21 :: v_dual_add_f32 v31, 1.0, v31// 000000975BAC: C8C82B23 201E3EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000975BB4: BF870112
	v_div_scale_f32 v39, null, v29, v29, v9                    // 000000975BB8: D6FC7C27 04263B1D
	v_fma_f32 v16, -v17, v32, v35                              // 000000975BC0: D6130010 248E4111
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000975BC8: BF870293
	v_div_scale_f32 v12, null, v31, v31, v15                   // 000000975BCC: D6FC7C0C 043E3F1F
	v_add_f32_e32 v30, 1.0, v30                                // 000000975BD4: 063C3CF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000975BD8: BF870194
	v_rcp_f32_e32 v43, v39                                     // 000000975BDC: 7E565527
	v_fmac_f32_e32 v32, v16, v21                               // 000000975BE0: 56402B10
	s_waitcnt vmcnt(6)                                         // 000000975BE4: BF891BF7
	v_fma_mix_f32 v19, v27, v19, neg(0) op_sel_hi:[1,0,0]      // 000000975BE8: CC200013 8A02271B
	v_rcp_f32_e32 v45, v12                                     // 000000975BF0: 7E5A550C
	v_div_scale_f32 v33, null, v30, v30, v11                   // 000000975BF4: D6FC7C21 042E3D1E
	v_fma_f32 v17, -v17, v32, v35                              // 000000975BFC: D6130011 248E4111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000975C04: BF870092
	v_rcp_f32_e32 v16, v33                                     // 000000975C08: 7E205521
	v_div_fmas_f32 v17, v17, v21, v32                          // 000000975C0C: D6370011 04822B11
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000975C14: BF870116
	v_fma_f32 v13, -v12, v45, 1.0                              // 000000975C18: D613000D 23CA5B0C
	v_div_fixup_f32 v6, v17, v8, v6                            // 000000975C20: D6270006 041A1111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000975C28: BF870292
	v_fmac_f32_e32 v45, v13, v45                               // 000000975C2C: 565A5B0D
	v_fma_f32 v46, -v33, v16, 1.0                              // 000000975C30: D613002E 23CA2121
	v_div_scale_f32 v13, s8, v15, v31, v15                     // 000000975C38: D6FC080D 043E3F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000975C40: BF870194
	v_mul_f32_e32 v6, v19, v6                                  // 000000975C44: 100C0D13
	v_fmac_f32_e32 v16, v46, v16                               // 000000975C48: 5620212E
	v_div_scale_f32 v46, s5, v11, v30, v11                     // 000000975C4C: D6FC052E 042E3D0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000975C54: BF870004
	v_mul_f32_e32 v47, v13, v45                                // 000000975C58: 105E5B0D
	s_waitcnt vmcnt(4)                                         // 000000975C5C: BF8913F7
	v_fma_mix_f32 v0, v25, v0, neg(0) op_sel_hi:[1,0,0]        // 000000975C60: CC200000 8A020119
	s_waitcnt vmcnt(3)                                         // 000000975C68: BF890FF7
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 000000975C6C: CC200005 8A020B1A
	v_fma_f32 v17, -v12, v47, v13                              // 000000975C74: D6130011 24365F0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000975C7C: BF870112
	v_mul_f32_e32 v26, 0xbfb8aa3b, v5                          // 000000975C80: 10340AFF BFB8AA3B
	v_fmac_f32_e32 v47, v17, v45                               // 000000975C88: 565E5B11
	s_waitcnt vmcnt(0)                                         // 000000975C8C: BF8903F7
	v_fma_mix_f32 v6, v24, v6, neg(0) op_sel_hi:[1,0,0]        // 000000975C90: CC200006 8A020D18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000975C98: BF870293
	v_exp_f32_e32 v26, v26                                     // 000000975C9C: 7E344B1A
	v_add_f32_e32 v26, 1.0, v26                                // 000000975CA0: 063434F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000975CA4: BF8702C1
	v_div_scale_f32 v36, null, v26, v26, v5                    // 000000975CA8: D6FC7C24 0416351A
	v_div_scale_f32 v10, s6, v5, v26, v5                       // 000000975CB0: D6FC060A 04163505
	s_mov_b32 vcc_lo, s6                                       // 000000975CB8: BEEA0006
	v_rcp_f32_e32 v38, v36                                     // 000000975CBC: 7E4C5524
	v_fma_f32 v44, -v36, v38, 1.0                              // 000000975CC0: D613002C 23CA4D24
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000975CC8: BF870121
	v_fmac_f32_e32 v38, v44, v38                               // 000000975CCC: 564C4D2C
	v_fma_f32 v44, -v39, v43, 1.0                              // 000000975CD0: D613002C 23CA5727
	v_mul_f32_e32 v35, v10, v38                                // 000000975CD8: 10464D0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000975CDC: BF8701A2
	v_fmac_f32_e32 v43, v44, v43                               // 000000975CE0: 5656572C
	v_div_scale_f32 v44, s7, v9, v29, v9                       // 000000975CE4: D6FC072C 04263B09
	v_fma_f32 v21, -v36, v35, v10                              // 000000975CEC: D6130015 242A4724
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000975CF4: BF870121
	v_dual_mul_f32 v32, v44, v43 :: v_dual_fmac_f32 v35, v21, v38// 000000975CF8: C8C0572C 20224D15
	v_mul_f32_e32 v21, v46, v16                                // 000000975D00: 102A212E
	v_fma_f32 v8, -v39, v32, v44                               // 000000975D04: D6130008 24B24127
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000975D0C: BF870113
	v_fma_f32 v10, -v36, v35, v10                              // 000000975D10: D613000A 242A4724
	v_fmac_f32_e32 v32, v8, v43                                // 000000975D18: 56405708
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000975D1C: BF870194
	v_fma_f32 v8, -v33, v21, v46                               // 000000975D20: D6130008 24BA2B21
	v_div_fmas_f32 v10, v10, v38, v35                          // 000000975D28: D637000A 048E4D0A
	s_mov_b32 vcc_lo, s7                                       // 000000975D30: BEEA0007
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000975D34: BF870193
	v_fma_f32 v17, -v39, v32, v44                              // 000000975D38: D6130011 24B24127
	v_fmac_f32_e32 v21, v8, v16                                // 000000975D40: 562A2108
	v_fma_f32 v8, -v12, v47, v13                               // 000000975D44: D6130008 24365F0C
	v_div_fixup_f32 v5, v10, v26, v5                           // 000000975D4C: D6270005 0416350A
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 000000975D54: 101C1CFF 3DB504F3
	v_div_fmas_f32 v12, v17, v43, v32                          // 000000975D5C: D637000C 04825711
	v_fma_f32 v13, -v33, v21, v46                              // 000000975D64: D613000D 24BA2B21
	s_mov_b32 vcc_lo, s8                                       // 000000975D6C: BEEA0008
	v_fma_mix_f32 v10, v34, v18, neg(0) op_sel_hi:[1,0,0]      // 000000975D70: CC20000A 8A022522
	v_div_fmas_f32 v8, v8, v45, v47                            // 000000975D78: D6370008 04BE5B08
	s_mov_b32 vcc_lo, s5                                       // 000000975D80: BEEA0005
	v_div_fixup_f32 v9, v12, v29, v9                           // 000000975D84: D6270009 04263B0C
	v_div_fmas_f32 v13, v13, v16, v21                          // 000000975D8C: D637000D 0456210D
	v_fma_mix_f32 v12, v23, v22, neg(0) op_sel_hi:[1,0,0]      // 000000975D94: CC20000C 8A022D17
	v_fma_mix_f32 v7, v7, v14, neg(0) op_sel_hi:[1,0,0]        // 000000975D9C: CC200007 8A021D07
	v_div_fixup_f32 v8, v8, v31, v15                           // 000000975DA4: D6270008 043E3F08
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000975DAC: BF870214
	v_div_fixup_f32 v11, v13, v30, v11                         // 000000975DB0: D627000B 042E3D0D
	v_mul_f32_e32 v9, v12, v9                                  // 000000975DB8: 1012130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000975DBC: BF870223
	v_dual_mul_f32 v5, v7, v5 :: v_dual_mul_f32 v8, v10, v8    // 000000975DC0: C8C60B07 0508110A
	v_fma_mix_f32 v10, v4, v40, v6 op_sel_hi:[0,1,0]           // 000000975DC8: CC20000A 141A5104
	v_mul_f32_e32 v0, v0, v11                                  // 000000975DD0: 10001700
	s_delay_alu instid0(VALU_DEP_4)                            // 000000975DD4: BF870004
	v_fma_mix_f32 v7, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 000000975DD8: CC200007 8A02131C
	v_fma_mix_f32 v9, v2, v37, v3 op_sel_hi:[0,1,0]            // 000000975DE0: CC200009 140E4B02
	v_fma_mix_f32 v2, v2, v37, -v3 op_sel_hi:[0,1,0]           // 000000975DE8: CC200002 940E4B02
	v_fma_mix_f32 v3, v4, v40, -v6 op_sel_hi:[0,1,0]           // 000000975DF0: CC200003 941A5104
	v_fma_mix_f32 v0, v20, v0, neg(0) op_sel_hi:[1,0,0]        // 000000975DF8: CC200000 8A020114
	v_fma_mix_f32 v11, v5, v41, v7 op_sel_hi:[0,1,0]           // 000000975E00: CC20000B 141E5305
	v_fma_mix_f32 v4, v5, v41, -v7 op_sel_hi:[0,1,0]           // 000000975E08: CC200004 941E5305
	v_add_f32_e32 v5, v9, v10                                  // 000000975E10: 060A1509
	v_sub_f32_e32 v7, v9, v10                                  // 000000975E14: 080E1509
	v_fma_mix_f32 v12, v8, v42, v0 op_sel_hi:[0,1,0]           // 000000975E18: CC20000C 14025508
	v_fma_mix_f32 v0, v8, v42, -v0 op_sel_hi:[0,1,0]           // 000000975E20: CC200000 94025508
	v_add_f32_e32 v8, v2, v3                                   // 000000975E28: 06100702
	v_sub_f32_e32 v2, v2, v3                                   // 000000975E2C: 08040702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000975E30: BF8701B4
	v_add_f32_e32 v6, v11, v12                                 // 000000975E34: 060C190B
	v_sub_f32_e32 v9, v11, v12                                 // 000000975E38: 0812190B
	v_add_f32_e32 v10, v4, v0                                  // 000000975E3C: 06140104
	v_dual_sub_f32 v0, v4, v0 :: v_dual_add_f32 v3, v5, v6     // 000000975E40: C9480104 00020D05
	v_sub_f32_e32 v4, v5, v6                                   // 000000975E48: 08080D05
	s_delay_alu instid0(VALU_DEP_3)                            // 000000975E4C: BF870003
	v_add_f32_e32 v6, v8, v10                                  // 000000975E50: 060C1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000975E54: 08101508
	v_add_f32_e32 v10, v7, v9                                  // 000000975E58: 06141307
	v_mov_b32_dpp v5, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975E5C: 7E0A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000975E64: D5010003 200A0703
	v_sub_f32_e32 v7, v7, v9                                   // 000000975E6C: 080E1307
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975E70: 7E1C02FA FF016104
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975E78: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000975E80: D501000A 200A150A
	v_add_f32_e32 v3, v3, v5                                   // 000000975E88: 06060B03
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975E8C: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000975E94: D5010006 200A0D06
	v_cndmask_b32_e64 v15, -v4, v4, s2                         // 000000975E9C: D501000F 200A0904
	v_add_f32_e32 v9, v10, v9                                  // 000000975EA4: 0612130A
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975EA8: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000975EB0: D5010003 200E0703
	v_add_f32_e32 v5, v6, v5                                   // 000000975EB8: 060A0B06
	v_add_f32_e32 v6, v2, v0                                   // 000000975EBC: 060C0102
	v_sub_f32_e32 v10, v2, v0                                  // 000000975EC0: 08140102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000975EC4: BF870214
	v_add_f32_e32 v0, v3, v11                                  // 000000975EC8: 06001703
	v_mov_b32_dpp v2, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975ECC: 7E0402FA FF016205
	v_cndmask_b32_e64 v3, -v5, v5, s3                          // 000000975ED4: D5010003 200E0B05
	v_mov_b32_dpp v5, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975EDC: 7E0A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000975EE4: D5010009 200E1309
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975EEC: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000975EF4: D5010006 200A0D06
	v_add_f32_e32 v2, v3, v2                                   // 000000975EFC: 06040503
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975F00: 7E2002FA FF01610A
	v_add_f32_e32 v5, v9, v5                                   // 000000975F08: 060A0B09
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000975F0C: D501000A 200A150A
	v_add_f32_e32 v6, v6, v11                                  // 000000975F14: 060C1706
	v_mov_b32_dpp v9, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975F18: 7E1202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000975F20: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975F28: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000975F30: D5010005 20120B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975F38: 7E1802FA FF016206
	v_cndmask_b32_e64 v13, -v6, v6, s3                         // 000000975F40: D501000D 200E0D06
	v_add_f32_e32 v4, v2, v9                                   // 000000975F48: 06081302
	v_add_f32_e32 v10, v10, v16                                // 000000975F4C: 0614210A
	v_dual_add_f32 v6, v5, v11 :: v_dual_add_f32 v11, v15, v14 // 000000975F50: C9081705 060A1D0F
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975F58: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000975F60: D5010008 200A1108
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000975F68: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000975F70: D5010007 200A0F07
	v_add_f32_e32 v9, v13, v12                                 // 000000975F78: 0612190D
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975F7C: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000975F84: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000975F8C: BF870234
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v7, v15   // 000000975F90: C9081D08 08061F07
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975F98: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000975FA0: D501000A 200E150A
	v_add_f32_e32 v11, v11, v13                                // 000000975FA8: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000975FAC: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975FB0: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000975FB8: D5010008 200E1108
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000975FC0: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000975FC8: D5010007 200E0F07
	v_add_f32_e32 v10, v10, v15                                // 000000975FD0: 06141F0A
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975FD4: 7E0602FA FF016400
	v_add_f32_e32 v8, v8, v13                                  // 000000975FDC: 06101B08
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000975FE0: D5010000 20120100
	v_add_f32_e32 v7, v7, v14                                  // 000000975FE8: 060E1D07
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975FEC: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000975FF4: D5010009 20121309
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000975FFC: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000976004: D501000B 2012170B
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000097600C: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000976014: D5010008 20121108
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000097601C: 7E1E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000976024: D5010007 20120F07
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000097602C: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s4                       // 000000976034: D5010011 2012150A
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v9, v12    // 00000097603C: C9080700 00081909
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v8, v14// 000000976044: C9081B0B 0A0A1D08
	v_add_f32_e32 v13, v7, v15                                 // 00000097604C: 061A1F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000976050: BF870214
	v_add_f32_e32 v15, v17, v16                                // 000000976054: 061E2111
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000976058: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000976060: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000976068: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000976070: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000976078: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000976080: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000976088: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000976090: 7E2002FA FF01680F
	s_mov_b32 s2, 0x3db504f3                                   // 000000976098: BE8200FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s0                             // 0000009760A0: 8B7E007E
	s_cbranch_execz 65                                         // 0000009760A4: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x60ac>
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 0000009760A8: D501000F 20061F0F
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 0000009760B0: D5010000 20060100
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000009760B8: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000009760C0: D5010006 20060D06
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000009760C8: D5010009 20061309
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 0000009760D0: D501000D 20061B0D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009760D8: D501000A 2006150A
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000009760E0: D501000B 2006170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 0000009760E8: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 0000009760F0: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 0000009760F4: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 0000009760F8: 060E0F09
	s_mul_i32 s0, s10, 0x500                                   // 0000009760FC: 9600FF0A 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 000000976104: C9081D0D 0D08110A
	s_mul_hi_i32 s1, s10, 0x500                                // 00000097610C: 9701FF0A 00000500
	v_add_f32_e32 v11, v11, v12                                // 000000976114: 0616190B
	s_add_u32 s0, s22, s0                                      // 000000976118: 80000016
	v_fma_mixlo_f16 v0, v0, s2, 0                              // 00000097611C: CC210000 02000500
	s_addc_u32 s1, s23, s1                                     // 000000976124: 82010117
	v_fma_mixhi_f16 v0, v3, s2, 0                              // 000000976128: CC220000 02000503
	s_add_u32 s0, s0, s12                                      // 000000976130: 80000C00
	v_fma_mixlo_f16 v2, v5, s2, 0                              // 000000976134: CC210002 02000505
	s_addc_u32 s1, s1, s13                                     // 00000097613C: 82010D01
	v_fma_mixhi_f16 v2, v7, s2, 0                              // 000000976140: CC220002 02000507
	v_fma_mixlo_f16 v3, v8, s2, 0                              // 000000976148: CC210003 02000508
	v_fma_mixhi_f16 v3, v11, s2, 0                             // 000000976150: CC220003 0200050B
	v_fma_mixlo_f16 v4, v13, s2, 0                             // 000000976158: CC210004 0200050D
	v_fma_mixhi_f16 v4, v15, s2, 0                             // 000000976160: CC220004 0200050F
	s_clause 0x7                                               // 000000976168: BF850007
	global_store_b16 v1, v0, s[0:1]                            // 00000097616C: DC660000 00000001
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000976174: DC960020 00000001
	global_store_b16 v1, v2, s[0:1] offset:64                  // 00000097617C: DC660040 00000201
	global_store_d16_hi_b16 v1, v2, s[0:1] offset:96           // 000000976184: DC960060 00000201
	global_store_b16 v1, v3, s[0:1] offset:128                 // 00000097618C: DC660080 00000301
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:160          // 000000976194: DC9600A0 00000301
	global_store_b16 v1, v4, s[0:1] offset:192                 // 00000097619C: DC6600C0 00000401
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:224          // 0000009761A4: DC9600E0 00000401
	s_nop 0                                                    // 0000009761AC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000009761B0: BFB60003
	s_endpgm                                                   // 0000009761B4: BFB00000
		...

