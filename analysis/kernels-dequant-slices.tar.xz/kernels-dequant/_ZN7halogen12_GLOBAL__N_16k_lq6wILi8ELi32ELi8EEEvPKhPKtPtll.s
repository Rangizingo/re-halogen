0000000000350900 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi8EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi8EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000350900: F40C0100 F8000000
	v_mov_b32_e32 v6, 0                                        // 000000350908: 7E0C0280
	s_mov_b32 s3, 0                                            // 00000035090C: BE830080
	v_lshrrev_b32_e32 v16, 5, v0                               // 000000350910: 32200085
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v5, 0              // 000000350914: CA100080 12040080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v8, 0               // 00000035091C: CA100080 07080080
	v_mov_b32_e32 v15, 0                                       // 000000350924: 7E1E0280
	v_mov_b32_e32 v11, 0                                       // 000000350928: 7E160280
	v_dual_mov_b32 v14, 0 :: v_dual_and_b32 v17, 31, v0        // 00000035092C: CA240080 0E10009F
	s_waitcnt lgkmcnt(0)                                       // 000000350934: BF89FC07
	s_ashr_i32 s16, s11, 31                                    // 000000350938: 86109F0B
	v_mov_b32_e32 v1, s4                                       // 00000035093C: 7E020204
	s_lshr_b32 s12, s16, 27                                    // 000000350940: 850C9B10
	v_mov_b32_e32 v2, s5                                       // 000000350944: 7E040205
	s_add_u32 s12, s10, s12                                    // 000000350948: 800C0C0A
	s_addc_u32 s13, s11, 0                                     // 00000035094C: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000350950: BF8704B9
	s_lshr_b64 s[18:19], s[12:13], 5                           // 000000350954: 8592850C
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000350958: F4040300 F8000020
	s_add_i32 s14, s18, 7                                      // 000000350960: 810E8712
	s_ashr_i32 s15, s14, 31                                    // 000000350964: 860F9F0E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000350968: BF870499
	s_lshr_b32 s0, s15, 29                                     // 00000035096C: 85009D0F
	s_add_i32 s14, s14, s0                                     // 000000350970: 810E000E
	s_lshr_b32 s0, s11, 31                                     // 000000350974: 85009F0B
	s_ashr_i32 s19, s14, 3                                     // 000000350978: 8613830E
	s_add_u32 s0, s10, s0                                      // 00000035097C: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000350980: 8201800B
	s_lshr_b32 s17, s16, 30                                    // 000000350984: 85119E10
	s_ashr_i64 s[14:15], s[0:1], 1                             // 000000350988: 868E8100
	s_add_u32 s0, s10, s17                                     // 00000035098C: 8000110A
	s_addc_u32 s1, s11, 0                                      // 000000350990: 8201800B
	s_lshr_b32 s20, s16, 28                                    // 000000350994: 85149C10
	s_ashr_i64 s[16:17], s[0:1], 2                             // 000000350998: 86908200
	s_add_u32 s0, s10, s20                                     // 00000035099C: 8000140A
	s_addc_u32 s1, s11, 0                                      // 0000003509A0: 8201800B
	.long 0xd72c0003                                           // 0000003509A4: D72C0003
	v_cndmask_b32_e32 v1, s19, v16, vcc_lo                     // 0000003509A8: 02022013
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003509AC: 86808400
	s_add_u32 s4, s16, s14                                     // 0000003509B0: 80040E10
	s_addc_u32 s20, s17, s15                                   // 0000003509B4: 82140F11
	s_add_u32 s0, s4, s0                                       // 0000003509B8: 80000004
	s_addc_u32 s1, s20, s1                                     // 0000003509BC: 82010114
	s_add_u32 s0, s0, 15                                       // 0000003509C0: 80008F00
	s_addc_u32 s1, s1, 0                                       // 0000003509C4: 82018001
	s_waitcnt lgkmcnt(0)                                       // 0000003509C8: BF89FC07
	.long 0xd4510014                                           // 0000003509CC: D4510014
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000003509D0: 02001802
	s_ashr_i32 s4, s1, 31                                      // 0000003509D4: 86049F01
	v_add_nc_u32_e32 v19, v3, v17                              // 0000003509D8: 4A262303
	s_lshr_b32 s4, s4, 28                                      // 0000003509DC: 85049C04
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003509E0: BF870009
	s_add_u32 s0, s0, s4                                       // 0000003509E4: 80000400
	s_addc_u32 s1, s1, 0                                       // 0000003509E8: 82018001
	s_lshl_b64 s[4:5], s[2:3], 4                               // 0000003509EC: 84848402
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003509F0: 86808400
	s_and_b32 s20, s20, exec_lo                                // 0000003509F4: 8B147E14
	s_cselect_b32 s4, s4, 0                                    // 0000003509F8: 98048004
	s_cselect_b32 s5, s5, 0                                    // 0000003509FC: 98058005
	v_mad_u64_u32 v[9:10], null, s4, s0, v[1:2]                // 000000350A00: D6FE7C09 04040004
	v_add_nc_u32_e32 v1, s19, v3                               // 000000350A08: 4A020613
	s_mul_i32 s5, s5, s0                                       // 000000350A0C: 96050005
	s_mul_i32 s4, s4, s1                                       // 000000350A10: 96040104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000350A14: BF870191
	v_min_i32_e32 v20, s18, v1                                 // 000000350A18: 22280212
	v_add_nc_u32_e32 v1, s5, v10                               // 000000350A1C: 4A021405
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350A20: BF870112
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 000000350A24: 7C822913
	v_add_nc_u32_e32 v21, s4, v1                               // 000000350A28: 4A2A0204
	s_and_saveexec_b32 s1, vcc_lo                              // 000000350A2C: BE81206A
	s_cbranch_execz 39                                         // 000000350A30: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi8EEEvPKhPKtPtll+0x1d0>
	v_lshlrev_b32_e32 v1, 4, v19                               // 000000350A34: 30022684
	v_lshlrev_b32_e32 v4, 1, v19                               // 000000350A38: 30082681
	v_lshlrev_b32_e32 v3, 3, v19                               // 000000350A3C: 30062683
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000350A40: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000350A44: 3404029F
	.long 0xd7000001                                           // 000000350A48: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 000000350A4C: 02020309
	v_and_b32_e32 v8, -4, v4                                   // 000000350A50: 361008C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000350A54: BF870214
	v_ashrrev_i32_e32 v7, 31, v3                               // 000000350A58: 340E069F
	v_add_co_ci_u32_e64 v2, null, v21, v2, s0                  // 000000350A5C: D5207C02 00020515
	.long 0xd7000005                                           // 000000350A64: D7000005
	v_cndmask_b32_e32 v0, v9, v14, vcc_lo                      // 000000350A68: 02001D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000350A6C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s15, v21, s0                 // 000000350A70: D5207C06 00022A0F
	v_ashrrev_i32_e32 v12, 31, v8                              // 000000350A78: 3418109F
	.long 0xd700000a                                           // 000000350A7C: D700000A
	v_cndmask_b32_e32 v0, v5, v16, vcc_lo                      // 000000350A80: 02002105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000350A84: BF8700A1
	v_add_co_ci_u32_e64 v11, null, s17, v6, s0                 // 000000350A88: D5207C0B 00020C11
	.long 0xd7000003                                           // 000000350A90: D7000003
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 000000350A94: 02020705
	v_add_co_ci_u32_e64 v4, null, v6, v7, s0                   // 000000350A98: D5207C04 00020F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350AA0: BF870094
	.long 0xd700000a                                           // 000000350AA4: D700000A
	v_cndmask_b32_e32 v1, v10, v8, vcc_lo                      // 000000350AA8: 0202110A
	v_add_co_ci_u32_e64 v11, null, v11, v12, s0                // 000000350AAC: D5207C0B 0002190B
	s_clause 0x2                                               // 000000350AB4: BF850002
	global_load_b128 v[5:8], v[1:2], off                       // 000000350AB8: DC5E0000 057C0001
	global_load_b64 v[14:15], v[3:4], off                      // 000000350AC0: DC560000 0E7C0003
	global_load_b32 v11, v[10:11], off                         // 000000350AC8: DC520000 0B7C000A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000350AD0: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000350AD4: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 000000350ADC: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 000000350AE4: CA100080 1A1A0080
	v_mov_b32_e32 v28, 0                                       // 000000350AEC: 7E380280
	s_and_saveexec_b32 s1, vcc_lo                              // 000000350AF0: BE81206A
	s_cbranch_execz 1130                                       // 000000350AF4: BFA5046A <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi8EEEvPKhPKtPtll+0x13a0>
	.long 0xd7006a1d                                           // 000000350AF8: D7006A1D
	v_cndmask_b32_e32 v0, v9, v14, vcc_lo                      // 000000350AFC: 02001D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000350B00: BF8701A1
	v_add_co_ci_u32_e64 v30, null, s15, v21, vcc_lo            // 000000350B04: D5207C1E 01AA2A0F
	v_dual_mov_b32 v18, 0 :: v_dual_add_nc_u32 v1, 32, v19     // 000000350B0C: CA200080 120026A0
	.long 0xd7006a1f                                           // 000000350B14: D7006A1F
	v_cndmask_b32_e32 v0, v29, v16, vcc_lo                     // 000000350B18: 0200211D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000350B1C: BF870221
	v_add_co_ci_u32_e64 v32, null, s17, v30, vcc_lo            // 000000350B20: D5207C20 01AA3C11
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v10, 5, v19    // 000000350B28: CA220080 170A2685
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v33, 4, v1     // 000000350B30: CA220080 16200284
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v34, 3, v1     // 000000350B38: CA220080 19220283
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v35, 1, v1     // 000000350B40: CA220080 18220281
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 000000350B48: CA100080 1A1A0080
	v_mov_b32_e32 v28, 0                                       // 000000350B50: 7E380280
	s_waitcnt vmcnt(0)                                         // 000000350B54: BF8903F7
	v_mov_b32_e32 v36, v11                                     // 000000350B58: 7E48030B
	s_mul_i32 s0, s11, 6                                       // 000000350B5C: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000350B60: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000350B64: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000350B68: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000350B6C: 9610860A
	s_mov_b32 s15, 0                                           // 000000350B70: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000350B74: 848A810A
	s_branch 1057                                              // 000000350B78: BFA00421 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi8EEEvPKhPKtPtll+0x1300>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000350B7C: 8C7E117E
	v_lshlrev_b32_e32 v37, 4, v14                              // 000000350B80: 304A1C84
	v_lshlrev_b32_e32 v39, 2, v14                              // 000000350B84: 304E1C82
	v_lshrrev_b32_e32 v38, 4, v5                               // 000000350B88: 324C0A84
	.long 0x7f603880                                           // 000000350B8C: 7F603880
	v_lshrrev_b32_e32 v40, 6, v14                              // 000000350B90: 32501C86
	v_and_b32_e32 v37, 48, v37                                 // 000000350B94: 364A4AB0
	v_and_b32_e32 v39, 48, v39                                 // 000000350B98: 364E4EB0
	v_lshrrev_b32_e32 v41, 22, v14                             // 000000350B9C: 32521C96
	v_lshrrev_b32_e32 v43, 6, v15                              // 000000350BA0: 32561E86
	v_and_b32_e32 v40, 48, v40                                 // 000000350BA4: 365050B0
	v_and_or_b32 v37, v5, 15, v37                              // 000000350BA8: D6570025 04951F05
	v_and_or_b32 v38, v38, 15, v39                             // 000000350BB0: D6570026 049D1F26
	v_and_b32_e32 v41, 48, v41                                 // 000000350BB8: 365252B0
	v_lshrrev_b32_e32 v42, 20, v7                              // 000000350BBC: 32540E94
	v_and_b32_e32 v43, 48, v43                                 // 000000350BC0: 365656B0
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000350BC4: 7E4A2325
	v_lshrrev_b32_e32 v50, 18, v15                             // 000000350BC8: 32641E92
	v_lshrrev_b32_e32 v51, 22, v15                             // 000000350BCC: 32661E96
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000350BD0: 8B006A7E
	v_and_or_b32 v42, v42, 15, v43                             // 000000350BD4: D657002A 04AD1F2A
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350BDC: CC206025 142E1725
	v_and_b32_e32 v50, 48, v50                                 // 000000350BE4: 366464B0
	v_and_b32_e32 v51, 48, v51                                 // 000000350BE8: 366666B0
	v_add_nc_u32_e32 v33, 0x200, v33                           // 000000350BEC: 4A4242FF 00000200
	v_add_nc_u32_e32 v34, 0x100, v34                           // 000000350BF4: 4A4444FF 00000100
	v_bfe_u32 v39, v37, 16, 1                                  // 000000350BFC: D6100027 02052125
	v_add_nc_u32_e32 v35, 64, v35                              // 000000350C04: 4A4646C0
	s_or_b32 s15, s0, s15                                      // 000000350C08: 8C0F0F00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000350C0C: BF870122
	v_add3_u32 v37, v37, v39, 0x7fff                           // 000000350C10: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 2, v14                              // 000000350C1C: 324E1C82
	.long 0x7e6039a5                                           // 000000350C20: 7E6039A5
	v_cvt_f32_ubyte0_e32 v37, v38                              // 000000350C24: 7E4A2326
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350C28: BF870113
	v_and_b32_e32 v39, 48, v39                                 // 000000350C2C: 364E4EB0
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350C30: CC206025 142E1725
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350C38: BF870091
	v_bfe_u32 v38, v37, 16, 1                                  // 000000350C3C: D6100026 02052125
	v_add3_u32 v37, v37, v38, 0x7fff                           // 000000350C44: D6550025 03FE4D25 00007FFF
	v_and_b32_e32 v38, 48, v14                                 // 000000350C50: 364C1CB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000350C54: BF8700A2
	v_and_or_b32 v44, 0xffff0000, v37, v48                     // 000000350C58: D657002C 04C24AFF FFFF0000
	v_lshrrev_b32_e32 v37, 8, v5                               // 000000350C64: 324A0A88
	v_and_or_b32 v37, v37, 15, v38                             // 000000350C68: D6570025 04991F25
	v_lshrrev_b32_e32 v38, 12, v5                              // 000000350C70: 324C0A8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350C74: BF870112
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000350C78: 7E4A2325
	v_and_or_b32 v38, v38, 15, v39                             // 000000350C7C: D6570026 049D1F26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350C84: BF870092
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350C88: CC206025 142E1725
	v_bfe_u32 v39, v37, 16, 1                                  // 000000350C90: D6100027 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000350C98: BF870121
	v_add3_u32 v37, v37, v39, 0x7fff                           // 000000350C9C: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 20, v5                              // 000000350CA8: 324E0A94
	.long 0x7e6039a5                                           // 000000350CAC: 7E6039A5
	v_cvt_f32_ubyte0_e32 v37, v38                              // 000000350CB0: 7E4A2326
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350CB4: BF870113
	v_and_or_b32 v39, v39, 15, v40                             // 000000350CB8: D6570027 04A11F27
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350CC0: CC206025 142E1725
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350CC8: BF870091
	v_bfe_u32 v38, v37, 16, 1                                  // 000000350CCC: D6100026 02052125
	v_add3_u32 v37, v37, v38, 0x7fff                           // 000000350CD4: D6550025 03FE4D25 00007FFF
	v_lshrrev_b32_e32 v38, 4, v14                              // 000000350CE0: 324C1C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000350CE4: BF8701A2
	v_and_or_b32 v45, 0xffff0000, v37, v48                     // 000000350CE8: D657002D 04C24AFF FFFF0000
	.long 0x7e603985                                           // 000000350CF4: 7E603985
	v_and_b32_e32 v38, 48, v38                                 // 000000350CF8: 364C4CB0
	v_lshrrev_b32_e32 v37, 8, v14                              // 000000350CFC: 324A1C88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350D00: BF870112
	v_and_or_b32 v38, v48, 15, v38                             // 000000350D04: D6570026 04991F30
	v_and_b32_e32 v37, 48, v37                                 // 000000350D0C: 364A4AB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350D10: BF870092
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000350D14: 7E4C2326
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350D18: CC206026 142E1726
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350D20: BF870091
	v_bfe_u32 v40, v38, 16, 1                                  // 000000350D24: D6100028 02052126
	v_add3_u32 v38, v38, v40, 0x7fff                           // 000000350D2C: D6550026 03FE5126 00007FFF
	v_lshrrev_b32_e32 v40, 18, v14                             // 000000350D38: 32501C92
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000350D3C: BF8701A2
	.long 0x7e6039a6                                           // 000000350D40: 7E6039A6
	v_cvt_f32_ubyte0_e32 v38, v39                              // 000000350D44: 7E4C2327
	v_and_b32_e32 v40, 48, v40                                 // 000000350D48: 365050B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350D4C: BF870092
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350D50: CC206026 142E1726
	v_bfe_u32 v39, v38, 16, 1                                  // 000000350D58: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000350D60: BF870121
	v_add3_u32 v38, v38, v39, 0x7fff                           // 000000350D64: D6550026 03FE4F26 00007FFF
	v_lshrrev_b32_e32 v39, 12, v14                             // 000000350D70: 324E1C8C
	v_and_or_b32 v46, 0xffff0000, v38, v48                     // 000000350D74: D657002E 04C24CFF FFFF0000
	v_lshrrev_b32_e32 v38, 24, v5                              // 000000350D80: 324C0A98
	v_lshrrev_b32_e32 v5, 28, v5                               // 000000350D84: 320A0A9C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000350D88: BF870122
	v_and_or_b32 v37, v38, 15, v37                             // 000000350D8C: D6570025 04951F26
	v_lshrrev_b32_e32 v38, 10, v14                             // 000000350D94: 324C1C8A
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000350D98: 7E4A2325
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350D9C: BF870112
	v_and_or_b32 v5, v38, 48, v5                               // 000000350DA0: D6570005 04156126
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350DA8: CC206025 142E1725
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350DB0: BF870112
	v_cvt_f32_ubyte0_e32 v5, v5                                // 000000350DB4: 7E0A2305
	v_bfe_u32 v38, v37, 16, 1                                  // 000000350DB8: D6100026 02052125
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350DC0: BF870112
	v_fma_mix_f32 v5, v5, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350DC4: CC206005 142E1705
	v_add3_u32 v37, v37, v38, 0x7fff                           // 000000350DCC: D6550025 03FE4D25 00007FFF
	v_lshrrev_b32_e32 v38, 14, v14                             // 000000350DD8: 324C1C8E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000350DDC: BF870212
	.long 0x7e6039a5                                           // 000000350DE0: 7E6039A5
	v_bfe_u32 v37, v5, 16, 1                                   // 000000350DE4: D6100025 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350DEC: BF870113
	v_and_b32_e32 v38, 48, v38                                 // 000000350DF0: 364C4CB0
	v_add3_u32 v5, v5, v37, 0x7fff                             // 000000350DF4: D6550005 03FE4B05 00007FFF
	v_lshrrev_b32_e32 v37, 4, v6                               // 000000350E00: 324A0C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000350E04: BF8701A2
	v_and_or_b32 v47, 0xffff0000, v5, v48                      // 000000350E08: D657002F 04C20AFF FFFF0000
	v_and_b32_e32 v5, 48, v39                                  // 000000350E14: 360A4EB0
	v_and_or_b32 v37, v37, 15, v38                             // 000000350E18: D6570025 04991F25
	.long 0x7e60398e                                           // 000000350E20: 7E60398E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000350E24: BF870193
	v_and_or_b32 v5, v6, 15, v5                                // 000000350E28: D6570005 04151F06
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000350E30: 7E4A2325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000350E34: BF870193
	v_and_b32_e32 v39, 48, v48                                 // 000000350E38: 364E60B0
	v_cvt_f32_ubyte0_e32 v5, v5                                // 000000350E3C: 7E0A2305
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350E40: BF870113
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350E44: CC206025 142E1725
	v_fma_mix_f32 v5, v5, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350E4C: CC206005 142E1705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350E54: BF870091
	v_bfe_u32 v38, v5, 16, 1                                   // 000000350E58: D6100026 02052105
	v_add3_u32 v5, v5, v38, 0x7fff                             // 000000350E60: D6550005 03FE4D05 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350E6C: BF870114
	v_bfe_u32 v38, v37, 16, 1                                  // 000000350E70: D6100026 02052125
	.long 0x7e0a3985                                           // 000000350E78: 7E0A3985
	.long 0x7f0a39b0                                           // 000000350E7C: 7F0A39B0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000350E80: BF870123
	v_add3_u32 v37, v37, v38, 0x7fff                           // 000000350E84: D6550025 03FE4D25 00007FFF
	v_lshrrev_b32_e32 v38, 20, v14                             // 000000350E90: 324C1C94
	v_and_or_b32 v5, 0xffff0000, v37, v5                       // 000000350E94: D6570005 04164AFF FFFF0000
	v_lshrrev_b32_e32 v37, 8, v6                               // 000000350EA0: 324A0C88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350EA4: BF870113
	v_and_b32_e32 v38, 48, v38                                 // 000000350EA8: 364C4CB0
	v_and_or_b32 v37, v37, 15, v39                             // 000000350EAC: D6570025 049D1F25
	v_lshrrev_b32_e32 v39, 12, v6                              // 000000350EB4: 324E0C8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350EB8: BF870112
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000350EBC: 7E4A2325
	v_and_or_b32 v39, v39, 15, v40                             // 000000350EC0: D6570027 04A11F27
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350EC8: BF870092
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350ECC: CC206025 142E1725
	v_bfe_u32 v40, v37, 16, 1                                  // 000000350ED4: D6100028 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000350EDC: BF870121
	v_add3_u32 v37, v37, v40, 0x7fff                           // 000000350EE0: D6550025 03FE5125 00007FFF
	v_lshrrev_b32_e32 v40, 20, v6                              // 000000350EEC: 32500C94
	.long 0x7e6039a5                                           // 000000350EF0: 7E6039A5
	v_cvt_f32_ubyte0_e32 v37, v39                              // 000000350EF4: 7E4A2327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350EF8: BF870113
	v_and_or_b32 v40, v40, 15, v41                             // 000000350EFC: D6570028 04A51F28
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350F04: CC206025 142E1725
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350F0C: BF870091
	v_bfe_u32 v39, v37, 16, 1                                  // 000000350F10: D6100027 02052125
	v_add3_u32 v37, v37, v39, 0x7fff                           // 000000350F18: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 24, v14                             // 000000350F24: 324E1C98
	v_lshrrev_b32_e32 v14, 26, v14                             // 000000350F28: 321C1C9A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000350F2C: BF870223
	v_and_or_b32 v37, 0xffff0000, v37, v48                     // 000000350F30: D6570025 04C24AFF FFFF0000
	.long 0x7e603986                                           // 000000350F3C: 7E603986
	v_and_b32_e32 v39, 48, v39                                 // 000000350F40: 364E4EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350F44: BF870092
	v_and_or_b32 v38, v48, 15, v38                             // 000000350F48: D6570026 04991F30
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000350F50: 7E4C2326
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350F54: BF870091
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350F58: CC206026 142E1726
	v_bfe_u32 v41, v38, 16, 1                                  // 000000350F60: D6100029 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000350F68: BF870121
	v_add3_u32 v38, v38, v41, 0x7fff                           // 000000350F6C: D6550026 03FE5326 00007FFF
	v_lshrrev_b32_e32 v41, 2, v15                              // 000000350F78: 32521E82
	.long 0x7e6039a6                                           // 000000350F7C: 7E6039A6
	v_cvt_f32_ubyte0_e32 v38, v40                              // 000000350F80: 7E4C2328
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000350F84: BF870113
	v_and_b32_e32 v41, 48, v41                                 // 000000350F88: 365252B0
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350F8C: CC206026 142E1726
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350F94: BF870091
	v_bfe_u32 v40, v38, 16, 1                                  // 000000350F98: D6100028 02052126
	v_add3_u32 v38, v38, v40, 0x7fff                           // 000000350FA0: D6550026 03FE5126 00007FFF
	v_lshrrev_b32_e32 v40, 24, v6                              // 000000350FAC: 32500C98
	v_lshrrev_b32_e32 v6, 28, v6                               // 000000350FB0: 320C0C9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000350FB4: BF870193
	v_and_or_b32 v38, 0xffff0000, v38, v48                     // 000000350FB8: D6570026 04C24CFF FFFF0000
	v_and_or_b32 v39, v40, 15, v39                             // 000000350FC4: D6570027 049D1F28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000350FCC: BF8701A3
	v_and_or_b32 v6, v14, 48, v6                               // 000000350FD0: D6570006 0419610E
	v_lshlrev_b32_e32 v40, 2, v15                              // 000000350FD8: 30501E82
	v_cvt_f32_ubyte0_e32 v14, v39                              // 000000350FDC: 7E1C2327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000350FE0: BF870193
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000350FE4: 7E0C2306
	v_and_b32_e32 v40, 48, v40                                 // 000000350FE8: 365050B0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000350FEC: BF870193
	v_fma_mix_f32 v14, v14, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350FF0: CC20600E 142E170E
	v_fma_mix_f32 v6, v6, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000350FF8: CC206006 142E1706
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351000: BF870092
	v_bfe_u32 v39, v14, 16, 1                                  // 000000351004: D6100027 0205210E
	v_add3_u32 v14, v14, v39, 0x7fff                           // 00000035100C: D655000E 03FE4F0E 00007FFF
	v_lshrrev_b32_e32 v39, 4, v7                               // 000000351018: 324E0E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000035101C: BF8701A2
	.long 0x7e60398e                                           // 000000351020: 7E60398E
	v_bfe_u32 v14, v6, 16, 1                                   // 000000351024: D610000E 02052106
	v_and_or_b32 v39, v39, 15, v40                             // 00000035102C: D6570027 04A11F27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000351034: BF870122
	v_add3_u32 v6, v6, v14, 0x7fff                             // 000000351038: D6550006 03FE1D06 00007FFF
	v_lshlrev_b32_e32 v14, 4, v15                              // 000000351044: 301C1E84
	v_and_or_b32 v6, 0xffff0000, v6, v48                       // 000000351048: D6570006 04C20CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351054: BF870092
	v_and_b32_e32 v14, 48, v14                                 // 000000351058: 361C1CB0
	v_and_or_b32 v14, v7, 15, v14                              // 00000035105C: D657000E 04391F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351064: BF870091
	v_cvt_f32_ubyte0_e32 v14, v14                              // 000000351068: 7E1C230E
	v_fma_mix_f32 v14, v14, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035106C: CC20600E 142E170E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351074: BF870091
	v_bfe_u32 v40, v14, 16, 1                                  // 000000351078: D6100028 0205210E
	v_add3_u32 v14, v14, v40, 0x7fff                           // 000000351080: D655000E 03FE510E 00007FFF
	v_and_b32_e32 v40, 48, v15                                 // 00000035108C: 36501EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000351090: BF8700A2
	.long 0x7e60398e                                           // 000000351094: 7E60398E
	v_cvt_f32_ubyte0_e32 v14, v39                              // 000000351098: 7E1C2327
	v_fma_mix_f32 v14, v14, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035109C: CC20600E 142E170E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003510A4: BF870091
	v_bfe_u32 v39, v14, 16, 1                                  // 0000003510A8: D6100027 0205210E
	v_add3_u32 v14, v14, v39, 0x7fff                           // 0000003510B0: D655000E 03FE4F0E 00007FFF
	v_lshrrev_b32_e32 v39, 8, v7                               // 0000003510BC: 324E0E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003510C0: BF870112
	v_and_or_b32 v14, 0xffff0000, v14, v48                     // 0000003510C4: D657000E 04C21CFF FFFF0000
	v_and_or_b32 v39, v39, 15, v40                             // 0000003510D0: D6570027 04A11F27
	v_lshrrev_b32_e32 v40, 12, v7                              // 0000003510D8: 32500E8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003510DC: BF870112
	v_cvt_f32_ubyte0_e32 v39, v39                              // 0000003510E0: 7E4E2327
	v_and_or_b32 v40, v40, 15, v41                             // 0000003510E4: D6570028 04A51F28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003510EC: BF870092
	v_fma_mix_f32 v39, v39, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003510F0: CC206027 142E1727
	v_bfe_u32 v41, v39, 16, 1                                  // 0000003510F8: D6100029 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000351100: BF870121
	v_add3_u32 v39, v39, v41, 0x7fff                           // 000000351104: D6550027 03FE5327 00007FFF
	v_lshrrev_b32_e32 v41, 8, v15                              // 000000351110: 32521E88
	.long 0x7e6039a7                                           // 000000351114: 7E6039A7
	v_cvt_f32_ubyte0_e32 v39, v40                              // 000000351118: 7E4E2328
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035111C: BF870113
	v_and_b32_e32 v41, 48, v41                                 // 000000351120: 365252B0
	v_fma_mix_f32 v39, v39, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000351124: CC206027 142E1727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035112C: BF870091
	v_bfe_u32 v40, v39, 16, 1                                  // 000000351130: D6100028 02052127
	v_add3_u32 v39, v39, v40, 0x7fff                           // 000000351138: D6550027 03FE5127 00007FFF
	v_lshrrev_b32_e32 v40, 4, v15                              // 000000351144: 32501E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000351148: BF8701A2
	v_and_or_b32 v39, 0xffff0000, v39, v48                     // 00000035114C: D6570027 04C24EFF FFFF0000
	.long 0x7e603987                                           // 000000351158: 7E603987
	v_and_b32_e32 v40, 48, v40                                 // 00000035115C: 365050B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351160: BF870091
	v_and_or_b32 v40, v48, 15, v40                             // 000000351164: D6570028 04A11F30
	v_cvt_f32_ubyte0_e32 v40, v40                              // 00000035116C: 7E502328
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351170: BF870091
	v_fma_mix_f32 v40, v40, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000351174: CC206028 142E1728
	v_bfe_u32 v43, v40, 16, 1                                  // 00000035117C: D610002B 02052128
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000351184: BF870121
	v_add3_u32 v40, v40, v43, 0x7fff                           // 000000351188: D6550028 03FE5728 00007FFF
	v_lshrrev_b32_e32 v43, 12, v15                             // 000000351194: 32561E8C
	.long 0x7e6039a8                                           // 000000351198: 7E6039A8
	v_cvt_f32_ubyte0_e32 v40, v42                              // 00000035119C: 7E50232A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003511A0: BF870091
	v_fma_mix_f32 v40, v40, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003511A4: CC206028 142E1728
	v_bfe_u32 v42, v40, 16, 1                                  // 0000003511AC: D610002A 02052128
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003511B4: BF8701B1
	v_add3_u32 v40, v40, v42, 0x7fff                           // 0000003511B8: D6550028 03FE5528 00007FFF
	v_lshrrev_b32_e32 v42, 24, v7                              // 0000003511C4: 32540E98
	v_lshrrev_b32_e32 v7, 28, v7                               // 0000003511C8: 320E0E9C
	v_and_or_b32 v40, 0xffff0000, v40, v48                     // 0000003511CC: D6570028 04C250FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003511D8: BF870123
	v_and_or_b32 v41, v42, 15, v41                             // 0000003511DC: D6570029 04A51F2A
	v_lshrrev_b32_e32 v42, 10, v15                             // 0000003511E4: 32541E8A
	v_cvt_f32_ubyte0_e32 v41, v41                              // 0000003511E8: 7E522329
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003511EC: BF870112
	v_and_or_b32 v7, v42, 48, v7                               // 0000003511F0: D6570007 041D612A
	v_fma_mix_f32 v41, v41, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003511F8: CC206029 142E1729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000351200: BF870112
	v_cvt_f32_ubyte0_e32 v7, v7                                // 000000351204: 7E0E2307
	v_bfe_u32 v42, v41, 16, 1                                  // 000000351208: D610002A 02052129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000351210: BF870112
	v_fma_mix_f32 v7, v7, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000351214: CC206007 142E1707
	v_add3_u32 v41, v41, v42, 0x7fff                           // 00000035121C: D6550029 03FE5529 00007FFF
	v_lshrrev_b32_e32 v42, 4, v8                               // 000000351228: 32541084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035122C: BF870212
	.long 0x7e6039a9                                           // 000000351230: 7E6039A9
	v_bfe_u32 v41, v7, 16, 1                                   // 000000351234: D6100029 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000035123C: BF870121
	v_add3_u32 v7, v7, v41, 0x7fff                             // 000000351240: D6550007 03FE5307 00007FFF
	v_and_b32_e32 v41, 15, v8                                  // 00000035124C: 3652108F
	v_and_or_b32 v7, 0xffff0000, v7, v48                       // 000000351250: D6570007 04C20EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000035125C: BF8701B2
	v_and_or_b32 v41, v43, 48, v41                             // 000000351260: D6570029 04A5612B
	v_lshrrev_b32_e32 v43, 14, v15                             // 000000351268: 32561E8E
	.long 0x7e60398f                                           // 00000035126C: 7E60398F
	v_cvt_f32_ubyte0_e32 v41, v41                              // 000000351270: 7E522329
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000351274: BF870193
	v_and_b32_e32 v43, 48, v43                                 // 000000351278: 365656B0
	v_and_b32_e32 v49, 48, v48                                 // 00000035127C: 366260B0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000351280: BF870193
	v_fma_mix_f32 v41, v41, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000351284: CC206029 142E1729
	v_and_or_b32 v42, v42, 15, v43                             // 00000035128C: D657002A 04AD1F2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000351294: BF870112
	v_bfe_u32 v43, v41, 16, 1                                  // 000000351298: D610002B 02052129
	v_cvt_f32_ubyte0_e32 v42, v42                              // 0000003512A0: 7E54232A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003512A4: BF870112
	v_add3_u32 v41, v41, v43, 0x7fff                           // 0000003512A8: D6550029 03FE5729 00007FFF
	v_fma_mix_f32 v42, v42, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003512B4: CC20602A 142E172A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003512BC: BF870112
	.long 0x7e5239a9                                           // 0000003512C0: 7E5239A9
	v_bfe_u32 v43, v42, 16, 1                                  // 0000003512C4: D610002B 0205212A
	.long 0x7f5239b0                                           // 0000003512CC: 7F5239B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003512D0: BF870122
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000003512D4: D655002A 03FE572A 00007FFF
	v_lshrrev_b32_e32 v43, 20, v15                             // 0000003512E0: 32561E94
	v_and_or_b32 v41, 0xffff0000, v42, v41                     // 0000003512E4: D6570029 04A654FF FFFF0000
	v_lshrrev_b32_e32 v42, 8, v8                               // 0000003512F0: 32541088
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003512F4: BF870113
	v_and_b32_e32 v43, 48, v43                                 // 0000003512F8: 365656B0
	v_and_or_b32 v42, v42, 15, v49                             // 0000003512FC: D657002A 04C51F2A
	v_lshrrev_b32_e32 v49, 12, v8                              // 000000351304: 3262108C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000351308: BF870112
	v_cvt_f32_ubyte0_e32 v42, v42                              // 00000035130C: 7E54232A
	v_and_or_b32 v49, v49, 15, v50                             // 000000351310: D6570031 04C91F31
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351318: BF870092
	v_fma_mix_f32 v42, v42, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035131C: CC20602A 142E172A
	v_bfe_u32 v50, v42, 16, 1                                  // 000000351324: D6100032 0205212A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000035132C: BF870121
	v_add3_u32 v42, v42, v50, 0x7fff                           // 000000351330: D655002A 03FE652A 00007FFF
	v_lshrrev_b32_e32 v50, 20, v8                              // 00000035133C: 32641094
	.long 0x7e6039aa                                           // 000000351340: 7E6039AA
	v_cvt_f32_ubyte0_e32 v42, v49                              // 000000351344: 7E542331
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000351348: BF870113
	v_and_or_b32 v50, v50, 15, v51                             // 00000035134C: D6570032 04CD1F32
	v_fma_mix_f32 v42, v42, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000351354: CC20602A 142E172A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035135C: BF870091
	v_bfe_u32 v49, v42, 16, 1                                  // 000000351360: D6100031 0205212A
	v_add3_u32 v42, v42, v49, 0x7fff                           // 000000351368: D655002A 03FE632A 00007FFF
	v_lshrrev_b32_e32 v49, 24, v15                             // 000000351374: 32621E98
	v_lshrrev_b32_e32 v15, 26, v15                             // 000000351378: 321E1E9A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000035137C: BF870223
	v_and_or_b32 v42, 0xffff0000, v42, v48                     // 000000351380: D657002A 04C254FF FFFF0000
	.long 0x7e603988                                           // 00000035138C: 7E603988
	v_and_b32_e32 v49, 48, v49                                 // 000000351390: 366262B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351394: BF870092
	v_and_or_b32 v43, v48, 15, v43                             // 000000351398: D657002B 04AD1F30
	v_cvt_f32_ubyte0_e32 v43, v43                              // 0000003513A0: 7E56232B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003513A4: BF870091
	v_fma_mix_f32 v43, v43, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003513A8: CC20602B 142E172B
	v_bfe_u32 v51, v43, 16, 1                                  // 0000003513B0: D6100033 0205212B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003513B8: BF870091
	v_add3_u32 v43, v43, v51, 0x7fff                           // 0000003513BC: D655002B 03FE672B 00007FFF
	.long 0x7e6039ab                                           // 0000003513C8: 7E6039AB
	v_cvt_f32_ubyte0_e32 v43, v50                              // 0000003513CC: 7E562332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003513D0: BF870091
	v_fma_mix_f32 v43, v43, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003513D4: CC20602B 142E172B
	v_bfe_u32 v50, v43, 16, 1                                  // 0000003513DC: D6100032 0205212B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003513E4: BF8701B1
	v_add3_u32 v43, v43, v50, 0x7fff                           // 0000003513E8: D655002B 03FE652B 00007FFF
	v_lshrrev_b32_e32 v50, 24, v8                              // 0000003513F4: 32641098
	v_lshrrev_b32_e32 v8, 28, v8                               // 0000003513F8: 3210109C
	v_and_or_b32 v43, 0xffff0000, v43, v48                     // 0000003513FC: D657002B 04C256FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000351408: BF870193
	v_and_or_b32 v49, v50, 15, v49                             // 00000035140C: D6570031 04C51F32
	v_and_or_b32 v8, v15, 48, v8                               // 000000351414: D6570008 0421610F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035141C: BF870112
	v_cvt_f32_ubyte0_e32 v15, v49                              // 000000351420: 7E1E2331
	v_cvt_f32_ubyte0_e32 v8, v8                                // 000000351424: 7E102308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000351428: BF870112
	v_fma_mix_f32 v15, v15, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035142C: CC20600F 142E170F
	v_fma_mix_f32 v8, v8, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000351434: CC206008 142E1708
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035143C: BF870112
	v_bfe_u32 v49, v15, 16, 1                                  // 000000351440: D6100031 0205210F
	v_bfe_u32 v11, v8, 16, 1                                   // 000000351448: D610000B 02052108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000351450: BF870112
	v_add3_u32 v15, v15, v49, 0x7fff                           // 000000351454: D655000F 03FE630F 00007FFF
	v_add3_u32 v8, v8, v11, 0x7fff                             // 000000351460: D6550008 03FE1708 00007FFF
	v_ashrrev_i32_e32 v11, 31, v10                             // 00000035146C: 3416149F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000351470: BF870133
	.long 0x7e60398f                                           // 000000351474: 7E60398F
	s_waitcnt vmcnt(1)                                         // 000000351478: BF8907F7
	v_mov_b32_e32 v15, v13                                     // 00000035147C: 7E1E030D
	v_and_or_b32 v8, 0xffff0000, v8, v48                       // 000000351480: D6570008 04C210FF FFFF0000
	.long 0xd73c0030                                           // 00000035148C: D73C0030
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 000000351490: 02021481
	v_add_nc_u32_e32 v10, 0x400, v10                           // 000000351494: 4A1414FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035149C: BF870092
	.long 0xd7006a40                                           // 0000003514A0: D7006A40
	v_cndmask_b32_e32 v1, s6, v48, vcc_lo                      // 0000003514A4: 02026006
	v_add_co_ci_u32_e64 v65, null, s7, v49, vcc_lo             // 0000003514A8: D5207C41 01AA6207
	s_clause 0x3                                               // 0000003514B0: BF850003
	global_load_b128 v[48:51], v[64:65], off                   // 0000003514B4: DC5E0000 307C0040
	global_load_b128 v[52:55], v[64:65], off offset:16         // 0000003514BC: DC5E0010 347C0040
	global_load_b128 v[56:59], v[64:65], off offset:32         // 0000003514C4: DC5E0020 387C0040
	global_load_b128 v[60:63], v[64:65], off offset:48         // 0000003514CC: DC5E0030 3C7C0040
	s_waitcnt vmcnt(3)                                         // 0000003514D4: BF890FF7
	v_dot2_f32_bf16 v11, v48, v44, 0                           // 0000003514D8: CC1A400B 1A025930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003514E0: BF870091
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 0000003514E4: CC1A400B 1C2E5B31
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 0000003514EC: CC1A400B 1C2E5D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003514F4: BF8700A1
	v_dot2_f32_bf16 v11, v51, v47, v11                         // 0000003514F8: CC1A400B 1C2E5F33
	s_waitcnt vmcnt(2)                                         // 000000351500: BF890BF7
	v_dot2_f32_bf16 v11, v52, v5, v11                          // 000000351504: CC1A400B 1C2E0B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035150C: BF870091
	v_dot2_f32_bf16 v11, v53, v37, v11                         // 000000351510: CC1A400B 1C2E4B35
	v_dot2_f32_bf16 v11, v54, v38, v11                         // 000000351518: CC1A400B 1C2E4D36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000351520: BF8700A1
	v_dot2_f32_bf16 v11, v55, v6, v11                          // 000000351524: CC1A400B 1C2E0D37
	s_waitcnt vmcnt(1)                                         // 00000035152C: BF8907F7
	v_dot2_f32_bf16 v11, v56, v14, v11                         // 000000351530: CC1A400B 1C2E1D38
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351538: BF870091
	v_dot2_f32_bf16 v11, v57, v39, v11                         // 00000035153C: CC1A400B 1C2E4F39
	v_dot2_f32_bf16 v11, v58, v40, v11                         // 000000351544: CC1A400B 1C2E513A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035154C: BF8700A1
	v_dot2_f32_bf16 v11, v59, v7, v11                          // 000000351550: CC1A400B 1C2E0F3B
	s_waitcnt vmcnt(0)                                         // 000000351558: BF8903F7
	v_dot2_f32_bf16 v11, v60, v41, v11                         // 00000035155C: CC1A400B 1C2E533C
	.long 0xd7006a3c                                           // 000000351564: D7006A3C
	v_cndmask_b32_e32 v0, v64, v10, vcc_lo                     // 000000351568: 02001540
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000035156C: BF8701B2
	v_dot2_f32_bf16 v11, v61, v42, v11                         // 000000351570: CC1A400B 1C2E553D
	v_add_co_ci_u32_e64 v61, null, s11, v65, vcc_lo            // 000000351578: D5207C3D 01AA820B
	.long 0xd7006a42                                           // 000000351580: D7006A42
	v_cndmask_b32_e32 v0, v64, v4, vcc_lo                      // 000000351584: 02000940
	v_dot2_f32_bf16 v11, v62, v43, v11                         // 000000351588: CC1A400B 1C2E573E
	v_add_co_ci_u32_e64 v67, null, s5, v65, vcc_lo             // 000000351590: D5207C43 01AA8205
	.long 0xd7006a40                                           // 000000351598: D7006A40
	v_cndmask_b32_e32 v0, v64, v16, vcc_lo                     // 00000035159C: 02002140
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003515A0: BF870003
	v_dot2_f32_bf16 v11, v63, v8, v11                          // 0000003515A4: CC1A400B 1C2E113F
	s_clause 0x3                                               // 0000003515AC: BF850003
	global_load_b128 v[48:51], v[60:61], off                   // 0000003515B0: DC5E0000 307C003C
	global_load_b128 v[52:55], v[60:61], off offset:16         // 0000003515B8: DC5E0010 347C003C
	global_load_b128 v[56:59], v[60:61], off offset:32         // 0000003515C0: DC5E0020 387C003C
	global_load_b128 v[60:63], v[60:61], off offset:48         // 0000003515C8: DC5E0030 3C7C003C
	v_add_co_ci_u32_e64 v65, null, s14, v65, vcc_lo            // 0000003515D0: D5207C41 01AA820E
	v_add_f32_e32 v28, v28, v11                                // 0000003515D8: 0638171C
	s_waitcnt vmcnt(3)                                         // 0000003515DC: BF890FF7
	v_dot2_f32_bf16 v11, v48, v44, 0                           // 0000003515E0: CC1A400B 1A025930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003515E8: BF870091
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 0000003515EC: CC1A400B 1C2E5B31
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 0000003515F4: CC1A400B 1C2E5D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003515FC: BF8700A1
	v_dot2_f32_bf16 v11, v51, v47, v11                         // 000000351600: CC1A400B 1C2E5F33
	s_waitcnt vmcnt(2)                                         // 000000351608: BF890BF7
	v_dot2_f32_bf16 v11, v52, v5, v11                          // 00000035160C: CC1A400B 1C2E0B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351614: BF870091
	v_dot2_f32_bf16 v11, v53, v37, v11                         // 000000351618: CC1A400B 1C2E4B35
	v_dot2_f32_bf16 v11, v54, v38, v11                         // 000000351620: CC1A400B 1C2E4D36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000351628: BF8700A1
	v_dot2_f32_bf16 v11, v55, v6, v11                          // 00000035162C: CC1A400B 1C2E0D37
	s_waitcnt vmcnt(1)                                         // 000000351634: BF8907F7
	v_dot2_f32_bf16 v11, v56, v14, v11                         // 000000351638: CC1A400B 1C2E1D38
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351640: BF870091
	v_dot2_f32_bf16 v11, v57, v39, v11                         // 000000351644: CC1A400B 1C2E4F39
	v_dot2_f32_bf16 v11, v58, v40, v11                         // 00000035164C: CC1A400B 1C2E513A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000351654: BF8700A1
	v_dot2_f32_bf16 v11, v59, v7, v11                          // 000000351658: CC1A400B 1C2E0F3B
	s_waitcnt vmcnt(0)                                         // 000000351660: BF8903F7
	v_dot2_f32_bf16 v11, v60, v41, v11                         // 000000351664: CC1A400B 1C2E533C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035166C: BF870091
	v_dot2_f32_bf16 v11, v61, v42, v11                         // 000000351670: CC1A400B 1C2E553D
	v_dot2_f32_bf16 v11, v62, v43, v11                         // 000000351678: CC1A400B 1C2E573E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000351680: BF870001
	v_dot2_f32_bf16 v11, v63, v8, v11                          // 000000351684: CC1A400B 1C2E113F
	s_clause 0x3                                               // 00000035168C: BF850003
	global_load_b128 v[48:51], v[66:67], off                   // 000000351690: DC5E0000 307C0042
	global_load_b128 v[52:55], v[66:67], off offset:16         // 000000351698: DC5E0010 347C0042
	global_load_b128 v[56:59], v[66:67], off offset:32         // 0000003516A0: DC5E0020 387C0042
	global_load_b128 v[60:63], v[66:67], off offset:48         // 0000003516A8: DC5E0030 3C7C0042
	.long 0xd7006a42                                           // 0000003516B0: D7006A42
	v_cndmask_b32_e32 v0, v66, v4, vcc_lo                      // 0000003516B4: 02000942
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003516B8: BF8700C1
	v_add_co_ci_u32_e64 v67, null, s5, v67, vcc_lo             // 0000003516BC: D5207C43 01AA8605
	v_add_f32_e32 v27, v27, v11                                // 0000003516C4: 0636171B
	s_waitcnt vmcnt(3)                                         // 0000003516C8: BF890FF7
	v_dot2_f32_bf16 v11, v48, v44, 0                           // 0000003516CC: CC1A400B 1A025930
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 0000003516D4: CC1A400B 1C2E5B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003516DC: BF870091
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 0000003516E0: CC1A400B 1C2E5D32
	v_dot2_f32_bf16 v11, v51, v47, v11                         // 0000003516E8: CC1A400B 1C2E5F33
	s_waitcnt vmcnt(2)                                         // 0000003516F0: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003516F4: BF870091
	v_dot2_f32_bf16 v11, v52, v5, v11                          // 0000003516F8: CC1A400B 1C2E0B34
	v_dot2_f32_bf16 v11, v53, v37, v11                         // 000000351700: CC1A400B 1C2E4B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351708: BF870091
	v_dot2_f32_bf16 v11, v54, v38, v11                         // 00000035170C: CC1A400B 1C2E4D36
	v_dot2_f32_bf16 v11, v55, v6, v11                          // 000000351714: CC1A400B 1C2E0D37
	s_waitcnt vmcnt(1)                                         // 00000035171C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351720: BF870091
	v_dot2_f32_bf16 v11, v56, v14, v11                         // 000000351724: CC1A400B 1C2E1D38
	v_dot2_f32_bf16 v11, v57, v39, v11                         // 00000035172C: CC1A400B 1C2E4F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351734: BF870091
	v_dot2_f32_bf16 v11, v58, v40, v11                         // 000000351738: CC1A400B 1C2E513A
	v_dot2_f32_bf16 v11, v59, v7, v11                          // 000000351740: CC1A400B 1C2E0F3B
	s_waitcnt vmcnt(0)                                         // 000000351748: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035174C: BF870091
	v_dot2_f32_bf16 v11, v60, v41, v11                         // 000000351750: CC1A400B 1C2E533C
	v_dot2_f32_bf16 v11, v61, v42, v11                         // 000000351758: CC1A400B 1C2E553D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351760: BF870091
	v_dot2_f32_bf16 v11, v62, v43, v11                         // 000000351764: CC1A400B 1C2E573E
	v_dot2_f32_bf16 v11, v63, v8, v11                          // 00000035176C: CC1A400B 1C2E113F
	s_clause 0x3                                               // 000000351774: BF850003
	global_load_b128 v[48:51], v[64:65], off                   // 000000351778: DC5E0000 307C0040
	global_load_b128 v[52:55], v[64:65], off offset:16         // 000000351780: DC5E0010 347C0040
	global_load_b128 v[56:59], v[64:65], off offset:32         // 000000351788: DC5E0020 387C0040
	global_load_b128 v[60:63], v[64:65], off offset:48         // 000000351790: DC5E0030 3C7C0040
	.long 0xd7006a40                                           // 000000351798: D7006A40
	v_cndmask_b32_e32 v0, v64, v4, vcc_lo                      // 00000035179C: 02000940
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003517A0: BF8700C1
	v_add_co_ci_u32_e64 v65, null, s5, v65, vcc_lo             // 0000003517A4: D5207C41 01AA8205
	v_add_f32_e32 v26, v26, v11                                // 0000003517AC: 0634171A
	s_waitcnt vmcnt(3)                                         // 0000003517B0: BF890FF7
	v_dot2_f32_bf16 v11, v48, v44, 0                           // 0000003517B4: CC1A400B 1A025930
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 0000003517BC: CC1A400B 1C2E5B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003517C4: BF870091
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 0000003517C8: CC1A400B 1C2E5D32
	v_dot2_f32_bf16 v11, v51, v47, v11                         // 0000003517D0: CC1A400B 1C2E5F33
	s_waitcnt vmcnt(2)                                         // 0000003517D8: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003517DC: BF870091
	v_dot2_f32_bf16 v11, v52, v5, v11                          // 0000003517E0: CC1A400B 1C2E0B34
	v_dot2_f32_bf16 v11, v53, v37, v11                         // 0000003517E8: CC1A400B 1C2E4B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003517F0: BF870091
	v_dot2_f32_bf16 v11, v54, v38, v11                         // 0000003517F4: CC1A400B 1C2E4D36
	v_dot2_f32_bf16 v11, v55, v6, v11                          // 0000003517FC: CC1A400B 1C2E0D37
	s_waitcnt vmcnt(1)                                         // 000000351804: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351808: BF870091
	v_dot2_f32_bf16 v11, v56, v14, v11                         // 00000035180C: CC1A400B 1C2E1D38
	v_dot2_f32_bf16 v11, v57, v39, v11                         // 000000351814: CC1A400B 1C2E4F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035181C: BF870091
	v_dot2_f32_bf16 v11, v58, v40, v11                         // 000000351820: CC1A400B 1C2E513A
	v_dot2_f32_bf16 v11, v59, v7, v11                          // 000000351828: CC1A400B 1C2E0F3B
	s_waitcnt vmcnt(0)                                         // 000000351830: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351834: BF870091
	v_dot2_f32_bf16 v11, v60, v41, v11                         // 000000351838: CC1A400B 1C2E533C
	v_dot2_f32_bf16 v11, v61, v42, v11                         // 000000351840: CC1A400B 1C2E553D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351848: BF870091
	v_dot2_f32_bf16 v11, v62, v43, v11                         // 00000035184C: CC1A400B 1C2E573E
	v_dot2_f32_bf16 v11, v63, v8, v11                          // 000000351854: CC1A400B 1C2E113F
	s_clause 0x3                                               // 00000035185C: BF850003
	global_load_b128 v[48:51], v[66:67], off                   // 000000351860: DC5E0000 307C0042
	global_load_b128 v[52:55], v[66:67], off offset:16         // 000000351868: DC5E0010 347C0042
	global_load_b128 v[56:59], v[66:67], off offset:32         // 000000351870: DC5E0020 387C0042
	global_load_b128 v[60:63], v[66:67], off offset:48         // 000000351878: DC5E0030 3C7C0042
	v_add_f32_e32 v25, v25, v11                                // 000000351880: 06321719
	s_waitcnt vmcnt(3)                                         // 000000351884: BF890FF7
	v_dot2_f32_bf16 v11, v48, v44, 0                           // 000000351888: CC1A400B 1A025930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351890: BF870091
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 000000351894: CC1A400B 1C2E5B31
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 00000035189C: CC1A400B 1C2E5D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003518A4: BF8700A1
	v_dot2_f32_bf16 v11, v51, v47, v11                         // 0000003518A8: CC1A400B 1C2E5F33
	s_waitcnt vmcnt(2)                                         // 0000003518B0: BF890BF7
	v_dot2_f32_bf16 v11, v52, v5, v11                          // 0000003518B4: CC1A400B 1C2E0B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003518BC: BF870091
	v_dot2_f32_bf16 v11, v53, v37, v11                         // 0000003518C0: CC1A400B 1C2E4B35
	v_dot2_f32_bf16 v11, v54, v38, v11                         // 0000003518C8: CC1A400B 1C2E4D36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003518D0: BF8700A1
	v_dot2_f32_bf16 v11, v55, v6, v11                          // 0000003518D4: CC1A400B 1C2E0D37
	s_waitcnt vmcnt(1)                                         // 0000003518DC: BF8907F7
	v_dot2_f32_bf16 v11, v56, v14, v11                         // 0000003518E0: CC1A400B 1C2E1D38
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003518E8: BF870091
	v_dot2_f32_bf16 v11, v57, v39, v11                         // 0000003518EC: CC1A400B 1C2E4F39
	v_dot2_f32_bf16 v11, v58, v40, v11                         // 0000003518F4: CC1A400B 1C2E513A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003518FC: BF8700A1
	v_dot2_f32_bf16 v11, v59, v7, v11                          // 000000351900: CC1A400B 1C2E0F3B
	s_waitcnt vmcnt(0)                                         // 000000351908: BF8903F7
	v_dot2_f32_bf16 v11, v60, v41, v11                         // 00000035190C: CC1A400B 1C2E533C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351914: BF870091
	v_dot2_f32_bf16 v11, v61, v42, v11                         // 000000351918: CC1A400B 1C2E553D
	v_dot2_f32_bf16 v11, v62, v43, v11                         // 000000351920: CC1A400B 1C2E573E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000351928: BF870001
	v_dot2_f32_bf16 v11, v63, v8, v11                          // 00000035192C: CC1A400B 1C2E113F
	s_clause 0x3                                               // 000000351934: BF850003
	global_load_b128 v[48:51], v[64:65], off                   // 000000351938: DC5E0000 307C0040
	global_load_b128 v[52:55], v[64:65], off offset:16         // 000000351940: DC5E0010 347C0040
	global_load_b128 v[56:59], v[64:65], off offset:32         // 000000351948: DC5E0020 387C0040
	global_load_b128 v[60:63], v[64:65], off offset:48         // 000000351950: DC5E0030 3C7C0040
	v_add_f32_e32 v24, v24, v11                                // 000000351958: 06301718
	s_waitcnt vmcnt(3)                                         // 00000035195C: BF890FF7
	v_dot2_f32_bf16 v11, v48, v44, 0                           // 000000351960: CC1A400B 1A025930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351968: BF870091
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 00000035196C: CC1A400B 1C2E5B31
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 000000351974: CC1A400B 1C2E5D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035197C: BF8700A1
	v_dot2_f32_bf16 v11, v51, v47, v11                         // 000000351980: CC1A400B 1C2E5F33
	s_waitcnt vmcnt(2)                                         // 000000351988: BF890BF7
	v_dot2_f32_bf16 v11, v52, v5, v11                          // 00000035198C: CC1A400B 1C2E0B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351994: BF870091
	v_dot2_f32_bf16 v11, v53, v37, v11                         // 000000351998: CC1A400B 1C2E4B35
	v_dot2_f32_bf16 v11, v54, v38, v11                         // 0000003519A0: CC1A400B 1C2E4D36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003519A8: BF8700A1
	v_dot2_f32_bf16 v11, v55, v6, v11                          // 0000003519AC: CC1A400B 1C2E0D37
	s_waitcnt vmcnt(1)                                         // 0000003519B4: BF8907F7
	v_dot2_f32_bf16 v11, v56, v14, v11                         // 0000003519B8: CC1A400B 1C2E1D38
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003519C0: BF870091
	v_dot2_f32_bf16 v11, v57, v39, v11                         // 0000003519C4: CC1A400B 1C2E4F39
	v_dot2_f32_bf16 v11, v58, v40, v11                         // 0000003519CC: CC1A400B 1C2E513A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003519D4: BF8700A1
	v_dot2_f32_bf16 v11, v59, v7, v11                          // 0000003519D8: CC1A400B 1C2E0F3B
	s_waitcnt vmcnt(0)                                         // 0000003519E0: BF8903F7
	v_dot2_f32_bf16 v11, v60, v41, v11                         // 0000003519E4: CC1A400B 1C2E533C
	.long 0xd7006a3c                                           // 0000003519EC: D7006A3C
	v_cndmask_b32_e32 v0, v66, v4, vcc_lo                      // 0000003519F0: 02000942
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003519F4: BF870122
	v_dot2_f32_bf16 v11, v61, v42, v11                         // 0000003519F8: CC1A400B 1C2E553D
	v_add_co_ci_u32_e64 v61, null, s5, v67, vcc_lo             // 000000351A00: D5207C3D 01AA8605
	v_dot2_f32_bf16 v11, v62, v43, v11                         // 000000351A08: CC1A400B 1C2E573E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000351A10: BF870001
	v_dot2_f32_bf16 v11, v63, v8, v11                          // 000000351A14: CC1A400B 1C2E113F
	s_clause 0x3                                               // 000000351A1C: BF850003
	global_load_b128 v[48:51], v[60:61], off                   // 000000351A20: DC5E0000 307C003C
	global_load_b128 v[52:55], v[60:61], off offset:16         // 000000351A28: DC5E0010 347C003C
	global_load_b128 v[56:59], v[60:61], off offset:32         // 000000351A30: DC5E0020 387C003C
	global_load_b128 v[60:63], v[60:61], off offset:48         // 000000351A38: DC5E0030 3C7C003C
	v_add_f32_e32 v23, v23, v11                                // 000000351A40: 062E1717
	s_waitcnt vmcnt(3)                                         // 000000351A44: BF890FF7
	v_dot2_f32_bf16 v11, v48, v44, 0                           // 000000351A48: CC1A400B 1A025930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351A50: BF870091
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 000000351A54: CC1A400B 1C2E5B31
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 000000351A5C: CC1A400B 1C2E5D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000351A64: BF8700A1
	v_dot2_f32_bf16 v11, v51, v47, v11                         // 000000351A68: CC1A400B 1C2E5F33
	s_waitcnt vmcnt(2)                                         // 000000351A70: BF890BF7
	v_dot2_f32_bf16 v11, v52, v5, v11                          // 000000351A74: CC1A400B 1C2E0B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351A7C: BF870091
	v_dot2_f32_bf16 v11, v53, v37, v11                         // 000000351A80: CC1A400B 1C2E4B35
	v_dot2_f32_bf16 v11, v54, v38, v11                         // 000000351A88: CC1A400B 1C2E4D36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000351A90: BF8700A1
	v_dot2_f32_bf16 v11, v55, v6, v11                          // 000000351A94: CC1A400B 1C2E0D37
	s_waitcnt vmcnt(1)                                         // 000000351A9C: BF8907F7
	v_dot2_f32_bf16 v11, v56, v14, v11                         // 000000351AA0: CC1A400B 1C2E1D38
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351AA8: BF870091
	v_dot2_f32_bf16 v11, v57, v39, v11                         // 000000351AAC: CC1A400B 1C2E4F39
	v_dot2_f32_bf16 v11, v58, v40, v11                         // 000000351AB4: CC1A400B 1C2E513A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000351ABC: BF8700A1
	v_dot2_f32_bf16 v11, v59, v7, v11                          // 000000351AC0: CC1A400B 1C2E0F3B
	s_waitcnt vmcnt(0)                                         // 000000351AC8: BF8903F7
	v_dot2_f32_bf16 v11, v60, v41, v11                         // 000000351ACC: CC1A400B 1C2E533C
	.long 0xd7006a3c                                           // 000000351AD4: D7006A3C
	v_cndmask_b32_e32 v0, v64, v4, vcc_lo                      // 000000351AD8: 02000940
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000351ADC: BF870122
	v_dot2_f32_bf16 v11, v61, v42, v11                         // 000000351AE0: CC1A400B 1C2E553D
	v_add_co_ci_u32_e64 v61, null, s5, v65, vcc_lo             // 000000351AE8: D5207C3D 01AA8205
	v_dot2_f32_bf16 v11, v62, v43, v11                         // 000000351AF0: CC1A400B 1C2E573E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000351AF8: BF870001
	v_dot2_f32_bf16 v11, v63, v8, v11                          // 000000351AFC: CC1A400B 1C2E113F
	s_clause 0x3                                               // 000000351B04: BF850003
	global_load_b128 v[48:51], v[60:61], off                   // 000000351B08: DC5E0000 307C003C
	global_load_b128 v[52:55], v[60:61], off offset:16         // 000000351B10: DC5E0010 347C003C
	global_load_b128 v[56:59], v[60:61], off offset:32         // 000000351B18: DC5E0020 387C003C
	global_load_b128 v[60:63], v[60:61], off offset:48         // 000000351B20: DC5E0030 3C7C003C
	v_add_f32_e32 v22, v22, v11                                // 000000351B28: 062C1716
	s_waitcnt vmcnt(3)                                         // 000000351B2C: BF890FF7
	v_dot2_f32_bf16 v11, v48, v44, 0                           // 000000351B30: CC1A400B 1A025930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351B38: BF870091
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 000000351B3C: CC1A400B 1C2E5B31
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 000000351B44: CC1A400B 1C2E5D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000351B4C: BF8700A1
	v_dot2_f32_bf16 v11, v51, v47, v11                         // 000000351B50: CC1A400B 1C2E5F33
	s_waitcnt vmcnt(2)                                         // 000000351B58: BF890BF7
	v_dot2_f32_bf16 v5, v52, v5, v11                           // 000000351B5C: CC1A4005 1C2E0B34
	v_mov_b32_e32 v11, v36                                     // 000000351B64: 7E160324
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351B68: BF870092
	v_dot2_f32_bf16 v5, v53, v37, v5                           // 000000351B6C: CC1A4005 1C164B35
	v_dot2_f32_bf16 v5, v54, v38, v5                           // 000000351B74: CC1A4005 1C164D36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000351B7C: BF870131
	v_dot2_f32_bf16 v5, v55, v6, v5                            // 000000351B80: CC1A4005 1C160D37
	v_mov_b32_e32 v6, v2                                       // 000000351B88: 7E0C0302
	s_waitcnt vmcnt(1)                                         // 000000351B8C: BF8907F7
	v_dot2_f32_bf16 v5, v56, v14, v5                           // 000000351B90: CC1A4005 1C161D38
	v_mov_b32_e32 v14, v12                                     // 000000351B98: 7E1C030C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351B9C: BF870092
	v_dot2_f32_bf16 v5, v57, v39, v5                           // 000000351BA0: CC1A4005 1C164F39
	v_dot2_f32_bf16 v5, v58, v40, v5                           // 000000351BA8: CC1A4005 1C16513A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000351BB0: BF870131
	v_dot2_f32_bf16 v5, v59, v7, v5                            // 000000351BB4: CC1A4005 1C160F3B
	v_mov_b32_e32 v7, v3                                       // 000000351BBC: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 000000351BC0: BF8903F7
	v_dot2_f32_bf16 v5, v60, v41, v5                           // 000000351BC4: CC1A4005 1C16533C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000351BCC: BF870091
	v_dot2_f32_bf16 v5, v61, v42, v5                           // 000000351BD0: CC1A4005 1C16553D
	v_dot2_f32_bf16 v5, v62, v43, v5                           // 000000351BD8: CC1A4005 1C16573E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000351BE0: BF870121
	v_dot2_f32_bf16 v5, v63, v8, v5                            // 000000351BE4: CC1A4005 1C16113F
	v_mov_b32_e32 v8, v4                                       // 000000351BEC: 7E100304
	v_dual_add_f32 v18, v18, v5 :: v_dual_mov_b32 v5, v1       // 000000351BF0: C9100B12 12040101
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000351BF8: 917E0F7E
	s_cbranch_execz 39                                         // 000000351BFC: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi8EEEvPKhPKtPtll+0x139c>
	v_dual_mov_b32 v2, v6 :: v_dual_add_nc_u32 v19, 32, v19    // 000000351C00: CA200106 021226A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000351C08: BF870002
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v4, v8             // 000000351C0C: CA100105 01040108
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v12, v14           // 000000351C14: CA100107 030C010E
	v_mov_b32_e32 v13, v15                                     // 000000351C1C: 7E1A030F
	s_mov_b32 s17, exec_lo                                     // 000000351C20: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 000000351C24: 7C8C2913
	.long 0xd4c1007e                                           // 000000351C28: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 000000351C2C: 02022913
	s_cbranch_execz 64466                                      // 000000351C30: BFA5FBD2 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi8EEEvPKhPKtPtll+0x27c>
	v_and_b32_e32 v3, -4, v35                                  // 000000351C34: 360646C4
	v_ashrrev_i32_e32 v2, 31, v33                              // 000000351C38: 3404429F
	v_ashrrev_i32_e32 v4, 31, v34                              // 000000351C3C: 3408449F
	.long 0xd7000001                                           // 000000351C40: D7000001
	v_cndmask_b32_e32 v1, v9, v33, vcc_lo                      // 000000351C44: 02024309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000351C48: BF870214
	v_ashrrev_i32_e32 v37, 31, v3                              // 000000351C4C: 344A069F
	v_add_co_ci_u32_e64 v2, null, v21, v2, s0                  // 000000351C50: D5207C02 00020515
	.long 0xd700000c                                           // 000000351C58: D700000C
	v_cndmask_b32_e32 v1, v29, v34, vcc_lo                     // 000000351C5C: 0202451D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000351C60: BF8700A1
	v_add_co_ci_u32_e64 v13, null, v30, v4, s0                 // 000000351C64: D5207C0D 0002091E
	.long 0xd7000024                                           // 000000351C6C: D7000024
	v_cndmask_b32_e32 v1, v31, v3, vcc_lo                      // 000000351C70: 0202071F
	v_add_co_ci_u32_e64 v37, null, v32, v37, s0                // 000000351C74: D5207C25 00024B20
	s_clause 0x2                                               // 000000351C7C: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 000000351C80: DC5E0000 017C0001
	global_load_b64 v[12:13], v[12:13], off                    // 000000351C88: DC560000 0C7C000C
	global_load_b32 v36, v[36:37], off                         // 000000351C90: DC520000 247C0024
	s_branch 64440                                             // 000000351C98: BFA0FBB8 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi8EEEvPKhPKtPtll+0x27c>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000351C9C: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000351CA0: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000351CA4: 8C7E017E
	.long 0xd71f0001                                           // 000000351CA8: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000351CAC: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000351CB0: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000351CB4: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 000000351CB8: 3A140288
	v_xor_b32_e32 v20, 4, v1                                   // 000000351CBC: 3A280284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000351CC0: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000351CC4: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000351CC8: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000351CCC: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000351CD0: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000351CD4: 30040482
	s_waitcnt vmcnt(2)                                         // 000000351CD8: BF890BF7
	ds_bpermute_b32 v5, v2, v26                                // 000000351CDC: DACC0000 05001A02
	s_waitcnt lgkmcnt(0)                                       // 000000351CE4: BF89FC07
	v_add_f32_e32 v5, v26, v5                                  // 000000351CE8: 060A0B1A
	ds_bpermute_b32 v3, v2, v28                                // 000000351CEC: DACC0000 03001C02
	ds_bpermute_b32 v7, v2, v24                                // 000000351CF4: DACC0000 07001802
	ds_bpermute_b32 v9, v2, v22                                // 000000351CFC: DACC0000 09001602
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000351D04: 02141501
	ds_bpermute_b32 v6, v2, v25                                // 000000351D08: DACC0000 06001902
	ds_bpermute_b32 v4, v2, v27                                // 000000351D10: DACC0000 04001B02
	ds_bpermute_b32 v8, v2, v23                                // 000000351D18: DACC0000 08001702
	ds_bpermute_b32 v2, v2, v18                                // 000000351D20: DACC0000 02001202
	v_cmp_gt_u32_e32 vcc_lo, 32, v20                           // 000000351D28: 7C9828A0
	s_waitcnt lgkmcnt(6)                                       // 000000351D2C: BF89FC67
	v_add_f32_e32 v3, v28, v3                                  // 000000351D30: 0606071C
	s_waitcnt lgkmcnt(5)                                       // 000000351D34: BF89FC57
	v_dual_add_f32 v7, v24, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 000000351D38: C9220F18 070A1482
	s_waitcnt lgkmcnt(4)                                       // 000000351D40: BF89FC47
	v_add_f32_e32 v9, v22, v9                                  // 000000351D44: 06121316
	s_waitcnt vmcnt(0)                                         // 000000351D48: BF8903F7
	ds_bpermute_b32 v11, v10, v3                               // 000000351D4C: DACC0000 0B00030A
	s_waitcnt lgkmcnt(4)                                       // 000000351D54: BF89FC47
	v_add_f32_e32 v6, v25, v6                                  // 000000351D58: 060C0D19
	ds_bpermute_b32 v13, v10, v5                               // 000000351D5C: DACC0000 0D00050A
	ds_bpermute_b32 v15, v10, v7                               // 000000351D64: DACC0000 0F00070A
	ds_bpermute_b32 v19, v10, v9                               // 000000351D6C: DACC0000 1300090A
	s_waitcnt lgkmcnt(6)                                       // 000000351D74: BF89FC67
	v_add_f32_e32 v4, v27, v4                                  // 000000351D78: 0608091B
	s_waitcnt lgkmcnt(5)                                       // 000000351D7C: BF89FC57
	v_add_f32_e32 v8, v23, v8                                  // 000000351D80: 06101117
	s_waitcnt lgkmcnt(3)                                       // 000000351D84: BF89FC37
	v_dual_add_f32 v2, v18, v2 :: v_dual_add_f32 v3, v3, v11   // 000000351D88: C9080512 02021703
	ds_bpermute_b32 v14, v10, v6                               // 000000351D90: DACC0000 0E00060A
	v_cndmask_b32_e32 v20, v1, v20, vcc_lo                     // 000000351D98: 02282901
	s_waitcnt lgkmcnt(3)                                       // 000000351D9C: BF89FC37
	v_add_f32_e32 v5, v5, v13                                  // 000000351DA0: 060A1B05
	ds_bpermute_b32 v12, v10, v4                               // 000000351DA4: DACC0000 0C00040A
	s_waitcnt lgkmcnt(3)                                       // 000000351DAC: BF89FC37
	v_add_f32_e32 v7, v7, v15                                  // 000000351DB0: 060E1F07
	s_waitcnt lgkmcnt(2)                                       // 000000351DB4: BF89FC27
	v_add_f32_e32 v9, v9, v19                                  // 000000351DB8: 06122709
	ds_bpermute_b32 v18, v10, v8                               // 000000351DBC: DACC0000 1200080A
	ds_bpermute_b32 v10, v10, v2                               // 000000351DC4: DACC0000 0A00020A
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000351DCC: 30282882
	s_waitcnt lgkmcnt(3)                                       // 000000351DD0: BF89FC37
	v_add_f32_e32 v6, v6, v14                                  // 000000351DD4: 060C1D06
	ds_bpermute_b32 v14, v20, v7                               // 000000351DD8: DACC0000 0E000714
	s_waitcnt lgkmcnt(1)                                       // 000000351DE0: BF89FC17
	v_add_f32_e32 v2, v2, v10                                  // 000000351DE4: 06041502
	s_waitcnt lgkmcnt(0)                                       // 000000351DE8: BF89FC07
	v_add_f32_e32 v7, v7, v14                                  // 000000351DEC: 060E1D07
	ds_bpermute_b32 v19, v20, v2                               // 000000351DF0: DACC0000 13000214
	v_add_f32_e32 v8, v8, v18                                  // 000000351DF8: 06102508
	ds_bpermute_b32 v18, v20, v9                               // 000000351DFC: DACC0000 12000914
	v_add_f32_e32 v4, v4, v12                                  // 000000351E04: 06081904
	ds_bpermute_b32 v12, v20, v5                               // 000000351E08: DACC0000 0C000514
	ds_bpermute_b32 v10, v20, v3                               // 000000351E10: DACC0000 0A000314
	s_waitcnt lgkmcnt(2)                                       // 000000351E18: BF89FC27
	v_add_f32_e32 v9, v9, v18                                  // 000000351E1C: 06122509
	ds_bpermute_b32 v11, v20, v4                               // 000000351E20: DACC0000 0B000414
	s_waitcnt lgkmcnt(2)                                       // 000000351E28: BF89FC27
	v_add_f32_e32 v5, v5, v12                                  // 000000351E2C: 060A1905
	ds_bpermute_b32 v13, v20, v6                               // 000000351E30: DACC0000 0D000614
	s_waitcnt lgkmcnt(1)                                       // 000000351E38: BF89FC17
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v4, v4, v11   // 000000351E3C: C9081503 03041704
	v_add_f32_e32 v11, v2, v19                                 // 000000351E44: 06162702
	ds_bpermute_b32 v15, v20, v8                               // 000000351E48: DACC0000 0F000814
	v_xor_b32_e32 v20, 2, v1                                   // 000000351E50: 3A280282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000351E54: BF8701D1
	v_cmp_gt_u32_e32 vcc_lo, 32, v20                           // 000000351E58: 7C9828A0
	v_cndmask_b32_e32 v20, v1, v20, vcc_lo                     // 000000351E5C: 02282901
	s_waitcnt lgkmcnt(0)                                       // 000000351E60: BF89FC07
	v_add_f32_e32 v8, v8, v15                                  // 000000351E64: 06101F08
	v_add_f32_e32 v6, v6, v13                                  // 000000351E68: 060C1B06
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000351E6C: 30282882
	ds_bpermute_b32 v2, v20, v3                                // 000000351E70: DACC0000 02000314
	ds_bpermute_b32 v10, v20, v4                               // 000000351E78: DACC0000 0A000414
	ds_bpermute_b32 v12, v20, v5                               // 000000351E80: DACC0000 0C000514
	ds_bpermute_b32 v13, v20, v6                               // 000000351E88: DACC0000 0D000614
	ds_bpermute_b32 v14, v20, v7                               // 000000351E90: DACC0000 0E000714
	ds_bpermute_b32 v15, v20, v8                               // 000000351E98: DACC0000 0F000814
	ds_bpermute_b32 v18, v20, v9                               // 000000351EA0: DACC0000 12000914
	ds_bpermute_b32 v19, v20, v11                              // 000000351EA8: DACC0000 13000B14
	v_xor_b32_e32 v20, 1, v1                                   // 000000351EB0: 3A280281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000351EB4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v20                           // 000000351EB8: 7C9828A0
	v_cndmask_b32_e32 v1, v1, v20, vcc_lo                      // 000000351EBC: 02022901
	s_waitcnt lgkmcnt(7)                                       // 000000351EC0: BF89FC77
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v20, 2, v1 // 000000351EC4: C9220503 01140282
	s_waitcnt lgkmcnt(3)                                       // 000000351ECC: BF89FC37
	v_add_f32_e32 v3, v7, v14                                  // 000000351ED0: 06061D07
	v_add_f32_e32 v2, v4, v10                                  // 000000351ED4: 06041504
	s_waitcnt lgkmcnt(2)                                       // 000000351ED8: BF89FC27
	v_dual_add_f32 v4, v5, v12 :: v_dual_add_f32 v7, v8, v15   // 000000351EDC: C9081905 04061F08
	s_waitcnt lgkmcnt(1)                                       // 000000351EE4: BF89FC17
	v_dual_add_f32 v5, v6, v13 :: v_dual_add_f32 v10, v9, v18  // 000000351EE8: C9081B06 050A2509
	s_waitcnt lgkmcnt(0)                                       // 000000351EF0: BF89FC07
	v_add_f32_e32 v12, v11, v19                                // 000000351EF4: 0618270B
	ds_bpermute_b32 v6, v20, v1                                // 000000351EF8: DACC0000 06000114
	ds_bpermute_b32 v8, v20, v2                                // 000000351F00: DACC0000 08000214
	ds_bpermute_b32 v11, v20, v4                               // 000000351F08: DACC0000 0B000414
	ds_bpermute_b32 v13, v20, v5                               // 000000351F10: DACC0000 0D000514
	ds_bpermute_b32 v9, v20, v3                                // 000000351F18: DACC0000 09000314
	ds_bpermute_b32 v14, v20, v7                               // 000000351F20: DACC0000 0E000714
	ds_bpermute_b32 v15, v20, v10                              // 000000351F28: DACC0000 0F000A14
	ds_bpermute_b32 v18, v20, v12                              // 000000351F30: DACC0000 12000C14
	v_cmpx_eq_u32_e32 0, v17                                   // 000000351F38: 7D942280
	s_cbranch_execz 14                                         // 000000351F3C: BFA5000E <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi8EEEvPKhPKtPtll+0x1678>
	s_waitcnt lgkmcnt(0)                                       // 000000351F40: BF89FC07
	v_dual_add_f32 v19, v12, v18 :: v_dual_add_f32 v18, v10, v15// 000000351F44: C908250C 13121F0A
	v_dual_add_f32 v17, v7, v14 :: v_dual_add_f32 v12, v4, v11 // 000000351F4C: C9081D07 110C1704
	v_add_f32_e32 v13, v5, v13                                 // 000000351F54: 061A1B05
	v_dual_add_f32 v11, v2, v8 :: v_dual_add_f32 v10, v1, v6   // 000000351F58: C9081102 0B0A0D01
	v_dual_add_f32 v16, v3, v9 :: v_dual_lshlrev_b32 v1, 5, v16// 000000351F60: C9221303 10002085
	ds_store_b128 v1, v[10:13]                                 // 000000351F68: DB7C0000 00000A01
	ds_store_b128 v1, v[16:19] offset:16                       // 000000351F70: DB7C0010 00001001
	s_or_b32 exec_lo, exec_lo, s0                              // 000000351F78: 8C7E007E
	.long 0xd4510000                                           // 000000351F7C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000351F80: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 8, v0                             // 000000351F84: 7C980088
	s_waitcnt lgkmcnt(0)                                       // 000000351F88: BF89FC07
	s_barrier                                                  // 000000351F8C: BFBD0000
	buffer_gl0_inv                                             // 000000351F90: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000351F98: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000351F9C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000351FA0: BE812000
	s_cbranch_execz 50                                         // 000000351FA4: BFA50032 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi8EEEvPKhPKtPtll+0x1770>
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000351FA8: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000351FAC: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:8                     // 000000351FB0: D8DC0800 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:16 offset1:24         // 000000351FB8: D8DC1810 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:32 offset1:40         // 000000351FC0: D8DC2820 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000351FC8: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000351FCC: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000351FD0: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000351FD4: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000351FD8: BF89FC17
	v_add_f32_e32 v1, v1, v3                                   // 000000351FDC: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000351FE0: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 000000351FE4: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000351FE8: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(0)                                       // 000000351FF0: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 000000351FF4: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000351FF8: BF8700D1
	v_add_f32_e32 v4, v3, v6                                   // 000000351FFC: 06080D03
	ds_load_2addr_b32 v[7:8], v7 offset0:48 offset1:56         // 000000352000: D8DC3830 07000007
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000352008: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 000000352010: BF89FC07
	v_add_f32_e32 v0, v4, v7                                   // 000000352014: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 000000352018: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035201C: BF870113
	.long 0xd73c0000                                           // 000000352020: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000352024: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 000000352028: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000352030: BF870092
	.long 0xd7006a00                                           // 000000352034: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000352038: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000035203C: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000352044: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000352048: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 000000352054: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000352058: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000035205C: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000352060: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000352068: DC960000 007C0200
	s_endpgm                                                   // 000000352070: BFB00000
		...

