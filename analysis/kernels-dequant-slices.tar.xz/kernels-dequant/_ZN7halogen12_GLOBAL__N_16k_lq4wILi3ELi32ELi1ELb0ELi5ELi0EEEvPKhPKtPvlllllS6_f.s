00000000008c0b00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008C0B00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000008C0B08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008C0B0C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000008C0B10: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C0B14: BF8701A9
	v_dual_mov_b32 v10, s3 :: v_dual_and_b32 v1, 15, v0        // 0000008C0B18: CA240003 0A00008F
	.long 0x7f103880                                           // 0000008C0B20: 7F103880
	v_and_b32_e32 v2, 60, v2                                   // 0000008C0B24: 360404BC
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C0B28: BF870003
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 0000008C0B2C: CA220080 12000282
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v16, 31, v0         // 0000008C0B34: CA240080 0310009F
	v_mov_b32_e32 v17, 0                                       // 0000008C0B3C: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 0000008C0B40: BF89FC07
	s_clause 0x1                                               // 0000008C0B44: BF850001
	global_load_b32 v4, v1, s[4:5]                             // 0000008C0B48: DC520000 04040001
	global_load_b32 v7, v2, s[4:5]                             // 0000008C0B50: DC520000 07040002
	v_lshrrev_b32_e32 v2, 5, v0                                // 0000008C0B58: 32040085
	s_add_u32 s14, s4, s14                                     // 0000008C0B5C: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000008C0B60: 820F0F05
	v_mov_b32_e32 v1, 0                                        // 0000008C0B64: 7E020280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C0B68: BF870002
	v_or_b32_e32 v9, s2, v2                                    // 0000008C0B6C: 38120402
	s_lshr_b32 s2, s11, 31                                     // 0000008C0B70: 85029F0B
	v_mov_b32_e32 v2, 0                                        // 0000008C0B74: 7E040280
	s_add_u32 s20, s10, s2                                     // 0000008C0B78: 8014020A
	s_addc_u32 s21, s11, 0                                     // 0000008C0B7C: 8215800B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000008C0B80: 7CA8120C
	s_ashr_i32 s22, s11, 31                                    // 0000008C0B84: 86169F0B
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 0000008C0B88: 02161280
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 0000008C0B8C: D501000E 01A80680
	s_ashr_i64 s[2:3], s[20:21], 1                             // 0000008C0B94: 86828114
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000008C0B98: BF870481
	.long 0xd72c0014                                           // 0000008C0B9C: D72C0014
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000008C0BA0: 0200050E
	.long 0xd72c000e                                           // 0000008C0BA4: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000008C0BA8: 02021C12
	s_waitcnt vmcnt(1)                                         // 0000008C0BAC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000008C0BB0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000008C0BB8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000008C0BBC: D6100013 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C0BC4: BF870112
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000008C0BC8: D6550004 03FE1904 00007FFF
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000008C0BD4: D6550007 03FE2707 00007FFF
	v_lshlrev_b32_e32 v19, 2, v0                               // 0000008C0BE0: 30260082
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C0BE4: BF870003
	.long 0x7e103984                                           // 0000008C0BE8: 7E103984
	v_mov_b32_e32 v4, 0                                        // 0000008C0BEC: 7E080280
	.long 0xd72c000d                                           // 0000008C0BF0: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 0000008C0BF4: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 0000008C0BF8: D6FE7C05 02021612
	.long 0xd72c000f                                           // 0000008C0C00: D72C000F
	v_cndmask_b32_e32 v0, v11, v3, vcc_lo                      // 0000008C0C04: 0200070B
	v_mad_u64_u32 v[11:12], null, v11, s2, s[14:15]            // 0000008C0C08: D6FE7C0B 0038050B
	s_lshr_b32 s19, s22, 27                                    // 0000008C0C10: 85139B16
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 0000008C0C14: D6570007 04220EFF FFFF0000
	s_add_u32 s14, s10, s19                                    // 0000008C0C20: 800E130A
	s_addc_u32 s15, s11, 0                                     // 0000008C0C24: 820F800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008C0C28: BF870009
	s_lshr_b64 s[14:15], s[14:15], 5                           // 0000008C0C2C: 858E850E
	v_add3_u32 v6, v6, v14, v13                                // 0000008C0C30: D6550006 04361D06
	.long 0xd4440002                                           // 0000008C0C38: D4440002
	v_cndmask_b32_e32 v1, s14, v16, vcc_lo                     // 0000008C0C3C: 0202200E
	v_add3_u32 v0, v20, v12, v15                               // 0000008C0C40: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 0000008C0C48: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 0000008C0C50: BF89FC07
	s_barrier                                                  // 0000008C0C54: BFBD0000
	buffer_gl0_inv                                             // 0000008C0C58: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 0000008C0C60: BE8F2002
	s_cbranch_execz 26                                         // 0000008C0C64: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1d0>
	s_add_u32 s3, s4, s16                                      // 0000008C0C68: 80031004
	s_addc_u32 s18, s5, s17                                    // 0000008C0C6C: 82121105
	v_lshlrev_b32_e32 v1, 1, v16                               // 0000008C0C70: 30022081
	.long 0xd7000302                                           // 0000008C0C74: D7000302
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 0000008C0C78: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C0C7C: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s18, v6, s3                  // 0000008C0C80: D5207C03 000E0C12
	v_lshlrev_b32_e32 v4, 4, v16                               // 0000008C0C88: 30082084
	.long 0xd7000301                                           // 0000008C0C8C: D7000301
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000008C0C90: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C0C94: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s3                    // 0000008C0C98: D5207C02 000E0680
	.long 0xd7000303                                           // 0000008C0CA0: D7000303
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 0000008C0CA4: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C0CA8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s3                    // 0000008C0CAC: D5207C04 000E0080
	s_clause 0x1                                               // 0000008C0CB4: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 0000008C0CB8: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008C0CC0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008C0CC8: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000008C0CCC: 7E241707
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008C0CD0: 8C7E0F7E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000008C0CD4: CA100080 13140080
	s_and_saveexec_b32 s15, s2                                 // 0000008C0CDC: BE8F2002
	s_cbranch_execz 331                                        // 0000008C0CE0: BFA5014B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x710>
	v_dual_mov_b32 v22, v16 :: v_dual_lshlrev_b32 v7, 1, v16   // 0000008C0CE4: CA220110 16062081
	.long 0xd7000205                                           // 0000008C0CEC: D7000205
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000008C0CF0: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C0CF4: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s2                  // 0000008C0CF8: D5207C06 000A0C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 0000008C0D00: CA220080 0D0C2085
	.long 0xd7000205                                           // 0000008C0D08: D7000205
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000008C0D0C: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C0D10: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 0000008C0D14: D5207C06 000A0C80
	v_lshl_or_b32 v21, v16, 4, 0x200                           // 0000008C0D1C: D6560015 03FD0910 00000200
	.long 0xd7000205                                           // 0000008C0D28: D7000205
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000008C0D2C: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C0D30: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s2                   // 0000008C0D34: D5207C06 000A0C05
	v_dual_mov_b32 v20, v13 :: v_dual_mov_b32 v23, v18         // 0000008C0D3C: CA10010D 14160112
	.long 0xd700020e                                           // 0000008C0D44: D700020E
	v_cndmask_b32_e32 v0, v5, v192, vcc_lo                     // 0000008C0D48: 02018105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C0D4C: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s2                   // 0000008C0D50: D5207C0F 000A0C80
	v_mov_b32_e32 v19, v13                                     // 0000008C0D58: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 0000008C0D5C: 7E22030D
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000008C0D60: 8484820A
	s_mov_b32 s16, 0                                           // 0000008C0D64: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000008C0D68: 848A810A
	s_branch 270                                               // 0000008C0D6C: BFA0010E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x6a8>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000008C0D70: 8C7E117E
	.long 0xd73c0018                                           // 0000008C0D74: D73C0018
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008C0D78: 02021881
	v_and_b32_e32 v72, 0xff, v1                                // 0000008C0D7C: 369002FF 000000FF
	v_lshrrev_b32_e32 v73, 6, v1                               // 0000008C0D84: 32920286
	v_lshrrev_b32_e32 v74, 14, v1                              // 0000008C0D88: 3294028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000008C0D8C: 32020296
	v_and_b32_e32 v75, 0xff, v2                                // 0000008C0D90: 369604FF 000000FF
	.long 0xd700033c                                           // 0000008C0D98: D700033C
	v_cndmask_b32_e32 v1, s6, v24, vcc_lo                      // 0000008C0D9C: 02023006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C0DA0: BF8701A1
	v_add_co_ci_u32_e64 v61, null, s7, v25, s3                 // 0000008C0DA4: D5207C3D 000E3207
	v_lshlrev_b32_e32 v72, 2, v72                              // 0000008C0DAC: 30909082
	.long 0xd7000340                                           // 0000008C0DB0: D7000340
	v_cndmask_b32_e32 v0, v60, v10, vcc_lo                     // 0000008C0DB4: 0200153C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C0DB8: BF8700A1
	v_add_co_ci_u32_e64 v65, null, s11, v61, s3                // 0000008C0DBC: D5207C41 000E7A0B
	.long 0xd7000344                                           // 0000008C0DC4: D7000344
	v_cndmask_b32_e32 v0, v60, v4, vcc_lo                      // 0000008C0DC8: 0200093C
	v_add_co_ci_u32_e64 v69, null, s5, v61, s3                 // 0000008C0DCC: D5207C45 000E7A05
	s_clause 0xb                                               // 0000008C0DD4: BF85000B
	global_load_b128 v[24:27], v[60:61], off                   // 0000008C0DD8: DC5E0000 187C003C
	global_load_b128 v[28:31], v[64:65], off                   // 0000008C0DE0: DC5E0000 1C7C0040
	global_load_b128 v[32:35], v[68:69], off                   // 0000008C0DE8: DC5E0000 207C0044
	global_load_b128 v[36:39], v[60:61], off offset:16         // 0000008C0DF0: DC5E0010 247C003C
	global_load_b128 v[40:43], v[64:65], off offset:16         // 0000008C0DF8: DC5E0010 287C0040
	global_load_b128 v[44:47], v[68:69], off offset:16         // 0000008C0E00: DC5E0010 2C7C0044
	global_load_b128 v[48:51], v[60:61], off offset:32         // 0000008C0E08: DC5E0020 307C003C
	global_load_b128 v[52:55], v[64:65], off offset:32         // 0000008C0E10: DC5E0020 347C0040
	global_load_b128 v[56:59], v[68:69], off offset:32         // 0000008C0E18: DC5E0020 387C0044
	global_load_b128 v[60:63], v[60:61], off offset:48         // 0000008C0E20: DC5E0030 3C7C003C
	global_load_b128 v[64:67], v[64:65], off offset:48         // 0000008C0E28: DC5E0030 407C0040
	global_load_b128 v[68:71], v[68:69], off offset:48         // 0000008C0E30: DC5E0030 447C0044
	v_and_b32_e32 v73, 0x3fc, v73                              // 0000008C0E38: 369292FF 000003FC
	ds_load_b32 v72, v72                                       // 0000008C0E40: D8D80000 48000048
	v_and_b32_e32 v74, 0x3fc, v74                              // 0000008C0E48: 369494FF 000003FC
	v_lshrrev_b32_e32 v76, 6, v2                               // 0000008C0E50: 32980486
	v_lshrrev_b32_e32 v77, 14, v2                              // 0000008C0E54: 329A048E
	ds_load_b32 v73, v73                                       // 0000008C0E58: D8D80000 49000049
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000008C0E60: 32040496
	ds_load_b32 v74, v74                                       // 0000008C0E64: D8D80000 4A00004A
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C0E6C: 360202FF 000003FC
	v_lshlrev_b32_e32 v75, 2, v75                              // 0000008C0E74: 30969682
	v_and_b32_e32 v76, 0x3fc, v76                              // 0000008C0E78: 369898FF 000003FC
	v_and_b32_e32 v77, 0x3fc, v77                              // 0000008C0E80: 369A9AFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000008C0E88: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000008C0E90: D8D80000 01000001
	ds_load_b32 v75, v75                                       // 0000008C0E98: D8D80000 4B00004B
	ds_load_b32 v76, v76                                       // 0000008C0EA0: D8D80000 4C00004C
	ds_load_b32 v77, v77                                       // 0000008C0EA8: D8D80000 4D00004D
	ds_load_b32 v2, v2                                         // 0000008C0EB0: D8D80000 02000002
	v_and_b32_e32 v78, 0xff, v3                                // 0000008C0EB8: 369C06FF 000000FF
	v_lshrrev_b32_e32 v79, 6, v3                               // 0000008C0EC0: 329E0686
	v_lshrrev_b32_e32 v80, 14, v3                              // 0000008C0EC4: 32A0068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000008C0EC8: 32060696
	v_and_b32_e32 v81, 0xff, v4                                // 0000008C0ECC: 36A208FF 000000FF
	v_lshrrev_b32_e32 v82, 14, v4                              // 0000008C0ED4: 32A4088E
	s_and_b32 s3, exec_lo, s2                                  // 0000008C0ED8: 8B03027E
	.long 0xd700020e                                           // 0000008C0EDC: D700020E
	v_cndmask_b32_e32 v0, v14, v192, vcc_lo                    // 0000008C0EE0: 0201810E
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000008C0EE4: 360606FF 000003FC
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008C0EEC: 4A1818FF 00000400
	v_add_nc_u32_e32 v21, 0x200, v21                           // 0000008C0EF4: 4A2A2AFF 00000200
	v_add_co_ci_u32_e64 v15, null, 0, v15, s2                  // 0000008C0EFC: D5207C0F 000A1E80
	s_or_b32 s16, s3, s16                                      // 0000008C0F04: 8C101003
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000008C0F08: BF892C77
	v_dot2_f32_bf16 v24, v24, v72, 0                           // 0000008C0F0C: CC1A4018 1A029118
	s_waitcnt vmcnt(10)                                        // 0000008C0F14: BF892BF7
	v_dot2_f32_bf16 v28, v28, v72, 0                           // 0000008C0F18: CC1A401C 1A02911C
	s_waitcnt vmcnt(9)                                         // 0000008C0F20: BF8927F7
	v_dot2_f32_bf16 v32, v32, v72, 0                           // 0000008C0F24: CC1A4020 1A029120
	v_lshrrev_b32_e32 v72, 6, v4                               // 0000008C0F2C: 32900886
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008C0F30: 32080896
	s_waitcnt lgkmcnt(6)                                       // 0000008C0F34: BF89FC67
	v_dot2_f32_bf16 v24, v25, v73, v24                         // 0000008C0F38: CC1A4018 1C629319
	v_dot2_f32_bf16 v25, v29, v73, v28                         // 0000008C0F40: CC1A4019 1C72931D
	v_dot2_f32_bf16 v28, v33, v73, v32                         // 0000008C0F48: CC1A401C 1C829321
	v_lshlrev_b32_e32 v29, 2, v78                              // 0000008C0F50: 303A9C82
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008C0F54: 360808FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000008C0F5C: BF89FC57
	v_dot2_f32_bf16 v24, v26, v74, v24                         // 0000008C0F60: CC1A4018 1C62951A
	v_dot2_f32_bf16 v25, v30, v74, v25                         // 0000008C0F68: CC1A4019 1C66951E
	v_dot2_f32_bf16 v26, v34, v74, v28                         // 0000008C0F70: CC1A401A 1C729522
	v_and_b32_e32 v28, 0x3fc, v79                              // 0000008C0F78: 36389EFF 000003FC
	v_and_b32_e32 v30, 0x3fc, v80                              // 0000008C0F80: 363CA0FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000008C0F88: BF89FC47
	v_dot2_f32_bf16 v24, v27, v1, v24                          // 0000008C0F8C: CC1A4018 1C62031B
	v_dot2_f32_bf16 v25, v31, v1, v25                          // 0000008C0F94: CC1A4019 1C66031F
	v_dot2_f32_bf16 v1, v35, v1, v26                           // 0000008C0F9C: CC1A4001 1C6A0323
	ds_load_b32 v27, v29                                       // 0000008C0FA4: D8D80000 1B00001D
	ds_load_b32 v30, v30                                       // 0000008C0FAC: D8D80000 1E00001E
	ds_load_b32 v28, v28                                       // 0000008C0FB4: D8D80000 1C00001C
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 0000008C0FBC: BF892067
	v_dot2_f32_bf16 v24, v36, v75, v24                         // 0000008C0FC0: CC1A4018 1C629724
	s_waitcnt vmcnt(7)                                         // 0000008C0FC8: BF891FF7
	v_dot2_f32_bf16 v25, v40, v75, v25                         // 0000008C0FCC: CC1A4019 1C669728
	s_waitcnt vmcnt(6)                                         // 0000008C0FD4: BF891BF7
	v_dot2_f32_bf16 v1, v44, v75, v1                           // 0000008C0FD8: CC1A4001 1C06972C
	v_lshlrev_b32_e32 v26, 2, v81                              // 0000008C0FE0: 3034A282
	v_and_b32_e32 v29, 0x3fc, v72                              // 0000008C0FE4: 363A90FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000008C0FEC: BF89FC57
	v_dot2_f32_bf16 v24, v37, v76, v24                         // 0000008C0FF0: CC1A4018 1C629925
	v_dot2_f32_bf16 v25, v41, v76, v25                         // 0000008C0FF8: CC1A4019 1C669929
	v_dot2_f32_bf16 v1, v45, v76, v1                           // 0000008C1000: CC1A4001 1C06992D
	v_and_b32_e32 v31, 0x3fc, v82                              // 0000008C1008: 363EA4FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000008C1010: BF89FC47
	v_dot2_f32_bf16 v24, v38, v77, v24                         // 0000008C1014: CC1A4018 1C629B26
	v_dot2_f32_bf16 v25, v42, v77, v25                         // 0000008C101C: CC1A4019 1C669B2A
	v_dot2_f32_bf16 v1, v46, v77, v1                           // 0000008C1024: CC1A4001 1C069B2E
	s_waitcnt lgkmcnt(3)                                       // 0000008C102C: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C1030: BF870193
	v_dot2_f32_bf16 v24, v39, v2, v24                          // 0000008C1034: CC1A4018 1C620527
	v_dot2_f32_bf16 v25, v43, v2, v25                          // 0000008C103C: CC1A4019 1C66052B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C1044: BF870003
	v_dot2_f32_bf16 v1, v47, v2, v1                            // 0000008C1048: CC1A4001 1C06052F
	ds_load_b32 v2, v3                                         // 0000008C1050: D8D80000 02000003
	ds_load_b32 v3, v26                                        // 0000008C1058: D8D80000 0300001A
	ds_load_b32 v26, v29                                       // 0000008C1060: D8D80000 1A00001D
	ds_load_b32 v29, v31                                       // 0000008C1068: D8D80000 1D00001F
	ds_load_b32 v31, v4                                        // 0000008C1070: D8D80000 1F000004
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 0000008C1078: BF891477
	v_dot2_f32_bf16 v4, v48, v27, v24                          // 0000008C107C: CC1A4004 1C623730
	s_waitcnt vmcnt(4)                                         // 0000008C1084: BF8913F7
	v_dot2_f32_bf16 v24, v52, v27, v25                         // 0000008C1088: CC1A4018 1C663734
	s_waitcnt vmcnt(3)                                         // 0000008C1090: BF890FF7
	v_dot2_f32_bf16 v1, v56, v27, v1                           // 0000008C1094: CC1A4001 1C063738
	s_waitcnt lgkmcnt(5)                                       // 0000008C109C: BF89FC57
	v_dot2_f32_bf16 v4, v49, v28, v4                           // 0000008C10A0: CC1A4004 1C123931
	v_dot2_f32_bf16 v24, v53, v28, v24                         // 0000008C10A8: CC1A4018 1C623935
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C10B0: BF870193
	v_dot2_f32_bf16 v1, v57, v28, v1                           // 0000008C10B4: CC1A4001 1C063939
	v_dot2_f32_bf16 v4, v50, v30, v4                           // 0000008C10BC: CC1A4004 1C123D32
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C10C4: BF870193
	v_dot2_f32_bf16 v24, v54, v30, v24                         // 0000008C10C8: CC1A4018 1C623D36
	v_dot2_f32_bf16 v1, v58, v30, v1                           // 0000008C10D0: CC1A4001 1C063D3A
	s_waitcnt lgkmcnt(4)                                       // 0000008C10D8: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C10DC: BF870193
	v_dot2_f32_bf16 v4, v51, v2, v4                            // 0000008C10E0: CC1A4004 1C120533
	v_dot2_f32_bf16 v24, v55, v2, v24                          // 0000008C10E8: CC1A4018 1C620537
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C10F0: BF8701A3
	v_dot2_f32_bf16 v1, v59, v2, v1                            // 0000008C10F4: CC1A4001 1C06053B
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000008C10FC: BF890837
	v_dot2_f32_bf16 v2, v60, v3, v4                            // 0000008C1100: CC1A4002 1C12073C
	s_waitcnt vmcnt(1)                                         // 0000008C1108: BF8907F7
	v_dot2_f32_bf16 v4, v64, v3, v24                           // 0000008C110C: CC1A4004 1C620740
	s_waitcnt vmcnt(0)                                         // 0000008C1114: BF8903F7
	v_dot2_f32_bf16 v1, v68, v3, v1                            // 0000008C1118: CC1A4001 1C060744
	s_waitcnt lgkmcnt(2)                                       // 0000008C1120: BF89FC27
	v_dot2_f32_bf16 v2, v61, v26, v2                           // 0000008C1124: CC1A4002 1C0A353D
	v_dot2_f32_bf16 v3, v65, v26, v4                           // 0000008C112C: CC1A4003 1C123541
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C1134: BF870003
	v_dot2_f32_bf16 v1, v69, v26, v1                           // 0000008C1138: CC1A4001 1C063545
	v_mov_b32_e32 v4, v8                                       // 0000008C1140: 7E080308
	s_waitcnt lgkmcnt(1)                                       // 0000008C1144: BF89FC17
	v_dot2_f32_bf16 v2, v62, v29, v2                           // 0000008C1148: CC1A4002 1C0A3B3E
	v_dot2_f32_bf16 v24, v66, v29, v3                          // 0000008C1150: CC1A4018 1C0E3B42
	v_dot2_f32_bf16 v1, v70, v29, v1                           // 0000008C1158: CC1A4001 1C063B46
	v_mov_b32_e32 v3, v7                                       // 0000008C1160: 7E060307
	s_waitcnt lgkmcnt(0)                                       // 0000008C1164: BF89FC07
	v_dot2_f32_bf16 v7, v63, v31, v2                           // 0000008C1168: CC1A4007 1C0A3F3F
	v_dot2_f32_bf16 v8, v67, v31, v24                          // 0000008C1170: CC1A4008 1C623F43
	v_dot2_f32_bf16 v24, v71, v31, v1                          // 0000008C1178: CC1A4018 1C063F47
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 0000008C1180: CA100106 02000105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008C1188: BF870214
	v_fmac_f32_e32 v20, v18, v7                                // 0000008C118C: 56280F12
	v_fmac_f32_e32 v19, v18, v8                                // 0000008C1190: 56261112
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008C1194: BF870004
	v_dual_fmac_f32 v17, v18, v24 :: v_dual_mov_b32 v18, v23   // 0000008C1198: C8103112 11120117
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008C11A0: 917E107E
	s_cbranch_execz 25                                         // 0000008C11A4: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x70c>
	s_waitcnt vmcnt(0)                                         // 0000008C11A8: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v22, 32, v22    // 0000008C11AC: CA200101 05162CA0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000008C11B4: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 0000008C11BC: 7E100304
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C11C0: BF870003
	.long 0xd4430002                                           // 0000008C11C4: D4430002
	v_cndmask_b32_e32 v1, s14, v22, vcc_lo                     // 0000008C11C8: 02022C0E
	s_mov_b32 s17, exec_lo                                     // 0000008C11CC: BE91007E
	.long 0xd4c4007e                                           // 0000008C11D0: D4C4007E
	v_cndmask_b32_e32 v1, s14, v22, vcc_lo                     // 0000008C11D4: 02022C0E
	s_cbranch_execz 65253                                      // 0000008C11D8: BFA5FEE5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x270>
	.long 0xd7000305                                           // 0000008C11DC: D7000305
	v_cndmask_b32_e32 v1, v11, v21, vcc_lo                     // 0000008C11E0: 02022B0B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C11E4: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s3                    // 0000008C11E8: D5207C06 000E0080
	global_load_d16_b16 v23, v[14:15], off                     // 0000008C11F0: DC820000 177C000E
	global_load_b128 v[5:8], v[5:6], off                       // 0000008C11F8: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 0000008C1200: BF8907F7
	v_cvt_f32_f16_e32 v23, v23                                 // 0000008C1204: 7E2E1717
	s_branch 65241                                             // 0000008C1208: BFA0FED9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x270>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000008C120C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C1210: BF8700B9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008C1214: 8C7E0F7E
	.long 0xd71f0000                                           // 0000008C1218: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008C121C: 020100C1
	s_waitcnt vmcnt(0)                                         // 0000008C1220: BF8903F7
	v_xor_b32_e32 v1, 16, v0                                   // 0000008C1224: 3A020090
	v_xor_b32_e32 v4, 8, v0                                    // 0000008C1228: 3A080088
	v_xor_b32_e32 v7, 4, v0                                    // 0000008C122C: 3A0E0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1230: BF870093
	.long 0xd44c0002                                           // 0000008C1234: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000008C1238: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000008C123C: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C1244: BF870114
	.long 0xd44c0002                                           // 0000008C1248: D44C0002
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 0000008C124C: 020208A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008C1250: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C1254: BF870002
	v_cndmask_b32_e64 v4, v0, v4, s2                           // 0000008C1258: D5010004 000A0900
	.long 0xd44c0002                                           // 0000008C1260: D44C0002
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000008C1264: 02020EA0
	ds_bpermute_b32 v2, v1, v20                                // 0000008C1268: DACC0000 02001401
	v_cndmask_b32_e64 v7, v0, v7, s2                           // 0000008C1270: D5010007 000A0F00
	s_waitcnt lgkmcnt(0)                                       // 0000008C1278: BF89FC07
	v_add_f32_e32 v2, v20, v2                                  // 0000008C127C: 06040514
	ds_bpermute_b32 v3, v1, v19                                // 0000008C1280: DACC0000 03001301
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008C1288: 30080882
	ds_bpermute_b32 v1, v1, v17                                // 0000008C128C: DACC0000 01001101
	s_waitcnt lgkmcnt(1)                                       // 0000008C1294: BF89FC17
	v_add_f32_e32 v3, v19, v3                                  // 0000008C1298: 06060713
	ds_bpermute_b32 v5, v4, v2                                 // 0000008C129C: DACC0000 05000204
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000008C12A4: 300E0E82
	ds_bpermute_b32 v6, v4, v3                                 // 0000008C12A8: DACC0000 06000304
	s_waitcnt lgkmcnt(1)                                       // 0000008C12B0: BF89FC17
	v_add_f32_e32 v2, v2, v5                                   // 0000008C12B4: 06040B02
	v_add_f32_e32 v1, v17, v1                                  // 0000008C12B8: 06020311
	s_waitcnt lgkmcnt(0)                                       // 0000008C12BC: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 0000008C12C0: 06060D03
	ds_bpermute_b32 v4, v4, v1                                 // 0000008C12C4: DACC0000 04000104
	ds_bpermute_b32 v5, v7, v3                                 // 0000008C12CC: DACC0000 05000307
	s_waitcnt lgkmcnt(0)                                       // 0000008C12D4: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 0000008C12D8: 06060B03
	v_add_f32_e32 v1, v1, v4                                   // 0000008C12DC: 06020901
	ds_bpermute_b32 v4, v7, v2                                 // 0000008C12E0: DACC0000 04000207
	ds_bpermute_b32 v6, v7, v1                                 // 0000008C12E8: DACC0000 06000107
	v_xor_b32_e32 v7, 2, v0                                    // 0000008C12F0: 3A0E0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C12F4: BF870091
	.long 0xd44c0002                                           // 0000008C12F8: D44C0002
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000008C12FC: 02020EA0
	v_cndmask_b32_e64 v7, v0, v7, s2                           // 0000008C1300: D5010007 000A0F00
	s_waitcnt lgkmcnt(1)                                       // 0000008C1308: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C130C: BF870001
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v7, 2, v7  // 0000008C1310: C9220902 02060E82
	s_waitcnt lgkmcnt(0)                                       // 0000008C1318: BF89FC07
	v_add_f32_e32 v4, v1, v6                                   // 0000008C131C: 06080D01
	ds_bpermute_b32 v1, v7, v2                                 // 0000008C1320: DACC0000 01000207
	ds_bpermute_b32 v6, v7, v4                                 // 0000008C1328: DACC0000 06000407
	s_waitcnt lgkmcnt(0)                                       // 0000008C1330: BF89FC07
	v_dual_add_f32 v1, v2, v1 :: v_dual_add_f32 v4, v4, v6     // 0000008C1334: C9080302 01040D04
	ds_bpermute_b32 v5, v7, v3                                 // 0000008C133C: DACC0000 05000307
	v_xor_b32_e32 v7, 1, v0                                    // 0000008C1344: 3A0E0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1348: BF870091
	.long 0xd44c0002                                           // 0000008C134C: D44C0002
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000008C1350: 02020EA0
	v_cndmask_b32_e64 v0, v0, v7, s2                           // 0000008C1354: D5010000 000A0F00
	.long 0xd44a0002                                           // 0000008C135C: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 0000008C1360: 02022080
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C1364: BF870002
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000008C1368: 300E0082
	s_and_b32 s2, s2, vcc_lo                                   // 0000008C136C: 8B026A02
	s_waitcnt lgkmcnt(0)                                       // 0000008C1370: BF89FC07
	v_add_f32_e32 v0, v3, v5                                   // 0000008C1374: 06000B03
	ds_bpermute_b32 v2, v7, v1                                 // 0000008C1378: DACC0000 02000107
	ds_bpermute_b32 v5, v7, v4                                 // 0000008C1380: DACC0000 05000407
	ds_bpermute_b32 v3, v7, v0                                 // 0000008C1388: DACC0000 03000007
	s_and_saveexec_b32 s3, s2                                  // 0000008C1390: BE832002
	s_cbranch_execz 86                                         // 0000008C1394: BFA50056 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x9f0>
	v_ashrrev_i32_e32 v6, 31, v10                              // 0000008C1398: 340C149F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008C139C: F4040080 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000008C13A4: BF89FC07
	v_add_f32_e32 v8, v4, v5                                   // 0000008C13A8: 06100B04
	v_dual_add_f32 v2, v1, v2 :: v_dual_add_f32 v3, v0, v3     // 0000008C13AC: C9080501 02020700
	v_lshrrev_b32_e32 v6, 23, v6                               // 0000008C13B4: 320C0C97
	s_lshr_b32 s1, s13, 31                                     // 0000008C13B8: 85019F0D
	v_mov_b32_e32 v11, s9                                      // 0000008C13BC: 7E160209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C13C0: BF870092
	.long 0xd7006a06                                           // 0000008C13C4: D7006A06
	v_cndmask_b32_e32 v1, v9, v6, vcc_lo                       // 0000008C13C8: 02020D09
	v_add_co_ci_u32_e64 v7, null, 0, v10, vcc_lo               // 0000008C13CC: D5207C07 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C13D4: BF870092
	v_and_b32_e32 v6, 0xfffffe00, v6                           // 0000008C13D8: 360C0CFF FFFFFE00
	.long 0xd7016a04                                           // 0000008C13E0: D7016A04
	v_cndmask_b32_e32 v1, v9, v6, vcc_lo                       // 0000008C13E4: 02020D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C13E8: BF8701A1
	v_sub_co_ci_u32_e64 v5, null, v10, v7, vcc_lo              // 0000008C13EC: D5217C05 01AA0F0A
	.long 0x7f143880                                           // 0000008C13F4: 7F143880
	.long 0xd7000000                                           // 0000008C13F8: D7000000
	v_cndmask_b32_e32 v1, 0xffffff00, v4, vcc_lo               // 0000008C13FC: 020208FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C1404: BF870003
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[4:5]                     // 0000008C1408: 7CA808FF 00000100
	v_add_co_ci_u32_e64 v1, null, -1, v5, s0                   // 0000008C1410: D5207C01 00020AC1
	v_mov_b32_e32 v9, s8                                       // 0000008C1418: 7E120208
	.long 0x7e143983                                           // 0000008C141C: 7E143983
	s_add_u32 s0, s12, s1                                      // 0000008C1420: 8000010C
	v_dual_cndmask_b32 v11, s3, v11 :: v_dual_cndmask_b32 v0, v0, v4// 0000008C1424: CA521603 0B000900
	.long 0x7e083982                                           // 0000008C142C: 7E083982
	.long 0x7f08398a                                           // 0000008C1430: 7F08398A
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 0000008C1434: 02020B01
	v_cndmask_b32_e32 v5, s2, v9, vcc_lo                       // 0000008C1438: 020A1202
	v_and_b32_e32 v9, 1, v10                                   // 0000008C143C: 36121481
	s_addc_u32 s1, s13, 0                                      // 0000008C1440: 8201800D
	v_and_b32_e32 v4, 1, v4                                    // 0000008C1444: 36080881
	.long 0xd73c0000                                           // 0000008C1448: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000008C144C: 02020081
	.long 0xd7006a05                                           // 0000008C1450: D7006A05
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 0000008C1454: 02020D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C1458: BF8700B1
	v_add_co_ci_u32_e64 v6, null, v11, v7, vcc_lo              // 0000008C145C: D5207C06 01AA0F0B
	s_and_b32 s2, s0, -2                                       // 0000008C1464: 8B02C200
	.long 0xd7006a00                                           // 0000008C1468: D7006A00
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000008C146C: 02020105
	v_add_co_ci_u32_e64 v1, null, v6, v1, vcc_lo               // 0000008C1470: D5207C01 01AA0306
	v_add3_u32 v7, v2, v4, 0x7fff                              // 0000008C1478: D6550007 03FE0902 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C1484: BF870003
	.long 0xd7006a02                                           // 0000008C1488: D7006A02
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000008C148C: 02000500
	v_bfe_u32 v4, v8, 16, 1                                    // 0000008C1490: D6100004 02052108
	v_add3_u32 v6, v3, v9, 0x7fff                              // 0000008C1498: D6550006 03FE1303 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000008C14A4: D5207C03 01AA0201
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000008C14AC: 84808100
	v_add3_u32 v8, v8, v4, 0x7fff                              // 0000008C14B0: D6550008 03FE0908 00007FFF
	s_and_b32 s0, s0, -4                                       // 0000008C14BC: 8B00C400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C14C0: BF870099
	.long 0xd7006a04                                           // 0000008C14C4: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008C14C8: 02000100
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 0000008C14CC: D5207C05 01AA0201
	s_clause 0x2                                               // 0000008C14D4: BF850002
	global_store_d16_hi_b16 v[0:1], v7, off                    // 0000008C14D8: DC960000 007C0700
	global_store_d16_hi_b16 v[2:3], v6, off                    // 0000008C14E0: DC960000 007C0602
	global_store_d16_hi_b16 v[4:5], v8, off                    // 0000008C14E8: DC960000 007C0804
	s_endpgm                                                   // 0000008C14F0: BFB00000
		...

