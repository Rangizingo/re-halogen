0000000000811c00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000811C00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000811C08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000811C0C: 32040082
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000811C10: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000811C14: BF8701A9
	v_dual_mov_b32 v24, s1 :: v_dual_and_b32 v1, 15, v0        // 000000811C18: CA240001 1800008F
	v_and_b32_e32 v30, 31, v0                                  // 000000811C20: 363C009F
	v_and_b32_e32 v2, 60, v2                                   // 000000811C24: 360404BC
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000811C28: 300E0082
	s_delay_alu instid0(VALU_DEP_4)                            // 000000811C2C: BF870004
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000811C30: 30020282
	.long 0x7f0c3880                                           // 000000811C34: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 000000811C38: BF89FC07
	s_clause 0x1                                               // 000000811C3C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000811C40: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000811C48: DC520000 04040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000811C50: 32020085
	s_add_u32 s22, s4, s16                                     // 000000811C54: 80161004
	s_addc_u32 s23, s5, s17                                    // 000000811C58: 82171105
	s_ashr_i32 s2, s11, 31                                     // 000000811C5C: 86029F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000811C60: BF8704A1
	v_or_b32_e32 v23, s0, v1                                   // 000000811C64: 382E0200
	s_lshr_b32 s2, s2, 27                                      // 000000811C68: 85029B02
	s_add_u32 s2, s10, s2                                      // 000000811C6C: 8002020A
	s_addc_u32 s3, s11, 0                                      // 000000811C70: 8203800B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000811C74: BF8704A1
	.long 0xd4540000                                           // 000000811C78: D4540000
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 000000811C7C: 02022E0C
	s_lshr_b64 s[20:21], s[2:3], 5                             // 000000811C80: 85948502
	s_cmpk_lt_i32 s20, 0x101                                   // 000000811C84: B3940101
	.long 0xd4440002                                           // 000000811C88: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 000000811C8C: 02023C14
	v_cndmask_b32_e64 v2, 0, v23, s0                           // 000000811C90: D5010002 00022E80
	v_cndmask_b32_e64 v5, 0, s1, s0                            // 000000811C98: D5010005 00000280
	s_cselect_b32 s1, -1, 0                                    // 000000811CA0: 980180C1
	s_cmpk_gt_i32 s20, 0x100                                   // 000000811CA4: B2940100
	s_delay_alu instid0(VALU_DEP_2)                            // 000000811CA8: BF870002
	.long 0xd72c0008                                           // 000000811CAC: D72C0008
	v_cndmask_b32_e32 v1, s19, v2, vcc_lo                      // 000000811CB0: 02020413
	v_mad_u64_u32 v[0:1], null, s18, v2, 0                     // 000000811CB4: D6FE7C00 02020412
	s_waitcnt vmcnt(1)                                         // 000000811CBC: BF8907F7
	v_bfe_u32 v9, v3, 16, 1                                    // 000000811CC0: D6100009 02052103
	s_waitcnt vmcnt(0)                                         // 000000811CC8: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 000000811CCC: D610000A 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000811CD4: BF8701A2
	v_add3_u32 v3, v3, v9, 0x7fff                              // 000000811CD8: D6550003 03FE1303 00007FFF
	.long 0xd72c0009                                           // 000000811CE4: D72C0009
	v_cndmask_b32_e32 v1, s18, v5, vcc_lo                      // 000000811CE8: 02020A12
	v_add3_u32 v4, v4, v10, 0x7fff                             // 000000811CEC: D6550004 03FE1504 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 000000811CF8: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000811CFC: BF870239
	s_and_b32 vcc_lo, exec_lo, s18                             // 000000811D00: 8B6A127E
	.long 0x7e0c3983                                           // 000000811D04: 7E0C3983
	.long 0xd7000303                                           // 000000811D08: D7000303
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 000000811D0C: 02020016
	v_add3_u32 v1, v1, v9, v8                                  // 000000811D10: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000811D18: BF870113
	v_and_or_b32 v6, 0xffff0000, v4, v6                        // 000000811D1C: D6570006 041A08FF FFFF0000
	v_add_co_ci_u32_e64 v4, null, s23, v1, s3                  // 000000811D28: D5207C04 000E0217
	ds_store_b32 v7, v6                                        // 000000811D30: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 000000811D38: BF89FC07
	s_barrier                                                  // 000000811D3C: BFBD0000
	buffer_gl0_inv                                             // 000000811D40: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 000000811D48: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x394>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 000000811D4C: CA100080 08060080
	s_and_saveexec_b32 s3, s2                                  // 000000811D54: BE832002
	s_cbranch_execz 10                                         // 000000811D58: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x184>
	v_lshlrev_b32_e32 v6, 1, v30                               // 000000811D5C: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811D60: BF870091
	.long 0xd7006a06                                           // 000000811D64: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000811D68: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 000000811D6C: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 000000811D74: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000811D7C: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 000000811D80: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s3                              // 000000811D84: 8C7E037E
	v_or_b32_e32 v6, 32, v30                                   // 000000811D88: 380C3CA0
	s_mov_b32 s2, exec_lo                                      // 000000811D8C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000811D90: BF870001
	.long 0xd4c4007e                                           // 000000811D94: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000811D98: 02020C14
	s_cbranch_execz 10                                         // 000000811D9C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1c8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000811DA0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811DA4: BF870091
	.long 0xd7006a08                                           // 000000811DA8: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000811DAC: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 000000811DB0: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 000000811DB8: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 000000811DC0: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 000000811DC4: 7E101706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000811DC8: 8C7E027E
	v_or_b32_e32 v6, 64, v30                                   // 000000811DCC: 380C3CC0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 000000811DD0: CA100080 0A080080
	s_mov_b32 s2, exec_lo                                      // 000000811DD8: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000811DDC: BF870002
	.long 0xd4c4007e                                           // 000000811DE0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000811DE4: 02020C14
	s_cbranch_execz 10                                         // 000000811DE8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x214>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000811DEC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811DF0: BF870091
	.long 0xd7006a0b                                           // 000000811DF4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000811DF8: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 000000811DFC: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 000000811E04: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 000000811E0C: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 000000811E10: 7E121706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000811E14: 8C7E027E
	v_or_b32_e32 v6, 0x60, v30                                 // 000000811E18: 380C3CFF 00000060
	s_mov_b32 s2, exec_lo                                      // 000000811E20: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000811E24: BF870001
	.long 0xd4c4007e                                           // 000000811E28: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000811E2C: 02020C14
	s_cbranch_execz 10                                         // 000000811E30: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x25c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000811E34: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811E38: BF870091
	.long 0xd7006a0a                                           // 000000811E3C: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000811E40: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 000000811E44: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 000000811E4C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000811E54: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 000000811E58: 7E141706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000811E5C: 8C7E027E
	v_or_b32_e32 v6, 0x80, v30                                 // 000000811E60: 380C3CFF 00000080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 000000811E68: CA100080 0C0A0080
	s_mov_b32 s2, exec_lo                                      // 000000811E70: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000811E74: BF870002
	.long 0xd4c4007e                                           // 000000811E78: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000811E7C: 02020C14
	s_cbranch_execz 10                                         // 000000811E80: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2ac>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000811E84: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811E88: BF870091
	.long 0xd7006a0d                                           // 000000811E8C: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000811E90: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 000000811E94: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 000000811E9C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 000000811EA4: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 000000811EA8: 7E161706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000811EAC: 8C7E027E
	v_or_b32_e32 v6, 0xa0, v30                                 // 000000811EB0: 380C3CFF 000000A0
	s_mov_b32 s2, exec_lo                                      // 000000811EB8: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000811EBC: BF870001
	.long 0xd4c4007e                                           // 000000811EC0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000811EC4: 02020C14
	s_cbranch_execz 10                                         // 000000811EC8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2f4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000811ECC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811ED0: BF870091
	.long 0xd7006a0c                                           // 000000811ED4: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000811ED8: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 000000811EDC: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 000000811EE4: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 000000811EEC: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 000000811EF0: 7E181706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000811EF4: 8C7E027E
	v_or_b32_e32 v6, 0xc0, v30                                 // 000000811EF8: 380C3CFF 000000C0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 000000811F00: CA100080 0E0C0080
	s_mov_b32 s2, exec_lo                                      // 000000811F08: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000811F0C: BF870002
	.long 0xd4c4007e                                           // 000000811F10: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000811F14: 02020C14
	s_cbranch_execz 10                                         // 000000811F18: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x344>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000811F1C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811F20: BF870091
	.long 0xd7006a0f                                           // 000000811F24: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000811F28: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 000000811F2C: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 000000811F34: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 000000811F3C: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 000000811F40: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000811F44: 8C7E027E
	v_or_b32_e32 v6, 0xe0, v30                                 // 000000811F48: 380C3CFF 000000E0
	s_mov_b32 s2, exec_lo                                      // 000000811F50: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000811F54: BF870001
	.long 0xd4c4007e                                           // 000000811F58: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000811F5C: 02020C14
	s_cbranch_execz 10                                         // 000000811F60: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000811F64: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811F68: BF870091
	.long 0xd7006a0e                                           // 000000811F6C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000811F70: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 000000811F74: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 000000811F7C: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 000000811F84: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 000000811F88: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000811F8C: 8C7E027E
	s_branch 9                                                 // 000000811F90: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_mov_b32_e32 v7, 0                                        // 000000811F94: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000811F98: BF870001
	v_mov_b32_e32 v8, v7                                       // 000000811F9C: 7E100307
	v_mov_b32_e32 v9, v7                                       // 000000811FA0: 7E120307
	v_mov_b32_e32 v10, v7                                      // 000000811FA4: 7E140307
	v_mov_b32_e32 v11, v7                                      // 000000811FA8: 7E160307
	v_mov_b32_e32 v12, v7                                      // 000000811FAC: 7E180307
	v_mov_b32_e32 v13, v7                                      // 000000811FB0: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 000000811FB4: 7E1C0307
	s_add_u32 s2, s4, s14                                      // 000000811FB8: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000811FBC: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 000000811FC0: 850E9F0B
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 000000811FC4: CA100080 13140080
	s_add_u32 s14, s10, s14                                    // 000000811FCC: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000811FD0: 820F800B
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v22, 0             // 000000811FD4: CA100080 21160080
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000811FDC: 868E810E
	v_cndmask_b32_e64 v31, 0, 1, s18                           // 000000811FE0: D501001F 00490280
	v_mad_u64_u32 v[25:26], null, v2, s14, s[2:3]              // 000000811FE8: D6FE7C19 00081D02
	.long 0xd72c0002                                           // 000000811FF0: D72C0002
	v_cndmask_b32_e32 v0, v2, v15, vcc_lo                      // 000000811FF4: 02001F02
	.long 0xd72c0005                                           // 000000811FF8: D72C0005
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 000000811FFC: 02001D05
	.long 0xd4440002                                           // 000000812000: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 000000812004: 02023C14
	v_mov_b32_e32 v41, 0                                       // 000000812008: 7E520280
	v_mov_b32_e32 v21, 0                                       // 00000081200C: 7E2A0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000812010: BF870004
	v_add3_u32 v32, v5, v26, v2                                // 000000812014: D6550020 040A3505
	s_and_saveexec_b32 s3, s2                                  // 00000081201C: BE832002
	s_cbranch_execz 21                                         // 000000812020: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 000000812024: CA220080 29023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081202C: BF870091
	.long 0xd7006a05                                           // 000000812030: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 000000812034: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v32, vcc_lo               // 000000812038: D5207C06 01AA4080
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 000000812040: 916A127E
	global_load_b128 v[19:22], v[5:6], off                     // 000000812044: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000081204C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 1, v30                               // 000000812050: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000812054: BF870091
	.long 0xd7006a02                                           // 000000812058: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000081205C: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 000000812060: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 000000812068: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000812070: BF8903F7
	v_cvt_f32_f16_e32 v41, v2                                  // 000000812074: 7E521702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000812078: 8C7E037E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000081207C: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 000000812084: CA100080 24240080
	s_and_saveexec_b32 s3, s2                                  // 00000081208C: BE832002
	s_cbranch_execz 507                                        // 000000812090: BFA501FB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xc80>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 000000812094: CA220080 1B023C81
	.long 0xd7006a00                                           // 00000081209C: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000008120A0: 02020010
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008120A4: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000008120A8: D5207C01 01AA0211
	v_dual_mov_b32 v39, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 0000008120B0: CA22011E 271A3C85
	.long 0xd7006a00                                           // 0000008120B8: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 0000008120BC: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008120C0: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000008120C4: D5207C01 01AA0280
	v_lshl_or_b32 v38, v30, 4, 0x200                           // 0000008120CC: D6560026 03FD091E 00000200
	.long 0xd7006a00                                           // 0000008120D8: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000008120DC: 02020004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008120E0: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000008120E4: D5207C01 01AA0205
	v_dual_mov_b32 v37, v27 :: v_dual_mov_b32 v40, v41         // 0000008120EC: CA10011B 25280129
	.long 0xd7006a1c                                           // 0000008120F4: D7006A1C
	v_cndmask_b32_e32 v0, v0, v192, vcc_lo                     // 0000008120F8: 02018100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008120FC: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 000000812100: D5207C1D 01AA0280
	v_mov_b32_e32 v36, v27                                     // 000000812108: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 00000081210C: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 000000812110: 7E44031B
	v_mov_b32_e32 v33, v27                                     // 000000812114: 7E42031B
	s_mul_i32 s2, s11, 6                                       // 000000812118: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 00000081211C: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000812120: 848E820A
	s_add_i32 s18, s18, s2                                     // 000000812124: 81120212
	s_mul_i32 s17, s10, 6                                      // 000000812128: 9611860A
	s_mov_b32 s16, 0                                           // 00000081212C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000812130: 8484810A
	s_branch 437                                               // 000000812134: BFA001B5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xc0c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000812138: 8C7E0A7E
	v_cndmask_b32_e64 v51, v41, v7, s1                         // 00000081213C: D5010033 00060F29
	v_cndmask_b32_e64 v1, v8, v9, s1                           // 000000812144: D5010001 00061308
	v_cndmask_b32_e64 v0, v7, v8, s1                           // 00000081214C: D5010000 00061107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 000000812154: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s1                         // 000000812160: D5010006 00061D0D
	v_cndmask_b32_e64 v5, v12, v13, s1                         // 000000812168: D5010005 00061B0C
	v_cndmask_b32_e64 v4, v11, v12, s1                         // 000000812170: D5010004 0006190B
	v_cndmask_b32_e64 v3, v10, v11, s1                         // 000000812178: D5010003 0006170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000812180: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s1                          // 000000812184: D5010002 00061509
	s_and_b32 s2, exec_lo, s2                                  // 00000081218C: 8B02027E
	v_add_nc_u32_e32 v38, 0x200, v38                           // 000000812190: 4A4C4CFF 00000200
	s_or_b32 s16, s2, s16                                      // 000000812198: 8C101002
	ds_load_b32 v14, v8                                        // 00000081219C: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 0000008121A4: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008121A8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008121AC: 361010FF 000003FC
	ds_load_b32 v52, v8                                        // 0000008121B4: D8D80000 34000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 0000008121BC: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008121C0: 361010FF 000003FC
	ds_load_b32 v53, v8                                        // 0000008121C8: D8D80000 35000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 0000008121D0: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008121D4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008121D8: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 0000008121E0: D8D80000 36000008
	v_and_b32_e32 v8, 0xff, v20                                // 0000008121E8: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008121F0: 30101082
	ds_load_b32 v55, v8                                        // 0000008121F4: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 0000008121FC: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000812200: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000812204: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 00000081220C: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 000000812214: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000812218: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 000000812220: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 000000812228: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081222C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000812230: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 000000812238: D8D80000 3A000008
	v_and_b32_e32 v8, 0xff, v21                                // 000000812240: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000812248: 30101082
	ds_load_b32 v59, v8                                        // 00000081224C: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 000000812254: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000812258: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081225C: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 000000812264: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 00000081226C: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000812270: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 000000812278: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 000000812280: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000812284: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000812288: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 000000812290: D8D80000 3E000008
	v_and_b32_e32 v8, 0xff, v22                                // 000000812298: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008122A0: 30101082
	ds_load_b32 v63, v8                                        // 0000008122A4: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 0000008122AC: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008122B0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008122B4: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 0000008122BC: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 0000008122C4: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008122C8: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 0000008122D0: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 0000008122D8: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008122DC: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008122E0: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 0000008122E8: D8D80000 42000008
	.long 0xd73c0008                                           // 0000008122F0: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008122F4: 02023481
	v_add_nc_u32_e32 v26, 0x400, v26                           // 0000008122F8: 4A3434FF 00000400
	.long 0xd7006a0c                                           // 000000812300: D7006A0C
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 000000812304: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000812308: BF870001
	v_add_co_ci_u32_e64 v13, null, s7, v9, vcc_lo              // 00000081230C: D5207C0D 01AA1207
	s_clause 0x3                                               // 000000812314: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000812318: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000812320: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 000000812328: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 000000812330: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000812338: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000081233C: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 000000812344: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000812348: BF8700A1
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000081234C: CC1A4008 1C226909
	s_waitcnt lgkmcnt(13)                                      // 000000812354: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000812358: CC1A4008 1C226B0A
	s_waitcnt lgkmcnt(12)                                      // 000000812360: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000812364: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000812368: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000812370: BF8908B7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000812374: CC1A4008 1C226F13
	s_waitcnt lgkmcnt(10)                                      // 00000081237C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000812380: BF8700A1
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000812384: CC1A4008 1C227114
	s_waitcnt lgkmcnt(9)                                       // 00000081238C: BF89FC97
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 000000812390: CC1A4008 1C227315
	s_waitcnt lgkmcnt(8)                                       // 000000812398: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081239C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000008123A0: CC1A4008 1C227516
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008123A8: BF890477
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000008123AC: CC1A4008 1C227729
	s_waitcnt lgkmcnt(6)                                       // 0000008123B4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008123B8: BF8700A1
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008123BC: CC1A4008 1C22792A
	s_waitcnt lgkmcnt(5)                                       // 0000008123C4: BF89FC57
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008123C8: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(4)                                       // 0000008123D0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008123D4: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008123D8: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008123E0: BF890037
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008123E4: CC1A4008 1C227F2D
	.long 0xd7006a2d                                           // 0000008123EC: D7006A2D
	v_cndmask_b32_e32 v0, v12, v4, vcc_lo                      // 0000008123F0: 0200090C
	s_waitcnt lgkmcnt(2)                                       // 0000008123F4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008123F8: BF8701C2
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008123FC: CC1A4008 1C22812E
	v_add_co_ci_u32_e64 v46, null, s5, v13, vcc_lo             // 000000812404: D5207C2E 01AA1A05
	.long 0xd7006a31                                           // 00000081240C: D7006A31
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 000000812410: 02001D0C
	s_waitcnt lgkmcnt(1)                                       // 000000812414: BF89FC17
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000812418: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v50, null, s15, v13, vcc_lo            // 000000812420: D5207C32 01AA1A0F
	.long 0xd7006a0c                                           // 000000812428: D7006A0C
	v_cndmask_b32_e32 v0, v12, v17, vcc_lo                     // 00000081242C: 0200230C
	s_waitcnt lgkmcnt(0)                                       // 000000812430: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000812434: BF870123
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000812438: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v13, null, s18, v13, vcc_lo            // 000000812440: D5207C0D 01AA1A12
	v_fmac_f32_e32 v37, v51, v8                                // 000000812448: 564A1133
	s_clause 0x3                                               // 00000081244C: BF850003
	global_load_b128 v[8:11], v[45:46], off                    // 000000812450: DC5E0000 087C002D
	global_load_b128 v[19:22], v[45:46], off offset:16         // 000000812458: DC5E0010 137C002D
	global_load_b128 v[41:44], v[45:46], off offset:32         // 000000812460: DC5E0020 297C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 000000812468: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 000000812470: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000812474: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081247C: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000812480: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000812488: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000812490: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000812494: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 00000081249C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 0000008124A0: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008124A8: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 0000008124AC: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 0000008124B4: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008124BC: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000008124C0: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 0000008124C8: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000008124CC: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008124D4: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008124D8: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008124E0: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008124E8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008124EC: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000008124F4: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008124F8: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000812500: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000812504: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000081250C: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000812514: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000812518: CC1A4008 1C228530
	v_fmac_f32_e32 v36, v51, v8                                // 000000812520: 56481133
	s_clause 0x3                                               // 000000812524: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 000000812528: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 000000812530: DC5E0010 137C0031
	global_load_b128 v[41:44], v[49:50], off offset:32         // 000000812538: DC5E0020 297C0031
	global_load_b128 v[45:48], v[49:50], off offset:48         // 000000812540: DC5E0030 2D7C0031
	s_waitcnt vmcnt(3)                                         // 000000812548: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000081254C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000812554: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000812558: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000812560: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000812568: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000081256C: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 000000812574: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000812578: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000812580: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000812584: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000081258C: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000812594: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 000000812598: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 0000008125A0: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000008125A4: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008125AC: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008125B0: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008125B8: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008125C0: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008125C4: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000008125CC: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008125D0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008125D8: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008125DC: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008125E4: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008125EC: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008125F0: CC1A4008 1C228530
	v_fmac_f32_e32 v35, v51, v8                                // 0000008125F8: 56461133
	s_clause 0x3                                               // 0000008125FC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000812600: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000812608: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 000000812610: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 000000812618: DC5E0030 2D7C000C
	.long 0xd7006a0c                                           // 000000812620: D7006A0C
	v_cndmask_b32_e32 v0, v49, v14, vcc_lo                     // 000000812624: 02001D31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000812628: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s15, v50, vcc_lo            // 00000081262C: D5207C0D 01AA640F
	.long 0xd7006a1c                                           // 000000812634: D7006A1C
	v_cndmask_b32_e32 v0, v28, v192, vcc_lo                    // 000000812638: 0201811C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 00000081263C: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 000000812644: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000812648: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000812650: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000812654: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000081265C: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000812664: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000812668: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 000000812670: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000812674: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081267C: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000812680: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 000000812688: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000812690: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 000000812694: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 00000081269C: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000008126A0: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008126A8: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008126AC: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008126B4: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008126BC: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008126C0: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000008126C8: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008126CC: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008126D4: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008126D8: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008126E0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008126E8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008126EC: CC1A4008 1C228530
	v_fmac_f32_e32 v34, v51, v8                                // 0000008126F4: 56441133
	s_clause 0x3                                               // 0000008126F8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008126FC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000812704: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 00000081270C: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 000000812714: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3)                                         // 00000081271C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000812720: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000812728: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000081272C: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000812734: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081273C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000812740: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 000000812748: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 00000081274C: CC1A4008 1C226F13
	v_mov_b32_e32 v19, v15                                     // 000000812754: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000812758: BF870122
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 00000081275C: CC1A4008 1C227114
	v_mov_b32_e32 v20, v16                                     // 000000812764: 7E280310
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 000000812768: CC1A4008 1C227315
	v_mov_b32_e32 v21, v17                                     // 000000812770: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000812774: BF870132
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 000000812778: CC1A4008 1C227516
	v_mov_b32_e32 v22, v18                                     // 000000812780: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 000000812784: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 000000812788: CC1A4008 1C227729
	v_mov_b32_e32 v41, v40                                     // 000000812790: 7E520328
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000812794: BF870092
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000812798: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008127A0: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008127A8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008127AC: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000008127B4: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008127B8: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008127C0: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008127C4: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008127CC: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008127D4: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008127D8: CC1A4008 1C228530
	v_fmac_f32_e32 v33, v51, v8                                // 0000008127E0: 56421133
	v_mov_b32_e32 v14, v7                                      // 0000008127E4: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 0000008127E8: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 0000008127F0: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 0000008127F8: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 000000812800: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000812804: 917E107E
	s_cbranch_execz 28                                         // 000000812808: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xc7c>
	s_waitcnt vmcnt(0)                                         // 00000081280C: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v39, 32, v39  // 000000812810: CA200114 10264EA0
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 000000812818: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 000000812820: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 000000812824: BF870003
	.long 0xd4430002                                           // 000000812828: D4430002
	v_cndmask_b32_e32 v1, s20, v39, vcc_lo                     // 00000081282C: 02024E14
	s_mov_b32 s10, exec_lo                                     // 000000812830: BE8A007E
	.long 0xd4c4007e                                           // 000000812834: D4C4007E
	v_cndmask_b32_e32 v1, s20, v39, vcc_lo                     // 000000812838: 02024E14
	s_cbranch_execz 65086                                      // 00000081283C: BFA5FE3E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x538>
	.long 0xd7006a00                                           // 000000812840: D7006A00
	v_cndmask_b32_e32 v1, v25, v38, vcc_lo                     // 000000812844: 02024D19
	s_delay_alu instid0(VALU_DEP_1)                            // 000000812848: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v32, vcc_lo               // 00000081284C: D5207C01 01AA4080
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 000000812854: 7C9A3E81
	v_mov_b32_e32 v40, v41                                     // 000000812858: 7E500329
	global_load_b128 v[15:18], v[0:1], off                     // 00000081285C: DC5E0000 0F7C0000
	s_cbranch_vccnz 65076                                      // 000000812864: BFA4FE34 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x538>
	global_load_d16_b16 v0, v[28:29], off                      // 000000812868: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 000000812870: BF8903F7
	v_cvt_f32_f16_e32 v40, v0                                  // 000000812874: 7E501700
	s_branch 65071                                             // 000000812878: BFA0FE2F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x538>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000081287C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000812880: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000812884: 8C7E037E
	.long 0xd71f0000                                           // 000000812888: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000081288C: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000812890: 3A020090
	v_xor_b32_e32 v6, 8, v0                                    // 000000812894: 3A0C0088
	v_xor_b32_e32 v11, 4, v0                                   // 000000812898: 3A160084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000081289C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000008128A0: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000008128A4: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000008128A8: 7C980CA0
	v_cndmask_b32_e32 v6, v0, v6, vcc_lo                       // 0000008128AC: 020C0D00
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 0000008128B0: 7C9816A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008128B4: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000008128B8: 300C0C82
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008128BC: 30020282
	ds_bpermute_b32 v2, v1, v37                                // 0000008128C0: DACC0000 02002501
	s_waitcnt lgkmcnt(0)                                       // 0000008128C8: BF89FC07
	v_add_f32_e32 v2, v37, v2                                  // 0000008128CC: 06040525
	ds_bpermute_b32 v3, v1, v36                                // 0000008128D0: DACC0000 03002401
	ds_bpermute_b32 v4, v1, v35                                // 0000008128D8: DACC0000 04002301
	ds_bpermute_b32 v5, v1, v34                                // 0000008128E0: DACC0000 05002201
	ds_bpermute_b32 v1, v1, v33                                // 0000008128E8: DACC0000 01002101
	ds_bpermute_b32 v7, v6, v2                                 // 0000008128F0: DACC0000 07000206
	s_waitcnt lgkmcnt(3)                                       // 0000008128F8: BF89FC37
	v_dual_add_f32 v3, v36, v3 :: v_dual_add_f32 v4, v35, v4   // 0000008128FC: C9080724 03040923
	s_waitcnt lgkmcnt(2)                                       // 000000812904: BF89FC27
	v_add_f32_e32 v5, v34, v5                                  // 000000812908: 060A0B22
	s_waitcnt lgkmcnt(0)                                       // 00000081290C: BF89FC07
	v_dual_add_f32 v1, v33, v1 :: v_dual_add_f32 v2, v2, v7    // 000000812910: C9080321 01020F02
	ds_bpermute_b32 v8, v6, v3                                 // 000000812918: DACC0000 08000306
	ds_bpermute_b32 v9, v6, v4                                 // 000000812920: DACC0000 09000406
	v_cndmask_b32_e32 v11, v0, v11, vcc_lo                     // 000000812928: 02161700
	ds_bpermute_b32 v10, v6, v5                                // 00000081292C: DACC0000 0A000506
	ds_bpermute_b32 v6, v6, v1                                 // 000000812934: DACC0000 06000106
	v_lshlrev_b32_e32 v11, 2, v11                              // 00000081293C: 30161682
	s_waitcnt lgkmcnt(2)                                       // 000000812940: BF89FC27
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v4, v4, v9     // 000000812944: C9081103 03041304
	ds_bpermute_b32 v7, v11, v3                                // 00000081294C: DACC0000 0700030B
	ds_bpermute_b32 v8, v11, v4                                // 000000812954: DACC0000 0800040B
	s_waitcnt lgkmcnt(3)                                       // 00000081295C: BF89FC37
	v_add_f32_e32 v5, v5, v10                                  // 000000812960: 060A1505
	s_waitcnt lgkmcnt(0)                                       // 000000812964: BF89FC07
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 000000812968: C9080F03 03041104
	v_add_f32_e32 v1, v1, v6                                   // 000000812970: 06020D01
	ds_bpermute_b32 v6, v11, v2                                // 000000812974: DACC0000 0600020B
	ds_bpermute_b32 v9, v11, v5                                // 00000081297C: DACC0000 0900050B
	ds_bpermute_b32 v10, v11, v1                               // 000000812984: DACC0000 0A00010B
	v_xor_b32_e32 v11, 2, v0                                   // 00000081298C: 3A160082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000812990: BF870151
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 000000812994: 7C9816A0
	s_waitcnt lgkmcnt(2)                                       // 000000812998: BF89FC27
	v_dual_add_f32 v2, v2, v6 :: v_dual_cndmask_b32 v11, v0, v11// 00000081299C: C9120D02 020A1700
	s_waitcnt lgkmcnt(1)                                       // 0000008129A4: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 0000008129A8: 060A1305
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000008129AC: 30161682
	ds_bpermute_b32 v8, v11, v4                                // 0000008129B0: DACC0000 0800040B
	ds_bpermute_b32 v6, v11, v2                                // 0000008129B8: DACC0000 0600020B
	ds_bpermute_b32 v7, v11, v3                                // 0000008129C0: DACC0000 0700030B
	ds_bpermute_b32 v9, v11, v5                                // 0000008129C8: DACC0000 0900050B
	s_waitcnt lgkmcnt(3)                                       // 0000008129D0: BF89FC37
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v1, v1, v10    // 0000008129D4: C9081104 04001501
	s_waitcnt lgkmcnt(1)                                       // 0000008129DC: BF89FC17
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v3, v7     // 0000008129E0: C9080D02 02020F03
	s_waitcnt lgkmcnt(0)                                       // 0000008129E8: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 0000008129EC: 060A1305
	ds_bpermute_b32 v10, v11, v1                               // 0000008129F0: DACC0000 0A00010B
	v_xor_b32_e32 v11, 1, v0                                   // 0000008129F8: 3A160081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008129FC: BF870131
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 000000812A00: 7C9816A0
	v_cndmask_b32_e32 v0, v0, v11, vcc_lo                      // 000000812A04: 02001700
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 000000812A08: 7C943C80
	v_lshlrev_b32_e32 v11, 2, v0                               // 000000812A0C: 30160082
	s_and_b32 s0, vcc_lo, s0                                   // 000000812A10: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 000000812A14: BF89FC07
	v_add_f32_e32 v0, v1, v10                                  // 000000812A18: 06001501
	ds_bpermute_b32 v6, v11, v2                                // 000000812A1C: DACC0000 0600020B
	ds_bpermute_b32 v7, v11, v3                                // 000000812A24: DACC0000 0700030B
	ds_bpermute_b32 v8, v11, v4                                // 000000812A2C: DACC0000 0800040B
	ds_bpermute_b32 v9, v11, v5                                // 000000812A34: DACC0000 0900050B
	ds_bpermute_b32 v1, v11, v0                                // 000000812A3C: DACC0000 0100000B
	s_and_saveexec_b32 s1, s0                                  // 000000812A44: BE812000
	s_cbranch_execz 252                                        // 000000812A48: BFA500FC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x123c>
	s_waitcnt lgkmcnt(3)                                       // 000000812A4C: BF89FC37
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v3, v7     // 000000812A50: C9080D02 02020F03
	s_waitcnt lgkmcnt(1)                                       // 000000812A58: BF89FC17
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v5, v5, v9     // 000000812A5C: C9081104 04041305
	.long 0x7f183880                                           // 000000812A64: 7F183880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000812A68: BF870223
	v_bfe_u32 v6, v2, 16, 1                                    // 000000812A6C: D6100006 02052102
	v_bfe_u32 v7, v3, 16, 1                                    // 000000812A74: D6100007 02052103
	v_bfe_u32 v8, v4, 16, 1                                    // 000000812A7C: D6100008 02052104
	v_bfe_u32 v9, v5, 16, 1                                    // 000000812A84: D6100009 02052105
	.long 0x7f22398c                                           // 000000812A8C: 7F22398C
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000812A90: D6550002 03FE0D02 00007FFF
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000812A9C: D6550003 03FE0F03 00007FFF
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000812AA8: D6550004 03FE1104 00007FFF
	v_add3_u32 v5, v5, v9, 0x7fff                              // 000000812AB4: D6550005 03FE1305 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 000000812AC0: BF89FC07
	v_dual_add_f32 v0, v0, v1 :: v_dual_and_b32 v1, 0xffff0000, v2// 000000812AC4: C9240300 000004FF FFFF0000
	v_and_b32_e32 v2, 0xffff0000, v3                           // 000000812AD0: 360406FF FFFF0000
	v_and_b32_e32 v3, 0xffff0000, v4                           // 000000812AD8: 360608FF FFFF0000
	v_and_b32_e32 v4, 0xffff0000, v5                           // 000000812AE0: 36080AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000812AE8: BF870134
	v_bfe_u32 v5, v0, 16, 1                                    // 000000812AEC: D6100005 02052100
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000812AF4: 100202FF BFB8AA3B
	s_lshl_b64 s[4:5], s[12:13], 1                             // 000000812AFC: 8484810C
	v_add3_u32 v0, v0, v5, 0x7fff                              // 000000812B00: D6550000 03FE0B00 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000812B0C: BF870092
	v_exp_f32_e32 v5, v1                                       // 000000812B10: 7E0A4B01
	v_and_b32_e32 v6, 0xffff0000, v0                           // 000000812B14: 360C00FF FFFF0000
	.long 0xd73c0000                                           // 000000812B1C: D73C0000
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 000000812B20: 02022E81
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000812B24: BF8700A5
	v_dual_add_f32 v5, 1.0, v5 :: v_dual_mul_f32 v2, 0xbfb8aa3b, v2// 000000812B28: C9060AF2 050204FF BFB8AA3B
	s_waitcnt vmcnt(0)                                         // 000000812B34: BF8903F7
	v_div_scale_f32 v19, vcc_lo, 1.0, v5, 1.0                  // 000000812B38: D6FC6A13 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000812B40: BF870292
	v_exp_f32_e32 v2, v2                                       // 000000812B44: 7E044B02
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 000000812B48: C90604F2 020206FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000812B54: BF870111
	v_div_scale_f32 v20, s0, 1.0, v2, 1.0                      // 000000812B58: D6FC0014 03CA04F2
	v_exp_f32_e32 v3, v3                                       // 000000812B60: 7E064B03
	v_div_scale_f32 v9, null, v2, v2, 1.0                      // 000000812B64: D6FC7C09 03CA0502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000812B6C: BF870311
	v_rcp_f32_e32 v14, v9                                      // 000000812B70: 7E1C5509
	v_dual_add_f32 v7, 1.0, v3 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 000000812B74: C90606F2 070408FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000812B80: BF870111
	v_div_scale_f32 v10, null, v7, v7, 1.0                     // 000000812B84: D6FC7C0A 03CA0F07
	v_exp_f32_e32 v4, v4                                       // 000000812B8C: 7E084B04
	v_div_scale_f32 v21, s1, 1.0, v7, 1.0                      // 000000812B90: D6FC0115 03CA0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000812B98: BF870292
	v_rcp_f32_e32 v15, v10                                     // 000000812B9C: 7E1E550A
	v_fma_f32 v22, -v10, v15, 1.0                              // 000000812BA0: D6130016 23CA1F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000812BA8: BF870091
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_fmac_f32 v15, v22, v15// 000000812BAC: C8C00CFF 060E1F16 BFB8AA3B
	v_exp_f32_e32 v3, v6                                       // 000000812BB8: 7E064B06
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 000000812BBC: D6FC7C06 03CA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000812BC4: BF870311
	v_rcp_f32_e32 v13, v6                                      // 000000812BC8: 7E1A5506
	v_add_f32_e32 v18, 1.0, v3                                 // 000000812BCC: 062406F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000812BD0: BF870095
	v_fma_f32 v3, -v6, v13, 1.0                                // 000000812BD4: D6130003 23CA1B06
	v_dual_fmac_f32 v13, v3, v13 :: v_dual_add_f32 v8, 1.0, v4 // 000000812BDC: C8081B03 0D0808F2
	v_fma_f32 v4, -v9, v14, 1.0                                // 000000812BE4: D6130004 23CA1D09
	.long 0xd7000303                                           // 000000812BEC: D7000303
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000812BF0: 02020008
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000812BF4: BF870093
	v_div_scale_f32 v11, null, v8, v8, 1.0                     // 000000812BF8: D6FC7C0B 03CA1108
	v_rcp_f32_e32 v16, v11                                     // 000000812C00: 7E20550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000812C04: BF870095
	v_fma_f32 v23, -v11, v16, 1.0                              // 000000812C08: D6130017 23CA210B
	v_fmac_f32_e32 v16, v23, v16                               // 000000812C10: 56202117
	v_mul_f32_e32 v23, v19, v13                                // 000000812C14: 102E1B13
	v_div_scale_f32 v24, s2, 1.0, v8, 1.0                      // 000000812C18: D6FC0218 03CA10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000812C20: BF8701B2
	v_fma_f32 v29, -v6, v23, v19                               // 000000812C24: D613001D 244E2F06
	v_fmac_f32_e32 v14, v4, v14                                // 000000812C2C: 561C1D04
	v_add_co_ci_u32_e64 v4, null, s9, v1, s3                   // 000000812C30: D5207C04 000E0209
	v_fmac_f32_e32 v23, v29, v13                               // 000000812C38: 562E1B1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000812C3C: BF8701A3
	v_mul_f32_e32 v25, v20, v14                                // 000000812C40: 10321D14
	v_div_scale_f32 v22, null, v18, v18, 1.0                   // 000000812C44: D6FC7C16 03CA2512
	v_fma_f32 v1, -v6, v23, v19                                // 000000812C4C: D6130001 244E2F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000812C54: BF870193
	v_fma_f32 v30, -v9, v25, v20                               // 000000812C58: D613001E 24523309
	v_rcp_f32_e32 v28, v22                                     // 000000812C60: 7E385516
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000812C64: BF870112
	v_div_fmas_f32 v1, v1, v13, v23                            // 000000812C68: D6370001 045E1B01
	v_dual_fmac_f32 v25, v30, v14 :: v_dual_mul_f32 v26, v21, v15// 000000812C70: C8061D1E 191A1F15
	v_mul_f32_e32 v27, v24, v16                                // 000000812C78: 10362118
	s_mov_b32 vcc_lo, s0                                       // 000000812C7C: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000812C80: BF870193
	v_div_fixup_f32 v1, v1, v5, 1.0                            // 000000812C84: D6270001 03CA0B01
	v_fma_f32 v6, -v9, v25, v20                                // 000000812C8C: D6130006 24523309
	v_fma_f32 v31, -v10, v26, v21                              // 000000812C94: D613001F 2456350A
	v_fma_f32 v32, -v11, v27, v24                              // 000000812C9C: D6130020 2462370B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000812CA4: BF870235
	v_fma_f32 v0, -v22, v28, 1.0                               // 000000812CA8: D6130000 23CA3916
	.long 0x7e223981                                           // 000000812CB0: 7E223981
	v_div_fmas_f32 v6, v6, v14, v25                            // 000000812CB4: D6370006 04661D06
	v_dual_fmac_f32 v26, v31, v15 :: v_dual_fmac_f32 v27, v32, v16// 000000812CBC: C8001F1F 1A1A2120
	s_mov_b32 vcc_lo, s1                                       // 000000812CC4: BEEA0001
	v_fmac_f32_e32 v28, v0, v28                                // 000000812CC8: 56383900
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000812CCC: BF870193
	v_div_fixup_f32 v2, v6, v2, 1.0                            // 000000812CD0: D6270002 03CA0506
	v_fma_f32 v9, -v10, v26, v21                               // 000000812CD8: D6130009 2456350A
	v_fma_f32 v10, -v11, v27, v24                              // 000000812CE0: D613000A 2462370B
	v_div_scale_f32 v0, s3, 1.0, v18, 1.0                      // 000000812CE8: D6FC0300 03CA24F2
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000812CF0: 8480820C
	.long 0x7e183982                                           // 000000812CF4: 7E183982
	v_div_fmas_f32 v9, v9, v15, v26                            // 000000812CF8: D6370009 046A1F09
	s_mov_b32 vcc_lo, s2                                       // 000000812D00: BEEA0002
	v_div_fmas_f32 v6, v10, v16, v27                           // 000000812D04: D6370006 046E210A
	s_mov_b32 vcc_lo, s3                                       // 000000812D0C: BEEA0003
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000812D10: BF8701A2
	v_div_fixup_f32 v9, v9, v7, 1.0                            // 000000812D14: D6270009 03CA0F09
	.long 0x7f0e398c                                           // 000000812D1C: 7F0E398C
	v_div_fixup_f32 v10, v6, v8, 1.0                           // 000000812D20: D627000A 03CA1106
	v_and_b32_e32 v6, 1, v12                                   // 000000812D28: 360C1881
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000812D2C: BF870224
	.long 0x7e0e3989                                           // 000000812D30: 7E0E3989
	v_mul_f32_e32 v11, v0, v28                                 // 000000812D34: 10163900
	.long 0x7e18398a                                           // 000000812D38: 7E18398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000812D3C: BF870114
	v_add3_u32 v14, v2, v6, 0x7fff                             // 000000812D40: D655000E 03FE0D02 00007FFF
	v_and_b32_e32 v2, 1, v12                                   // 000000812D4C: 36041881
	v_and_b32_e32 v12, 1, v7                                   // 000000812D50: 36180E81
	v_fma_f32 v5, -v22, v11, v0                                // 000000812D54: D6130005 24021716
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000812D5C: BF870193
	v_add3_u32 v16, v10, v2, 0x7fff                            // 000000812D60: D6550010 03FE050A 00007FFF
	v_add3_u32 v12, v9, v12, 0x7fff                            // 000000812D6C: D655000C 03FE1909 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000812D78: BF870123
	v_fmac_f32_e32 v11, v5, v28                                // 000000812D7C: 56163905
	v_and_b32_e32 v5, 1, v17                                   // 000000812D80: 360A2281
	v_fma_f32 v0, -v22, v11, v0                                // 000000812D84: D6130000 24021716
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000812D8C: BF870112
	v_add3_u32 v13, v1, v5, 0x7fff                             // 000000812D90: D655000D 03FE0B01 00007FFF
	v_div_fmas_f32 v0, v0, v28, v11                            // 000000812D9C: D6370000 042E3900
	.long 0xd7006a05                                           // 000000812DA4: D7006A05
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 000000812DA8: 02000903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000812DAC: BF870191
	v_add_co_ci_u32_e64 v6, null, s5, v4, vcc_lo               // 000000812DB0: D5207C06 01AA0805
	v_div_fixup_f32 v11, v0, v18, 1.0                          // 000000812DB8: D627000B 03CA2500
	v_mad_u64_u32 v[0:1], null, s12, 6, v[3:4]                 // 000000812DC0: D6FE7C00 040D0C0C
	.long 0xd7006a07                                           // 000000812DC8: D7006A07
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 000000812DCC: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000812DD0: BF870211
	v_add_co_ci_u32_e64 v8, null, s1, v4, vcc_lo               // 000000812DD4: D5207C08 01AA0801
	v_bfe_u32 v15, v11, 16, 1                                  // 000000812DDC: D610000F 0205210B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000812DE4: BF870223
	.long 0xd7006a09                                           // 000000812DE8: D7006A09
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 000000812DEC: 02000107
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 000000812DF0: D6FE7C01 04050C0D
	v_add_co_ci_u32_e64 v10, null, s1, v8, vcc_lo              // 000000812DF8: D5207C0A 01AA1001
	s_delay_alu instid0(VALU_DEP_4)                            // 000000812E00: BF870004
	v_add3_u32 v2, v11, v15, 0x7fff                            // 000000812E04: D6550002 03FE1F0B 00007FFF
	s_clause 0x4                                               // 000000812E10: BF850004
	global_store_d16_hi_b16 v[3:4], v13, off                   // 000000812E14: DC960000 007C0D03
	global_store_d16_hi_b16 v[5:6], v14, off                   // 000000812E1C: DC960000 007C0E05
	global_store_d16_hi_b16 v[7:8], v12, off                   // 000000812E24: DC960000 007C0C07
	global_store_d16_hi_b16 v[0:1], v16, off                   // 000000812E2C: DC960000 007C1000
	global_store_d16_hi_b16 v[9:10], v2, off                   // 000000812E34: DC960000 007C0209
	s_endpgm                                                   // 000000812E3C: BFB00000
		...

