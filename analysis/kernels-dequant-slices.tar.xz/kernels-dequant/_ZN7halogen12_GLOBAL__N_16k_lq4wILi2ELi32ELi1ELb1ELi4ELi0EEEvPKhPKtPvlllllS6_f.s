0000000000f88c00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000F88C00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000F88C08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000F88C0C: 32040082
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000F88C10: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F88C14: BF8701A9
	v_dual_mov_b32 v10, s1 :: v_dual_and_b32 v1, 15, v0        // 000000F88C18: CA240001 0A00008F
	.long 0x7f103880                                           // 000000F88C20: 7F103880
	v_and_b32_e32 v2, 60, v2                                   // 000000F88C24: 360404BC
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F88C28: BF870003
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 000000F88C2C: CA220080 12000282
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v16, 31, v0         // 000000F88C34: CA240080 0310009F
	v_mov_b32_e32 v17, 0                                       // 000000F88C3C: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 000000F88C40: BF89FC07
	s_clause 0x1                                               // 000000F88C44: BF850001
	global_load_b32 v4, v1, s[4:5]                             // 000000F88C48: DC520000 04040001
	global_load_b32 v7, v2, s[4:5]                             // 000000F88C50: DC520000 07040002
	v_lshrrev_b32_e32 v2, 5, v0                                // 000000F88C58: 32040085
	s_add_u32 s2, s4, s14                                      // 000000F88C5C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000F88C60: 82030F05
	v_mov_b32_e32 v1, 0                                        // 000000F88C64: 7E020280
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F88C68: BF870002
	v_or_b32_e32 v9, s0, v2                                    // 000000F88C6C: 38120400
	s_lshr_b32 s0, s11, 31                                     // 000000F88C70: 85009F0B
	v_mov_b32_e32 v2, 0                                        // 000000F88C74: 7E040280
	s_add_u32 s14, s10, s0                                     // 000000F88C78: 800E000A
	s_addc_u32 s15, s11, 0                                     // 000000F88C7C: 820F800B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 000000F88C80: 7CA8120C
	s_ashr_i32 s20, s11, 31                                    // 000000F88C84: 86149F0B
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 000000F88C88: 02161280
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 000000F88C8C: D501000E 01A80280
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000F88C94: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 000000F88C98: 850E9B14
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F88C9C: BF870001
	.long 0xd72c0014                                           // 000000F88CA0: D72C0014
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 000000F88CA4: 0200010E
	.long 0xd72c000e                                           // 000000F88CA8: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 000000F88CAC: 02021C12
	s_waitcnt vmcnt(1)                                         // 000000F88CB0: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 000000F88CB4: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 000000F88CBC: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 000000F88CC0: D6100013 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F88CC8: BF870112
	v_add3_u32 v4, v4, v12, 0x7fff                             // 000000F88CCC: D6550004 03FE1904 00007FFF
	v_add3_u32 v7, v7, v19, 0x7fff                             // 000000F88CD8: D6550007 03FE2707 00007FFF
	v_lshlrev_b32_e32 v19, 2, v0                               // 000000F88CE4: 30260082
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F88CE8: BF870003
	.long 0x7e103984                                           // 000000F88CEC: 7E103984
	v_mov_b32_e32 v4, 0                                        // 000000F88CF0: 7E080280
	.long 0xd72c000d                                           // 000000F88CF4: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 000000F88CF8: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 000000F88CFC: D6FE7C05 02021612
	.long 0xd72c000f                                           // 000000F88D04: D72C000F
	v_cndmask_b32_e32 v0, v11, v1, vcc_lo                      // 000000F88D08: 0200030B
	v_mad_u64_u32 v[11:12], null, v11, s0, s[2:3]              // 000000F88D0C: D6FE7C0B 0008010B
	s_add_u32 s2, s10, s14                                     // 000000F88D14: 80020E0A
	s_addc_u32 s3, s11, 0                                      // 000000F88D18: 8203800B
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 000000F88D1C: D6570007 04220EFF FFFF0000
	s_lshr_b64 s[2:3], s[2:3], 5                               // 000000F88D28: 85828502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F88D2C: BF870009
	.long 0xd4440000                                           // 000000F88D30: D4440000
	v_cndmask_b32_e32 v1, s2, v16, vcc_lo                      // 000000F88D34: 02022002
	v_add3_u32 v6, v6, v14, v13                                // 000000F88D38: D6550006 04361D06
	v_add3_u32 v0, v20, v12, v15                               // 000000F88D40: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 000000F88D48: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 000000F88D50: BF89FC07
	s_barrier                                                  // 000000F88D54: BFBD0000
	buffer_gl0_inv                                             // 000000F88D58: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000F88D60: BE832000
	s_cbranch_execz 26                                         // 000000F88D64: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x1d0>
	s_add_u32 s1, s4, s16                                      // 000000F88D68: 80011004
	s_addc_u32 s14, s5, s17                                    // 000000F88D6C: 820E1105
	v_lshlrev_b32_e32 v1, 1, v16                               // 000000F88D70: 30022081
	.long 0xd7000102                                           // 000000F88D74: D7000102
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000F88D78: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F88D7C: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s14, v6, s1                  // 000000F88D80: D5207C03 00060C0E
	v_lshlrev_b32_e32 v4, 4, v16                               // 000000F88D88: 30082084
	.long 0xd7000101                                           // 000000F88D8C: D7000101
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000F88D90: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F88D94: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s1                    // 000000F88D98: D5207C02 00060680
	.long 0xd7000103                                           // 000000F88DA0: D7000103
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 000000F88DA4: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F88DA8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s1                    // 000000F88DAC: D5207C04 00060080
	s_clause 0x1                                               // 000000F88DB4: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 000000F88DB8: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000F88DC0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000F88DC8: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 000000F88DCC: 7E241707
	s_or_b32 exec_lo, exec_lo, s3                              // 000000F88DD0: 8C7E037E
	v_mov_b32_e32 v19, 0                                       // 000000F88DD4: 7E260280
	s_and_saveexec_b32 s3, s0                                  // 000000F88DD8: BE832000
	s_cbranch_execz 281                                        // 000000F88DDC: BFA50119 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x644>
	v_dual_mov_b32 v22, v18 :: v_dual_lshlrev_b32 v7, 1, v16   // 000000F88DE0: CA220112 16062081
	.long 0xd7000005                                           // 000000F88DE8: D7000005
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 000000F88DEC: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F88DF0: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s0                  // 000000F88DF4: D5207C06 00020C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 000000F88DFC: CA220080 0D0C2085
	.long 0xd7000005                                           // 000000F88E04: D7000005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000F88E08: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F88E0C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 000000F88E10: D5207C06 00020C80
	v_lshl_or_b32 v20, v16, 4, 0x200                           // 000000F88E18: D6560014 03FD0910 00000200
	.long 0xd7000005                                           // 000000F88E24: D7000005
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000F88E28: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F88E2C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s0                   // 000000F88E30: D5207C06 00020C05
	v_mov_b32_e32 v21, v16                                     // 000000F88E38: 7E2A0310
	.long 0xd700000e                                           // 000000F88E3C: D700000E
	v_cndmask_b32_e32 v0, v5, v192, vcc_lo                     // 000000F88E40: 02018105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F88E44: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s0                   // 000000F88E48: D5207C0F 00020C80
	v_mov_b32_e32 v19, v13                                     // 000000F88E50: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 000000F88E54: 7E22030D
	s_mov_b32 s14, 0                                           // 000000F88E58: BE8E0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000F88E5C: 8484810A
	s_branch 222                                               // 000000F88E60: BFA000DE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x5dc>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000F88E64: 8C7E0A7E
	.long 0xd73c0017                                           // 000000F88E68: D73C0017
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000F88E6C: 02021881
	v_and_b32_e32 v55, 0xff, v1                                // 000000F88E70: 366E02FF 000000FF
	v_lshrrev_b32_e32 v56, 6, v1                               // 000000F88E78: 32700286
	v_lshrrev_b32_e32 v57, 14, v1                              // 000000F88E7C: 3272028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000F88E80: 32020296
	v_and_b32_e32 v58, 0xff, v2                                // 000000F88E84: 367404FF 000000FF
	.long 0xd700012f                                           // 000000F88E8C: D700012F
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 000000F88E90: 02022E06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F88E94: BF8701A1
	v_add_co_ci_u32_e64 v48, null, s7, v24, s1                 // 000000F88E98: D5207C30 00063007
	v_lshlrev_b32_e32 v55, 2, v55                              // 000000F88EA0: 306E6E82
	.long 0xd7000133                                           // 000000F88EA4: D7000133
	v_cndmask_b32_e32 v0, v47, v4, vcc_lo                      // 000000F88EA8: 0200092F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F88EAC: BF870001
	v_add_co_ci_u32_e64 v52, null, s5, v48, s1                 // 000000F88EB0: D5207C34 00066005
	v_and_b32_e32 v56, 0x3fc, v56                              // 000000F88EB8: 367070FF 000003FC
	ds_load_b32 v55, v55                                       // 000000F88EC0: D8D80000 37000037
	s_clause 0x7                                               // 000000F88EC8: BF850007
	global_load_b128 v[23:26], v[47:48], off                   // 000000F88ECC: DC5E0000 177C002F
	global_load_b128 v[27:30], v[51:52], off                   // 000000F88ED4: DC5E0000 1B7C0033
	global_load_b128 v[31:34], v[47:48], off offset:16         // 000000F88EDC: DC5E0010 1F7C002F
	global_load_b128 v[35:38], v[51:52], off offset:16         // 000000F88EE4: DC5E0010 237C0033
	global_load_b128 v[39:42], v[47:48], off offset:32         // 000000F88EEC: DC5E0020 277C002F
	global_load_b128 v[43:46], v[51:52], off offset:32         // 000000F88EF4: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[47:48], off offset:48         // 000000F88EFC: DC5E0030 2F7C002F
	global_load_b128 v[51:54], v[51:52], off offset:48         // 000000F88F04: DC5E0030 337C0033
	v_and_b32_e32 v57, 0x3fc, v57                              // 000000F88F0C: 367272FF 000003FC
	v_lshrrev_b32_e32 v59, 6, v2                               // 000000F88F14: 32760486
	ds_load_b32 v56, v56                                       // 000000F88F18: D8D80000 38000038
	v_lshrrev_b32_e32 v60, 14, v2                              // 000000F88F20: 3278048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 000000F88F24: 32040496
	ds_load_b32 v57, v57                                       // 000000F88F28: D8D80000 39000039
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F88F30: 360202FF 000003FC
	v_lshlrev_b32_e32 v58, 2, v58                              // 000000F88F38: 30747482
	v_and_b32_e32 v59, 0x3fc, v59                              // 000000F88F3C: 367676FF 000003FC
	v_and_b32_e32 v60, 0x3fc, v60                              // 000000F88F44: 367878FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000F88F4C: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 000000F88F54: D8D80000 01000001
	ds_load_b32 v58, v58                                       // 000000F88F5C: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 000000F88F64: D8D80000 3B00003B
	ds_load_b32 v60, v60                                       // 000000F88F6C: D8D80000 3C00003C
	ds_load_b32 v2, v2                                         // 000000F88F74: D8D80000 02000002
	s_and_b32 s1, exec_lo, s0                                  // 000000F88F7C: 8B01007E
	.long 0xd700000e                                           // 000000F88F80: D700000E
	v_cndmask_b32_e32 v0, v14, v192, vcc_lo                    // 000000F88F84: 0201810E
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000F88F88: 4A1818FF 00000400
	v_add_nc_u32_e32 v20, 0x200, v20                           // 000000F88F90: 4A2828FF 00000200
	v_add_co_ci_u32_e64 v15, null, 0, v15, s0                  // 000000F88F98: D5207C0F 00021E80
	s_or_b32 s14, s1, s14                                      // 000000F88FA0: 8C0E0E01
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 000000F88FA4: BF891C77
	v_dot2_f32_bf16 v23, v23, v55, 0                           // 000000F88FA8: CC1A4017 1A026F17
	s_waitcnt vmcnt(6)                                         // 000000F88FB0: BF891BF7
	v_dot2_f32_bf16 v27, v27, v55, 0                           // 000000F88FB4: CC1A401B 1A026F1B
	v_and_b32_e32 v55, 0xff, v3                                // 000000F88FBC: 366E06FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 000000F88FC4: BF89FC67
	v_dot2_f32_bf16 v23, v24, v56, v23                         // 000000F88FC8: CC1A4017 1C5E7118
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F88FD0: BF870003
	v_dot2_f32_bf16 v24, v28, v56, v27                         // 000000F88FD4: CC1A4018 1C6E711C
	v_lshrrev_b32_e32 v27, 6, v3                               // 000000F88FDC: 32360686
	v_lshrrev_b32_e32 v28, 14, v3                              // 000000F88FE0: 3238068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 000000F88FE4: 32060696
	s_waitcnt lgkmcnt(5)                                       // 000000F88FE8: BF89FC57
	v_dot2_f32_bf16 v23, v25, v57, v23                         // 000000F88FEC: CC1A4017 1C5E7319
	v_dot2_f32_bf16 v24, v29, v57, v24                         // 000000F88FF4: CC1A4018 1C62731D
	v_and_b32_e32 v25, 0xff, v4                                // 000000F88FFC: 363208FF 000000FF
	v_lshrrev_b32_e32 v29, 6, v4                               // 000000F89004: 323A0886
	v_lshrrev_b32_e32 v56, 14, v4                              // 000000F89008: 3270088E
	s_waitcnt lgkmcnt(4)                                       // 000000F8900C: BF89FC47
	v_dot2_f32_bf16 v23, v26, v1, v23                          // 000000F89010: CC1A4017 1C5E031A
	v_dot2_f32_bf16 v1, v30, v1, v24                           // 000000F89018: CC1A4001 1C62031E
	v_lshlrev_b32_e32 v24, 2, v55                              // 000000F89020: 30306E82
	v_and_b32_e32 v26, 0x3fc, v27                              // 000000F89024: 363436FF 000003FC
	v_and_b32_e32 v27, 0x3fc, v28                              // 000000F8902C: 363638FF 000003FC
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 000000F89034: BF891437
	v_dot2_f32_bf16 v23, v31, v58, v23                         // 000000F89038: CC1A4017 1C5E751F
	s_waitcnt vmcnt(4)                                         // 000000F89040: BF8913F7
	v_dot2_f32_bf16 v1, v35, v58, v1                           // 000000F89044: CC1A4001 1C067523
	ds_load_b32 v24, v24                                       // 000000F8904C: D8D80000 18000018
	ds_load_b32 v26, v26                                       // 000000F89054: D8D80000 1A00001A
	ds_load_b32 v27, v27                                       // 000000F8905C: D8D80000 1B00001B
	s_waitcnt lgkmcnt(5)                                       // 000000F89064: BF89FC57
	v_dot2_f32_bf16 v23, v32, v59, v23                         // 000000F89068: CC1A4017 1C5E7720
	v_dot2_f32_bf16 v1, v36, v59, v1                           // 000000F89070: CC1A4001 1C067724
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000F89078: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 000000F8907C: 360606FF 000003FC
	v_lshlrev_b32_e32 v25, 2, v25                              // 000000F89084: 30323282
	s_waitcnt lgkmcnt(4)                                       // 000000F89088: BF89FC47
	v_dot2_f32_bf16 v23, v33, v60, v23                         // 000000F8908C: CC1A4017 1C5E7921
	v_dot2_f32_bf16 v1, v37, v60, v1                           // 000000F89094: CC1A4001 1C067925
	v_and_b32_e32 v28, 0x3fc, v29                              // 000000F8909C: 36383AFF 000003FC
	v_and_b32_e32 v29, 0x3fc, v56                              // 000000F890A4: 363A70FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000F890AC: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000F890B4: BF89FC37
	v_dot2_f32_bf16 v23, v34, v2, v23                          // 000000F890B8: CC1A4017 1C5E0522
	v_dot2_f32_bf16 v1, v38, v2, v1                            // 000000F890C0: CC1A4001 1C060526
	ds_load_b32 v2, v3                                         // 000000F890C8: D8D80000 02000003
	ds_load_b32 v3, v25                                        // 000000F890D0: D8D80000 03000019
	ds_load_b32 v25, v28                                       // 000000F890D8: D8D80000 1900001C
	ds_load_b32 v28, v29                                       // 000000F890E0: D8D80000 1C00001D
	ds_load_b32 v29, v4                                        // 000000F890E8: D8D80000 1D000004
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 000000F890F0: BF890C77
	v_dot2_f32_bf16 v4, v39, v24, v23                          // 000000F890F4: CC1A4004 1C5E3127
	s_waitcnt vmcnt(2)                                         // 000000F890FC: BF890BF7
	v_dot2_f32_bf16 v1, v43, v24, v1                           // 000000F89100: CC1A4001 1C06312B
	s_waitcnt lgkmcnt(6)                                       // 000000F89108: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F8910C: BF870112
	v_dot2_f32_bf16 v4, v40, v26, v4                           // 000000F89110: CC1A4004 1C123528
	v_dot2_f32_bf16 v1, v44, v26, v1                           // 000000F89118: CC1A4001 1C06352C
	s_waitcnt lgkmcnt(5)                                       // 000000F89120: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F89124: BF870112
	v_dot2_f32_bf16 v4, v41, v27, v4                           // 000000F89128: CC1A4004 1C123729
	v_dot2_f32_bf16 v1, v45, v27, v1                           // 000000F89130: CC1A4001 1C06372D
	s_waitcnt lgkmcnt(4)                                       // 000000F89138: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F8913C: BF870112
	v_dot2_f32_bf16 v4, v42, v2, v4                            // 000000F89140: CC1A4004 1C12052A
	v_dot2_f32_bf16 v1, v46, v2, v1                            // 000000F89148: CC1A4001 1C06052E
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 000000F89150: BF890437
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F89154: BF870122
	v_dot2_f32_bf16 v2, v47, v3, v4                            // 000000F89158: CC1A4002 1C12072F
	s_waitcnt vmcnt(0)                                         // 000000F89160: BF8903F7
	v_dot2_f32_bf16 v1, v51, v3, v1                            // 000000F89164: CC1A4001 1C060733
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 000000F8916C: CA100108 04020107
	s_waitcnt lgkmcnt(2)                                       // 000000F89174: BF89FC27
	v_dot2_f32_bf16 v2, v48, v25, v2                           // 000000F89178: CC1A4002 1C0A3330
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F89180: BF870123
	v_dot2_f32_bf16 v1, v52, v25, v1                           // 000000F89184: CC1A4001 1C063334
	s_waitcnt lgkmcnt(1)                                       // 000000F8918C: BF89FC17
	v_dot2_f32_bf16 v2, v49, v28, v2                           // 000000F89190: CC1A4002 1C0A3931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F89198: BF870122
	v_dot2_f32_bf16 v1, v53, v28, v1                           // 000000F8919C: CC1A4001 1C063935
	s_waitcnt lgkmcnt(0)                                       // 000000F891A4: BF89FC07
	v_dot2_f32_bf16 v8, v50, v29, v2                           // 000000F891A8: CC1A4008 1C0A3B32
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F891B0: BF8701A2
	v_dot2_f32_bf16 v23, v54, v29, v1                          // 000000F891B4: CC1A4017 1C063B36
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 000000F891BC: CA100106 02000105
	v_fmac_f32_e32 v19, v18, v8                                // 000000F891C4: 56261112
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F891C8: BF870003
	v_fmac_f32_e32 v17, v18, v23                               // 000000F891CC: 56222F12
	v_mov_b32_e32 v18, v22                                     // 000000F891D0: 7E240316
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 000000F891D4: 917E0E7E
	s_cbranch_execz 25                                         // 000000F891D8: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x640>
	s_waitcnt vmcnt(0)                                         // 000000F891DC: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v21, 32, v21    // 000000F891E0: CA200102 06142AA0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 000000F891E8: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 000000F891F0: 7E0E0303
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F891F4: BF870003
	.long 0xd4430000                                           // 000000F891F8: D4430000
	v_cndmask_b32_e32 v1, s2, v21, vcc_lo                      // 000000F891FC: 02022A02
	s_mov_b32 s10, exec_lo                                     // 000000F89200: BE8A007E
	.long 0xd4c4007e                                           // 000000F89204: D4C4007E
	v_cndmask_b32_e32 v1, s2, v21, vcc_lo                      // 000000F89208: 02022A02
	s_cbranch_execz 65301                                      // 000000F8920C: BFA5FF15 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x264>
	.long 0xd7000105                                           // 000000F89210: D7000105
	v_cndmask_b32_e32 v1, v11, v20, vcc_lo                     // 000000F89214: 0202290B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F89218: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s1                    // 000000F8921C: D5207C06 00060080
	global_load_d16_b16 v22, v[14:15], off                     // 000000F89224: DC820000 167C000E
	global_load_b128 v[5:8], v[5:6], off                       // 000000F8922C: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 000000F89234: BF8907F7
	v_cvt_f32_f16_e32 v22, v22                                 // 000000F89238: 7E2C1716
	s_branch 65289                                             // 000000F8923C: BFA0FF09 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x264>
	s_or_b32 exec_lo, exec_lo, s14                             // 000000F89240: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F89244: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000F89248: 8C7E037E
	.long 0xd71f0000                                           // 000000F8924C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000F89250: 020100C1
	s_waitcnt vmcnt(0)                                         // 000000F89254: BF8903F7
	v_xor_b32_e32 v1, 16, v0                                   // 000000F89258: 3A020090
	v_xor_b32_e32 v3, 8, v0                                    // 000000F8925C: 3A060088
	v_xor_b32_e32 v5, 4, v0                                    // 000000F89260: 3A0A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F89264: BF870093
	.long 0xd44c0000                                           // 000000F89268: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000F8926C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000F89270: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F89278: BF870114
	.long 0xd44c0000                                           // 000000F8927C: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 000000F89280: 020206A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F89284: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000F89288: BF8700D2
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 000000F8928C: D5010003 00020700
	.long 0xd44c0000                                           // 000000F89294: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000F89298: 02020AA0
	ds_bpermute_b32 v2, v1, v19                                // 000000F8929C: DACC0000 02001301
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 000000F892A4: D5010005 00020B00
	s_waitcnt lgkmcnt(0)                                       // 000000F892AC: BF89FC07
	v_dual_add_f32 v2, v19, v2 :: v_dual_lshlrev_b32 v5, 2, v5 // 000000F892B0: C9220513 02040A82
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000F892B8: 30060682
	ds_bpermute_b32 v1, v1, v17                                // 000000F892BC: DACC0000 01001101
	ds_bpermute_b32 v4, v3, v2                                 // 000000F892C4: DACC0000 04000203
	s_waitcnt lgkmcnt(0)                                       // 000000F892CC: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v17, v1    // 000000F892D0: C9080902 02000311
	ds_bpermute_b32 v3, v3, v1                                 // 000000F892D8: DACC0000 03000103
	s_waitcnt lgkmcnt(0)                                       // 000000F892E0: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 000000F892E4: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 000000F892E8: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 000000F892F0: DACC0000 04000105
	v_xor_b32_e32 v5, 2, v0                                    // 000000F892F8: 3A0A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F892FC: BF870091
	.long 0xd44c0000                                           // 000000F89300: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000F89304: 02020AA0
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 000000F89308: D5010005 00020B00
	s_waitcnt lgkmcnt(1)                                       // 000000F89310: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F89314: BF870001
	v_dual_add_f32 v2, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v5  // 000000F89318: C9220702 02040A82
	s_waitcnt lgkmcnt(0)                                       // 000000F89320: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 000000F89324: 06020901
	ds_bpermute_b32 v3, v5, v2                                 // 000000F89328: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 000000F89330: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 000000F89338: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8933C: BF870091
	.long 0xd44c0000                                           // 000000F89340: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000F89344: 02020AA0
	v_cndmask_b32_e64 v0, v0, v5, s0                           // 000000F89348: D5010000 00020B00
	.long 0xd44a0000                                           // 000000F89350: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000F89354: 02022080
	s_waitcnt lgkmcnt(1)                                       // 000000F89358: BF89FC17
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F8935C: BF870002
	v_dual_add_f32 v0, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v0  // 000000F89360: C9220702 00040082
	s_and_b32 s0, s0, vcc_lo                                   // 000000F89368: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 000000F8936C: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 000000F89370: 06020901
	ds_bpermute_b32 v2, v5, v0                                 // 000000F89374: DACC0000 02000005
	ds_bpermute_b32 v3, v5, v1                                 // 000000F8937C: DACC0000 03000105
	s_and_saveexec_b32 s1, s0                                  // 000000F89384: BE812000
	s_cbranch_execz 74                                         // 000000F89388: BFA5004A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x8b4>
	s_waitcnt lgkmcnt(0)                                       // 000000F8938C: BF89FC07
	v_dual_add_f32 v0, v0, v2 :: v_dual_add_f32 v1, v1, v3     // 000000F89390: C9080500 00000701
	s_lshl_b64 s[2:3], s[12:13], 2                             // 000000F89398: 8482820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8939C: BF870091
	v_dual_mul_f32 v0, 0xbfb8aa3b, v0 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v1// 000000F893A0: C8C600FF 000002FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 000000F893AC: 7E004B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000F893B0: BF870291
	v_exp_f32_e32 v1, v1                                       // 000000F893B4: 7E024B01
	v_dual_add_f32 v2, 1.0, v0 :: v_dual_add_f32 v3, 1.0, v1   // 000000F893B8: C90800F2 020202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F893C0: BF870111
	v_div_scale_f32 v4, null, v2, v2, 1.0                      // 000000F893C4: D6FC7C04 03CA0502
	v_div_scale_f32 v5, null, v3, v3, 1.0                      // 000000F893CC: D6FC7C05 03CA0703
	v_div_scale_f32 v8, vcc_lo, 1.0, v2, 1.0                   // 000000F893D4: D6FC6A08 03CA04F2
	v_div_scale_f32 v11, s0, 1.0, v3, 1.0                      // 000000F893DC: D6FC000B 03CA06F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F893E4: BF870194
	v_rcp_f32_e32 v6, v4                                       // 000000F893E8: 7E0C5504
	v_rcp_f32_e32 v7, v5                                       // 000000F893EC: 7E0E5505
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000F893F0: BF870296
	v_fma_f32 v0, -v4, v6, 1.0                                 // 000000F893F4: D6130000 23CA0D04
	v_fma_f32 v1, -v5, v7, 1.0                                 // 000000F893FC: D6130001 23CA0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F89404: BF870091
	v_dual_fmac_f32 v6, v0, v6 :: v_dual_fmac_f32 v7, v1, v7   // 000000F89408: C8000D00 06060F01
	v_dual_mul_f32 v12, v8, v6 :: v_dual_mul_f32 v13, v11, v7  // 000000F89410: C8C60D08 0C0C0F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F89418: BF870111
	v_fma_f32 v0, -v4, v12, v8                                 // 000000F8941C: D6130000 24221904
	v_fma_f32 v1, -v5, v13, v11                                // 000000F89424: D6130001 242E1B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F8942C: BF870121
	v_dual_fmac_f32 v12, v0, v6 :: v_dual_fmac_f32 v13, v1, v7 // 000000F89430: C8000D00 0C0C0F01
	.long 0xd73c0000                                           // 000000F89438: D73C0000
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000F8943C: 02021282
	v_fma_f32 v4, -v4, v12, v8                                 // 000000F89440: D6130004 24221904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F89448: BF870113
	v_fma_f32 v5, -v5, v13, v11                                // 000000F8944C: D6130005 242E1B05
	v_div_fmas_f32 v4, v4, v6, v12                             // 000000F89454: D6370004 04320D04
	s_mov_b32 vcc_lo, s0                                       // 000000F8945C: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F89460: BF8700A2
	v_div_fmas_f32 v5, v5, v7, v13                             // 000000F89464: D6370005 04360F05
	.long 0xd7006a00                                           // 000000F8946C: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000F89470: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000F89474: D5207C01 01AA0209
	v_div_fixup_f32 v4, v4, v2, 1.0                            // 000000F8947C: D6270004 03CA0504
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F89484: BF870223
	.long 0xd7006a02                                           // 000000F89488: D7006A02
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 000000F8948C: 02000500
	v_div_fixup_f32 v5, v5, v3, 1.0                            // 000000F89490: D6270005 03CA0705
	v_add_co_ci_u32_e64 v3, null, s3, v1, vcc_lo               // 000000F89498: D5207C03 01AA0203
	s_clause 0x1                                               // 000000F894A0: BF850001
	global_store_b32 v[0:1], v4, off                           // 000000F894A4: DC6A0000 007C0400
	global_store_b32 v[2:3], v5, off                           // 000000F894AC: DC6A0000 007C0502
	s_endpgm                                                   // 000000F894B4: BFB00000
		...

