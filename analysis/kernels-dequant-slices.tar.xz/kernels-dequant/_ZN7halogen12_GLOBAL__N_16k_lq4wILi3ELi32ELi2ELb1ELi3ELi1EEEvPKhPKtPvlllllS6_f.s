000000000083c100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000083C100: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000083C108: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000083C10C: 32040082
	s_lshl_b64 s[20:21], s[2:3], 2                             // 00000083C110: 84948202
	v_and_b32_e32 v1, 15, v0                                   // 00000083C114: 3602008F
	v_lshrrev_b32_e32 v21, 6, v0                               // 00000083C118: 322A0086
	v_bfe_u32 v22, v0, 5, 1                                    // 00000083C11C: D6100016 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 00000083C124: 360404BC
	v_and_b32_e32 v23, 31, v0                                  // 00000083C128: 362E009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000083C12C: 30020282
	.long 0x7f0a3880                                           // 00000083C130: 7F0A3880
	s_waitcnt lgkmcnt(0)                                       // 00000083C134: BF89FC07
	s_clause 0x1                                               // 00000083C138: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000083C13C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000083C144: DC520000 04040002
	s_add_u32 s2, s4, s16                                      // 00000083C14C: 80021004
	s_addc_u32 s3, s5, s17                                     // 00000083C150: 82031105
	s_ashr_i32 s16, s11, 31                                    // 00000083C154: 86109F0B
	v_mov_b32_e32 v2, s21                                      // 00000083C158: 7E040215
	s_lshr_b32 s16, s16, 27                                    // 00000083C15C: 85109B10
	v_or_b32_e32 v1, s20, v21                                  // 00000083C160: 38022A14
	s_add_u32 s16, s10, s16                                    // 00000083C164: 8010100A
	s_addc_u32 s17, s11, 0                                     // 00000083C168: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083C16C: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 00000083C170: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000083C174: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 00000083C178: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000083C17C: BF870499
	s_lshr_b32 s22, s17, 31                                    // 00000083C180: 85169F11
	s_add_i32 s17, s17, s22                                    // 00000083C184: 81111611
	v_cndmask_b32_e32 v9, 0, v1, vcc_lo                        // 00000083C188: 02120280
	s_ashr_i32 s17, s17, 1                                     // 00000083C18C: 86118111
	v_cndmask_b32_e64 v10, 0, s21, vcc_lo                      // 00000083C190: D501000A 01A82A80
	.long 0xd72c0002                                           // 00000083C198: D72C0002
	v_cndmask_b32_e32 v1, s17, v22, vcc_lo                     // 00000083C19C: 02022C11
	s_cmpk_lt_i32 s16, 0x201                                   // 00000083C1A0: B3900201
	.long 0xd72c0007                                           // 00000083C1A4: D72C0007
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 00000083C1A8: 02021213
	v_mad_u64_u32 v[17:18], null, s18, v9, s[2:3]              // 00000083C1AC: D6FE7C11 000A1212
	s_cselect_b32 s2, -1, 0                                    // 00000083C1B4: 980280C1
	s_cmpk_gt_i32 s16, 0x200                                   // 00000083C1B8: B2900200
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000083C1BC: 30020082
	v_add_nc_u32_e32 v11, s17, v2                              // 00000083C1C0: 4A160411
	v_add_nc_u32_e32 v24, v2, v23                              // 00000083C1C4: 4A302F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000083C1C8: BF8704A2
	v_min_i32_e32 v25, s16, v11                                // 00000083C1CC: 22321610
	s_cselect_b32 s16, -1, 0                                   // 00000083C1D0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 00000083C1D4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000083C1D8: BF870151
	.long 0xd4410003                                           // 00000083C1DC: D4410003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000083C1E0: 02023318
	s_waitcnt vmcnt(1)                                         // 00000083C1E4: BF8907F7
	v_bfe_u32 v6, v3, 16, 1                                    // 00000083C1E8: D6100006 02052103
	s_waitcnt vmcnt(0)                                         // 00000083C1F0: BF8903F7
	v_bfe_u32 v8, v4, 16, 1                                    // 00000083C1F4: D6100008 02052104
	v_add3_u32 v3, v3, v6, 0x7fff                              // 00000083C1FC: D6550003 03FE0D03 00007FFF
	.long 0xd72c0006                                           // 00000083C208: D72C0006
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 00000083C20C: 02021412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000083C210: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 00000083C214: D6550004 03FE1104 00007FFF
	.long 0x7e0a3983                                           // 00000083C220: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083C224: BF870113
	v_add3_u32 v26, v7, v18, v6                                // 00000083C228: D655001A 041A2507
	v_and_or_b32 v2, 0xffff0000, v4, v5                        // 00000083C230: D6570002 041608FF FFFF0000
	ds_store_b32 v1, v2                                        // 00000083C23C: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 00000083C244: BF89FC07
	s_barrier                                                  // 00000083C248: BFBD0000
	buffer_gl0_inv                                             // 00000083C24C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 00000083C254: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 00000083C258: CA100080 02000080
	s_and_saveexec_b32 s17, s3                                 // 00000083C260: BE912003
	s_cbranch_execz 11                                         // 00000083C264: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v1, 1, v24                               // 00000083C268: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083C26C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 00000083C270: 3408029F
	.long 0xd7006a03                                           // 00000083C274: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 00000083C278: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 00000083C27C: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 00000083C284: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 00000083C28C: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 00000083C290: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 00000083C294: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 00000083C298: 4A0630A0
	s_mov_b32 s3, exec_lo                                      // 00000083C29C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083C2A0: BF870001
	.long 0xd4c1007e                                           // 00000083C2A4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 00000083C2A8: 02023303
	s_cbranch_execz 11                                         // 00000083C2AC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v2, 1, v3                                // 00000083C2B0: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083C2B4: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000083C2B8: 3406049F
	.long 0xd7006a02                                           // 00000083C2BC: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 00000083C2C0: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 00000083C2C4: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 00000083C2CC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000083C2D4: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 00000083C2D8: 7E041702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000083C2DC: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 00000083C2E0: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 00000083C2E8: 7E060280
	s_mov_b32 s3, exec_lo                                      // 00000083C2EC: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000083C2F0: BF870002
	.long 0xd4c1007e                                           // 00000083C2F4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 00000083C2F8: 02023305
	s_cbranch_execz 11                                         // 00000083C2FC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v5                                // 00000083C300: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083C304: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 00000083C308: 340C069F
	.long 0xd7006a05                                           // 00000083C30C: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 00000083C310: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 00000083C314: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 00000083C31C: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 00000083C324: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 00000083C328: 7E061703
	s_or_b32 exec_lo, exec_lo, s3                              // 00000083C32C: 8C7E037E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 00000083C330: 4A0A30FF 00000060
	s_mov_b32 s3, exec_lo                                      // 00000083C338: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083C33C: BF870001
	.long 0xd4c1007e                                           // 00000083C340: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 00000083C344: 02023305
	s_cbranch_execz 11                                         // 00000083C348: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v4, 1, v5                                // 00000083C34C: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083C350: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 00000083C354: 340A089F
	.long 0xd7006a04                                           // 00000083C358: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 00000083C35C: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 00000083C360: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 00000083C368: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 00000083C370: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 00000083C374: 7E081704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000083C378: 8C7E037E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 00000083C37C: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 00000083C388: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 00000083C38C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000083C390: BF870002
	.long 0xd4c1007e                                           // 00000083C394: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 00000083C398: 02023307
	s_cbranch_execz 11                                         // 00000083C39C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v5, 1, v7                                // 00000083C3A0: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083C3A4: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 00000083C3A8: 34100A9F
	.long 0xd7006a07                                           // 00000083C3AC: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 00000083C3B0: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 00000083C3B4: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 00000083C3BC: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 00000083C3C4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 00000083C3C8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s3                              // 00000083C3CC: 8C7E037E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 00000083C3D0: 4A0E30FF 000000A0
	s_mov_b32 s3, exec_lo                                      // 00000083C3D8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083C3DC: BF870001
	.long 0xd4c1007e                                           // 00000083C3E0: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 00000083C3E4: 02023307
	s_cbranch_execz 11                                         // 00000083C3E8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v6, 1, v7                                // 00000083C3EC: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083C3F0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000083C3F4: 340E0C9F
	.long 0xd7006a06                                           // 00000083C3F8: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 00000083C3FC: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 00000083C400: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 00000083C408: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000083C410: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 00000083C414: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s3                              // 00000083C418: 8C7E037E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xc0, v24   // 00000083C41C: CA200080 080A30FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 00000083C428: 7E0E0280
	s_mov_b32 s3, exec_lo                                      // 00000083C42C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000083C430: BF870002
	.long 0xd4c1007e                                           // 00000083C434: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 00000083C438: 0202330B
	s_cbranch_execz 11                                         // 00000083C43C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v7, 1, v11                               // 00000083C440: 300E1681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083C444: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v7                              // 00000083C448: 34180E9F
	.long 0xd7006a0b                                           // 00000083C44C: D7006A0B
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 00000083C450: 02020F11
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 00000083C454: D5207C0C 01AA191A
	global_load_d16_b16 v7, v[11:12], off                      // 00000083C45C: DC820000 077C000B
	s_waitcnt vmcnt(0)                                         // 00000083C464: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 00000083C468: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s3                              // 00000083C46C: 8C7E037E
	v_add_nc_u32_e32 v11, 0xe0, v24                            // 00000083C470: 4A1630FF 000000E0
	s_mov_b32 s3, exec_lo                                      // 00000083C478: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083C47C: BF870001
	.long 0xd4c1007e                                           // 00000083C480: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 00000083C484: 0202330B
	s_cbranch_execz 11                                         // 00000083C488: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v8, 1, v11                               // 00000083C48C: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083C490: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 00000083C494: 3418109F
	.long 0xd7006a0b                                           // 00000083C498: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 00000083C49C: 02021111
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 00000083C4A0: D5207C0C 01AA191A
	global_load_d16_b16 v8, v[11:12], off                      // 00000083C4A8: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 00000083C4B0: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 00000083C4B4: 7E101708
	s_or_b32 exec_lo, exec_lo, s3                              // 00000083C4B8: 8C7E037E
	s_branch 9                                                 // 00000083C4BC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v1, 0                                        // 00000083C4C0: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083C4C4: BF870001
	v_mov_b32_e32 v2, v1                                       // 00000083C4C8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 00000083C4CC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 00000083C4D0: 7E080301
	v_mov_b32_e32 v5, v1                                       // 00000083C4D4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 00000083C4D8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000083C4DC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 00000083C4E0: 7E100301
	s_add_u32 s4, s4, s14                                      // 00000083C4E4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 00000083C4E8: 82050F05
	s_lshr_b32 s3, s11, 31                                     // 00000083C4EC: 85039F0B
	v_mov_b32_e32 v27, 0                                       // 00000083C4F0: 7E360280
	s_add_u32 s14, s10, s3                                     // 00000083C4F4: 800E030A
	s_addc_u32 s15, s11, 0                                     // 00000083C4F8: 820F800B
	.long 0xd4410003                                           // 00000083C4FC: D4410003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000083C500: 02023318
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000083C504: 868E810E
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 00000083C508: D501001C 00410280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 00000083C510: D6FE7C12 00101D09
	.long 0xd72c000c                                           // 00000083C518: D72C000C
	v_cndmask_b32_e32 v0, v9, v15, vcc_lo                      // 00000083C51C: 02001F09
	.long 0xd72c000d                                           // 00000083C520: D72C000D
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 00000083C524: 02001D0A
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 00000083C528: CA100080 090A0080
	v_mov_b32_e32 v35, 0                                       // 00000083C530: 7E460280
	v_mov_b32_e32 v11, 0                                       // 00000083C534: 7E160280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000083C538: BF870004
	v_add3_u32 v29, v13, v19, v12                              // 00000083C53C: D655001D 0432270D
	v_mov_b32_e32 v12, 0                                       // 00000083C544: 7E180280
	s_and_saveexec_b32 s4, s3                                  // 00000083C548: BE842003
	s_cbranch_execz 22                                         // 00000083C54C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v9, 4, v24                               // 00000083C550: 30123084
	v_mov_b32_e32 v35, 0                                       // 00000083C554: 7E460280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083C558: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000083C55C: 3414129F
	.long 0xd7006a09                                           // 00000083C560: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 00000083C564: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 00000083C568: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 00000083C570: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 00000083C574: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 00000083C57C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v13, 1, v24                              // 00000083C580: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083C584: BF870091
	.long 0xd7006a0d                                           // 00000083C588: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 00000083C58C: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 00000083C590: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 00000083C598: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 00000083C5A0: BF8903F7
	v_cvt_f32_f16_e32 v35, v13                                 // 00000083C5A4: 7E46170D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000083C5A8: 8C7E047E
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0             // 00000083C5AC: CA100080 1F1E0080
	s_and_saveexec_b32 s14, s3                                 // 00000083C5B4: BE8E2003
	s_cbranch_execz 338                                        // 00000083C5B8: BFA50152 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xa04>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v13, 32, v24    // 00000083C5BC: CA200080 1E0C30A0
	v_dual_mov_b32 v34, v35 :: v_dual_lshlrev_b32 v19, 5, v24  // 00000083C5C4: CA220123 22123085
	s_delay_alu instid0(VALU_DEP_2)                            // 00000083C5CC: BF870002
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v32, 4, v13    // 00000083C5D0: CA220080 1F201A84
	v_lshlrev_b32_e32 v33, 1, v13                              // 00000083C5D8: 30421A81
	v_mov_b32_e32 v27, 0                                       // 00000083C5DC: 7E360280
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000083C5E0: 8484820A
	s_mov_b32 s15, 0                                           // 00000083C5E4: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000083C5E8: 848A810A
	s_branch 289                                               // 00000083C5EC: BFA00121 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x974>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000083C5F0: 8C7E107E
	v_ashrrev_i32_e32 v20, 31, v19                             // 00000083C5F4: 3428269F
	v_cndmask_b32_e64 v84, v35, v1, s2                         // 00000083C5F8: D5010054 000A0323
	v_lshrrev_b32_e32 v35, 6, v9                               // 00000083C600: 32461286
	v_lshrrev_b32_e32 v85, 14, v9                              // 00000083C604: 32AA128E
	v_and_b32_e32 v86, 0xff, v10                               // 00000083C608: 36AC14FF 000000FF
	.long 0xd73c0024                                           // 00000083C610: D73C0024
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000083C614: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 00000083C618: 362812FF 000000FF
	v_and_b32_e32 v35, 0x3fc, v35                              // 00000083C620: 364646FF 000003FC
	v_and_b32_e32 v85, 0x3fc, v85                              // 00000083C628: 36AAAAFF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 00000083C630: 32121296
	v_lshrrev_b32_e32 v87, 6, v10                              // 00000083C634: 32AE1486
	.long 0xd7006a48                                           // 00000083C638: D7006A48
	v_cndmask_b32_e32 v1, s6, v36, vcc_lo                      // 00000083C63C: 02024806
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083C640: BF8701A1
	v_add_co_ci_u32_e64 v73, null, s7, v37, vcc_lo             // 00000083C644: D5207C49 01AA4A07
	v_lshlrev_b32_e32 v20, 2, v20                              // 00000083C64C: 30282882
	.long 0xd7006a4c                                           // 00000083C650: D7006A4C
	v_cndmask_b32_e32 v0, v72, v10, vcc_lo                     // 00000083C654: 02001548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083C658: BF8700A1
	v_add_co_ci_u32_e64 v77, null, s11, v73, vcc_lo            // 00000083C65C: D5207C4D 01AA920B
	.long 0xd7006a50                                           // 00000083C664: D7006A50
	v_cndmask_b32_e32 v0, v72, v4, vcc_lo                      // 00000083C668: 02000948
	v_add_co_ci_u32_e64 v81, null, s5, v73, vcc_lo             // 00000083C66C: D5207C51 01AA9205
	s_clause 0xb                                               // 00000083C674: BF85000B
	global_load_b128 v[36:39], v[72:73], off                   // 00000083C678: DC5E0000 247C0048
	global_load_b128 v[40:43], v[76:77], off                   // 00000083C680: DC5E0000 287C004C
	global_load_b128 v[44:47], v[80:81], off                   // 00000083C688: DC5E0000 2C7C0050
	global_load_b128 v[48:51], v[72:73], off offset:16         // 00000083C690: DC5E0010 307C0048
	global_load_b128 v[52:55], v[76:77], off offset:16         // 00000083C698: DC5E0010 347C004C
	global_load_b128 v[56:59], v[80:81], off offset:16         // 00000083C6A0: DC5E0010 387C0050
	global_load_b128 v[60:63], v[72:73], off offset:32         // 00000083C6A8: DC5E0020 3C7C0048
	global_load_b128 v[64:67], v[76:77], off offset:32         // 00000083C6B0: DC5E0020 407C004C
	global_load_b128 v[68:71], v[80:81], off offset:32         // 00000083C6B8: DC5E0020 447C0050
	global_load_b128 v[72:75], v[72:73], off offset:48         // 00000083C6C0: DC5E0030 487C0048
	global_load_b128 v[76:79], v[76:77], off offset:48         // 00000083C6C8: DC5E0030 4C7C004C
	global_load_b128 v[80:83], v[80:81], off offset:48         // 00000083C6D0: DC5E0030 507C0050
	ds_load_b32 v20, v20                                       // 00000083C6D8: D8D80000 14000014
	ds_load_b32 v35, v35                                       // 00000083C6E0: D8D80000 23000023
	ds_load_b32 v85, v85                                       // 00000083C6E8: D8D80000 55000055
	v_lshrrev_b32_e32 v88, 14, v10                             // 00000083C6F0: 32B0148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 00000083C6F4: 32141496
	v_lshlrev_b32_e32 v86, 2, v86                              // 00000083C6F8: 30ACAC82
	v_and_b32_e32 v87, 0x3fc, v87                              // 00000083C6FC: 36AEAEFF 000003FC
	v_and_b32_e32 v89, 0xff, v11                               // 00000083C704: 36B216FF 000000FF
	v_and_b32_e32 v88, 0x3fc, v88                              // 00000083C70C: 36B0B0FF 000003FC
	v_lshrrev_b32_e32 v90, 6, v11                              // 00000083C714: 32B41686
	v_lshrrev_b32_e32 v91, 14, v11                             // 00000083C718: 32B6168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 00000083C71C: 32161696
	v_lshrrev_b32_e32 v93, 14, v12                             // 00000083C720: 32BA188E
	v_add_nc_u32_e32 v33, 64, v33                              // 00000083C724: 4A4242C0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 00000083C728: 4A2626FF 00000400
	s_and_b32 s3, exec_lo, s3                                  // 00000083C730: 8B03037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000083C734: BF870009
	s_or_b32 s15, s3, s15                                      // 00000083C738: 8C0F0F03
	s_waitcnt vmcnt(11) lgkmcnt(2)                             // 00000083C73C: BF892C27
	v_dot2_f32_bf16 v36, v36, v20, 0                           // 00000083C740: CC1A4024 1A022924
	s_waitcnt vmcnt(10)                                        // 00000083C748: BF892BF7
	v_dot2_f32_bf16 v40, v40, v20, 0                           // 00000083C74C: CC1A4028 1A022928
	s_waitcnt vmcnt(9)                                         // 00000083C754: BF8927F7
	v_dot2_f32_bf16 v20, v44, v20, 0                           // 00000083C758: CC1A4014 1A02292C
	v_lshrrev_b32_e32 v44, 6, v12                              // 00000083C760: 32581886
	s_waitcnt lgkmcnt(1)                                       // 00000083C764: BF89FC17
	v_dot2_f32_bf16 v36, v37, v35, v36                         // 00000083C768: CC1A4024 1C924725
	v_dot2_f32_bf16 v37, v41, v35, v40                         // 00000083C770: CC1A4025 1CA24729
	v_dot2_f32_bf16 v20, v45, v35, v20                         // 00000083C778: CC1A4014 1C52472D
	v_and_b32_e32 v40, 0x3fc, v91                              // 00000083C780: 3650B6FF 000003FC
	v_and_b32_e32 v41, 0x3fc, v93                              // 00000083C788: 3652BAFF 000003FC
	s_waitcnt lgkmcnt(0)                                       // 00000083C790: BF89FC07
	v_dot2_f32_bf16 v36, v38, v85, v36                         // 00000083C794: CC1A4024 1C92AB26
	v_dot2_f32_bf16 v37, v42, v85, v37                         // 00000083C79C: CC1A4025 1C96AB2A
	v_cndmask_b32_e64 v42, v7, v8, s2                          // 00000083C7A4: D501002A 000A1107
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000083C7AC: 361212FF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 00000083C7B4: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 00000083C7BC: D8D80000 09000009
	ds_load_b32 v86, v86                                       // 00000083C7C4: D8D80000 56000056
	ds_load_b32 v87, v87                                       // 00000083C7CC: D8D80000 57000057
	ds_load_b32 v88, v88                                       // 00000083C7D4: D8D80000 58000058
	ds_load_b32 v10, v10                                       // 00000083C7DC: D8D80000 0A00000A
	v_dot2_f32_bf16 v20, v46, v85, v20                         // 00000083C7E4: CC1A4014 1C52AB2E
	v_lshlrev_b32_e32 v35, 2, v89                              // 00000083C7EC: 3046B282
	v_and_b32_e32 v38, 0x3fc, v90                              // 00000083C7F0: 364CB4FF 000003FC
	ds_load_b32 v35, v35                                       // 00000083C7F8: D8D80000 23000023
	ds_load_b32 v38, v38                                       // 00000083C800: D8D80000 26000026
	s_waitcnt lgkmcnt(6)                                       // 00000083C808: BF89FC67
	v_dot2_f32_bf16 v36, v39, v9, v36                          // 00000083C80C: CC1A4024 1C921327
	v_dot2_f32_bf16 v37, v43, v9, v37                          // 00000083C814: CC1A4025 1C96132B
	v_dot2_f32_bf16 v9, v47, v9, v20                           // 00000083C81C: CC1A4009 1C52132F
	ds_load_b32 v43, v40                                       // 00000083C824: D8D80000 2B000028
	v_and_b32_e32 v92, 0xff, v12                               // 00000083C82C: 36B818FF 000000FF
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 00000083C834: BF892067
	v_dot2_f32_bf16 v36, v48, v86, v36                         // 00000083C838: CC1A4024 1C92AD30
	s_waitcnt vmcnt(7)                                         // 00000083C840: BF891FF7
	v_dot2_f32_bf16 v37, v52, v86, v37                         // 00000083C844: CC1A4025 1C96AD34
	s_waitcnt vmcnt(6)                                         // 00000083C84C: BF891BF7
	v_dot2_f32_bf16 v9, v56, v86, v9                           // 00000083C850: CC1A4009 1C26AD38
	v_lshrrev_b32_e32 v12, 22, v12                             // 00000083C858: 32181896
	v_cndmask_b32_e64 v40, v5, v6, s2                          // 00000083C85C: D5010028 000A0D05
	s_waitcnt lgkmcnt(5)                                       // 00000083C864: BF89FC57
	v_dot2_f32_bf16 v36, v49, v87, v36                         // 00000083C868: CC1A4024 1C92AF31
	v_dot2_f32_bf16 v37, v53, v87, v37                         // 00000083C870: CC1A4025 1C96AF35
	v_dot2_f32_bf16 v9, v57, v87, v9                           // 00000083C878: CC1A4009 1C26AF39
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000083C880: 361616FF 000003FC
	v_lshlrev_b32_e32 v20, 2, v92                              // 00000083C888: 3028B882
	s_waitcnt lgkmcnt(4)                                       // 00000083C88C: BF89FC47
	v_dot2_f32_bf16 v36, v50, v88, v36                         // 00000083C890: CC1A4024 1C92B132
	v_dot2_f32_bf16 v37, v54, v88, v37                         // 00000083C898: CC1A4025 1C96B136
	v_dot2_f32_bf16 v9, v58, v88, v9                           // 00000083C8A0: CC1A4009 1C26B13A
	v_and_b32_e32 v39, 0x3fc, v44                              // 00000083C8A8: 364E58FF 000003FC
	v_and_b32_e32 v12, 0x3fc, v12                              // 00000083C8B0: 361818FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 00000083C8B8: BF89FC37
	v_dot2_f32_bf16 v36, v51, v10, v36                         // 00000083C8BC: CC1A4024 1C921533
	v_dot2_f32_bf16 v37, v55, v10, v37                         // 00000083C8C4: CC1A4025 1C961537
	v_dot2_f32_bf16 v9, v59, v10, v9                           // 00000083C8CC: CC1A4009 1C26153B
	ds_load_b32 v10, v11                                       // 00000083C8D4: D8D80000 0A00000B
	ds_load_b32 v11, v20                                       // 00000083C8DC: D8D80000 0B000014
	ds_load_b32 v20, v39                                       // 00000083C8E4: D8D80000 14000027
	ds_load_b32 v44, v41                                       // 00000083C8EC: D8D80000 2C000029
	ds_load_b32 v45, v12                                       // 00000083C8F4: D8D80000 2D00000C
	v_cndmask_b32_e64 v41, v6, v7, s2                          // 00000083C8FC: D5010029 000A0F06
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 00000083C904: BF891477
	v_dot2_f32_bf16 v12, v60, v35, v36                         // 00000083C908: CC1A400C 1C92473C
	s_waitcnt vmcnt(4)                                         // 00000083C910: BF8913F7
	v_dot2_f32_bf16 v36, v64, v35, v37                         // 00000083C914: CC1A4024 1C964740
	s_waitcnt vmcnt(3)                                         // 00000083C91C: BF890FF7
	v_dot2_f32_bf16 v9, v68, v35, v9                           // 00000083C920: CC1A4009 1C264744
	v_cndmask_b32_e64 v39, v4, v5, s2                          // 00000083C928: D5010027 000A0B04
	v_cndmask_b32_e64 v37, v2, v3, s2                          // 00000083C930: D5010025 000A0702
	s_waitcnt lgkmcnt(6)                                       // 00000083C938: BF89FC67
	v_dot2_f32_bf16 v7, v61, v38, v12                          // 00000083C93C: CC1A4007 1C324D3D
	v_dot2_f32_bf16 v12, v65, v38, v36                         // 00000083C944: CC1A400C 1C924D41
	v_dot2_f32_bf16 v9, v69, v38, v9                           // 00000083C94C: CC1A4009 1C264D45
	v_cndmask_b32_e64 v38, v3, v4, s2                          // 00000083C954: D5010026 000A0903
	v_cndmask_b32_e64 v36, v1, v2, s2                          // 00000083C95C: D5010024 000A0501
	s_waitcnt lgkmcnt(5)                                       // 00000083C964: BF89FC57
	v_dot2_f32_bf16 v5, v62, v43, v7                           // 00000083C968: CC1A4005 1C1E573E
	v_dot2_f32_bf16 v6, v66, v43, v12                          // 00000083C970: CC1A4006 1C325742
	v_dot2_f32_bf16 v7, v70, v43, v9                           // 00000083C978: CC1A4007 1C265746
	v_dual_mov_b32 v43, v8 :: v_dual_add_nc_u32 v32, 0x200, v32// 00000083C980: CA200108 2B2040FF 00000200
	s_waitcnt lgkmcnt(4)                                       // 00000083C98C: BF89FC47
	v_dot2_f32_bf16 v3, v63, v10, v5                           // 00000083C990: CC1A4003 1C16153F
	v_dot2_f32_bf16 v4, v67, v10, v6                           // 00000083C998: CC1A4004 1C1A1543
	v_dot2_f32_bf16 v5, v71, v10, v7                           // 00000083C9A0: CC1A4005 1C1E1547
	v_mov_b32_e32 v12, v16                                     // 00000083C9A8: 7E180310
	v_mov_b32_e32 v10, v14                                     // 00000083C9AC: 7E14030E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 00000083C9B0: BF890837
	v_dot2_f32_bf16 v1, v72, v11, v3                           // 00000083C9B4: CC1A4001 1C0E1748
	s_waitcnt vmcnt(1)                                         // 00000083C9BC: BF8907F7
	v_dot2_f32_bf16 v2, v76, v11, v4                           // 00000083C9C0: CC1A4002 1C12174C
	s_waitcnt vmcnt(0)                                         // 00000083C9C8: BF8903F7
	v_dot2_f32_bf16 v3, v80, v11, v5                           // 00000083C9CC: CC1A4003 1C161750
	v_mov_b32_e32 v11, v15                                     // 00000083C9D4: 7E16030F
	v_mov_b32_e32 v9, v13                                      // 00000083C9D8: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 00000083C9DC: BF89FC27
	v_dot2_f32_bf16 v1, v73, v20, v1                           // 00000083C9E0: CC1A4001 1C062949
	v_dot2_f32_bf16 v2, v77, v20, v2                           // 00000083C9E8: CC1A4002 1C0A294D
	v_dot2_f32_bf16 v3, v81, v20, v3                           // 00000083C9F0: CC1A4003 1C0E2951
	v_mov_b32_e32 v35, v34                                     // 00000083C9F8: 7E460322
	s_waitcnt lgkmcnt(1)                                       // 00000083C9FC: BF89FC17
	v_dot2_f32_bf16 v1, v74, v44, v1                           // 00000083CA00: CC1A4001 1C06594A
	v_dot2_f32_bf16 v2, v78, v44, v2                           // 00000083CA08: CC1A4002 1C0A594E
	v_dot2_f32_bf16 v3, v82, v44, v3                           // 00000083CA10: CC1A4003 1C0E5952
	s_waitcnt lgkmcnt(0)                                       // 00000083CA18: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000083CA1C: BF870193
	v_dot2_f32_bf16 v1, v75, v45, v1                           // 00000083CA20: CC1A4001 1C065B4B
	v_dot2_f32_bf16 v2, v79, v45, v2                           // 00000083CA28: CC1A4002 1C0A5B4F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000083CA30: BF870193
	v_dot2_f32_bf16 v3, v83, v45, v3                           // 00000083CA34: CC1A4003 1C0E5B53
	v_fmac_f32_e32 v30, v84, v1                                // 00000083CA3C: 563C0354
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000083CA40: BF870193
	v_fmac_f32_e32 v31, v84, v2                                // 00000083CA44: 563E0554
	v_fmac_f32_e32 v27, v84, v3                                // 00000083CA48: 56360754
	v_dual_mov_b32 v1, v36 :: v_dual_mov_b32 v2, v37           // 00000083CA4C: CA100124 01020125
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v39           // 00000083CA54: CA100126 03040127
	v_dual_mov_b32 v5, v40 :: v_dual_mov_b32 v6, v41           // 00000083CA5C: CA100128 05060129
	v_dual_mov_b32 v7, v42 :: v_dual_mov_b32 v8, v43           // 00000083CA64: CA10012A 0708012B
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000083CA6C: 917E0F7E
	s_cbranch_execz 35                                         // 00000083CA70: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xa00>
	s_waitcnt vmcnt(0)                                         // 00000083CA74: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 00000083CA78: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 00000083CA80: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 00000083CA88: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000083CA8C: BF870003
	.long 0xd4460003                                           // 00000083CA90: D4460003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000083CA94: 02023318
	s_mov_b32 s16, exec_lo                                     // 00000083CA98: BE90007E
	.long 0xd4c1007e                                           // 00000083CA9C: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000083CAA0: 02023318
	s_cbranch_execz 65234                                      // 00000083CAA4: BFA5FED2 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4f0>
	v_ashrrev_i32_e32 v14, 31, v32                             // 00000083CAA8: 341C409F
	.long 0xd7006a0d                                           // 00000083CAAC: D7006A0D
	v_cndmask_b32_e32 v1, v18, v32, vcc_lo                     // 00000083CAB0: 02024112
	v_mov_b32_e32 v34, v35                                     // 00000083CAB4: 7E440323
	s_delay_alu instid0(VALU_DEP_3)                            // 00000083CAB8: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 00000083CABC: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 00000083CAC4: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 00000083CAC8: DC5E0000 0D7C000D
	s_cbranch_vccnz 65223                                      // 00000083CAD0: BFA4FEC7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4f0>
	v_ashrrev_i32_e32 v20, 31, v33                             // 00000083CAD4: 3428429F
	.long 0xd7006a24                                           // 00000083CAD8: D7006A24
	v_cndmask_b32_e32 v1, v17, v33, vcc_lo                     // 00000083CADC: 02024311
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083CAE0: BF870001
	v_add_co_ci_u32_e64 v37, null, v26, v20, vcc_lo            // 00000083CAE4: D5207C25 01AA291A
	global_load_d16_b16 v20, v[36:37], off                     // 00000083CAEC: DC820000 147C0024
	s_waitcnt vmcnt(0)                                         // 00000083CAF4: BF8903F7
	v_cvt_f32_f16_e32 v34, v20                                 // 00000083CAF8: 7E441714
	s_branch 65212                                             // 00000083CAFC: BFA0FEBC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4f0>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000083CB00: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000083CB04: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 00000083CB08: 8C7E0E7E
	.long 0xd71f0001                                           // 00000083CB0C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000083CB10: 020100C1
	s_mov_b32 s2, exec_lo                                      // 00000083CB14: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000083CB18: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 00000083CB1C: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 00000083CB20: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000083CB24: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000083CB28: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000083CB2C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 00000083CB30: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 00000083CB34: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000083CB38: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000083CB3C: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000083CB40: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000083CB44: 30040482
	ds_bpermute_b32 v3, v2, v30                                // 00000083CB48: DACC0000 03001E02
	s_waitcnt lgkmcnt(0)                                       // 00000083CB50: BF89FC07
	v_add_f32_e32 v3, v30, v3                                  // 00000083CB54: 0606071E
	ds_bpermute_b32 v4, v2, v31                                // 00000083CB58: DACC0000 04001F02
	ds_bpermute_b32 v2, v2, v27                                // 00000083CB60: DACC0000 02001B02
	ds_bpermute_b32 v6, v5, v3                                 // 00000083CB68: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 00000083CB70: 02101101
	s_waitcnt lgkmcnt(2)                                       // 00000083CB74: BF89FC27
	v_add_f32_e32 v4, v31, v4                                  // 00000083CB78: 0608091F
	s_waitcnt lgkmcnt(1)                                       // 00000083CB7C: BF89FC17
	v_add_f32_e32 v2, v27, v2                                  // 00000083CB80: 0604051B
	s_waitcnt lgkmcnt(0)                                       // 00000083CB84: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 00000083CB88: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 00000083CB8C: DACC0000 07000405
	ds_bpermute_b32 v5, v5, v2                                 // 00000083CB94: DACC0000 05000205
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000083CB9C: 30101082
	s_waitcnt lgkmcnt(0)                                       // 00000083CBA0: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 00000083CBA4: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 00000083CBA8: DACC0000 05000308
	s_waitcnt lgkmcnt(0)                                       // 00000083CBB0: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v7     // 00000083CBB4: C9080B03 03040F04
	ds_bpermute_b32 v7, v8, v2                                 // 00000083CBBC: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 00000083CBC4: DACC0000 06000408
	v_xor_b32_e32 v8, 2, v1                                    // 00000083CBCC: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083CBD0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000083CBD4: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 00000083CBD8: 02101101
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000083CBDC: 30101082
	s_waitcnt lgkmcnt(1)                                       // 00000083CBE0: BF89FC17
	v_add_f32_e32 v2, v2, v7                                   // 00000083CBE4: 06040F02
	s_waitcnt lgkmcnt(0)                                       // 00000083CBE8: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 00000083CBEC: 06080D04
	ds_bpermute_b32 v5, v8, v3                                 // 00000083CBF0: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 00000083CBF8: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 00000083CC00: DACC0000 06000408
	v_xor_b32_e32 v8, 1, v1                                    // 00000083CC08: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083CC0C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000083CC10: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 00000083CC14: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 00000083CC18: 30100282
	s_waitcnt lgkmcnt(1)                                       // 00000083CC1C: BF89FC17
	v_dual_add_f32 v1, v3, v5 :: v_dual_add_f32 v2, v2, v7     // 00000083CC20: C9080B03 01020F02
	s_waitcnt lgkmcnt(0)                                       // 00000083CC28: BF89FC07
	v_add_f32_e32 v3, v4, v6                                   // 00000083CC2C: 06060D04
	ds_bpermute_b32 v4, v8, v1                                 // 00000083CC30: DACC0000 04000108
	ds_bpermute_b32 v5, v8, v2                                 // 00000083CC38: DACC0000 05000208
	ds_bpermute_b32 v6, v8, v3                                 // 00000083CC40: DACC0000 06000308
	v_cmpx_eq_u32_e32 0, v23                                   // 00000083CC48: 7D942E80
	s_cbranch_execz 16                                         // 00000083CC4C: BFA50010 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xb90>
	.long 0xd72c0007                                           // 00000083CC50: D72C0007
	v_cndmask_b32_e32 v0, v21, v152, vcc_lo                    // 00000083CC54: 02013115
	s_waitcnt lgkmcnt(1)                                       // 00000083CC58: BF89FC17
	v_dual_add_f32 v1, v1, v4 :: v_dual_add_f32 v2, v2, v5     // 00000083CC5C: C9080901 01020B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083CC64: BF8700A2
	v_mad_u32_u24 v7, v22, 12, v7                              // 00000083CC68: D60B0007 041D1916
	s_waitcnt lgkmcnt(0)                                       // 00000083CC70: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_nc_u32 v4, 0x400, v7// 00000083CC74: C9200D03 03040EFF 00000400
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 00000083CC80: D8380100 00030104
	ds_store_b32 v7, v2 offset:1032                            // 00000083CC88: D8340408 00000207
	s_or_b32 exec_lo, exec_lo, s2                              // 00000083CC90: 8C7E027E
	.long 0xd7050001                                           // 00000083CC94: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 00000083CC98: 020200FF 000000AB
	.long 0x7f063880                                           // 00000083CCA0: 7F063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000083CCA4: BF890007
	s_barrier                                                  // 00000083CCA8: BFBD0000
	buffer_gl0_inv                                             // 00000083CCAC: E0AC0000 00000000
	.long 0xd7390003                                           // 00000083CCB4: D7390003
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 00000083CCB8: 02020289
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083CCBC: BF870091
	.long 0xd7000201                                           // 00000083CCC0: D7000201
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 00000083CCC4: 02020614
	v_add_co_ci_u32_e64 v2, null, s21, 0, s2                   // 00000083CCC8: D5207C02 00090015
	.long 0xd44c0002                                           // 00000083CCD0: D44C0002
	v_cndmask_b32_e32 v1, 12, v0, vcc_lo                       // 00000083CCD4: 0202008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000083CCD8: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000083CCDC: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 00000083CCE0: 8B026A02
	s_and_saveexec_b32 s3, s2                                  // 00000083CCE4: BE832002
	s_cbranch_execz 81                                         // 00000083CCE8: BFA50051 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xd30>
	.long 0xd7054000                                           // 00000083CCEC: D7054000
	v_cndmask_b32_e32 v0, v3, v131, vcc_lo                     // 00000083CCF0: 02010703
	v_mul_u32_u24_e32 v3, 24, v3                               // 00000083CCF4: 16060698
	s_load_b32 s0, s[0:1], 0x48                                // 00000083CCF8: F4000000 F8000048
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083CD00: BF870092
	.long 0xd7041000                                           // 00000083CD04: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 00000083CD08: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 00000083CD0C: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083CD14: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 00000083CD18: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 00000083CD20: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:3                     // 00000083CD28: D8DC0300 03000003
	s_waitcnt lgkmcnt(0)                                       // 00000083CD30: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 00000083CD34: 06060680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083CD38: BF870091
	v_add_f32_e32 v3, v3, v4                                   // 00000083CD3C: 06060903
	v_bfe_u32 v4, v3, 16, 1                                    // 00000083CD40: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083CD48: BF870091
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000083CD4C: D6550003 03FE0903 00007FFF
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000083CD58: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083CD60: BF870091
	v_mul_f32_e32 v3, s0, v3                                   // 00000083CD64: 10060600
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 00000083CD68: 100606FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000083CD70: BF870291
	v_exp_f32_e32 v3, v3                                       // 00000083CD74: 7E064B03
	v_add_f32_e32 v6, 1.0, v3                                  // 00000083CD78: 060C06F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000083CD7C: BF870121
	v_div_scale_f32 v7, null, v6, v6, 1.0                      // 00000083CD80: D6FC7C07 03CA0D06
	v_div_scale_f32 v9, vcc_lo, 1.0, v6, 1.0                   // 00000083CD88: D6FC6A09 03CA0CF2
	v_rcp_f32_e32 v8, v7                                       // 00000083CD90: 7E105507
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083CD94: BF870095
	v_fma_f32 v3, -v7, v8, 1.0                                 // 00000083CD98: D6130003 23CA1107
	v_fmac_f32_e32 v8, v3, v8                                  // 00000083CDA0: 56101103
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 00000083CDA4: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083CDAC: BF870092
	v_mul_f32_e32 v10, v9, v8                                  // 00000083CDB0: 10141109
	v_fma_f32 v5, -v7, v10, v9                                 // 00000083CDB4: D6130005 24261507
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000083CDBC: BF870211
	v_fmac_f32_e32 v10, v5, v8                                 // 00000083CDC0: 56141105
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 00000083CDC4: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083CDCC: BF870112
	v_fma_f32 v0, -v7, v10, v9                                 // 00000083CDD0: D6130000 24261507
	.long 0xd73c0003                                           // 00000083CDD8: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000083CDDC: 02020682
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083CDE0: BF8701A2
	v_div_fmas_f32 v5, v0, v8, v10                             // 00000083CDE4: D6370005 042A1100
	.long 0xd73c0000                                           // 00000083CDEC: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000083CDF0: 02020282
	.long 0xd7006a03                                           // 00000083CDF4: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000083CDF8: 02020608
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083CDFC: BF8701A3
	v_div_fixup_f32 v2, v5, v6, 1.0                            // 00000083CE00: D6270002 03CA0D05
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000083CE08: D5207C04 01AA0809
	.long 0xd7006a00                                           // 00000083CE10: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000083CE14: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000083CE18: BF870193
	v_add_f32_e32 v2, v2, v2                                   // 00000083CE1C: 06040502
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000083CE20: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 00000083CE28: DC6A0000 007C0200
	s_endpgm                                                   // 00000083CE30: BFB00000
		...

