000000000054e900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000054E900: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 00000054E908: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000054E910: 32040082
	s_ashr_i32 s3, s2, 31                                      // 00000054E914: 86039F02
	v_lshrrev_b32_e32 v15, 5, v0                               // 00000054E918: 321E0085
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054E91C: BF870003
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000054E920: 30020282
	.long 0x7f283880                                           // 00000054E924: 7F283880
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v2, 60, v2         // 00000054E928: CA240080 110204BC
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 00000054E930: CA100080 04020080
	v_lshlrev_b32_e32 v14, 2, v0                               // 00000054E938: 301C0082
	s_waitcnt lgkmcnt(0)                                       // 00000054E93C: BF89FC07
	s_clause 0x1                                               // 00000054E940: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 00000054E944: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 00000054E94C: DC520000 0D040002
	.long 0xd4510000                                           // 00000054E954: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000054E958: 02001802
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 00000054E95C: CA100080 01020080
	s_and_b32 s0, s0, exec_lo                                  // 00000054E964: 8B007E00
	s_cselect_b32 s22, s3, 0                                   // 00000054E968: 98168003
	s_cselect_b32 s23, s2, 0                                   // 00000054E96C: 98178002
	s_add_u32 s0, s4, s14                                      // 00000054E970: 80000E04
	s_addc_u32 s1, s5, s15                                     // 00000054E974: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 00000054E978: 850E9F0B
	v_mov_b32_e32 v6, s1                                       // 00000054E97C: 7E0C0201
	s_add_u32 s14, s10, s14                                    // 00000054E980: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000054E984: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000054E988: 86149F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000054E98C: 868E810E
	s_lshr_b32 s20, s20, 27                                    // 00000054E990: 85149B14
	v_dual_mov_b32 v5, s0 :: v_dual_and_b32 v16, 31, v0        // 00000054E994: CA240000 0510009F
	s_add_u32 s20, s10, s20                                    // 00000054E99C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 00000054E9A0: 8215800B
	s_mul_i32 s19, s19, s23                                    // 00000054E9A4: 96131713
	s_lshr_b64 s[20:21], s[20:21], 5                           // 00000054E9A8: 85948514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000054E9AC: BF870499
	s_add_i32 s21, s20, 7                                      // 00000054E9B0: 81158714
	s_ashr_i32 s24, s21, 31                                    // 00000054E9B4: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000054E9B8: BF870499
	s_lshr_b32 s24, s24, 29                                    // 00000054E9BC: 85189D18
	s_add_i32 s21, s21, s24                                    // 00000054E9C0: 81151815
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000054E9C4: BF870009
	s_ashr_i32 s21, s21, 3                                     // 00000054E9C8: 86158315
	s_add_u32 s0, s4, s16                                      // 00000054E9CC: 80001004
	s_addc_u32 s1, s5, s17                                     // 00000054E9D0: 82011105
	.long 0xd72c0013                                           // 00000054E9D4: D72C0013
	v_cndmask_b32_e32 v1, s21, v15, vcc_lo                     // 00000054E9D8: 02021E15
	v_dual_mov_b32 v8, s1 :: v_dual_mov_b32 v7, s0             // 00000054E9DC: CA100001 08060000
	v_mad_u64_u32 v[9:10], null, s23, s14, v[5:6]              // 00000054E9E4: D6FE7C09 04141C17
	s_mul_i32 s0, s22, s14                                     // 00000054E9EC: 96000E16
	s_waitcnt vmcnt(1)                                         // 00000054E9F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 00000054E9F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 00000054E9FC: BF8903F7
	v_bfe_u32 v5, v13, 16, 1                                   // 00000054EA00: D6100005 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000054EA08: BF870232
	v_add3_u32 v6, v11, v12, 0x7fff                            // 00000054EA0C: D6550006 03FE190B 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, s23, v[7:8]             // 00000054EA18: D6FE7C0B 041C2E12
	v_add_nc_u32_e32 v7, s21, v19                              // 00000054EA20: 4A0E2615
	v_add3_u32 v5, v13, v5, 0x7fff                             // 00000054EA24: D6550005 03FE0B0D 00007FFF
	s_mul_i32 s23, s23, s15                                    // 00000054EA30: 96170F17
	.long 0x7e283986                                           // 00000054EA34: 7E283986
	v_add_nc_u32_e32 v6, s0, v10                               // 00000054EA38: 4A0C1400
	v_add_nc_u32_e32 v10, v19, v16                             // 00000054EA3C: 4A142113
	v_min_i32_e32 v19, s20, v7                                 // 00000054EA40: 22260E14
	v_add_nc_u32_e32 v7, s19, v12                              // 00000054EA44: 4A0E1813
	s_mul_i32 s0, s18, s22                                     // 00000054EA48: 96001612
	v_and_or_b32 v5, 0xffff0000, v5, v20                       // 00000054EA4C: D6570005 04520AFF FFFF0000
	v_add_nc_u32_e32 v20, s23, v6                              // 00000054EA58: 4A280C17
	v_cmp_lt_i32_e32 vcc_lo, v10, v19                          // 00000054EA5C: 7C82270A
	v_add_nc_u32_e32 v21, s0, v7                               // 00000054EA60: 4A2A0E00
	ds_store_b32 v14, v5                                       // 00000054EA64: D8340000 0000050E
	s_waitcnt lgkmcnt(0)                                       // 00000054EA6C: BF89FC07
	s_barrier                                                  // 00000054EA70: BFBD0000
	buffer_gl0_inv                                             // 00000054EA74: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 00000054EA7C: BE81206A
	s_cbranch_execz 21                                         // 00000054EA80: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1d8>
	v_lshlrev_b32_e32 v1, 1, v10                               // 00000054EA84: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 00000054EA88: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054EA8C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000054EA90: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000054EA94: 3408069F
	.long 0xd7000001                                           // 00000054EA98: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 00000054EA9C: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054EAA0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s0                  // 00000054EAA4: D5207C02 00020515
	.long 0xd7000003                                           // 00000054EAAC: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 00000054EAB0: 02020709
	v_add_co_ci_u32_e64 v4, null, v20, v4, s0                  // 00000054EAB4: D5207C04 00020914
	s_clause 0x1                                               // 00000054EABC: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 00000054EAC0: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000054EAC8: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000054EAD0: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 00000054EAD4: 7E241705
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054EAD8: 8C7E017E
	v_mov_b32_e32 v22, 0                                       // 00000054EADC: 7E2C0280
	s_and_saveexec_b32 s1, vcc_lo                              // 00000054EAE0: BE81206A
	s_cbranch_execz 264                                        // 00000054EAE4: BFA50108 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x608>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, 32, v10     // 00000054EAE8: CA200080 160414A0
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 00000054EAF0: CA220080 110C1485
	s_mov_b32 s14, 0                                           // 00000054EAF8: BE8E0080
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054EAFC: BF870002
	v_lshlrev_b32_e32 v23, 4, v5                               // 00000054EB00: 302E0A84
	v_dual_mov_b32 v25, v18 :: v_dual_lshlrev_b32 v24, 1, v5   // 00000054EB04: CA220112 19180A81
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000054EB0C: 8484810A
	s_branch 221                                               // 00000054EB10: BFA000DD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x588>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000054EB14: 8C7E0A7E
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000054EB18: 341A189F
	v_lshrrev_b32_e32 v58, 6, v1                               // 00000054EB1C: 32740286
	v_lshrrev_b32_e32 v59, 14, v1                              // 00000054EB20: 3276028E
	v_and_b32_e32 v60, 0xff, v2                                // 00000054EB24: 367804FF 000000FF
	v_lshrrev_b32_e32 v61, 6, v2                               // 00000054EB2C: 327A0486
	.long 0xd73c001a                                           // 00000054EB30: D73C001A
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000054EB34: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 00000054EB38: 361A02FF 000000FF
	v_and_b32_e32 v58, 0x3fc, v58                              // 00000054EB40: 367474FF 000003FC
	v_and_b32_e32 v59, 0x3fc, v59                              // 00000054EB48: 367676FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 00000054EB50: 32020296
	v_lshrrev_b32_e32 v62, 14, v2                              // 00000054EB54: 327C048E
	.long 0xd7000032                                           // 00000054EB58: D7000032
	v_cndmask_b32_e32 v1, s6, v26, vcc_lo                      // 00000054EB5C: 02023406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054EB60: BF8701A1
	v_add_co_ci_u32_e64 v51, null, s7, v27, s0                 // 00000054EB64: D5207C33 00023607
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000054EB6C: 301A1A82
	.long 0xd7000036                                           // 00000054EB70: D7000036
	v_cndmask_b32_e32 v0, v50, v4, vcc_lo                      // 00000054EB74: 02000932
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054EB78: BF870001
	v_add_co_ci_u32_e64 v55, null, s5, v51, s0                 // 00000054EB7C: D5207C37 00026605
	ds_load_b32 v13, v13                                       // 00000054EB84: D8D80000 0D00000D
	ds_load_b32 v58, v58                                       // 00000054EB8C: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 00000054EB94: D8D80000 3B00003B
	s_clause 0x7                                               // 00000054EB9C: BF850007
	global_load_b128 v[26:29], v[50:51], off                   // 00000054EBA0: DC5E0000 1A7C0032
	global_load_b128 v[30:33], v[54:55], off                   // 00000054EBA8: DC5E0000 1E7C0036
	global_load_b128 v[34:37], v[50:51], off offset:16         // 00000054EBB0: DC5E0010 227C0032
	global_load_b128 v[38:41], v[54:55], off offset:16         // 00000054EBB8: DC5E0010 267C0036
	global_load_b128 v[42:45], v[50:51], off offset:32         // 00000054EBC0: DC5E0020 2A7C0032
	global_load_b128 v[46:49], v[54:55], off offset:32         // 00000054EBC8: DC5E0020 2E7C0036
	global_load_b128 v[50:53], v[50:51], off offset:48         // 00000054EBD0: DC5E0030 327C0032
	global_load_b128 v[54:57], v[54:55], off offset:48         // 00000054EBD8: DC5E0030 367C0036
	v_lshrrev_b32_e32 v2, 22, v2                               // 00000054EBE0: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000054EBE4: 360202FF 000003FC
	v_lshlrev_b32_e32 v60, 2, v60                              // 00000054EBEC: 30787882
	v_and_b32_e32 v61, 0x3fc, v61                              // 00000054EBF0: 367A7AFF 000003FC
	v_and_b32_e32 v62, 0x3fc, v62                              // 00000054EBF8: 367C7CFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 00000054EC00: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 00000054EC08: D8D80000 01000001
	ds_load_b32 v60, v60                                       // 00000054EC10: D8D80000 3C00003C
	ds_load_b32 v61, v61                                       // 00000054EC18: D8D80000 3D00003D
	ds_load_b32 v62, v62                                       // 00000054EC20: D8D80000 3E00003E
	ds_load_b32 v2, v2                                         // 00000054EC28: D8D80000 02000002
	v_add_nc_u32_e32 v23, 0x200, v23                           // 00000054EC30: 4A2E2EFF 00000200
	v_add_nc_u32_e32 v24, 64, v24                              // 00000054EC38: 4A3030C0
	v_add_nc_u32_e32 v12, 0x400, v12                           // 00000054EC3C: 4A1818FF 00000400
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000054EC44: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000054EC48: BF870009
	s_or_b32 s14, s0, s14                                      // 00000054EC4C: 8C0E0E00
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 00000054EC50: BF891C77
	v_dot2_f32_bf16 v26, v26, v13, 0                           // 00000054EC54: CC1A401A 1A021B1A
	s_waitcnt vmcnt(6)                                         // 00000054EC5C: BF891BF7
	v_dot2_f32_bf16 v13, v30, v13, 0                           // 00000054EC60: CC1A400D 1A021B1E
	v_and_b32_e32 v30, 0xff, v3                                // 00000054EC68: 363C06FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 00000054EC70: BF89FC67
	v_dot2_f32_bf16 v26, v27, v58, v26                         // 00000054EC74: CC1A401A 1C6A751B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054EC7C: BF870003
	v_dot2_f32_bf16 v13, v31, v58, v13                         // 00000054EC80: CC1A400D 1C36751F
	v_lshrrev_b32_e32 v27, 6, v3                               // 00000054EC88: 32360686
	v_lshrrev_b32_e32 v31, 14, v3                              // 00000054EC8C: 323E068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 00000054EC90: 32060696
	s_waitcnt lgkmcnt(5)                                       // 00000054EC94: BF89FC57
	v_dot2_f32_bf16 v26, v28, v59, v26                         // 00000054EC98: CC1A401A 1C6A771C
	v_dot2_f32_bf16 v13, v32, v59, v13                         // 00000054ECA0: CC1A400D 1C367720
	v_and_b32_e32 v27, 0x3fc, v27                              // 00000054ECA8: 363636FF 000003FC
	v_and_b32_e32 v28, 0xff, v4                                // 00000054ECB0: 363808FF 000000FF
	v_lshrrev_b32_e32 v32, 6, v4                               // 00000054ECB8: 32400886
	s_waitcnt lgkmcnt(4)                                       // 00000054ECBC: BF89FC47
	v_dot2_f32_bf16 v26, v29, v1, v26                          // 00000054ECC0: CC1A401A 1C6A031D
	v_dot2_f32_bf16 v1, v33, v1, v13                           // 00000054ECC8: CC1A4001 1C360321
	v_lshlrev_b32_e32 v13, 2, v30                              // 00000054ECD0: 301A3C82
	v_and_b32_e32 v29, 0x3fc, v31                              // 00000054ECD4: 363A3EFF 000003FC
	v_lshrrev_b32_e32 v58, 14, v4                              // 00000054ECDC: 3274088E
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 00000054ECE0: BF891437
	v_dot2_f32_bf16 v26, v34, v60, v26                         // 00000054ECE4: CC1A401A 1C6A7922
	s_waitcnt vmcnt(4)                                         // 00000054ECEC: BF8913F7
	v_dot2_f32_bf16 v1, v38, v60, v1                           // 00000054ECF0: CC1A4001 1C067926
	ds_load_b32 v13, v13                                       // 00000054ECF8: D8D80000 0D00000D
	ds_load_b32 v27, v27                                       // 00000054ED00: D8D80000 1B00001B
	ds_load_b32 v29, v29                                       // 00000054ED08: D8D80000 1D00001D
	s_waitcnt lgkmcnt(5)                                       // 00000054ED10: BF89FC57
	v_dot2_f32_bf16 v26, v35, v61, v26                         // 00000054ED14: CC1A401A 1C6A7B23
	v_dot2_f32_bf16 v1, v39, v61, v1                           // 00000054ED1C: CC1A4001 1C067B27
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000054ED24: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 00000054ED28: 360606FF 000003FC
	v_lshlrev_b32_e32 v28, 2, v28                              // 00000054ED30: 30383882
	s_waitcnt lgkmcnt(4)                                       // 00000054ED34: BF89FC47
	v_dot2_f32_bf16 v26, v36, v62, v26                         // 00000054ED38: CC1A401A 1C6A7D24
	v_dot2_f32_bf16 v1, v40, v62, v1                           // 00000054ED40: CC1A4001 1C067D28
	v_and_b32_e32 v30, 0x3fc, v32                              // 00000054ED48: 363C40FF 000003FC
	v_and_b32_e32 v31, 0x3fc, v58                              // 00000054ED50: 363E74FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000054ED58: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 00000054ED60: BF89FC37
	v_dot2_f32_bf16 v26, v37, v2, v26                          // 00000054ED64: CC1A401A 1C6A0525
	v_dot2_f32_bf16 v1, v41, v2, v1                            // 00000054ED6C: CC1A4001 1C060529
	ds_load_b32 v2, v3                                         // 00000054ED74: D8D80000 02000003
	ds_load_b32 v3, v28                                        // 00000054ED7C: D8D80000 0300001C
	ds_load_b32 v28, v30                                       // 00000054ED84: D8D80000 1C00001E
	ds_load_b32 v30, v31                                       // 00000054ED8C: D8D80000 1E00001F
	ds_load_b32 v31, v4                                        // 00000054ED94: D8D80000 1F000004
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 00000054ED9C: BF890C77
	v_dot2_f32_bf16 v4, v42, v13, v26                          // 00000054EDA0: CC1A4004 1C6A1B2A
	s_waitcnt vmcnt(2)                                         // 00000054EDA8: BF890BF7
	v_dot2_f32_bf16 v1, v46, v13, v1                           // 00000054EDAC: CC1A4001 1C061B2E
	s_waitcnt lgkmcnt(6)                                       // 00000054EDB4: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054EDB8: BF870112
	v_dot2_f32_bf16 v4, v43, v27, v4                           // 00000054EDBC: CC1A4004 1C12372B
	v_dot2_f32_bf16 v1, v47, v27, v1                           // 00000054EDC4: CC1A4001 1C06372F
	s_waitcnt lgkmcnt(5)                                       // 00000054EDCC: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054EDD0: BF870112
	v_dot2_f32_bf16 v4, v44, v29, v4                           // 00000054EDD4: CC1A4004 1C123B2C
	v_dot2_f32_bf16 v1, v48, v29, v1                           // 00000054EDDC: CC1A4001 1C063B30
	s_waitcnt lgkmcnt(4)                                       // 00000054EDE4: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054EDE8: BF870112
	v_dot2_f32_bf16 v4, v45, v2, v4                            // 00000054EDEC: CC1A4004 1C12052D
	v_dot2_f32_bf16 v1, v49, v2, v1                            // 00000054EDF4: CC1A4001 1C060531
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 00000054EDFC: BF890437
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000054EE00: BF870122
	v_dot2_f32_bf16 v2, v50, v3, v4                            // 00000054EE04: CC1A4002 1C120732
	s_waitcnt vmcnt(0)                                         // 00000054EE0C: BF8903F7
	v_dot2_f32_bf16 v1, v54, v3, v1                            // 00000054EE10: CC1A4001 1C060736
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 00000054EE18: CA100108 04020107
	s_waitcnt lgkmcnt(2)                                       // 00000054EE20: BF89FC27
	v_dot2_f32_bf16 v2, v51, v28, v2                           // 00000054EE24: CC1A4002 1C0A3933
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000054EE2C: BF870123
	v_dot2_f32_bf16 v1, v55, v28, v1                           // 00000054EE30: CC1A4001 1C063937
	s_waitcnt lgkmcnt(1)                                       // 00000054EE38: BF89FC17
	v_dot2_f32_bf16 v2, v52, v30, v2                           // 00000054EE3C: CC1A4002 1C0A3D34
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000054EE44: BF870122
	v_dot2_f32_bf16 v1, v56, v30, v1                           // 00000054EE48: CC1A4001 1C063D38
	s_waitcnt lgkmcnt(0)                                       // 00000054EE50: BF89FC07
	v_dot2_f32_bf16 v7, v53, v31, v2                           // 00000054EE54: CC1A4007 1C0A3F35
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054EE5C: BF8701A2
	v_dot2_f32_bf16 v8, v57, v31, v1                           // 00000054EE60: CC1A4008 1C063F39
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 00000054EE68: CA100106 02000105
	v_fmac_f32_e32 v22, v18, v7                                // 00000054EE70: 562C0F12
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054EE74: BF870003
	v_dual_fmac_f32 v17, v18, v8 :: v_dual_mov_b32 v18, v25    // 00000054EE78: C8101112 11120119
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 00000054EE80: 917E0E7E
	s_cbranch_execz 31                                         // 00000054EE84: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x604>
	s_waitcnt vmcnt(0)                                         // 00000054EE88: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v10, 32, v10    // 00000054EE8C: CA200101 050A14A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 00000054EE94: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 00000054EE9C: 7E100304
	s_mov_b32 s10, exec_lo                                     // 00000054EEA0: BE8A007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054EEA4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v19                          // 00000054EEA8: 7C8C270A
	.long 0xd4c1007e                                           // 00000054EEAC: D4C1007E
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 00000054EEB0: 0202270A
	s_cbranch_execz 65303                                      // 00000054EEB4: BFA5FF17 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x214>
	v_ashrrev_i32_e32 v6, 31, v24                              // 00000054EEB8: 340C309F
	v_ashrrev_i32_e32 v8, 31, v23                              // 00000054EEBC: 34102E9F
	.long 0xd7000005                                           // 00000054EEC0: D7000005
	v_cndmask_b32_e32 v1, v11, v24, vcc_lo                     // 00000054EEC4: 0202310B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054EEC8: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s0                  // 00000054EECC: D5207C06 00020D15
	.long 0xd7000007                                           // 00000054EED4: D7000007
	v_cndmask_b32_e32 v1, v9, v23, vcc_lo                      // 00000054EED8: 02022F09
	v_add_co_ci_u32_e64 v8, null, v20, v8, s0                  // 00000054EEDC: D5207C08 00021114
	s_clause 0x1                                               // 00000054EEE4: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 00000054EEE8: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 00000054EEF0: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 00000054EEF8: BF8907F7
	v_cvt_f32_f16_e32 v25, v13                                 // 00000054EEFC: 7E32170D
	s_branch 65284                                             // 00000054EF00: BFA0FF04 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x214>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000054EF04: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000054EF08: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054EF0C: 8C7E017E
	s_waitcnt vmcnt(0)                                         // 00000054EF10: BF8903F7
	.long 0xd71f0001                                           // 00000054EF14: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000054EF18: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000054EF1C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000054EF20: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 00000054EF24: 3A080288
	v_xor_b32_e32 v6, 4, v1                                    // 00000054EF28: 3A0C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000054EF2C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000054EF30: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000054EF34: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000054EF38: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054EF3C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000054EF40: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000054EF44: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000054EF48: 7C980CA0
	ds_bpermute_b32 v3, v2, v22                                // 00000054EF4C: DACC0000 03001602
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000054EF54: 30080882
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 00000054EF58: 020C0D01
	s_waitcnt lgkmcnt(0)                                       // 00000054EF5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054EF60: BF870001
	v_dual_add_f32 v3, v22, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 00000054EF64: C9220716 03060C82
	ds_bpermute_b32 v5, v4, v3                                 // 00000054EF6C: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 00000054EF74: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000054EF78: 06060B03
	ds_bpermute_b32 v2, v2, v17                                // 00000054EF7C: DACC0000 02001102
	s_waitcnt lgkmcnt(0)                                       // 00000054EF84: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 00000054EF88: 06040511
	ds_bpermute_b32 v4, v4, v2                                 // 00000054EF8C: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 00000054EF94: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 00000054EF98: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 00000054EF9C: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 00000054EFA4: DACC0000 05000206
	v_xor_b32_e32 v6, 2, v1                                    // 00000054EFAC: 3A0C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000054EFB0: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000054EFB4: 7C980CA0
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 00000054EFB8: 020C0D01
	s_waitcnt lgkmcnt(1)                                       // 00000054EFBC: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v6  // 00000054EFC0: C9220903 03060C82
	s_waitcnt lgkmcnt(0)                                       // 00000054EFC8: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 00000054EFCC: 06040B02
	ds_bpermute_b32 v4, v6, v3                                 // 00000054EFD0: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 00000054EFD8: DACC0000 05000206
	v_xor_b32_e32 v6, 1, v1                                    // 00000054EFE0: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000054EFE4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000054EFE8: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 00000054EFEC: 02020D01
	s_waitcnt lgkmcnt(1)                                       // 00000054EFF0: BF89FC17
	v_dual_add_f32 v1, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v1  // 00000054EFF4: C9220903 01060282
	s_waitcnt lgkmcnt(0)                                       // 00000054EFFC: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 00000054F000: 06040B02
	ds_bpermute_b32 v3, v6, v1                                 // 00000054F004: DACC0000 03000106
	ds_bpermute_b32 v4, v6, v2                                 // 00000054F00C: DACC0000 04000206
	v_cmpx_eq_u32_e32 0, v16                                   // 00000054F014: 7D942080
	s_cbranch_execz 6                                          // 00000054F018: BFA50006 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x734>
	s_waitcnt lgkmcnt(0)                                       // 00000054F01C: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v5, 3, v15 // 00000054F020: C9220902 02041E83
	v_add_f32_e32 v1, v1, v3                                   // 00000054F028: 06020701
	ds_store_b64 v5, v[1:2] offset:1024                        // 00000054F02C: D9340400 00000105
	s_or_b32 exec_lo, exec_lo, s0                              // 00000054F034: 8C7E007E
	.long 0xd4510000                                           // 00000054F038: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000054F03C: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 2, v0                             // 00000054F040: 7C980082
	s_waitcnt lgkmcnt(0)                                       // 00000054F044: BF89FC07
	s_barrier                                                  // 00000054F048: BFBD0000
	buffer_gl0_inv                                             // 00000054F04C: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 00000054F054: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000054F058: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000054F05C: BE812000
	s_cbranch_execz 52                                         // 00000054F060: BFA50034 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x834>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 00000054F064: 4A0E1CFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 1                               // 00000054F06C: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:2                     // 00000054F070: D8DC0200 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:4 offset1:6           // 00000054F078: D8DC0604 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:8 offset1:10          // 00000054F080: D8DC0A08 05000007
	ds_load_2addr_b32 v[7:8], v7 offset0:12 offset1:14         // 00000054F088: D8DC0E0C 07000007
	s_waitcnt lgkmcnt(3)                                       // 00000054F090: BF89FC37
	v_add_f32_e32 v1, 0, v1                                    // 00000054F094: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054F098: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 00000054F09C: 06020501
	s_waitcnt lgkmcnt(2)                                       // 00000054F0A0: BF89FC27
	v_add_f32_e32 v1, v1, v3                                   // 00000054F0A4: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000054F0A8: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 00000054F0AC: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 00000054F0B0: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(1)                                       // 00000054F0B8: BF89FC17
	v_add_f32_e32 v3, v3, v5                                   // 00000054F0BC: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054F0C0: BF870191
	v_add_f32_e32 v4, v3, v6                                   // 00000054F0C4: 06080D03
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 00000054F0C8: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 00000054F0D0: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054F0D4: BF870092
	v_add_f32_e32 v0, v4, v7                                   // 00000054F0D8: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 00000054F0DC: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054F0E0: BF870113
	.long 0xd73c0000                                           // 00000054F0E4: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000054F0E8: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 00000054F0EC: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054F0F4: BF870092
	.long 0xd7006a00                                           // 00000054F0F8: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000054F0FC: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000054F100: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054F108: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000054F10C: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 00000054F118: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000054F11C: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054F120: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000054F124: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000054F12C: DC960000 007C0200
	s_endpgm                                                   // 00000054F134: BFB00000
		...

