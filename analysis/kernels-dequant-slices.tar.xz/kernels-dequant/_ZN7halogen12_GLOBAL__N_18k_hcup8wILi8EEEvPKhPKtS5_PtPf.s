00000000003da600 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi8EEEvPKhPKtS5_PtPf>:
; _ZN7halogen12_GLOBAL__N_18k_hcup8wILi8EEEvPKhPKtS5_PtPf():
	s_load_b256 s[4:11], s[0:1], null                          // 0000003DA600: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 6, v0                                // 0000003DA608: 32020086
	v_bfe_u32 v2, v0, 4, 2                                     // 0000003DA60C: D6100002 02090900
	s_lshl_b32 s2, s2, 2                                       // 0000003DA614: 84028202
	v_dual_mov_b32 v14, 0 :: v_dual_and_b32 v13, 15, v0        // 0000003DA618: CA240080 0E0C008F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DA620: BF870193
	v_or_b32_e32 v1, s2, v1                                    // 0000003DA624: 38020202
	v_mul_u32_u24_e32 v2, 0xa00, v2                            // 0000003DA628: 160404FF 00000A00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003DA630: BF870223
	v_lshlrev_b32_e32 v11, 4, v13                              // 0000003DA634: 30161A84
	v_or_b32_e32 v20, 16, v13                                  // 0000003DA638: 38281A90
	v_ashrrev_i32_e32 v3, 31, v1                               // 0000003DA63C: 3406029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA640: BF870094
	.long 0xd7006a01                                           // 0000003DA644: D7006A01
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000003DA648: 02020302
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 0000003DA64C: D5207C02 01AA0680
	v_and_b32_e32 v3, 12, v0                                   // 0000003DA654: 3606008C
	s_waitcnt lgkmcnt(0)                                       // 0000003DA658: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003DA65C: BF8700D3
	v_mad_u64_u32 v[9:10], null, 0x154, v1, s[4:5]             // 0000003DA660: D6FE7C09 001202FF 00000154
	s_load_b64 s[4:5], s[0:1], 0x20                            // 0000003DA66C: F4040100 F8000020
	s_mov_b32 s0, exec_lo                                      // 0000003DA674: BE80007E
	v_mad_i32_i24 v10, 0x154, v2, v10                          // 0000003DA678: D60A000A 042A04FF 00000154
	.long 0xd7006a01                                           // 0000003DA684: D7006A01
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 0000003DA688: 02021709
	v_add_co_ci_u32_e64 v2, null, 0, v10, vcc_lo               // 0000003DA68C: D5207C02 01AA1480
	.long 0xd7006a03                                           // 0000003DA694: D7006A03
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000003DA698: 02020709
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003DA69C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v10, vcc_lo               // 0000003DA6A0: D5207C04 01AA1480
	s_clause 0x1                                               // 0000003DA6A8: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 0000003DA6AC: DC5E0000 057C0001
	global_load_b32 v16, v[3:4], off offset:320                // 0000003DA6B4: DC520140 107C0003
	v_cmpx_gt_u32_e32 20, v20                                  // 0000003DA6BC: 7D982894
	s_cbranch_execz 5                                          // 0000003DA6C0: BFA50005 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi8EEEvPKhPKtS5_PtPf+0xd8>
	s_clause 0x1                                               // 0000003DA6C4: BF850001
	global_load_b128 v[1:4], v[1:2], off offset:256            // 0000003DA6C8: DC5E0100 017C0001
	global_load_b32 v14, v[9:10], off offset:336               // 0000003DA6D0: DC520150 0E7C0009
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003DA6D8: 8C7E007E
	v_lshlrev_b32_e32 v15, 1, v11                              // 0000003DA6DC: 301E1681
	s_waitcnt vmcnt(1)                                         // 0000003DA6E0: BF8907F7
	v_cvt_f32_ubyte0_e32 v17, v5                               // 0000003DA6E4: 7E222305
	v_cvt_f32_ubyte1_e32 v18, v5                               // 0000003DA6E8: 7E242505
	v_cvt_f32_ubyte2_e32 v19, v5                               // 0000003DA6EC: 7E262705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 0000003DA6F0: 7E0A2905
	.long 0xd700000b                                           // 0000003DA6F4: D700000B
	v_cndmask_b32_e32 v1, s6, v15, vcc_lo                      // 0000003DA6F8: 02021E06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003DA6FC: BF870001
	v_add_co_ci_u32_e64 v12, null, s7, 0, s0                   // 0000003DA700: D5207C0C 00010007
	s_clause 0x6                                               // 0000003DA708: BF850006
	global_load_b128 v[21:24], v15, s[6:7]                     // 0000003DA70C: DC5E0000 1506000F
	global_load_b128 v[25:28], v15, s[6:7] offset:640          // 0000003DA714: DC5E0280 1906000F
	global_load_b128 v[29:32], v15, s[6:7] offset:1280         // 0000003DA71C: DC5E0500 1D06000F
	global_load_b128 v[33:36], v15, s[6:7] offset:1920         // 0000003DA724: DC5E0780 2106000F
	global_load_b128 v[37:40], v15, s[6:7] offset:2560         // 0000003DA72C: DC5E0A00 2506000F
	global_load_b128 v[41:44], v15, s[6:7] offset:3200         // 0000003DA734: DC5E0C80 2906000F
	global_load_b128 v[45:48], v15, s[6:7] offset:3840         // 0000003DA73C: DC5E0F00 2D06000F
	.long 0xd7006a09                                           // 0000003DA744: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v11, vcc_lo                  // 0000003DA748: 020216FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003DA750: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v12, vcc_lo              // 0000003DA754: D5207C0A 01AA1880
	s_waitcnt vmcnt(7)                                         // 0000003DA75C: BF891FF7
	v_fma_mix_f32 v17, v17, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA760: CC206011 14422111
	v_cvt_f32_ubyte0_e32 v85, v6                               // 0000003DA768: 7EAA2306
	v_cvt_f32_ubyte1_e32 v86, v6                               // 0000003DA76C: 7EAC2506
	s_clause 0x8                                               // 0000003DA770: BF850008
	global_load_b128 v[49:52], v[9:10], off offset:384         // 0000003DA774: DC5E0180 317C0009
	global_load_b128 v[53:56], v15, s[6:7] offset:16           // 0000003DA77C: DC5E0010 3506000F
	global_load_b128 v[57:60], v15, s[6:7] offset:656          // 0000003DA784: DC5E0290 3906000F
	global_load_b128 v[61:64], v15, s[6:7] offset:1296         // 0000003DA78C: DC5E0510 3D06000F
	global_load_b128 v[65:68], v15, s[6:7] offset:1936         // 0000003DA794: DC5E0790 4106000F
	global_load_b128 v[69:72], v15, s[6:7] offset:2576         // 0000003DA79C: DC5E0A10 4506000F
	global_load_b128 v[73:76], v15, s[6:7] offset:3216         // 0000003DA7A4: DC5E0C90 4906000F
	global_load_b128 v[77:80], v15, s[6:7] offset:3856         // 0000003DA7AC: DC5E0F10 4D06000F
	global_load_b128 v[81:84], v[9:10], off offset:400         // 0000003DA7B4: DC5E0190 517C0009
	v_cvt_f32_ubyte2_e32 v87, v6                               // 0000003DA7BC: 7EAE2706
	v_fma_mix_f32 v18, v18, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA7C0: CC206012 14422112
	v_fma_mix_f32 v19, v19, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA7C8: CC206013 14422113
	v_fma_mix_f32 v5, v5, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA7D0: CC206005 14422105
	v_bfe_u32 v94, v17, 16, 1                                  // 0000003DA7D8: D610005E 02052111
	v_cvt_f32_ubyte0_e32 v88, v7                               // 0000003DA7E0: 7EB02307
	v_cvt_f32_ubyte1_e32 v89, v7                               // 0000003DA7E4: 7EB22507
	v_fma_mix_f32 v85, v85, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA7E8: CC206055 14422155
	v_fma_mix_f32 v86, v86, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA7F0: CC206056 14422156
	v_fma_mix_f32 v87, v87, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA7F8: CC206057 14422157
	v_bfe_u32 v96, v18, 16, 1                                  // 0000003DA800: D6100060 02052112
	v_bfe_u32 v98, v19, 16, 1                                  // 0000003DA808: D6100062 02052113
	v_add3_u32 v17, v17, v94, 0x7fff                           // 0000003DA810: D6550011 03FEBD11 00007FFF
	v_bfe_u32 v94, v5, 16, 1                                   // 0000003DA81C: D610005E 02052105
	v_cvt_f32_ubyte0_e32 v91, v8                               // 0000003DA824: 7EB62308
	v_fma_mix_f32 v88, v88, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA828: CC206058 14422158
	v_fma_mix_f32 v89, v89, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA830: CC206059 14422159
	v_add3_u32 v18, v18, v96, 0x7fff                           // 0000003DA838: D6550012 03FEC112 00007FFF
	v_bfe_u32 v96, v85, 16, 1                                  // 0000003DA844: D6100060 02052155
	v_add3_u32 v19, v19, v98, 0x7fff                           // 0000003DA84C: D6550013 03FEC513 00007FFF
	v_bfe_u32 v98, v86, 16, 1                                  // 0000003DA858: D6100062 02052156
	v_add3_u32 v5, v5, v94, 0x7fff                             // 0000003DA860: D6550005 03FEBD05 00007FFF
	v_bfe_u32 v94, v87, 16, 1                                  // 0000003DA86C: D610005E 02052157
	v_cvt_f32_ubyte1_e32 v92, v8                               // 0000003DA874: 7EB82508
	.long 0x7f1e3880                                           // 0000003DA878: 7F1E3880
	v_fma_mix_f32 v91, v91, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA87C: CC20605B 1442215B
	v_add3_u32 v85, v85, v96, 0x7fff                           // 0000003DA884: D6550055 03FEC155 00007FFF
	v_add3_u32 v86, v86, v98, 0x7fff                           // 0000003DA890: D6550056 03FEC556 00007FFF
	v_bfe_u32 v98, v88, 16, 1                                  // 0000003DA89C: D6100062 02052158
	v_add3_u32 v87, v87, v94, 0x7fff                           // 0000003DA8A4: D6550057 03FEBD57 00007FFF
	v_bfe_u32 v94, v89, 16, 1                                  // 0000003DA8B0: D610005E 02052159
	.long 0x7e1e3991                                           // 0000003DA8B8: 7E1E3991
	v_fma_mix_f32 v92, v92, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA8BC: CC20605C 1442215C
	v_add3_u32 v88, v88, v98, 0x7fff                           // 0000003DA8C4: D6550058 03FEC558 00007FFF
	v_cvt_f32_ubyte3_e32 v6, v6                                // 0000003DA8D0: 7E0C2906
	v_add3_u32 v89, v89, v94, 0x7fff                           // 0000003DA8D4: D6550059 03FEBD59 00007FFF
	v_bfe_u32 v94, v91, 16, 1                                  // 0000003DA8E0: D610005E 0205215B
	v_and_or_b32 v18, 0xffff0000, v18, v15                     // 0000003DA8E8: D6570012 043E24FF FFFF0000
	.long 0x7e1e39d5                                           // 0000003DA8F4: 7E1E39D5
	v_cvt_f32_ubyte2_e32 v90, v7                               // 0000003DA8F8: 7EB42707
	v_cvt_f32_ubyte3_e32 v7, v7                                // 0000003DA8FC: 7E0E2907
	v_cvt_f32_ubyte2_e32 v93, v8                               // 0000003DA900: 7EBA2708
	v_cvt_f32_ubyte3_e32 v8, v8                                // 0000003DA904: 7E102908
	v_bfe_u32 v17, v92, 16, 1                                  // 0000003DA908: D6100011 0205215C
	v_add3_u32 v91, v91, v94, 0x7fff                           // 0000003DA910: D655005B 03FEBD5B 00007FFF
	v_and_or_b32 v86, 0xffff0000, v86, v15                     // 0000003DA91C: D6570056 043EACFF FFFF0000
	.long 0x7e1e39d8                                           // 0000003DA928: 7E1E39D8
	v_fma_mix_f32 v6, v6, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA92C: CC206006 14422106
	v_fma_mix_f32 v90, v90, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA934: CC20605A 1442215A
	v_fma_mix_f32 v7, v7, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA93C: CC206007 14422107
	v_fma_mix_f32 v93, v93, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA944: CC20605D 1442215D
	v_fma_mix_f32 v8, v8, v16, v16 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DA94C: CC206008 14422108
	.long 0x7f20398f                                           // 0000003DA954: 7F20398F
	v_add3_u32 v17, v92, v17, 0x7fff                           // 0000003DA958: D6550011 03FE235C 00007FFF
	.long 0x7e203993                                           // 0000003DA964: 7E203993
	v_and_or_b32 v19, 0xffff0000, v89, v15                     // 0000003DA968: D6570013 043EB2FF FFFF0000
	.long 0x7e1e39db                                           // 0000003DA974: 7E1E39DB
	v_bfe_u32 v96, v6, 16, 1                                   // 0000003DA978: D6100060 02052106
	.long 0x7fbe398f                                           // 0000003DA980: 7FBE398F
	v_and_or_b32 v5, 0xffff0000, v5, v16                       // 0000003DA984: D6570005 04420AFF FFFF0000
	.long 0x7ebe39d7                                           // 0000003DA990: 7EBE39D7
	v_and_or_b32 v16, 0xffff0000, v17, v15                     // 0000003DA994: D6570010 043E22FF FFFF0000
	v_add3_u32 v6, v6, v96, 0x7fff                             // 0000003DA9A0: D6550006 03FEC106 00007FFF
	v_bfe_u32 v96, v90, 16, 1                                  // 0000003DA9AC: D6100060 0205215A
	v_bfe_u32 v98, v7, 16, 1                                   // 0000003DA9B4: D6100062 02052107
	.long 0x7fc2398f                                           // 0000003DA9BC: 7FC2398F
	.long 0x7faa398f                                           // 0000003DA9C0: 7FAA398F
	v_and_or_b32 v6, 0xffff0000, v6, v95                       // 0000003DA9C4: D6570006 057E0CFF FFFF0000
	v_add3_u32 v90, v90, v96, 0x7fff                           // 0000003DA9D0: D655005A 03FEC15A 00007FFF
	v_bfe_u32 v96, v93, 16, 1                                  // 0000003DA9DC: D6100060 0205215D
	v_add3_u32 v7, v7, v98, 0x7fff                             // 0000003DA9E4: D6550007 03FEC507 00007FFF
	v_bfe_u32 v98, v8, 16, 1                                   // 0000003DA9F0: D6100062 02052108
	s_mov_b32 s0, exec_lo                                      // 0000003DA9F8: BE80007E
	.long 0x7ec239da                                           // 0000003DA9FC: 7EC239DA
	v_add3_u32 v92, v93, v96, 0x7fff                           // 0000003DAA00: D655005C 03FEC15D 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DAA0C: BF870193
	v_add3_u32 v8, v8, v98, 0x7fff                             // 0000003DAA10: D6550008 03FEC508 00007FFF
	v_and_or_b32 v7, 0xffff0000, v7, v97                       // 0000003DAA1C: D6570007 05860EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DAA28: BF870093
	.long 0x7eaa39dc                                           // 0000003DAA2C: 7EAA39DC
	v_and_or_b32 v8, 0xffff0000, v8, v85                       // 0000003DAA30: D6570008 055610FF FFFF0000
	s_waitcnt vmcnt(15)                                        // 0000003DAA3C: BF893FF7
	v_dot2_f32_bf16 v17, v21, v18, 0                           // 0000003DAA40: CC1A4011 1A022515
	s_waitcnt vmcnt(14)                                        // 0000003DAA48: BF893BF7
	v_dot2_f32_bf16 v21, v25, v18, 0                           // 0000003DAA4C: CC1A4015 1A022519
	s_waitcnt vmcnt(13)                                        // 0000003DAA54: BF8937F7
	v_dot2_f32_bf16 v25, v29, v18, 0                           // 0000003DAA58: CC1A4019 1A02251D
	s_waitcnt vmcnt(12)                                        // 0000003DAA60: BF8933F7
	v_dot2_f32_bf16 v29, v33, v18, 0                           // 0000003DAA64: CC1A401D 1A022521
	s_waitcnt vmcnt(11)                                        // 0000003DAA6C: BF892FF7
	v_dot2_f32_bf16 v33, v37, v18, 0                           // 0000003DAA70: CC1A4021 1A022525
	s_waitcnt vmcnt(10)                                        // 0000003DAA78: BF892BF7
	v_dot2_f32_bf16 v37, v41, v18, 0                           // 0000003DAA7C: CC1A4025 1A022529
	s_waitcnt vmcnt(9)                                         // 0000003DAA84: BF8927F7
	v_dot2_f32_bf16 v41, v45, v18, 0                           // 0000003DAA88: CC1A4029 1A02252D
	v_dot2_f32_bf16 v17, v22, v5, v17                          // 0000003DAA90: CC1A4011 1C460B16
	s_waitcnt vmcnt(8)                                         // 0000003DAA98: BF8923F7
	v_dot2_f32_bf16 v18, v49, v18, 0                           // 0000003DAA9C: CC1A4012 1A022531
	v_dot2_f32_bf16 v21, v26, v5, v21                          // 0000003DAAA4: CC1A4015 1C560B1A
	v_dot2_f32_bf16 v22, v30, v5, v25                          // 0000003DAAAC: CC1A4016 1C660B1E
	v_dot2_f32_bf16 v25, v34, v5, v29                          // 0000003DAAB4: CC1A4019 1C760B22
	v_dot2_f32_bf16 v26, v38, v5, v33                          // 0000003DAABC: CC1A401A 1C860B26
	v_dot2_f32_bf16 v29, v42, v5, v37                          // 0000003DAAC4: CC1A401D 1C960B2A
	v_dot2_f32_bf16 v30, v46, v5, v41                          // 0000003DAACC: CC1A401E 1CA60B2E
	v_dot2_f32_bf16 v17, v23, v86, v17                         // 0000003DAAD4: CC1A4011 1C46AD17
	v_dot2_f32_bf16 v5, v50, v5, v18                           // 0000003DAADC: CC1A4005 1C4A0B32
	v_dot2_f32_bf16 v21, v27, v86, v21                         // 0000003DAAE4: CC1A4015 1C56AD1B
	v_dot2_f32_bf16 v22, v31, v86, v22                         // 0000003DAAEC: CC1A4016 1C5AAD1F
	v_dot2_f32_bf16 v23, v35, v86, v25                         // 0000003DAAF4: CC1A4017 1C66AD23
	v_dot2_f32_bf16 v25, v39, v86, v26                         // 0000003DAAFC: CC1A4019 1C6AAD27
	v_dot2_f32_bf16 v26, v43, v86, v29                         // 0000003DAB04: CC1A401A 1C76AD2B
	v_dot2_f32_bf16 v27, v47, v86, v30                         // 0000003DAB0C: CC1A401B 1C7AAD2F
	v_dot2_f32_bf16 v17, v24, v6, v17                          // 0000003DAB14: CC1A4011 1C460D18
	v_dot2_f32_bf16 v5, v51, v86, v5                           // 0000003DAB1C: CC1A4005 1C16AD33
	v_dot2_f32_bf16 v21, v28, v6, v21                          // 0000003DAB24: CC1A4015 1C560D1C
	v_dot2_f32_bf16 v22, v32, v6, v22                          // 0000003DAB2C: CC1A4016 1C5A0D20
	v_dot2_f32_bf16 v23, v36, v6, v23                          // 0000003DAB34: CC1A4017 1C5E0D24
	v_dot2_f32_bf16 v24, v40, v6, v25                          // 0000003DAB3C: CC1A4018 1C660D28
	v_dot2_f32_bf16 v25, v44, v6, v26                          // 0000003DAB44: CC1A4019 1C6A0D2C
	v_dot2_f32_bf16 v26, v48, v6, v27                          // 0000003DAB4C: CC1A401A 1C6E0D30
	s_waitcnt vmcnt(7)                                         // 0000003DAB54: BF891FF7
	v_dot2_f32_bf16 v17, v53, v19, v17                         // 0000003DAB58: CC1A4011 1C462735
	v_dot2_f32_bf16 v5, v52, v6, v5                            // 0000003DAB60: CC1A4005 1C160D34
	s_waitcnt vmcnt(6)                                         // 0000003DAB68: BF891BF7
	v_dot2_f32_bf16 v18, v57, v19, v21                         // 0000003DAB6C: CC1A4012 1C562739
	s_waitcnt vmcnt(5)                                         // 0000003DAB74: BF8917F7
	v_dot2_f32_bf16 v21, v61, v19, v22                         // 0000003DAB78: CC1A4015 1C5A273D
	s_waitcnt vmcnt(4)                                         // 0000003DAB80: BF8913F7
	v_dot2_f32_bf16 v22, v65, v19, v23                         // 0000003DAB84: CC1A4016 1C5E2741
	s_waitcnt vmcnt(3)                                         // 0000003DAB8C: BF890FF7
	v_dot2_f32_bf16 v23, v69, v19, v24                         // 0000003DAB90: CC1A4017 1C622745
	s_waitcnt vmcnt(2)                                         // 0000003DAB98: BF890BF7
	v_dot2_f32_bf16 v24, v73, v19, v25                         // 0000003DAB9C: CC1A4018 1C662749
	s_waitcnt vmcnt(1)                                         // 0000003DABA4: BF8907F7
	v_dot2_f32_bf16 v25, v77, v19, v26                         // 0000003DABA8: CC1A4019 1C6A274D
	v_dot2_f32_bf16 v17, v54, v7, v17                          // 0000003DABB0: CC1A4011 1C460F36
	s_waitcnt vmcnt(0)                                         // 0000003DABB8: BF8903F7
	v_dot2_f32_bf16 v5, v81, v19, v5                           // 0000003DABBC: CC1A4005 1C162751
	v_dot2_f32_bf16 v18, v58, v7, v18                          // 0000003DABC4: CC1A4012 1C4A0F3A
	v_dot2_f32_bf16 v21, v62, v7, v21                          // 0000003DABCC: CC1A4015 1C560F3E
	v_dot2_f32_bf16 v22, v66, v7, v22                          // 0000003DABD4: CC1A4016 1C5A0F42
	v_dot2_f32_bf16 v23, v70, v7, v23                          // 0000003DABDC: CC1A4017 1C5E0F46
	v_dot2_f32_bf16 v24, v74, v7, v24                          // 0000003DABE4: CC1A4018 1C620F4A
	v_dot2_f32_bf16 v25, v78, v7, v25                          // 0000003DABEC: CC1A4019 1C660F4E
	v_dot2_f32_bf16 v6, v55, v16, v17                          // 0000003DABF4: CC1A4006 1C462137
	v_dot2_f32_bf16 v5, v82, v7, v5                            // 0000003DABFC: CC1A4005 1C160F52
	v_dot2_f32_bf16 v17, v59, v16, v18                         // 0000003DAC04: CC1A4011 1C4A213B
	v_dot2_f32_bf16 v18, v63, v16, v21                         // 0000003DAC0C: CC1A4012 1C56213F
	v_dot2_f32_bf16 v21, v67, v16, v22                         // 0000003DAC14: CC1A4015 1C5A2143
	v_dot2_f32_bf16 v22, v71, v16, v23                         // 0000003DAC1C: CC1A4016 1C5E2147
	v_dot2_f32_bf16 v19, v75, v16, v24                         // 0000003DAC24: CC1A4013 1C62214B
	v_dot2_f32_bf16 v23, v79, v16, v25                         // 0000003DAC2C: CC1A4017 1C66214F
	v_dot2_f32_bf16 v6, v56, v8, v6                            // 0000003DAC34: CC1A4006 1C1A1138
	v_dot2_f32_bf16 v5, v83, v16, v5                           // 0000003DAC3C: CC1A4005 1C162153
	v_dot2_f32_bf16 v17, v60, v8, v17                          // 0000003DAC44: CC1A4011 1C46113C
	v_dot2_f32_bf16 v7, v64, v8, v18                           // 0000003DAC4C: CC1A4007 1C4A1140
	v_dot2_f32_bf16 v21, v68, v8, v21                          // 0000003DAC54: CC1A4015 1C561144
	v_dot2_f32_bf16 v22, v72, v8, v22                          // 0000003DAC5C: CC1A4016 1C5A1148
	v_dot2_f32_bf16 v24, v76, v8, v19                          // 0000003DAC64: CC1A4018 1C4E114C
	v_dot2_f32_bf16 v23, v80, v8, v23                          // 0000003DAC6C: CC1A4017 1C5E1150
	v_add_f32_e32 v18, 0, v6                                   // 0000003DAC74: 06240C80
	v_dot2_f32_bf16 v6, v84, v8, v5                            // 0000003DAC78: CC1A4006 1C161154
	v_dual_add_f32 v19, 0, v17 :: v_dual_add_f32 v16, 0, v7    // 0000003DAC80: C9082280 13100E80
	v_dual_add_f32 v17, 0, v21 :: v_dual_add_f32 v8, 0, v24    // 0000003DAC88: C9082A80 11083080
	v_add_f32_e32 v7, 0, v22                                   // 0000003DAC90: 060E2C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003DAC94: BF870004
	v_dual_add_f32 v5, 0, v23 :: v_dual_add_f32 v6, 0, v6      // 0000003DAC98: C9082E80 05060C80
	v_cmpx_gt_u32_e32 20, v20                                  // 0000003DACA0: 7D982894
	s_cbranch_execz 358                                        // 0000003DACA4: BFA50166 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi8EEEvPKhPKtS5_PtPf+0xc40>
	s_clause 0x6                                               // 0000003DACA8: BF850006
	global_load_b128 v[20:23], v[11:12], off offset:512        // 0000003DACAC: DC5E0200 147C000B
	global_load_b128 v[24:27], v[11:12], off offset:1152       // 0000003DACB4: DC5E0480 187C000B
	global_load_b128 v[28:31], v[11:12], off offset:1792       // 0000003DACBC: DC5E0700 1C7C000B
	global_load_b128 v[32:35], v[11:12], off offset:2432       // 0000003DACC4: DC5E0980 207C000B
	global_load_b128 v[36:39], v[11:12], off offset:3072       // 0000003DACCC: DC5E0C00 247C000B
	global_load_b128 v[40:43], v[11:12], off offset:3712       // 0000003DACD4: DC5E0E80 287C000B
	global_load_b128 v[44:47], v[9:10], off offset:896         // 0000003DACDC: DC5E0380 2C7C0009
	.long 0xd7006a4c                                           // 0000003DACE4: D7006A4C
	v_cndmask_b32_e32 v1, 0x200, v11, vcc_lo                   // 0000003DACE8: 020216FF 00000200
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003DACF0: BF870001
	v_add_co_ci_u32_e64 v77, null, 0, v12, vcc_lo              // 0000003DACF4: D5207C4D 01AA1880
	v_cvt_f32_ubyte0_e32 v80, v1                               // 0000003DACFC: 7EA02301
	v_cvt_f32_ubyte1_e32 v81, v1                               // 0000003DAD00: 7EA22501
	s_clause 0x8                                               // 0000003DAD04: BF850008
	global_load_b128 v[48:51], v[76:77], off offset:3840       // 0000003DAD08: DC5E0F00 307C004C
	global_load_b128 v[52:55], v[11:12], off offset:528        // 0000003DAD10: DC5E0210 347C000B
	global_load_b128 v[56:59], v[11:12], off offset:1168       // 0000003DAD18: DC5E0490 387C000B
	global_load_b128 v[60:63], v[11:12], off offset:1808       // 0000003DAD20: DC5E0710 3C7C000B
	global_load_b128 v[64:67], v[11:12], off offset:2448       // 0000003DAD28: DC5E0990 407C000B
	global_load_b128 v[68:71], v[11:12], off offset:3088       // 0000003DAD30: DC5E0C10 447C000B
	global_load_b128 v[72:75], v[11:12], off offset:3728       // 0000003DAD38: DC5E0E90 487C000B
	global_load_b128 v[9:12], v[9:10], off offset:912          // 0000003DAD40: DC5E0390 097C0009
	global_load_b128 v[76:79], v[76:77], off offset:3856       // 0000003DAD48: DC5E0F10 4C7C004C
	v_cvt_f32_ubyte2_e32 v82, v1                               // 0000003DAD50: 7EA42701
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000003DAD54: 7E022901
	v_cvt_f32_ubyte0_e32 v83, v2                               // 0000003DAD58: 7EA62302
	v_cvt_f32_ubyte1_e32 v84, v2                               // 0000003DAD5C: 7EA82502
	v_cvt_f32_ubyte2_e32 v85, v2                               // 0000003DAD60: 7EAA2702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 0000003DAD64: 7E042902
	v_cvt_f32_ubyte0_e32 v86, v3                               // 0000003DAD68: 7EAC2303
	v_cvt_f32_ubyte1_e32 v87, v3                               // 0000003DAD6C: 7EAE2503
	v_cvt_f32_ubyte2_e32 v88, v3                               // 0000003DAD70: 7EB02703
	v_cvt_f32_ubyte3_e32 v3, v3                                // 0000003DAD74: 7E062903
	v_cvt_f32_ubyte0_e32 v89, v4                               // 0000003DAD78: 7EB22304
	v_cvt_f32_ubyte1_e32 v90, v4                               // 0000003DAD7C: 7EB42504
	v_cvt_f32_ubyte2_e32 v91, v4                               // 0000003DAD80: 7EB62704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000003DAD84: 7E082904
	v_fma_mix_f32 v80, v80, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DAD88: CC206050 143A1D50
	v_fma_mix_f32 v81, v81, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DAD90: CC206051 143A1D51
	v_fma_mix_f32 v82, v82, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DAD98: CC206052 143A1D52
	v_fma_mix_f32 v1, v1, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DADA0: CC206001 143A1D01
	v_fma_mix_f32 v83, v83, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DADA8: CC206053 143A1D53
	v_fma_mix_f32 v84, v84, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DADB0: CC206054 143A1D54
	v_fma_mix_f32 v85, v85, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DADB8: CC206055 143A1D55
	v_fma_mix_f32 v2, v2, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DADC0: CC206002 143A1D02
	v_fma_mix_f32 v86, v86, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DADC8: CC206056 143A1D56
	v_fma_mix_f32 v87, v87, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DADD0: CC206057 143A1D57
	v_fma_mix_f32 v88, v88, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DADD8: CC206058 143A1D58
	v_fma_mix_f32 v3, v3, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DADE0: CC206003 143A1D03
	v_fma_mix_f32 v89, v89, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DADE8: CC206059 143A1D59
	v_fma_mix_f32 v90, v90, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DADF0: CC20605A 143A1D5A
	v_fma_mix_f32 v91, v91, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DADF8: CC20605B 143A1D5B
	v_fma_mix_f32 v4, v4, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003DAE00: CC206004 143A1D04
	v_bfe_u32 v14, v80, 16, 1                                  // 0000003DAE08: D610000E 02052150
	v_bfe_u32 v96, v81, 16, 1                                  // 0000003DAE10: D6100060 02052151
	v_bfe_u32 v97, v82, 16, 1                                  // 0000003DAE18: D6100061 02052152
	v_bfe_u32 v98, v1, 16, 1                                   // 0000003DAE20: D6100062 02052101
	.long 0x7fb8398f                                           // 0000003DAE28: 7FB8398F
	v_add3_u32 v14, v80, v14, 0x7fff                           // 0000003DAE2C: D655000E 03FE1D50 00007FFF
	v_add3_u32 v80, v81, v96, 0x7fff                           // 0000003DAE38: D6550050 03FEC151 00007FFF
	v_add3_u32 v81, v82, v97, 0x7fff                           // 0000003DAE44: D6550051 03FEC352 00007FFF
	v_bfe_u32 v99, v83, 16, 1                                  // 0000003DAE50: D6100063 02052153
	v_add3_u32 v1, v1, v98, 0x7fff                             // 0000003DAE58: D6550001 03FEC501 00007FFF
	.long 0x7e1e398e                                           // 0000003DAE64: 7E1E398E
	v_bfe_u32 v100, v84, 16, 1                                 // 0000003DAE68: D6100064 02052154
	.long 0x7eb839d1                                           // 0000003DAE70: 7EB839D1
	v_bfe_u32 v101, v85, 16, 1                                 // 0000003DAE74: D6100065 02052155
	v_add3_u32 v82, v83, v99, 0x7fff                           // 0000003DAE7C: D6550052 03FEC753 00007FFF
	v_and_or_b32 v80, 0xffff0000, v80, v15                     // 0000003DAE88: D6570050 043EA0FF FFFF0000
	v_bfe_u32 v102, v2, 16, 1                                  // 0000003DAE94: D6100066 02052102
	v_and_or_b32 v1, 0xffff0000, v1, v92                       // 0000003DAE9C: D6570001 057202FF FFFF0000
	v_bfe_u32 v103, v86, 16, 1                                 // 0000003DAEA8: D6100067 02052156
	v_add3_u32 v83, v84, v100, 0x7fff                          // 0000003DAEB0: D6550053 03FEC954 00007FFF
	v_add3_u32 v84, v85, v101, 0x7fff                          // 0000003DAEBC: D6550054 03FECB55 00007FFF
	.long 0x7e1e39d2                                           // 0000003DAEC8: 7E1E39D2
	.long 0x7fba398f                                           // 0000003DAECC: 7FBA398F
	v_bfe_u32 v104, v87, 16, 1                                 // 0000003DAED0: D6100068 02052157
	v_bfe_u32 v105, v88, 16, 1                                 // 0000003DAED8: D6100069 02052158
	v_add3_u32 v2, v2, v102, 0x7fff                            // 0000003DAEE0: D6550002 03FECD02 00007FFF
	v_add3_u32 v14, v86, v103, 0x7fff                          // 0000003DAEEC: D655000E 03FECF56 00007FFF
	v_and_or_b32 v83, 0xffff0000, v83, v15                     // 0000003DAEF8: D6570053 043EA6FF FFFF0000
	.long 0x7eba39d4                                           // 0000003DAF04: 7EBA39D4
	v_bfe_u32 v106, v3, 16, 1                                  // 0000003DAF08: D610006A 02052103
	v_bfe_u32 v107, v89, 16, 1                                 // 0000003DAF10: D610006B 02052159
	v_add3_u32 v85, v87, v104, 0x7fff                          // 0000003DAF18: D6550055 03FED157 00007FFF
	v_add3_u32 v86, v88, v105, 0x7fff                          // 0000003DAF24: D6550056 03FED358 00007FFF
	.long 0x7e1e398e                                           // 0000003DAF30: 7E1E398E
	v_and_or_b32 v2, 0xffff0000, v2, v93                       // 0000003DAF34: D6570002 057604FF FFFF0000
	.long 0x7fbc398f                                           // 0000003DAF40: 7FBC398F
	v_bfe_u32 v108, v90, 16, 1                                 // 0000003DAF44: D610006C 0205215A
	v_bfe_u32 v109, v91, 16, 1                                 // 0000003DAF4C: D610006D 0205215B
	v_add3_u32 v3, v3, v106, 0x7fff                            // 0000003DAF54: D6550003 03FED503 00007FFF
	v_add3_u32 v82, v89, v107, 0x7fff                          // 0000003DAF60: D6550052 03FED759 00007FFF
	.long 0x7ebc39d6                                           // 0000003DAF6C: 7EBC39D6
	v_and_or_b32 v14, 0xffff0000, v85, v15                     // 0000003DAF70: D657000E 043EAAFF FFFF0000
	v_bfe_u32 v110, v4, 16, 1                                  // 0000003DAF7C: D610006E 02052104
	v_add3_u32 v87, v90, v108, 0x7fff                          // 0000003DAF84: D6550057 03FED95A 00007FFF
	v_add3_u32 v88, v91, v109, 0x7fff                          // 0000003DAF90: D6550058 03FEDB5B 00007FFF
	.long 0x7e1e39d2                                           // 0000003DAF9C: 7E1E39D2
	v_and_or_b32 v3, 0xffff0000, v3, v94                       // 0000003DAFA0: D6570003 057A06FF FFFF0000
	.long 0x7fbe398f                                           // 0000003DAFAC: 7FBE398F
	v_add3_u32 v4, v4, v110, 0x7fff                            // 0000003DAFB0: D6550004 03FEDD04 00007FFF
	.long 0x7ebe39d8                                           // 0000003DAFBC: 7EBE39D8
	v_and_or_b32 v15, 0xffff0000, v87, v15                     // 0000003DAFC0: D657000F 043EAEFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003DAFCC: BF870002
	v_and_or_b32 v4, 0xffff0000, v4, v95                       // 0000003DAFD0: D6570004 057E08FF FFFF0000
	s_waitcnt vmcnt(15)                                        // 0000003DAFDC: BF893FF7
	v_dot2_f32_bf16 v20, v20, v80, 0                           // 0000003DAFE0: CC1A4014 1A02A114
	s_waitcnt vmcnt(14)                                        // 0000003DAFE8: BF893BF7
	v_dot2_f32_bf16 v24, v24, v80, 0                           // 0000003DAFEC: CC1A4018 1A02A118
	s_waitcnt vmcnt(13)                                        // 0000003DAFF4: BF8937F7
	v_dot2_f32_bf16 v28, v28, v80, 0                           // 0000003DAFF8: CC1A401C 1A02A11C
	s_waitcnt vmcnt(12)                                        // 0000003DB000: BF8933F7
	v_dot2_f32_bf16 v32, v32, v80, 0                           // 0000003DB004: CC1A4020 1A02A120
	s_waitcnt vmcnt(11)                                        // 0000003DB00C: BF892FF7
	v_dot2_f32_bf16 v36, v36, v80, 0                           // 0000003DB010: CC1A4024 1A02A124
	s_waitcnt vmcnt(10)                                        // 0000003DB018: BF892BF7
	v_dot2_f32_bf16 v40, v40, v80, 0                           // 0000003DB01C: CC1A4028 1A02A128
	s_waitcnt vmcnt(9)                                         // 0000003DB024: BF8927F7
	v_dot2_f32_bf16 v44, v44, v80, 0                           // 0000003DB028: CC1A402C 1A02A12C
	v_dot2_f32_bf16 v20, v21, v1, v20                          // 0000003DB030: CC1A4014 1C520315
	v_dot2_f32_bf16 v21, v25, v1, v24                          // 0000003DB038: CC1A4015 1C620319
	v_dot2_f32_bf16 v25, v33, v1, v32                          // 0000003DB040: CC1A4019 1C820321
	s_waitcnt vmcnt(8)                                         // 0000003DB048: BF8923F7
	v_dot2_f32_bf16 v33, v48, v80, 0                           // 0000003DB04C: CC1A4021 1A02A130
	v_dot2_f32_bf16 v24, v29, v1, v28                          // 0000003DB054: CC1A4018 1C72031D
	v_dot2_f32_bf16 v28, v37, v1, v36                          // 0000003DB05C: CC1A401C 1C920325
	v_dot2_f32_bf16 v29, v41, v1, v40                          // 0000003DB064: CC1A401D 1CA20329
	v_dot2_f32_bf16 v32, v45, v1, v44                          // 0000003DB06C: CC1A4020 1CB2032D
	v_dot2_f32_bf16 v1, v49, v1, v33                           // 0000003DB074: CC1A4001 1C860331
	v_dot2_f32_bf16 v20, v22, v83, v20                         // 0000003DB07C: CC1A4014 1C52A716
	v_dot2_f32_bf16 v21, v26, v83, v21                         // 0000003DB084: CC1A4015 1C56A71A
	v_dot2_f32_bf16 v22, v30, v83, v24                         // 0000003DB08C: CC1A4016 1C62A71E
	v_dot2_f32_bf16 v24, v34, v83, v25                         // 0000003DB094: CC1A4018 1C66A722
	v_dot2_f32_bf16 v25, v38, v83, v28                         // 0000003DB09C: CC1A4019 1C72A726
	v_dot2_f32_bf16 v26, v42, v83, v29                         // 0000003DB0A4: CC1A401A 1C76A72A
	v_dot2_f32_bf16 v28, v46, v83, v32                         // 0000003DB0AC: CC1A401C 1C82A72E
	v_dot2_f32_bf16 v1, v50, v83, v1                           // 0000003DB0B4: CC1A4001 1C06A732
	v_dot2_f32_bf16 v20, v23, v2, v20                          // 0000003DB0BC: CC1A4014 1C520517
	v_dot2_f32_bf16 v21, v27, v2, v21                          // 0000003DB0C4: CC1A4015 1C56051B
	v_dot2_f32_bf16 v22, v31, v2, v22                          // 0000003DB0CC: CC1A4016 1C5A051F
	v_dot2_f32_bf16 v23, v35, v2, v24                          // 0000003DB0D4: CC1A4017 1C620523
	v_dot2_f32_bf16 v24, v39, v2, v25                          // 0000003DB0DC: CC1A4018 1C660527
	v_dot2_f32_bf16 v25, v43, v2, v26                          // 0000003DB0E4: CC1A4019 1C6A052B
	v_dot2_f32_bf16 v26, v47, v2, v28                          // 0000003DB0EC: CC1A401A 1C72052F
	v_dot2_f32_bf16 v1, v51, v2, v1                            // 0000003DB0F4: CC1A4001 1C060533
	s_waitcnt vmcnt(7)                                         // 0000003DB0FC: BF891FF7
	v_dot2_f32_bf16 v20, v52, v14, v20                         // 0000003DB100: CC1A4014 1C521D34
	s_waitcnt vmcnt(6)                                         // 0000003DB108: BF891BF7
	v_dot2_f32_bf16 v21, v56, v14, v21                         // 0000003DB10C: CC1A4015 1C561D38
	s_waitcnt vmcnt(5)                                         // 0000003DB114: BF8917F7
	v_dot2_f32_bf16 v22, v60, v14, v22                         // 0000003DB118: CC1A4016 1C5A1D3C
	s_waitcnt vmcnt(4)                                         // 0000003DB120: BF8913F7
	v_dot2_f32_bf16 v23, v64, v14, v23                         // 0000003DB124: CC1A4017 1C5E1D40
	s_waitcnt vmcnt(3)                                         // 0000003DB12C: BF890FF7
	v_dot2_f32_bf16 v24, v68, v14, v24                         // 0000003DB130: CC1A4018 1C621D44
	s_waitcnt vmcnt(2)                                         // 0000003DB138: BF890BF7
	v_dot2_f32_bf16 v25, v72, v14, v25                         // 0000003DB13C: CC1A4019 1C661D48
	s_waitcnt vmcnt(1)                                         // 0000003DB144: BF8907F7
	v_dot2_f32_bf16 v9, v9, v14, v26                           // 0000003DB148: CC1A4009 1C6A1D09
	s_waitcnt vmcnt(0)                                         // 0000003DB150: BF8903F7
	v_dot2_f32_bf16 v1, v76, v14, v1                           // 0000003DB154: CC1A4001 1C061D4C
	v_dot2_f32_bf16 v2, v53, v3, v20                           // 0000003DB15C: CC1A4002 1C520735
	v_dot2_f32_bf16 v20, v57, v3, v21                          // 0000003DB164: CC1A4014 1C560739
	v_dot2_f32_bf16 v21, v61, v3, v22                          // 0000003DB16C: CC1A4015 1C5A073D
	v_dot2_f32_bf16 v22, v65, v3, v23                          // 0000003DB174: CC1A4016 1C5E0741
	v_dot2_f32_bf16 v23, v69, v3, v24                          // 0000003DB17C: CC1A4017 1C620745
	v_dot2_f32_bf16 v24, v73, v3, v25                          // 0000003DB184: CC1A4018 1C660749
	v_dot2_f32_bf16 v9, v10, v3, v9                            // 0000003DB18C: CC1A4009 1C26070A
	v_dot2_f32_bf16 v1, v77, v3, v1                            // 0000003DB194: CC1A4001 1C06074D
	v_dot2_f32_bf16 v2, v54, v15, v2                           // 0000003DB19C: CC1A4002 1C0A1F36
	v_dot2_f32_bf16 v10, v58, v15, v20                         // 0000003DB1A4: CC1A400A 1C521F3A
	v_dot2_f32_bf16 v14, v62, v15, v21                         // 0000003DB1AC: CC1A400E 1C561F3E
	v_dot2_f32_bf16 v20, v66, v15, v22                         // 0000003DB1B4: CC1A4014 1C5A1F42
	v_dot2_f32_bf16 v21, v70, v15, v23                         // 0000003DB1BC: CC1A4015 1C5E1F46
	v_dot2_f32_bf16 v22, v74, v15, v24                         // 0000003DB1C4: CC1A4016 1C621F4A
	v_dot2_f32_bf16 v9, v11, v15, v9                           // 0000003DB1CC: CC1A4009 1C261F0B
	v_dot2_f32_bf16 v1, v78, v15, v1                           // 0000003DB1D4: CC1A4001 1C061F4E
	v_dot2_f32_bf16 v2, v55, v4, v2                            // 0000003DB1DC: CC1A4002 1C0A0937
	v_dot2_f32_bf16 v3, v59, v4, v10                           // 0000003DB1E4: CC1A4003 1C2A093B
	v_dot2_f32_bf16 v10, v63, v4, v14                          // 0000003DB1EC: CC1A400A 1C3A093F
	v_dot2_f32_bf16 v11, v67, v4, v20                          // 0000003DB1F4: CC1A400B 1C520943
	v_dot2_f32_bf16 v14, v71, v4, v21                          // 0000003DB1FC: CC1A400E 1C560947
	v_dot2_f32_bf16 v15, v75, v4, v22                          // 0000003DB204: CC1A400F 1C5A094B
	v_dot2_f32_bf16 v9, v12, v4, v9                            // 0000003DB20C: CC1A4009 1C26090C
	v_dot2_f32_bf16 v1, v79, v4, v1                            // 0000003DB214: CC1A4001 1C06094F
	v_dual_add_f32 v18, v18, v2 :: v_dual_add_f32 v19, v19, v3 // 0000003DB21C: C9080512 12120713
	v_dual_add_f32 v16, v16, v10 :: v_dual_add_f32 v17, v17, v11// 0000003DB224: C9081510 10101711
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v8, v8, v15   // 0000003DB22C: C9081D07 07081F08
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003DB234: BF870004
	v_add_f32_e32 v5, v5, v1                                   // 0000003DB238: 060A0305
	v_add_f32_e32 v6, v6, v9                                   // 0000003DB23C: 060C1306
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003DB240: 8C7E007E
	.long 0xd71f0001                                           // 0000003DB244: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003DB248: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000003DB24C: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003DB250: BF870121
	v_xor_b32_e32 v2, 8, v1                                    // 0000003DB254: 3A040288
	v_xor_b32_e32 v15, 4, v1                                   // 0000003DB258: 3A1E0284
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000003DB25C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000003DB260: 02040501
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003DB264: BF8700A3
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 0000003DB268: 7C981EA0
	v_cndmask_b32_e32 v15, v1, v15, vcc_lo                     // 0000003DB26C: 021E1F01
	v_lshlrev_b32_e32 v15, 2, v15                              // 0000003DB270: 301E1E82
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003DB274: BF870004
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000003DB278: 30040482
	ds_bpermute_b32 v3, v2, v19                                // 0000003DB27C: DACC0000 03001302
	s_waitcnt lgkmcnt(0)                                       // 0000003DB284: BF89FC07
	v_add_f32_e32 v3, v19, v3                                  // 0000003DB288: 06060713
	ds_bpermute_b32 v11, v2, v8                                // 0000003DB28C: DACC0000 0B000802
	ds_bpermute_b32 v4, v2, v18                                // 0000003DB294: DACC0000 04001202
	ds_bpermute_b32 v9, v2, v17                                // 0000003DB29C: DACC0000 09001102
	ds_bpermute_b32 v10, v2, v16                               // 0000003DB2A4: DACC0000 0A001002
	ds_bpermute_b32 v12, v2, v7                                // 0000003DB2AC: DACC0000 0C000702
	ds_bpermute_b32 v14, v2, v6                                // 0000003DB2B4: DACC0000 0E000602
	ds_bpermute_b32 v2, v2, v5                                 // 0000003DB2BC: DACC0000 02000502
	v_xor_b32_e32 v19, 2, v1                                   // 0000003DB2C4: 3A260282
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003DB2C8: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000003DB2CC: 7C9826A0
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 0000003DB2D0: 02262701
	s_waitcnt lgkmcnt(6)                                       // 0000003DB2D4: BF89FC67
	v_add_f32_e32 v8, v8, v11                                  // 0000003DB2D8: 06101708
	s_waitcnt lgkmcnt(4)                                       // 0000003DB2DC: BF89FC47
	v_dual_add_f32 v4, v18, v4 :: v_dual_add_f32 v9, v17, v9   // 0000003DB2E0: C9080912 04081311
	s_waitcnt lgkmcnt(2)                                       // 0000003DB2E8: BF89FC27
	v_dual_add_f32 v10, v16, v10 :: v_dual_add_f32 v7, v7, v12 // 0000003DB2EC: C9081510 0A061907
	s_waitcnt lgkmcnt(1)                                       // 0000003DB2F4: BF89FC17
	v_add_f32_e32 v6, v6, v14                                  // 0000003DB2F8: 060C1D06
	s_waitcnt lgkmcnt(0)                                       // 0000003DB2FC: BF89FC07
	v_dual_add_f32 v2, v5, v2 :: v_dual_lshlrev_b32 v19, 2, v19// 0000003DB300: C9220505 02122682
	ds_bpermute_b32 v5, v15, v3                                // 0000003DB308: DACC0000 0500030F
	ds_bpermute_b32 v16, v15, v8                               // 0000003DB310: DACC0000 1000080F
	ds_bpermute_b32 v11, v15, v4                               // 0000003DB318: DACC0000 0B00040F
	ds_bpermute_b32 v17, v15, v7                               // 0000003DB320: DACC0000 1100070F
	ds_bpermute_b32 v18, v15, v6                               // 0000003DB328: DACC0000 1200060F
	ds_bpermute_b32 v12, v15, v9                               // 0000003DB330: DACC0000 0C00090F
	ds_bpermute_b32 v14, v15, v10                              // 0000003DB338: DACC0000 0E000A0F
	ds_bpermute_b32 v15, v15, v2                               // 0000003DB340: DACC0000 0F00020F
	s_waitcnt lgkmcnt(6)                                       // 0000003DB348: BF89FC67
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v8, v8, v16    // 0000003DB34C: C9080B03 03082108
	s_waitcnt lgkmcnt(4)                                       // 0000003DB354: BF89FC47
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v7, v7, v17   // 0000003DB358: C9081704 04062307
	s_waitcnt lgkmcnt(1)                                       // 0000003DB360: BF89FC17
	v_dual_add_f32 v5, v9, v12 :: v_dual_add_f32 v10, v10, v14 // 0000003DB364: C9081909 050A1D0A
	ds_bpermute_b32 v17, v19, v8                               // 0000003DB36C: DACC0000 11000813
	v_add_f32_e32 v11, v6, v18                                 // 0000003DB374: 06162506
	ds_bpermute_b32 v6, v19, v3                                // 0000003DB378: DACC0000 06000313
	v_xor_b32_e32 v14, 1, v1                                   // 0000003DB380: 3A1C0281
	ds_bpermute_b32 v9, v19, v4                                // 0000003DB384: DACC0000 09000413
	ds_bpermute_b32 v12, v19, v5                               // 0000003DB38C: DACC0000 0C000513
	ds_bpermute_b32 v16, v19, v10                              // 0000003DB394: DACC0000 10000A13
	ds_bpermute_b32 v18, v19, v7                               // 0000003DB39C: DACC0000 12000713
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 0000003DB3A4: 7C981CA0
	s_waitcnt lgkmcnt(6)                                       // 0000003DB3A8: BF89FC67
	v_dual_add_f32 v2, v2, v15 :: v_dual_cndmask_b32 v1, v1, v14// 0000003DB3AC: C9121F02 02001D01
	s_waitcnt lgkmcnt(4)                                       // 0000003DB3B4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003DB3B8: BF870001
	v_dual_add_f32 v14, v3, v6 :: v_dual_lshlrev_b32 v21, 2, v1// 0000003DB3BC: C9220D03 0E140282
	v_add_f32_e32 v6, v8, v17                                  // 0000003DB3C4: 060C2308
	ds_bpermute_b32 v20, v19, v11                              // 0000003DB3C8: DACC0000 14000B13
	ds_bpermute_b32 v19, v19, v2                               // 0000003DB3D0: DACC0000 13000213
	s_waitcnt lgkmcnt(3)                                       // 0000003DB3D8: BF89FC37
	v_dual_add_f32 v15, v4, v9 :: v_dual_add_f32 v10, v10, v16 // 0000003DB3DC: C9081304 0F0A210A
	v_add_f32_e32 v9, v5, v12                                  // 0000003DB3E4: 06121905
	s_waitcnt lgkmcnt(2)                                       // 0000003DB3E8: BF89FC27
	v_add_f32_e32 v5, v7, v18                                  // 0000003DB3EC: 060A2507
	ds_bpermute_b32 v16, v21, v14                              // 0000003DB3F0: DACC0000 10000E15
	ds_bpermute_b32 v17, v21, v15                              // 0000003DB3F8: DACC0000 11000F15
	ds_bpermute_b32 v8, v21, v6                                // 0000003DB400: DACC0000 08000615
	ds_bpermute_b32 v7, v21, v5                                // 0000003DB408: DACC0000 07000515
	s_waitcnt lgkmcnt(4)                                       // 0000003DB410: BF89FC47
	v_dual_add_f32 v1, v11, v20 :: v_dual_add_f32 v2, v2, v19  // 0000003DB414: C908290B 01022702
	ds_bpermute_b32 v11, v21, v10                              // 0000003DB41C: DACC0000 0B000A15
	ds_bpermute_b32 v12, v21, v9                               // 0000003DB424: DACC0000 0C000915
	ds_bpermute_b32 v3, v21, v1                                // 0000003DB42C: DACC0000 03000115
	ds_bpermute_b32 v4, v21, v2                                // 0000003DB434: DACC0000 04000215
	v_cmpx_eq_u32_e32 0, v13                                   // 0000003DB43C: 7D941A80
	s_cbranch_execz 65                                         // 0000003DB440: BFA50041 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi8EEEvPKhPKtS5_PtPf+0xf48>
	s_waitcnt lgkmcnt(6)                                       // 0000003DB444: BF89FC67
	v_dual_add_f32 v13, v15, v17 :: v_dual_add_f32 v14, v14, v16// 0000003DB448: C908230F 0D0E210E
	.long 0x7f1e3880                                           // 0000003DB450: 7F1E3880
	s_waitcnt lgkmcnt(2)                                       // 0000003DB454: BF89FC27
	v_dual_add_f32 v10, v10, v11 :: v_dual_add_f32 v9, v9, v12 // 0000003DB458: C908170A 0A081909
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003DB460: BF870003
	.long 0x7e20398d                                           // 0000003DB464: 7E20398D
	.long 0x7e1e398e                                           // 0000003DB468: 7E1E398E
	.long 0x7f20398f                                           // 0000003DB46C: 7F20398F
	v_lshrrev_b32_e32 v17, 4, v0                               // 0000003DB470: 32220084
	v_dual_add_f32 v6, v6, v8 :: v_dual_add_f32 v5, v5, v7     // 0000003DB474: C9081106 06040F05
	s_waitcnt lgkmcnt(0)                                       // 0000003DB47C: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000003DB480: 06040902
	v_and_b32_e32 v8, 1, v16                                   // 0000003DB484: 36102081
	v_and_b32_e32 v16, 1, v15                                  // 0000003DB488: 36201E81
	.long 0x7e1e3989                                           // 0000003DB48C: 7E1E3989
	v_lshlrev_b32_e32 v11, 4, v17                              // 0000003DB490: 30162284
	.long 0x7e18398a                                           // 0000003DB494: 7E18398A
	v_add3_u32 v8, v13, v8, 0x7fff                             // 0000003DB498: D6550008 03FE110D 00007FFF
	.long 0x7f18398f                                           // 0000003DB4A4: 7F18398F
	v_and_b32_e32 v4, 1, v15                                   // 0000003DB4A8: 36081E81
	.long 0x7e1e3986                                           // 0000003DB4AC: 7E1E3986
	v_add_f32_e32 v13, v1, v3                                  // 0000003DB4B0: 061A0701
	.long 0x7e0e3985                                           // 0000003DB4B4: 7E0E3985
	.long 0x7e023982                                           // 0000003DB4B8: 7E023982
	.long 0x7f02398f                                           // 0000003DB4BC: 7F02398F
	.long 0x7f0e398f                                           // 0000003DB4C0: 7F0E398F
	v_and_b32_e32 v3, 1, v12                                   // 0000003DB4C4: 36061881
	v_and_b32_e32 v12, 1, v15                                  // 0000003DB4C8: 36181E81
	.long 0x7e1e398d                                           // 0000003DB4CC: 7E1E398D
	v_and_b32_e32 v17, 1, v1                                   // 0000003DB4D0: 36220281
	v_and_b32_e32 v7, 1, v7                                    // 0000003DB4D4: 360E0E81
	v_add3_u32 v1, v14, v16, 0x7fff                            // 0000003DB4D8: D6550001 03FE210E 00007FFF
	v_add3_u32 v10, v10, v3, 0x7fff                            // 0000003DB4E4: D655000A 03FE070A 00007FFF
	v_and_b32_e32 v14, 1, v15                                  // 0000003DB4F0: 361C1E81
	v_add3_u32 v15, v2, v17, 0x7fff                            // 0000003DB4F4: D655000F 03FE2302 00007FFF
	v_add3_u32 v5, v5, v7, 0x7fff                              // 0000003DB500: D6550005 03FE0F05 00007FFF
	v_add3_u32 v2, v9, v4, 0x7fff                              // 0000003DB50C: D6550002 03FE0909 00007FFF
	v_add3_u32 v3, v6, v12, 0x7fff                             // 0000003DB518: D6550003 03FE1906 00007FFF
	v_add3_u32 v4, v13, v14, 0x7fff                            // 0000003DB524: D6550004 03FE1D0D 00007FFF
	.long 0x7e08398f                                           // 0000003DB530: 7E08398F
	.long 0x7e063985                                           // 0000003DB534: 7E063985
	.long 0x7e04398a                                           // 0000003DB538: 7E04398A
	.long 0x7e023988                                           // 0000003DB53C: 7E023988
	ds_store_b128 v11, v[1:4]                                  // 0000003DB540: DB7C0000 0000010B
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003DB548: 8C7E007E
	s_waitcnt lgkmcnt(0)                                       // 0000003DB54C: BF89FC07
	s_barrier                                                  // 0000003DB550: BFBD0000
	buffer_gl0_inv                                             // 0000003DB554: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 0000003DB55C: BE80007E
	v_cmpx_gt_u32_e32 32, v0                                   // 0000003DB560: 7D9800A0
	s_cbranch_execz 258                                        // 0000003DB564: BFA50102 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi8EEEvPKhPKtS5_PtPf+0x1370>
	v_lshrrev_b32_e32 v2, 3, v0                                // 0000003DB568: 32040083
	v_and_b32_e32 v11, 7, v0                                   // 0000003DB56C: 36160087
	s_cmp_eq_u64 s[4:5], 0                                     // 0000003DB570: BF108004
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DB574: BF870112
	v_or_b32_e32 v3, s2, v2                                    // 0000003DB578: 38060402
	v_mul_u32_u24_e32 v5, 0x5000, v11                          // 0000003DB57C: 160A16FF 00005000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DB584: BF870112
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000003DB588: 3408069F
	.long 0xd7000005                                           // 0000003DB58C: D7000005
	v_cndmask_b32_e32 v1, s8, v5, vcc_lo                       // 0000003DB590: 02020A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DB594: BF870191
	v_add_co_ci_u32_e64 v6, null, s9, 0, s0                    // 0000003DB598: D5207C06 00010009
	.long 0xd73c0000                                           // 0000003DB5A0: D73C0000
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000003DB5A4: 02020681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DB5A8: BF870091
	.long 0xd7006a00                                           // 0000003DB5AC: D7006A00
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000003DB5B0: 02020105
	v_add_co_ci_u32_e64 v1, null, v6, v1, vcc_lo               // 0000003DB5B4: D5207C01 01AA0306
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DB5BC: BF870092
	.long 0xd7006a05                                           // 0000003DB5C0: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v0, vcc_lo                   // 0000003DB5C4: 020200FF 00002000
	v_add_co_ci_u32_e64 v6, null, 0, v1, vcc_lo                // 0000003DB5CC: D5207C06 01AA0280
	.long 0xd7006a07                                           // 0000003DB5D4: D7006A07
	v_cndmask_b32_e32 v1, 0x3000, v0, vcc_lo                   // 0000003DB5D8: 020200FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003DB5E0: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v1, vcc_lo                // 0000003DB5E4: D5207C08 01AA0280
	.long 0xd7006a09                                           // 0000003DB5EC: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000003DB5F0: 020200FF 00001000
	v_add_co_ci_u32_e64 v10, null, 0, v1, vcc_lo               // 0000003DB5F8: D5207C0A 01AA0280
	s_clause 0x3                                               // 0000003DB600: BF850003
	global_load_u16 v5, v[5:6], off offset:2048                // 0000003DB604: DC4A0800 057C0005
	global_load_u16 v6, v[7:8], off offset:3072                // 0000003DB60C: DC4A0C00 067C0007
	global_load_u16 v0, v[0:1], off                            // 0000003DB614: DC4A0000 007C0000
	global_load_u16 v1, v[9:10], off offset:1024               // 0000003DB61C: DC4A0400 017C0009
	v_lshlrev_b32_e32 v7, 1, v11                               // 0000003DB624: 300E1681
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003DB628: BF870001
	v_lshl_or_b32 v2, v2, 6, v7                                // 0000003DB62C: D6560002 041D0D02
	ds_load_u16 v7, v2                                         // 0000003DB634: D8F00000 07000002
	ds_load_u16 v8, v2 offset:16                               // 0000003DB63C: D8F00010 08000002
	ds_load_u16 v9, v2 offset:32                               // 0000003DB644: D8F00020 09000002
	ds_load_u16 v2, v2 offset:48                               // 0000003DB64C: D8F00030 02000002
	s_waitcnt lgkmcnt(2)                                       // 0000003DB654: BF89FC27
	v_lshlrev_b32_e32 v8, 16, v8                               // 0000003DB658: 30101090
	s_waitcnt lgkmcnt(0)                                       // 0000003DB65C: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000003DB660: 30040490
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DB664: BF870112
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 0000003DB668: 101010FF BFB8AA3B
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 0000003DB670: 100404FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003DB678: BF870122
	v_exp_f32_e32 v8, v8                                       // 0000003DB67C: 7E104B08
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000003DB680: 300E0E90
	v_exp_f32_e32 v2, v2                                       // 0000003DB684: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003DB688: BF870296
	v_dual_add_f32 v8, 1.0, v8 :: v_dual_lshlrev_b32 v9, 16, v9// 0000003DB68C: C92210F2 08081290
	v_dual_mul_f32 v7, 0xbfb8aa3b, v7 :: v_dual_add_f32 v2, 1.0, v2// 0000003DB694: C8C80EFF 070204F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DB6A0: BF870192
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000003DB6A4: 101212FF BFB8AA3B
	v_div_scale_f32 v12, null, v8, v8, 1.0                     // 0000003DB6AC: D6FC7C0C 03CA1108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DB6B4: BF870193
	v_exp_f32_e32 v7, v7                                       // 0000003DB6B8: 7E0E4B07
	v_div_scale_f32 v14, null, v2, v2, 1.0                     // 0000003DB6BC: D6FC7C0E 03CA0502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003DB6C4: BF870133
	v_exp_f32_e32 v9, v9                                       // 0000003DB6C8: 7E124B09
	v_div_scale_f32 v20, s0, 1.0, v8, 1.0                      // 0000003DB6CC: D6FC0014 03CA10F2
	v_rcp_f32_e32 v16, v12                                     // 0000003DB6D4: 7E20550C
	v_rcp_f32_e32 v18, v14                                     // 0000003DB6D8: 7E24550E
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000003DB6DC: BF8702A6
	v_fma_f32 v22, -v12, v16, 1.0                              // 0000003DB6E0: D6130016 23CA210C
	v_add_f32_e32 v7, 1.0, v7                                  // 0000003DB6E8: 060E0EF2
	v_fma_f32 v25, -v14, v18, 1.0                              // 0000003DB6EC: D6130019 23CA250E
	s_delay_alu instid0(TRANS32_DEP_3) | instid1(VALU_DEP_3)   // 0000003DB6F4: BF870187
	v_dual_add_f32 v9, 1.0, v9 :: v_dual_fmac_f32 v16, v22, v16// 0000003DB6F8: C90012F2 09102116
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DB700: BF870193
	v_div_scale_f32 v10, null, v7, v7, 1.0                     // 0000003DB704: D6FC7C0A 03CA0F07
	v_fmac_f32_e32 v18, v25, v18                               // 0000003DB70C: 56242519
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000003DB710: BF8701C3
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 0000003DB714: D6FC7C0D 03CA1309
	v_div_scale_f32 v19, vcc_lo, 1.0, v7, 1.0                  // 0000003DB71C: D6FC6A13 03CA0EF2
	v_div_scale_f32 v24, s1, 1.0, v9, 1.0                      // 0000003DB724: D6FC0118 03CA12F2
	v_rcp_f32_e32 v15, v10                                     // 0000003DB72C: 7E1E550A
	v_rcp_f32_e32 v17, v13                                     // 0000003DB730: 7E22550D
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003DB734: BF870296
	v_fma_f32 v21, -v10, v15, 1.0                              // 0000003DB738: D6130015 23CA1F0A
	v_fma_f32 v23, -v13, v17, 1.0                              // 0000003DB740: D6130017 23CA230D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003DB748: BF8701A2
	v_fmac_f32_e32 v15, v21, v15                               // 0000003DB74C: 561E1F15
	v_div_scale_f32 v21, s2, 1.0, v2, 1.0                      // 0000003DB750: D6FC0215 03CA04F2
	v_fmac_f32_e32 v17, v23, v17                               // 0000003DB758: 56222317
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DB75C: BF870092
	v_dual_mul_f32 v23, v20, v16 :: v_dual_mul_f32 v26, v21, v18// 0000003DB760: C8C62114 171A2515
	v_fma_f32 v28, -v12, v23, v20                              // 0000003DB768: D613001C 24522F0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DB770: BF870092
	v_fma_f32 v30, -v14, v26, v21                              // 0000003DB774: D613001E 2456350E
	v_dual_fmac_f32 v23, v28, v16 :: v_dual_fmac_f32 v26, v30, v18// 0000003DB77C: C800211C 171A251E
	v_mul_f32_e32 v22, v19, v15                                // 0000003DB784: 102C1F13
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DB788: BF870192
	v_fma_f32 v12, -v12, v23, v20                              // 0000003DB78C: D613000C 24522F0C
	v_fma_f32 v14, -v14, v26, v21                              // 0000003DB794: D613000E 2456350E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DB79C: BF870093
	v_fma_f32 v27, -v10, v22, v19                              // 0000003DB7A0: D613001B 244E2D0A
	v_dual_mul_f32 v25, v24, v17 :: v_dual_fmac_f32 v22, v27, v15// 0000003DB7A8: C8C02318 19161F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DB7B0: BF870111
	v_fma_f32 v29, -v13, v25, v24                              // 0000003DB7B4: D613001D 2462330D
	v_fma_f32 v10, -v10, v22, v19                              // 0000003DB7BC: D613000A 244E2D0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DB7C4: BF870112
	v_fmac_f32_e32 v25, v29, v17                               // 0000003DB7C8: 5632231D
	v_div_fmas_f32 v10, v10, v15, v22                          // 0000003DB7CC: D637000A 045A1F0A
	s_mov_b32 vcc_lo, s0                                       // 0000003DB7D4: BEEA0000
	v_div_fmas_f32 v12, v12, v16, v23                          // 0000003DB7D8: D637000C 045E210C
	s_mov_b32 vcc_lo, s1                                       // 0000003DB7E0: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DB7E4: BF870112
	v_div_fixup_f32 v7, v10, v7, 1.0                           // 0000003DB7E8: D6270007 03CA0F0A
	v_div_fixup_f32 v8, v12, v8, 1.0                           // 0000003DB7F0: D6270008 03CA110C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DB7F8: BF870092
	v_bfe_u32 v12, v7, 16, 1                                   // 0000003DB7FC: D610000C 02052107
	v_add3_u32 v7, v7, v12, 0x7fff                             // 0000003DB804: D6550007 03FE1907 00007FFF
	s_waitcnt vmcnt(3)                                         // 0000003DB810: BF890FF7
	v_lshlrev_b32_e32 v5, 16, v5                               // 0000003DB814: 300A0A90
	s_waitcnt vmcnt(1)                                         // 0000003DB818: BF8907F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000003DB81C: 30000090
	v_fma_f32 v13, -v13, v25, v24                              // 0000003DB820: D613000D 2462330D
	s_waitcnt vmcnt(0)                                         // 0000003DB828: BF8903F7
	v_lshlrev_b32_e32 v1, 16, v1                               // 0000003DB82C: 30020290
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003DB830: BF870132
	v_div_fmas_f32 v10, v13, v17, v25                          // 0000003DB834: D637000A 0466230D
	s_mov_b32 vcc_lo, s2                                       // 0000003DB83C: BEEA0002
	v_div_fmas_f32 v13, v14, v18, v26                          // 0000003DB840: D637000D 046A250E
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000003DB848: D6270009 03CA130A
	v_bfe_u32 v10, v8, 16, 1                                   // 0000003DB850: D610000A 02052108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DB858: BF870193
	v_div_fixup_f32 v2, v13, v2, 1.0                           // 0000003DB85C: D6270002 03CA050D
	v_bfe_u32 v12, v9, 16, 1                                   // 0000003DB864: D610000C 02052109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DB86C: BF870193
	v_add3_u32 v8, v8, v10, 0x7fff                             // 0000003DB870: D6550008 03FE1508 00007FFF
	v_bfe_u32 v10, v2, 16, 1                                   // 0000003DB87C: D610000A 02052102
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DB884: BF870193
	v_add3_u32 v9, v9, v12, 0x7fff                             // 0000003DB888: D6550009 03FE1909 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000003DB894: 361010FF FFFF0000
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000003DB89C: 360E0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DB8A4: BF870114
	v_add3_u32 v2, v2, v10, 0x7fff                             // 0000003DB8A8: D6550002 03FE1502 00007FFF
	v_fma_f32 v0, v0, v7, 0                                    // 0000003DB8B4: D6130000 02020F00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DB8BC: BF870191
	v_dual_fmac_f32 v0, v1, v8 :: v_dual_and_b32 v7, 0xffff0000, v9// 0000003DB8C0: C8241101 000612FF FFFF0000
	v_and_b32_e32 v1, 0xffff0000, v2                           // 0000003DB8CC: 360204FF FFFF0000
	v_lshlrev_b32_e32 v2, 16, v6                               // 0000003DB8D4: 30040C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DB8D8: BF870093
	v_fmac_f32_e32 v0, v5, v7                                  // 0000003DB8DC: 56000F05
	v_fmac_f32_e32 v0, v2, v1                                  // 0000003DB8E0: 56000302
	v_mul_u32_u24_e32 v1, 0xa00, v11                           // 0000003DB8E4: 160216FF 00000A00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DB8EC: BF870112
	v_mul_f32_e32 v2, 0x3e800000, v0                           // 0000003DB8F0: 100400FF 3E800000
	.long 0xd7006a00                                           // 0000003DB8F8: D7006A00
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000003DB8FC: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DB900: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v4, vcc_lo                // 0000003DB904: D5207C01 01AA0880
	v_bfe_u32 v5, v2, 16, 1                                    // 0000003DB90C: D6100005 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DB914: BF870112
	.long 0xd73c0003                                           // 0000003DB918: D73C0003
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000003DB91C: 02020081
	v_add3_u32 v5, v2, v5, 0x7fff                              // 0000003DB920: D6550005 03FE0B02 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DB92C: BF870092
	.long 0xd7006a03                                           // 0000003DB930: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000003DB934: 0202060A
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 0000003DB938: D5207C04 01AA080B
	global_store_d16_hi_b16 v[3:4], v5, off                    // 0000003DB940: DC960000 007C0503
	s_cbranch_scc1 9                                           // 0000003DB948: BFA20009 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi8EEEvPKhPKtS5_PtPf+0x1370>
	.long 0xd73c0000                                           // 0000003DB94C: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000003DB950: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DB954: BF870091
	.long 0xd7006a00                                           // 0000003DB958: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000003DB95C: 02020004
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000003DB960: D5207C01 01AA0205
	global_store_b32 v[0:1], v2, off                           // 0000003DB968: DC6A0000 007C0200
	s_nop 0                                                    // 0000003DB970: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003DB974: BFB60003
	s_endpgm                                                   // 0000003DB978: BFB00000
		...

