000000000076b600 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000076B600: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000076B608: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000076B60C: 32040082
	s_lshl_b64 s[0:1], s[2:3], 3                               // 00000076B610: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000076B614: BF8701A9
	v_dual_mov_b32 v24, s1 :: v_dual_and_b32 v1, 15, v0        // 00000076B618: CA240001 1800008F
	v_and_b32_e32 v30, 31, v0                                  // 00000076B620: 363C009F
	v_and_b32_e32 v2, 60, v2                                   // 00000076B624: 360404BC
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000076B628: 300E0082
	s_delay_alu instid0(VALU_DEP_4)                            // 00000076B62C: BF870004
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000076B630: 30020282
	.long 0x7f0c3880                                           // 00000076B634: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 00000076B638: BF89FC07
	s_clause 0x1                                               // 00000076B63C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000076B640: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000076B648: DC520000 04040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000076B650: 32020085
	s_add_u32 s22, s4, s16                                     // 00000076B654: 80161004
	s_addc_u32 s23, s5, s17                                    // 00000076B658: 82171105
	s_ashr_i32 s2, s11, 31                                     // 00000076B65C: 86029F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000076B660: BF8704A1
	v_or_b32_e32 v23, s0, v1                                   // 00000076B664: 382E0200
	s_lshr_b32 s2, s2, 27                                      // 00000076B668: 85029B02
	s_add_u32 s2, s10, s2                                      // 00000076B66C: 8002020A
	s_addc_u32 s3, s11, 0                                      // 00000076B670: 8203800B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000076B674: BF8704A1
	.long 0xd4540000                                           // 00000076B678: D4540000
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 00000076B67C: 02022E0C
	s_lshr_b64 s[20:21], s[2:3], 5                             // 00000076B680: 85948502
	s_cmpk_lt_i32 s20, 0x101                                   // 00000076B684: B3940101
	.long 0xd4440002                                           // 00000076B688: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000076B68C: 02023C14
	v_cndmask_b32_e64 v2, 0, v23, s0                           // 00000076B690: D5010002 00022E80
	v_cndmask_b32_e64 v5, 0, s1, s0                            // 00000076B698: D5010005 00000280
	s_cselect_b32 s1, -1, 0                                    // 00000076B6A0: 980180C1
	s_cmpk_gt_i32 s20, 0x100                                   // 00000076B6A4: B2940100
	s_delay_alu instid0(VALU_DEP_2)                            // 00000076B6A8: BF870002
	.long 0xd72c0008                                           // 00000076B6AC: D72C0008
	v_cndmask_b32_e32 v1, s19, v2, vcc_lo                      // 00000076B6B0: 02020413
	v_mad_u64_u32 v[0:1], null, s18, v2, 0                     // 00000076B6B4: D6FE7C00 02020412
	s_waitcnt vmcnt(1)                                         // 00000076B6BC: BF8907F7
	v_bfe_u32 v9, v3, 16, 1                                    // 00000076B6C0: D6100009 02052103
	s_waitcnt vmcnt(0)                                         // 00000076B6C8: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 00000076B6CC: D610000A 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000076B6D4: BF8701A2
	v_add3_u32 v3, v3, v9, 0x7fff                              // 00000076B6D8: D6550003 03FE1303 00007FFF
	.long 0xd72c0009                                           // 00000076B6E4: D72C0009
	v_cndmask_b32_e32 v1, s18, v5, vcc_lo                      // 00000076B6E8: 02020A12
	v_add3_u32 v4, v4, v10, 0x7fff                             // 00000076B6EC: D6550004 03FE1504 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 00000076B6F8: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000076B6FC: BF870239
	s_and_b32 vcc_lo, exec_lo, s18                             // 00000076B700: 8B6A127E
	.long 0x7e0c3983                                           // 00000076B704: 7E0C3983
	.long 0xd7000303                                           // 00000076B708: D7000303
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 00000076B70C: 02020016
	v_add3_u32 v1, v1, v9, v8                                  // 00000076B710: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000076B718: BF870113
	v_and_or_b32 v6, 0xffff0000, v4, v6                        // 00000076B71C: D6570006 041A08FF FFFF0000
	v_add_co_ci_u32_e64 v4, null, s23, v1, s3                  // 00000076B728: D5207C04 000E0217
	ds_store_b32 v7, v6                                        // 00000076B730: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 00000076B738: BF89FC07
	s_barrier                                                  // 00000076B73C: BFBD0000
	buffer_gl0_inv                                             // 00000076B740: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 00000076B748: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x394>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 00000076B74C: CA100080 08060080
	s_and_saveexec_b32 s3, s2                                  // 00000076B754: BE832002
	s_cbranch_execz 10                                         // 00000076B758: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x184>
	v_lshlrev_b32_e32 v6, 1, v30                               // 00000076B75C: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B760: BF870091
	.long 0xd7006a06                                           // 00000076B764: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000076B768: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000076B76C: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 00000076B774: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000076B77C: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 00000076B780: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s3                              // 00000076B784: 8C7E037E
	v_or_b32_e32 v6, 32, v30                                   // 00000076B788: 380C3CA0
	s_mov_b32 s2, exec_lo                                      // 00000076B78C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076B790: BF870001
	.long 0xd4c4007e                                           // 00000076B794: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000076B798: 02020C14
	s_cbranch_execz 10                                         // 00000076B79C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1c8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000076B7A0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B7A4: BF870091
	.long 0xd7006a08                                           // 00000076B7A8: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000076B7AC: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 00000076B7B0: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 00000076B7B8: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 00000076B7C0: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 00000076B7C4: 7E101706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000076B7C8: 8C7E027E
	v_or_b32_e32 v6, 64, v30                                   // 00000076B7CC: 380C3CC0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 00000076B7D0: CA100080 0A080080
	s_mov_b32 s2, exec_lo                                      // 00000076B7D8: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000076B7DC: BF870002
	.long 0xd4c4007e                                           // 00000076B7E0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000076B7E4: 02020C14
	s_cbranch_execz 10                                         // 00000076B7E8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x214>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000076B7EC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B7F0: BF870091
	.long 0xd7006a0b                                           // 00000076B7F4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000076B7F8: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 00000076B7FC: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 00000076B804: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000076B80C: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 00000076B810: 7E121706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000076B814: 8C7E027E
	v_or_b32_e32 v6, 0x60, v30                                 // 00000076B818: 380C3CFF 00000060
	s_mov_b32 s2, exec_lo                                      // 00000076B820: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076B824: BF870001
	.long 0xd4c4007e                                           // 00000076B828: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000076B82C: 02020C14
	s_cbranch_execz 10                                         // 00000076B830: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x25c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000076B834: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B838: BF870091
	.long 0xd7006a0a                                           // 00000076B83C: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000076B840: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 00000076B844: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 00000076B84C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000076B854: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 00000076B858: 7E141706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000076B85C: 8C7E027E
	v_or_b32_e32 v6, 0x80, v30                                 // 00000076B860: 380C3CFF 00000080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000076B868: CA100080 0C0A0080
	s_mov_b32 s2, exec_lo                                      // 00000076B870: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000076B874: BF870002
	.long 0xd4c4007e                                           // 00000076B878: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000076B87C: 02020C14
	s_cbranch_execz 10                                         // 00000076B880: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2ac>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000076B884: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B888: BF870091
	.long 0xd7006a0d                                           // 00000076B88C: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000076B890: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 00000076B894: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 00000076B89C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 00000076B8A4: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 00000076B8A8: 7E161706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000076B8AC: 8C7E027E
	v_or_b32_e32 v6, 0xa0, v30                                 // 00000076B8B0: 380C3CFF 000000A0
	s_mov_b32 s2, exec_lo                                      // 00000076B8B8: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076B8BC: BF870001
	.long 0xd4c4007e                                           // 00000076B8C0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000076B8C4: 02020C14
	s_cbranch_execz 10                                         // 00000076B8C8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2f4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000076B8CC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B8D0: BF870091
	.long 0xd7006a0c                                           // 00000076B8D4: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000076B8D8: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000076B8DC: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 00000076B8E4: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 00000076B8EC: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 00000076B8F0: 7E181706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000076B8F4: 8C7E027E
	v_or_b32_e32 v6, 0xc0, v30                                 // 00000076B8F8: 380C3CFF 000000C0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 00000076B900: CA100080 0E0C0080
	s_mov_b32 s2, exec_lo                                      // 00000076B908: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000076B90C: BF870002
	.long 0xd4c4007e                                           // 00000076B910: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000076B914: 02020C14
	s_cbranch_execz 10                                         // 00000076B918: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x344>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000076B91C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B920: BF870091
	.long 0xd7006a0f                                           // 00000076B924: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000076B928: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000076B92C: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 00000076B934: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 00000076B93C: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 00000076B940: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000076B944: 8C7E027E
	v_or_b32_e32 v6, 0xe0, v30                                 // 00000076B948: 380C3CFF 000000E0
	s_mov_b32 s2, exec_lo                                      // 00000076B950: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076B954: BF870001
	.long 0xd4c4007e                                           // 00000076B958: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000076B95C: 02020C14
	s_cbranch_execz 10                                         // 00000076B960: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000076B964: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076B968: BF870091
	.long 0xd7006a0e                                           // 00000076B96C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000076B970: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 00000076B974: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 00000076B97C: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 00000076B984: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 00000076B988: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000076B98C: 8C7E027E
	s_branch 9                                                 // 00000076B990: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_mov_b32_e32 v7, 0                                        // 00000076B994: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076B998: BF870001
	v_mov_b32_e32 v8, v7                                       // 00000076B99C: 7E100307
	v_mov_b32_e32 v9, v7                                       // 00000076B9A0: 7E120307
	v_mov_b32_e32 v10, v7                                      // 00000076B9A4: 7E140307
	v_mov_b32_e32 v11, v7                                      // 00000076B9A8: 7E160307
	v_mov_b32_e32 v12, v7                                      // 00000076B9AC: 7E180307
	v_mov_b32_e32 v13, v7                                      // 00000076B9B0: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 00000076B9B4: 7E1C0307
	s_add_u32 s2, s4, s14                                      // 00000076B9B8: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000076B9BC: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 00000076B9C0: 850E9F0B
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v44, 0             // 00000076B9C4: CA100080 132C0080
	s_add_u32 s14, s10, s14                                    // 00000076B9CC: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000076B9D0: 820F800B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v20, 0             // 00000076B9D4: CA100080 1F140080
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000076B9DC: 868E810E
	v_cndmask_b32_e64 v32, 0, 1, s18                           // 00000076B9E0: D5010020 00490280
	v_mad_u64_u32 v[25:26], null, v2, s14, s[2:3]              // 00000076B9E8: D6FE7C19 00081D02
	.long 0xd72c0002                                           // 00000076B9F0: D72C0002
	v_cndmask_b32_e32 v0, v2, v15, vcc_lo                      // 00000076B9F4: 02001F02
	.long 0xd72c0005                                           // 00000076B9F8: D72C0005
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 00000076B9FC: 02001D05
	.long 0xd4440002                                           // 00000076BA00: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000076BA04: 02023C14
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 00000076BA08: CA100080 15160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000076BA10: BF870003
	v_add3_u32 v33, v5, v26, v2                                // 00000076BA14: D6550021 040A3505
	s_and_saveexec_b32 s3, s2                                  // 00000076BA1C: BE832002
	s_cbranch_execz 21                                         // 00000076BA20: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 4, v30                               // 00000076BA24: 30043C84
	v_mov_b32_e32 v44, 0                                       // 00000076BA28: 7E580280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BA2C: BF870092
	.long 0xd7006a05                                           // 00000076BA30: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 00000076BA34: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 00000076BA38: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 00000076BA40: 916A127E
	global_load_b128 v[19:22], v[5:6], off                     // 00000076BA44: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000076BA4C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 1, v30                               // 00000076BA50: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BA54: BF870091
	.long 0xd7006a02                                           // 00000076BA58: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000076BA5C: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 00000076BA60: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 00000076BA68: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000076BA70: BF8903F7
	v_cvt_f32_f16_e32 v44, v2                                  // 00000076BA74: 7E581702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000076BA78: 8C7E037E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000076BA7C: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 00000076BA84: CA100080 24240080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 00000076BA8C: CA100080 26260080
	v_mov_b32_e32 v40, 0                                       // 00000076BA94: 7E500280
	s_and_saveexec_b32 s3, s2                                  // 00000076BA98: BE832002
	s_cbranch_execz 685                                        // 00000076BA9C: BFA502AD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf54>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 00000076BAA0: CA220080 1B023C81
	.long 0xd7006a00                                           // 00000076BAA8: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000076BAAC: 02020010
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000076BAB0: BF870191
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000076BAB4: D5207C01 01AA0211
	v_dual_mov_b32 v39, v27 :: v_dual_lshlrev_b32 v26, 5, v30  // 00000076BABC: CA22011B 271A3C85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BAC4: BF870093
	.long 0xd7006a00                                           // 00000076BAC8: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 00000076BACC: 02020500
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000076BAD0: D5207C01 01AA0280
	v_lshl_or_b32 v41, v30, 4, 0x200                           // 00000076BAD8: D6560029 03FD091E 00000200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BAE4: BF870093
	.long 0xd7006a00                                           // 00000076BAE8: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000076BAEC: 02020004
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 00000076BAF0: D5207C01 01AA0205
	v_dual_mov_b32 v42, v30 :: v_dual_mov_b32 v37, v27         // 00000076BAF8: CA10011E 2A24011B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BB00: BF870093
	.long 0xd7006a1c                                           // 00000076BB04: D7006A1C
	v_cndmask_b32_e32 v0, v0, v192, vcc_lo                     // 00000076BB08: 02018100
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 00000076BB0C: D5207C1D 01AA0280
	v_dual_mov_b32 v40, v27 :: v_dual_mov_b32 v43, v44         // 00000076BB14: CA10011B 282A012C
	v_mov_b32_e32 v38, v27                                     // 00000076BB1C: 7E4C031B
	v_mov_b32_e32 v36, v27                                     // 00000076BB20: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 00000076BB24: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 00000076BB28: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 00000076BB2C: 7E3E031B
	s_mul_i32 s2, s11, 6                                       // 00000076BB30: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 00000076BB34: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000076BB38: 848E820A
	s_add_i32 s18, s18, s2                                     // 00000076BB3C: 81120212
	s_mul_i32 s17, s10, 6                                      // 00000076BB40: 9611860A
	s_mov_b32 s16, 0                                           // 00000076BB44: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000076BB48: 8484810A
	s_branch 612                                               // 00000076BB4C: BFA00264 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xee0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000076BB50: 8C7E0A7E
	v_cndmask_b32_e64 v44, v44, v7, s1                         // 00000076BB54: D501002C 00060F2C
	v_cndmask_b32_e64 v1, v8, v9, s1                           // 00000076BB5C: D5010001 00061308
	v_cndmask_b32_e64 v0, v7, v8, s1                           // 00000076BB64: D5010000 00061107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 00000076BB6C: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s1                         // 00000076BB78: D5010006 00061D0D
	v_cndmask_b32_e64 v5, v12, v13, s1                         // 00000076BB80: D5010005 00061B0C
	v_cndmask_b32_e64 v4, v11, v12, s1                         // 00000076BB88: D5010004 0006190B
	v_cndmask_b32_e64 v3, v10, v11, s1                         // 00000076BB90: D5010003 0006170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000076BB98: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s1                          // 00000076BB9C: D5010002 00061509
	s_and_b32 s2, exec_lo, s2                                  // 00000076BBA4: 8B02027E
	v_add_nc_u32_e32 v41, 0x200, v41                           // 00000076BBA8: 4A5252FF 00000200
	s_or_b32 s16, s2, s16                                      // 00000076BBB0: 8C101002
	ds_load_b32 v14, v8                                        // 00000076BBB4: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 00000076BBBC: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076BBC0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000076BBC4: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 00000076BBCC: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 00000076BBD4: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000076BBD8: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 00000076BBE0: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 00000076BBE8: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076BBEC: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000076BBF0: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 00000076BBF8: D8D80000 39000008
	v_and_b32_e32 v8, 0xff, v20                                // 00000076BC00: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000076BC08: 30101082
	ds_load_b32 v58, v8                                        // 00000076BC0C: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 00000076BC14: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076BC18: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000076BC1C: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 00000076BC24: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 00000076BC2C: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000076BC30: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 00000076BC38: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 00000076BC40: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076BC44: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000076BC48: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 00000076BC50: D8D80000 3D000008
	v_and_b32_e32 v8, 0xff, v21                                // 00000076BC58: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000076BC60: 30101082
	ds_load_b32 v62, v8                                        // 00000076BC64: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 00000076BC6C: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076BC70: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000076BC74: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 00000076BC7C: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 00000076BC84: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000076BC88: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 00000076BC90: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 00000076BC98: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076BC9C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000076BCA0: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 00000076BCA8: D8D80000 41000008
	v_and_b32_e32 v8, 0xff, v22                                // 00000076BCB0: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000076BCB8: 30101082
	ds_load_b32 v66, v8                                        // 00000076BCBC: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 00000076BCC4: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076BCC8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000076BCCC: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 00000076BCD4: D8D80000 43000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 00000076BCDC: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000076BCE0: 361010FF 000003FC
	ds_load_b32 v68, v8                                        // 00000076BCE8: D8D80000 44000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 00000076BCF0: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000076BCF4: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000076BCF8: 361010FF 000003FC
	ds_load_b32 v69, v8                                        // 00000076BD00: D8D80000 45000008
	.long 0xd73c0008                                           // 00000076BD08: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000076BD0C: 02023481
	v_add_nc_u32_e32 v26, 0x400, v26                           // 00000076BD10: 4A3434FF 00000400
	.long 0xd7006a0c                                           // 00000076BD18: D7006A0C
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 00000076BD1C: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076BD20: BF870001
	v_add_co_ci_u32_e64 v13, null, s7, v9, vcc_lo              // 00000076BD24: D5207C0D 01AA1207
	s_clause 0x3                                               // 00000076BD2C: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000076BD30: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000076BD38: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000076BD40: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000076BD48: DC5E0030 317C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000076BD50: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000076BD54: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 00000076BD5C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076BD60: BF8700A1
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000076BD64: CC1A4008 1C226F09
	s_waitcnt lgkmcnt(13)                                      // 00000076BD6C: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000076BD70: CC1A4008 1C22710A
	s_waitcnt lgkmcnt(12)                                      // 00000076BD78: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076BD7C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000076BD80: CC1A4008 1C22730B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000076BD88: BF8908B7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000076BD8C: CC1A4008 1C227513
	s_waitcnt lgkmcnt(10)                                      // 00000076BD94: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076BD98: BF8700A1
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000076BD9C: CC1A4008 1C227714
	s_waitcnt lgkmcnt(9)                                       // 00000076BDA4: BF89FC97
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000076BDA8: CC1A4008 1C227915
	s_waitcnt lgkmcnt(8)                                       // 00000076BDB0: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076BDB4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000076BDB8: CC1A4008 1C227B16
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000076BDC0: BF890477
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000076BDC4: CC1A4008 1C227D2D
	s_waitcnt lgkmcnt(6)                                       // 00000076BDCC: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076BDD0: BF8700A1
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000076BDD4: CC1A4008 1C227F2E
	s_waitcnt lgkmcnt(5)                                       // 00000076BDDC: BF89FC57
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000076BDE0: CC1A4008 1C22812F
	s_waitcnt lgkmcnt(4)                                       // 00000076BDE8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076BDEC: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000076BDF0: CC1A4008 1C228330
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000076BDF8: BF890037
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000076BDFC: CC1A4008 1C228531
	.long 0xd7006a31                                           // 00000076BE04: D7006A31
	v_cndmask_b32_e32 v0, v12, v4, vcc_lo                      // 00000076BE08: 0200090C
	s_waitcnt lgkmcnt(2)                                       // 00000076BE0C: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000076BE10: BF8701C2
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000076BE14: CC1A4008 1C228732
	v_add_co_ci_u32_e64 v50, null, s5, v13, vcc_lo             // 00000076BE1C: D5207C32 01AA1A05
	.long 0xd7006a35                                           // 00000076BE24: D7006A35
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000076BE28: 02001D0C
	s_waitcnt lgkmcnt(1)                                       // 00000076BE2C: BF89FC17
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000076BE30: CC1A4008 1C228933
	v_add_co_ci_u32_e64 v54, null, s15, v13, vcc_lo            // 00000076BE38: D5207C36 01AA1A0F
	.long 0xd7006a0c                                           // 00000076BE40: D7006A0C
	v_cndmask_b32_e32 v0, v12, v17, vcc_lo                     // 00000076BE44: 0200230C
	s_waitcnt lgkmcnt(0)                                       // 00000076BE48: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000076BE4C: BF870123
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000076BE50: CC1A4008 1C228B34
	v_add_co_ci_u32_e64 v13, null, s18, v13, vcc_lo            // 00000076BE58: D5207C0D 01AA1A12
	v_fmac_f32_e32 v40, v44, v8                                // 00000076BE60: 5650112C
	s_clause 0x3                                               // 00000076BE64: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 00000076BE68: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 00000076BE70: DC5E0010 137C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 00000076BE78: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 00000076BE80: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 00000076BE88: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000076BE8C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BE94: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000076BE98: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000076BEA0: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076BEA8: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000076BEAC: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000076BEB4: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000076BEB8: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BEC0: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000076BEC4: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000076BECC: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076BED4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000076BED8: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000076BEE0: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000076BEE4: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BEEC: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000076BEF0: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000076BEF8: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076BF00: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000076BF04: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000076BF0C: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000076BF10: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BF18: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000076BF1C: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000076BF24: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BF2C: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000076BF30: CC1A4008 1C228B34
	v_fmac_f32_e32 v39, v44, v8                                // 00000076BF38: 564E112C
	s_clause 0x3                                               // 00000076BF3C: BF850003
	global_load_b128 v[8:11], v[53:54], off                    // 00000076BF40: DC5E0000 087C0035
	global_load_b128 v[19:22], v[53:54], off offset:16         // 00000076BF48: DC5E0010 137C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 00000076BF50: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 00000076BF58: DC5E0030 317C0035
	.long 0xd7006a35                                           // 00000076BF60: D7006A35
	v_cndmask_b32_e32 v0, v53, v14, vcc_lo                     // 00000076BF64: 02001D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076BF68: BF8700B1
	v_add_co_ci_u32_e64 v54, null, s15, v54, vcc_lo            // 00000076BF6C: D5207C36 01AA6C0F
	s_waitcnt vmcnt(3)                                         // 00000076BF74: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000076BF78: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000076BF80: CC1A4008 1C226F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BF88: BF870091
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000076BF8C: CC1A4008 1C22710A
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000076BF94: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000076BF9C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BFA0: BF870091
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000076BFA4: CC1A4008 1C227513
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000076BFAC: CC1A4008 1C227714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BFB4: BF870091
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000076BFB8: CC1A4008 1C227915
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000076BFC0: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000076BFC8: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BFCC: BF870091
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000076BFD0: CC1A4008 1C227D2D
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000076BFD8: CC1A4008 1C227F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BFE0: BF870091
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000076BFE4: CC1A4008 1C22812F
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000076BFEC: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000076BFF4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076BFF8: BF870091
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000076BFFC: CC1A4008 1C228531
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000076C004: CC1A4008 1C228732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C00C: BF870091
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000076C010: CC1A4008 1C228933
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000076C018: CC1A4008 1C228B34
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076C020: BF870001
	v_fmac_f32_e32 v38, v44, v8                                // 00000076C024: 564C112C
	s_clause 0x3                                               // 00000076C028: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000076C02C: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000076C034: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000076C03C: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000076C044: DC5E0030 317C000C
	.long 0xd7006a0c                                           // 00000076C04C: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000076C050: 02001D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076C054: BF8700B1
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 00000076C058: D5207C0D 01AA1A0F
	s_waitcnt vmcnt(3)                                         // 00000076C060: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000076C064: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000076C06C: CC1A4008 1C226F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C074: BF870091
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000076C078: CC1A4008 1C22710A
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000076C080: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000076C088: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C08C: BF870091
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000076C090: CC1A4008 1C227513
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000076C098: CC1A4008 1C227714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C0A0: BF870091
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000076C0A4: CC1A4008 1C227915
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000076C0AC: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000076C0B4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C0B8: BF870091
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000076C0BC: CC1A4008 1C227D2D
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000076C0C4: CC1A4008 1C227F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C0CC: BF870091
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000076C0D0: CC1A4008 1C22812F
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000076C0D8: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000076C0E0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C0E4: BF870091
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000076C0E8: CC1A4008 1C228531
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000076C0F0: CC1A4008 1C228732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C0F8: BF870091
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000076C0FC: CC1A4008 1C228933
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000076C104: CC1A4008 1C228B34
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076C10C: BF870001
	v_fmac_f32_e32 v37, v44, v8                                // 00000076C110: 564A112C
	s_clause 0x3                                               // 00000076C114: BF850003
	global_load_b128 v[8:11], v[53:54], off                    // 00000076C118: DC5E0000 087C0035
	global_load_b128 v[19:22], v[53:54], off offset:16         // 00000076C120: DC5E0010 137C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 00000076C128: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 00000076C130: DC5E0030 317C0035
	s_waitcnt vmcnt(3)                                         // 00000076C138: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000076C13C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C144: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000076C148: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000076C150: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076C158: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000076C15C: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000076C164: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000076C168: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C170: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000076C174: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000076C17C: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076C184: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000076C188: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000076C190: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000076C194: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C19C: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000076C1A0: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000076C1A8: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076C1B0: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000076C1B4: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000076C1BC: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000076C1C0: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C1C8: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000076C1CC: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000076C1D4: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C1DC: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000076C1E0: CC1A4008 1C228B34
	v_fmac_f32_e32 v36, v44, v8                                // 00000076C1E8: 5648112C
	s_clause 0x3                                               // 00000076C1EC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000076C1F0: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000076C1F8: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000076C200: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000076C208: DC5E0030 317C000C
	s_waitcnt vmcnt(3)                                         // 00000076C210: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000076C214: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C21C: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000076C220: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000076C228: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076C230: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000076C234: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000076C23C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000076C240: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C248: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000076C24C: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000076C254: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076C25C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000076C260: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000076C268: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000076C26C: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C274: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000076C278: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000076C280: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076C288: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000076C28C: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000076C294: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000076C298: CC1A4008 1C228531
	.long 0xd7006a31                                           // 00000076C2A0: D7006A31
	v_cndmask_b32_e32 v0, v53, v14, vcc_lo                     // 00000076C2A4: 02001D35
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000076C2A8: BF8701B2
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000076C2AC: CC1A4008 1C228732
	v_add_co_ci_u32_e64 v50, null, s15, v54, vcc_lo            // 00000076C2B4: D5207C32 01AA6C0F
	.long 0xd7006a0c                                           // 00000076C2BC: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000076C2C0: 02001D0C
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000076C2C4: CC1A4008 1C228933
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 00000076C2CC: D5207C0D 01AA1A0F
	.long 0xd7006a1c                                           // 00000076C2D4: D7006A1C
	v_cndmask_b32_e32 v0, v28, v192, vcc_lo                    // 00000076C2D8: 0201811C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000076C2DC: BF870123
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000076C2E0: CC1A4008 1C228B34
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 00000076C2E8: D5207C1D 01AA3A80
	v_fmac_f32_e32 v35, v44, v8                                // 00000076C2F0: 5646112C
	s_clause 0x3                                               // 00000076C2F4: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 00000076C2F8: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 00000076C300: DC5E0010 137C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 00000076C308: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 00000076C310: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 00000076C318: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000076C31C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C324: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000076C328: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000076C330: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076C338: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000076C33C: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000076C344: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000076C348: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C350: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000076C354: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000076C35C: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076C364: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000076C368: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000076C370: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000076C374: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C37C: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000076C380: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000076C388: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076C390: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000076C394: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000076C39C: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000076C3A0: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C3A8: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000076C3AC: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000076C3B4: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C3BC: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000076C3C0: CC1A4008 1C228B34
	v_fmac_f32_e32 v34, v44, v8                                // 00000076C3C8: 5644112C
	s_clause 0x3                                               // 00000076C3CC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000076C3D0: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000076C3D8: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000076C3E0: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000076C3E8: DC5E0030 317C000C
	s_waitcnt vmcnt(3)                                         // 00000076C3F0: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000076C3F4: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C3FC: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000076C400: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000076C408: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076C410: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000076C414: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000076C41C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000076C420: CC1A4008 1C227513
	v_mov_b32_e32 v19, v15                                     // 00000076C428: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000076C42C: BF870122
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000076C430: CC1A4008 1C227714
	v_mov_b32_e32 v20, v16                                     // 00000076C438: 7E280310
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000076C43C: CC1A4008 1C227915
	v_mov_b32_e32 v21, v17                                     // 00000076C444: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000076C448: BF870132
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000076C44C: CC1A4008 1C227B16
	v_mov_b32_e32 v22, v18                                     // 00000076C454: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 00000076C458: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000076C45C: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C464: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000076C468: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000076C470: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076C478: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000076C47C: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000076C484: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000076C488: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C490: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000076C494: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000076C49C: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C4A4: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000076C4A8: CC1A4008 1C228B34
	v_dual_fmac_f32 v31, v44, v8 :: v_dual_mov_b32 v14, v7     // 00000076C4B0: C810112C 1F0E0107
	v_dual_mov_b32 v44, v43 :: v_dual_mov_b32 v13, v6          // 00000076C4B8: CA10012B 2C0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 00000076C4C0: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 00000076C4C8: CA100103 0A080102
	v_dual_mov_b32 v8, v1 :: v_dual_mov_b32 v7, v0             // 00000076C4D0: CA100101 08060100
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000076C4D8: 917E107E
	s_cbranch_execz 28                                         // 00000076C4DC: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf50>
	s_waitcnt vmcnt(0)                                         // 00000076C4E0: BF8903F7
	v_dual_mov_b32 v15, v19 :: v_dual_add_nc_u32 v42, 32, v42  // 00000076C4E4: CA200113 0F2A54A0
	v_dual_mov_b32 v16, v20 :: v_dual_mov_b32 v17, v21         // 00000076C4EC: CA100114 10100115
	v_mov_b32_e32 v18, v22                                     // 00000076C4F4: 7E240316
	s_delay_alu instid0(VALU_DEP_3)                            // 00000076C4F8: BF870003
	.long 0xd4430002                                           // 00000076C4FC: D4430002
	v_cndmask_b32_e32 v1, s20, v42, vcc_lo                     // 00000076C500: 02025414
	s_mov_b32 s10, exec_lo                                     // 00000076C504: BE8A007E
	.long 0xd4c4007e                                           // 00000076C508: D4C4007E
	v_cndmask_b32_e32 v1, s20, v42, vcc_lo                     // 00000076C50C: 02025414
	s_cbranch_execz 64911                                      // 00000076C510: BFA5FD8F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x550>
	.long 0xd7006a00                                           // 00000076C514: D7006A00
	v_cndmask_b32_e32 v1, v25, v41, vcc_lo                     // 00000076C518: 02025319
	s_delay_alu instid0(VALU_DEP_1)                            // 00000076C51C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 00000076C520: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 00000076C528: 7C9A4081
	v_mov_b32_e32 v43, v44                                     // 00000076C52C: 7E56032C
	global_load_b128 v[15:18], v[0:1], off                     // 00000076C530: DC5E0000 0F7C0000
	s_cbranch_vccnz 64901                                      // 00000076C538: BFA4FD85 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x550>
	global_load_d16_b16 v0, v[28:29], off                      // 00000076C53C: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 00000076C544: BF8903F7
	v_cvt_f32_f16_e32 v43, v0                                  // 00000076C548: 7E561700
	s_branch 64896                                             // 00000076C54C: BFA0FD80 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x550>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000076C550: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076C554: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000076C558: 8C7E037E
	.long 0xd71f0000                                           // 00000076C55C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000076C560: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 00000076C564: 3A020090
	v_xor_b32_e32 v9, 8, v0                                    // 00000076C568: 3A120088
	v_xor_b32_e32 v17, 4, v0                                   // 00000076C56C: 3A220084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000076C570: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 00000076C574: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000076C578: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000076C57C: 7C9812A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000076C580: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000076C584: 30020282
	ds_bpermute_b32 v2, v1, v40                                // 00000076C588: DACC0000 02002801
	s_waitcnt lgkmcnt(0)                                       // 00000076C590: BF89FC07
	v_add_f32_e32 v2, v40, v2                                  // 00000076C594: 06040528
	ds_bpermute_b32 v4, v1, v38                                // 00000076C598: DACC0000 04002601
	ds_bpermute_b32 v8, v1, v34                                // 00000076C5A0: DACC0000 08002201
	ds_bpermute_b32 v6, v1, v36                                // 00000076C5A8: DACC0000 06002401
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 00000076C5B0: 02121300
	ds_bpermute_b32 v5, v1, v37                                // 00000076C5B4: DACC0000 05002501
	ds_bpermute_b32 v7, v1, v35                                // 00000076C5BC: DACC0000 07002301
	ds_bpermute_b32 v3, v1, v39                                // 00000076C5C4: DACC0000 03002701
	ds_bpermute_b32 v1, v1, v31                                // 00000076C5CC: DACC0000 01001F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 00000076C5D4: 7C9822A0
	s_waitcnt lgkmcnt(6)                                       // 00000076C5D8: BF89FC67
	v_add_f32_e32 v4, v38, v4                                  // 00000076C5DC: 06080926
	s_waitcnt lgkmcnt(5)                                       // 00000076C5E0: BF89FC57
	v_dual_add_f32 v8, v34, v8 :: v_dual_lshlrev_b32 v9, 2, v9 // 00000076C5E4: C9221122 08081282
	s_waitcnt lgkmcnt(4)                                       // 00000076C5EC: BF89FC47
	v_add_f32_e32 v6, v36, v6                                  // 00000076C5F0: 060C0D24
	ds_bpermute_b32 v12, v9, v4                                // 00000076C5F4: DACC0000 0C000409
	ds_bpermute_b32 v14, v9, v6                                // 00000076C5FC: DACC0000 0E000609
	s_waitcnt lgkmcnt(5)                                       // 00000076C604: BF89FC57
	v_add_f32_e32 v5, v37, v5                                  // 00000076C608: 060A0B25
	s_waitcnt lgkmcnt(4)                                       // 00000076C60C: BF89FC47
	v_add_f32_e32 v7, v35, v7                                  // 00000076C610: 060E0F23
	ds_bpermute_b32 v16, v9, v8                                // 00000076C614: DACC0000 10000809
	ds_bpermute_b32 v10, v9, v2                                // 00000076C61C: DACC0000 0A000209
	s_waitcnt lgkmcnt(5)                                       // 00000076C624: BF89FC57
	v_add_f32_e32 v3, v39, v3                                  // 00000076C628: 06060727
	s_waitcnt lgkmcnt(3)                                       // 00000076C62C: BF89FC37
	v_dual_add_f32 v1, v31, v1 :: v_dual_add_f32 v4, v4, v12   // 00000076C630: C908031F 01041904
	ds_bpermute_b32 v13, v9, v5                                // 00000076C638: DACC0000 0D000509
	s_waitcnt lgkmcnt(3)                                       // 00000076C640: BF89FC37
	v_add_f32_e32 v6, v6, v14                                  // 00000076C644: 060C1D06
	ds_bpermute_b32 v15, v9, v7                                // 00000076C648: DACC0000 0F000709
	s_waitcnt lgkmcnt(3)                                       // 00000076C650: BF89FC37
	v_add_f32_e32 v8, v8, v16                                  // 00000076C654: 06102108
	s_waitcnt lgkmcnt(2)                                       // 00000076C658: BF89FC27
	v_add_f32_e32 v2, v2, v10                                  // 00000076C65C: 06041502
	ds_bpermute_b32 v11, v9, v3                                // 00000076C660: DACC0000 0B000309
	ds_bpermute_b32 v9, v9, v1                                 // 00000076C668: DACC0000 09000109
	s_waitcnt lgkmcnt(3)                                       // 00000076C670: BF89FC37
	v_add_f32_e32 v5, v5, v13                                  // 00000076C674: 060A1B05
	v_cndmask_b32_e32 v17, v0, v17, vcc_lo                     // 00000076C678: 02222300
	s_waitcnt lgkmcnt(2)                                       // 00000076C67C: BF89FC27
	v_add_f32_e32 v7, v7, v15                                  // 00000076C680: 060E1F07
	s_delay_alu instid0(VALU_DEP_2)                            // 00000076C684: BF870002
	v_lshlrev_b32_e32 v17, 2, v17                              // 00000076C688: 30222282
	s_waitcnt lgkmcnt(0)                                       // 00000076C68C: BF89FC07
	v_add_f32_e32 v1, v1, v9                                   // 00000076C690: 06021301
	ds_bpermute_b32 v15, v17, v8                               // 00000076C694: DACC0000 0F000811
	s_waitcnt lgkmcnt(0)                                       // 00000076C69C: BF89FC07
	v_add_f32_e32 v8, v8, v15                                  // 00000076C6A0: 06101F08
	ds_bpermute_b32 v9, v17, v2                                // 00000076C6A4: DACC0000 09000211
	v_add_f32_e32 v3, v3, v11                                  // 00000076C6AC: 06061703
	ds_bpermute_b32 v11, v17, v4                               // 00000076C6B0: DACC0000 0B000411
	ds_bpermute_b32 v12, v17, v5                               // 00000076C6B8: DACC0000 0C000511
	ds_bpermute_b32 v13, v17, v6                               // 00000076C6C0: DACC0000 0D000611
	ds_bpermute_b32 v14, v17, v7                               // 00000076C6C8: DACC0000 0E000711
	ds_bpermute_b32 v16, v17, v1                               // 00000076C6D0: DACC0000 10000111
	s_waitcnt lgkmcnt(5)                                       // 00000076C6D8: BF89FC57
	v_add_f32_e32 v2, v2, v9                                   // 00000076C6DC: 06041302
	ds_bpermute_b32 v10, v17, v3                               // 00000076C6E0: DACC0000 0A000311
	v_xor_b32_e32 v17, 2, v0                                   // 00000076C6E8: 3A220082
	s_waitcnt lgkmcnt(5)                                       // 00000076C6EC: BF89FC57
	v_add_f32_e32 v9, v4, v11                                  // 00000076C6F0: 06121704
	v_xor_b32_e32 v4, 1, v0                                    // 00000076C6F4: 3A080081
	s_waitcnt lgkmcnt(3)                                       // 00000076C6F8: BF89FC37
	v_add_f32_e32 v11, v6, v13                                 // 00000076C6FC: 06161B06
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 00000076C700: 7C9822A0
	v_cndmask_b32_e32 v17, v0, v17, vcc_lo                     // 00000076C704: 02222300
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000076C708: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000076C70C: BF8701C2
	v_dual_cndmask_b32 v0, v0, v4 :: v_dual_lshlrev_b32 v17, 2, v17// 00000076C710: CA620900 00102282
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 00000076C718: 7C943C80
	s_waitcnt lgkmcnt(0)                                       // 00000076C71C: BF89FC07
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v10, v5, v12  // 00000076C720: C9081503 030A1905
	v_dual_add_f32 v7, v7, v14 :: v_dual_lshlrev_b32 v18, 2, v0// 00000076C728: C9221D07 07120082
	s_and_b32 s0, vcc_lo, s0                                   // 00000076C730: 8B00006A
	ds_bpermute_b32 v12, v17, v10                              // 00000076C734: DACC0000 0C000A11
	s_waitcnt lgkmcnt(0)                                       // 00000076C73C: BF89FC07
	v_add_f32_e32 v0, v10, v12                                 // 00000076C740: 0600190A
	v_add_f32_e32 v13, v1, v16                                 // 00000076C744: 061A2101
	ds_bpermute_b32 v16, v17, v8                               // 00000076C748: DACC0000 10000811
	s_waitcnt lgkmcnt(0)                                       // 00000076C750: BF89FC07
	v_add_f32_e32 v12, v8, v16                                 // 00000076C754: 06182108
	ds_bpermute_b32 v1, v17, v2                                // 00000076C758: DACC0000 01000211
	ds_bpermute_b32 v6, v17, v9                                // 00000076C760: DACC0000 06000911
	ds_bpermute_b32 v14, v17, v11                              // 00000076C768: DACC0000 0E000B11
	ds_bpermute_b32 v15, v17, v7                               // 00000076C770: DACC0000 0F000711
	s_waitcnt lgkmcnt(3)                                       // 00000076C778: BF89FC37
	v_add_f32_e32 v4, v2, v1                                   // 00000076C77C: 06080302
	ds_bpermute_b32 v5, v17, v3                                // 00000076C780: DACC0000 05000311
	ds_bpermute_b32 v17, v17, v13                              // 00000076C788: DACC0000 11000D11
	s_waitcnt lgkmcnt(4)                                       // 00000076C790: BF89FC47
	v_add_f32_e32 v6, v9, v6                                   // 00000076C794: 060C0D09
	s_waitcnt lgkmcnt(3)                                       // 00000076C798: BF89FC37
	v_add_f32_e32 v1, v11, v14                                 // 00000076C79C: 06021D0B
	s_waitcnt lgkmcnt(2)                                       // 00000076C7A0: BF89FC27
	v_add_f32_e32 v7, v7, v15                                  // 00000076C7A4: 060E1F07
	ds_bpermute_b32 v8, v18, v4                                // 00000076C7A8: DACC0000 08000412
	ds_bpermute_b32 v2, v18, v0                                // 00000076C7B0: DACC0000 02000012
	ds_bpermute_b32 v10, v18, v6                               // 00000076C7B8: DACC0000 0A000612
	ds_bpermute_b32 v14, v18, v12                              // 00000076C7C0: DACC0000 0E000C12
	ds_bpermute_b32 v11, v18, v7                               // 00000076C7C8: DACC0000 0B000712
	s_waitcnt lgkmcnt(6)                                       // 00000076C7D0: BF89FC67
	v_add_f32_e32 v5, v3, v5                                   // 00000076C7D4: 060A0B03
	s_waitcnt lgkmcnt(5)                                       // 00000076C7D8: BF89FC57
	v_add_f32_e32 v13, v13, v17                                // 00000076C7DC: 061A230D
	ds_bpermute_b32 v3, v18, v1                                // 00000076C7E0: DACC0000 03000112
	ds_bpermute_b32 v9, v18, v5                                // 00000076C7E8: DACC0000 09000512
	ds_bpermute_b32 v15, v18, v13                              // 00000076C7F0: DACC0000 0F000D12
	s_and_saveexec_b32 s1, s0                                  // 00000076C7F8: BE812000
	s_cbranch_execz 70                                         // 00000076C7FC: BFA50046 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1318>
	s_waitcnt lgkmcnt(0)                                       // 00000076C800: BF89FC07
	v_dual_add_f32 v15, v13, v15 :: v_dual_add_f32 v14, v12, v14// 00000076C804: C9081F0D 0F0E1D0C
	.long 0xd73c000c                                           // 00000076C80C: D73C000C
	v_cndmask_b32_e32 v1, 2, v23, vcc_lo                       // 00000076C810: 02022E82
	v_dual_add_f32 v16, v7, v11 :: v_dual_add_f32 v17, v6, v10 // 00000076C814: C9081707 10101506
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000076C81C: 8480820C
	s_waitcnt vmcnt(0)                                         // 00000076C820: BF8903F7
	v_dual_add_f32 v18, v5, v9 :: v_dual_add_f32 v19, v4, v8   // 00000076C824: C9081305 12121104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C82C: BF870093
	.long 0xd7006a06                                           // 00000076C830: D7006A06
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 00000076C834: 02021808
	v_add_co_ci_u32_e64 v7, null, s9, v13, vcc_lo              // 00000076C838: D5207C07 01AA1A09
	v_dual_add_f32 v12, v1, v3 :: v_dual_add_f32 v13, v0, v2   // 00000076C840: C9080701 0C0C0500
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000076C848: BF870193
	.long 0xd7006a08                                           // 00000076C84C: D7006A08
	v_cndmask_b32_e32 v0, v6, v0, vcc_lo                       // 00000076C850: 02000106
	v_mad_u64_u32 v[4:5], null, s12, 12, v[6:7]                // 00000076C854: D6FE7C04 0419180C
	v_add_co_ci_u32_e64 v9, null, s1, v7, vcc_lo               // 00000076C85C: D5207C09 01AA0E01
	s_lshl_b64 s[0:1], s[12:13], 3                             // 00000076C864: 8480830C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C868: BF870099
	.long 0xd7006a0a                                           // 00000076C86C: D7006A0A
	v_cndmask_b32_e32 v0, v6, v0, vcc_lo                       // 00000076C870: 02000106
	v_add_co_ci_u32_e64 v11, null, s1, v7, vcc_lo              // 00000076C874: D5207C0B 01AA0E01
	s_clause 0x2                                               // 00000076C87C: BF850002
	global_store_b32 v[6:7], v19, off                          // 00000076C880: DC6A0000 007C1306
	global_store_b32 v[8:9], v18, off                          // 00000076C888: DC6A0000 007C1208
	global_store_b32 v[10:11], v17, off                        // 00000076C890: DC6A0000 007C110A
	v_mad_u64_u32 v[5:6], null, s13, 12, v[5:6]                // 00000076C898: D6FE7C05 0415180D
	.long 0xd7006a00                                           // 00000076C8A0: D7006A00
	v_cndmask_b32_e32 v0, v10, v0, vcc_lo                      // 00000076C8A4: 0200010A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076C8A8: BF8700A1
	v_add_co_ci_u32_e64 v1, null, s1, v11, vcc_lo              // 00000076C8AC: D5207C01 01AA1601
	.long 0xd7006a02                                           // 00000076C8B4: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 00000076C8B8: 02000104
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 00000076C8BC: D5207C03 01AA0A01
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C8C4: BF870094
	.long 0xd7006a06                                           // 00000076C8C8: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000076C8CC: 02000100
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 00000076C8D0: D5207C07 01AA0201
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076C8D8: BF870094
	.long 0xd7006a08                                           // 00000076C8DC: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 00000076C8E0: 02000102
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 00000076C8E4: D5207C09 01AA0601
	s_clause 0x4                                               // 00000076C8EC: BF850004
	global_store_b32 v[4:5], v13, off                          // 00000076C8F0: DC6A0000 007C0D04
	global_store_b32 v[0:1], v12, off                          // 00000076C8F8: DC6A0000 007C0C00
	global_store_b32 v[2:3], v16, off                          // 00000076C900: DC6A0000 007C1002
	global_store_b32 v[6:7], v14, off                          // 00000076C908: DC6A0000 007C0E06
	global_store_b32 v[8:9], v15, off                          // 00000076C910: DC6A0000 007C0F08
	s_endpgm                                                   // 00000076C918: BFB00000
		...

