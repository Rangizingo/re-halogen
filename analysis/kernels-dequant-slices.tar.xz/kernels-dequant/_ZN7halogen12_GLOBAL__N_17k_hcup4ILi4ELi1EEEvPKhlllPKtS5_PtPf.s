00000000002d2c00 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi4ELi1EEEvPKhlllPKtS5_PtPf>:
; _ZN7halogen12_GLOBAL__N_17k_hcup4ILi4ELi1EEEvPKhlllPKtS5_PtPf():
	s_load_b128 s[12:15], s[0:1], null                         // 0000002D2C00: F4080300 F8000000
	v_and_b32_e32 v2, 15, v0                                   // 0000002D2C08: 3604008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000002D2C0C: 32020084
	s_load_b256 s[4:11], s[0:1], 0x20                          // 0000002D2C10: F40C0100 F8000020
	s_mov_b32 s3, exec_lo                                      // 0000002D2C18: BE83007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D2C1C: BF870112
	v_lshlrev_b32_e32 v3, 2, v2                                // 0000002D2C20: 30060482
	v_lshlrev_b32_e32 v4, 2, v1                                // 0000002D2C24: 30080282
	s_waitcnt lgkmcnt(0)                                       // 0000002D2C28: BF89FC07
	s_clause 0x1                                               // 0000002D2C2C: BF850001
	global_load_b32 v3, v3, s[12:13]                           // 0000002D2C30: DC520000 030C0003
	global_load_b32 v4, v4, s[12:13]                           // 0000002D2C38: DC520000 040C0004
	s_waitcnt vmcnt(1)                                         // 0000002D2C40: BF8907F7
	v_bfe_u32 v5, v3, 16, 1                                    // 0000002D2C44: D6100005 02052103
	s_waitcnt vmcnt(0)                                         // 0000002D2C4C: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 0000002D2C50: D6100006 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002D2C58: BF8701A2
	v_add3_u32 v3, v3, v5, 0x7fff                              // 0000002D2C5C: D6550003 03FE0B03 00007FFF
	.long 0x7f0a3880                                           // 0000002D2C68: 7F0A3880
	v_add3_u32 v4, v4, v6, 0x7fff                              // 0000002D2C6C: D6550004 03FE0D04 00007FFF
	v_lshlrev_b32_e32 v6, 2, v0                                // 0000002D2C78: 300C0082
	v_mov_b32_e32 v0, 0                                        // 0000002D2C7C: 7E000280
	.long 0x7e0a3983                                           // 0000002D2C80: 7E0A3983
	v_mov_b32_e32 v3, 0                                        // 0000002D2C84: 7E060280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002D2C88: BF870002
	v_and_or_b32 v7, 0xffff0000, v4, v5                        // 0000002D2C8C: D6570007 041608FF FFFF0000
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 0000002D2C98: CA100080 04040080
	ds_store_b32 v6, v7                                        // 0000002D2CA0: D8340000 00000706
	s_waitcnt lgkmcnt(0)                                       // 0000002D2CA8: BF89FC07
	s_barrier                                                  // 0000002D2CAC: BFBD0000
	buffer_gl0_inv                                             // 0000002D2CB0: E0AC0000 00000000
	v_cmpx_gt_u32_e32 10, v2                                   // 0000002D2CB8: 7D98048A
	s_cbranch_execz 293                                        // 0000002D2CBC: BFA50125 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi4ELi1EEEvPKhlllPKtS5_PtPf+0x554>
	v_lshlrev_b32_e32 v0, 4, v2                                // 0000002D2CC0: 30000484
	s_add_u32 s14, s12, s14                                    // 0000002D2CC4: 800E0E0C
	s_addc_u32 s15, s13, s15                                   // 0000002D2CC8: 820F0F0D
	s_load_b64 s[0:1], s[0:1], 0x10                            // 0000002D2CCC: F4040000 F8000010
	global_load_b128 v[3:6], v0, s[14:15]                      // 0000002D2CD4: DC5E0000 030E0000
	v_lshlrev_b32_e32 v0, 6, v2                                // 0000002D2CDC: 30000486
	s_clause 0xf                                               // 0000002D2CE0: BF85000F
	global_load_b128 v[7:10], v0, s[4:5]                       // 0000002D2CE4: DC5E0000 07040000
	global_load_b128 v[11:14], v0, s[4:5] offset:640           // 0000002D2CEC: DC5E0280 0B040000
	global_load_b128 v[15:18], v0, s[4:5] offset:1280          // 0000002D2CF4: DC5E0500 0F040000
	global_load_b128 v[19:22], v0, s[4:5] offset:1920          // 0000002D2CFC: DC5E0780 13040000
	global_load_b128 v[23:26], v0, s[4:5] offset:16            // 0000002D2D04: DC5E0010 17040000
	global_load_b128 v[27:30], v0, s[4:5] offset:656           // 0000002D2D0C: DC5E0290 1B040000
	global_load_b128 v[31:34], v0, s[4:5] offset:1296          // 0000002D2D14: DC5E0510 1F040000
	global_load_b128 v[35:38], v0, s[4:5] offset:1936          // 0000002D2D1C: DC5E0790 23040000
	global_load_b128 v[39:42], v0, s[4:5] offset:32            // 0000002D2D24: DC5E0020 27040000
	global_load_b128 v[43:46], v0, s[4:5] offset:672           // 0000002D2D2C: DC5E02A0 2B040000
	global_load_b128 v[47:50], v0, s[4:5] offset:1312          // 0000002D2D34: DC5E0520 2F040000
	global_load_b128 v[51:54], v0, s[4:5] offset:1952          // 0000002D2D3C: DC5E07A0 33040000
	global_load_b128 v[55:58], v0, s[4:5] offset:48            // 0000002D2D44: DC5E0030 37040000
	global_load_b128 v[59:62], v0, s[4:5] offset:688           // 0000002D2D4C: DC5E02B0 3B040000
	global_load_b128 v[63:66], v0, s[4:5] offset:1328          // 0000002D2D54: DC5E0530 3F040000
	global_load_b128 v[67:70], v0, s[4:5] offset:1968          // 0000002D2D5C: DC5E07B0 43040000
	v_lshlrev_b32_e32 v0, 1, v2                                // 0000002D2D64: 30000481
	s_waitcnt lgkmcnt(0)                                       // 0000002D2D68: BF89FC07
	s_add_u32 s0, s12, s0                                      // 0000002D2D6C: 8000000C
	s_addc_u32 s1, s13, s1                                     // 0000002D2D70: 8201010D
	global_load_d16_b16 v71, v0, s[0:1]                        // 0000002D2D74: DC820000 47000000
	s_waitcnt vmcnt(17)                                        // 0000002D2D7C: BF8947F7
	v_and_b32_e32 v0, 0xff, v3                                 // 0000002D2D80: 360006FF 000000FF
	v_lshrrev_b32_e32 v72, 6, v3                               // 0000002D2D88: 32900686
	v_lshrrev_b32_e32 v73, 14, v3                              // 0000002D2D8C: 3292068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000002D2D90: 32060696
	v_and_b32_e32 v74, 0xff, v4                                // 0000002D2D94: 369408FF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000002D2D9C: 30000082
	v_and_b32_e32 v72, 0x3fc, v72                              // 0000002D2DA0: 369090FF 000003FC
	v_and_b32_e32 v73, 0x3fc, v73                              // 0000002D2DA8: 369292FF 000003FC
	v_lshrrev_b32_e32 v75, 6, v4                               // 0000002D2DB0: 32960886
	v_lshrrev_b32_e32 v76, 14, v4                              // 0000002D2DB4: 3298088E
	ds_load_b32 v0, v0                                         // 0000002D2DB8: D8D80000 00000000
	ds_load_b32 v72, v72                                       // 0000002D2DC0: D8D80000 48000048
	ds_load_b32 v73, v73                                       // 0000002D2DC8: D8D80000 49000049
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000002D2DD0: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000002D2DD4: 360606FF 000003FC
	v_lshlrev_b32_e32 v74, 2, v74                              // 0000002D2DDC: 30949482
	v_and_b32_e32 v75, 0x3fc, v75                              // 0000002D2DE0: 369696FF 000003FC
	v_and_b32_e32 v76, 0x3fc, v76                              // 0000002D2DE8: 369898FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000002D2DF0: 360808FF 000003FC
	ds_load_b32 v3, v3                                         // 0000002D2DF8: D8D80000 03000003
	ds_load_b32 v74, v74                                       // 0000002D2E00: D8D80000 4A00004A
	ds_load_b32 v75, v75                                       // 0000002D2E08: D8D80000 4B00004B
	ds_load_b32 v76, v76                                       // 0000002D2E10: D8D80000 4C00004C
	ds_load_b32 v4, v4                                         // 0000002D2E18: D8D80000 04000004
	v_and_b32_e32 v77, 0xff, v5                                // 0000002D2E20: 369A0AFF 000000FF
	v_lshrrev_b32_e32 v78, 6, v5                               // 0000002D2E28: 329C0A86
	v_and_b32_e32 v80, 0xff, v6                                // 0000002D2E2C: 36A00CFF 000000FF
	v_lshrrev_b32_e32 v81, 6, v6                               // 0000002D2E34: 32A20C86
	v_lshrrev_b32_e32 v82, 14, v6                              // 0000002D2E38: 32A40C8E
	v_lshrrev_b32_e32 v6, 22, v6                               // 0000002D2E3C: 320C0C96
	v_lshlrev_b32_e32 v77, 2, v77                              // 0000002D2E40: 309A9A82
	v_lshrrev_b32_e32 v79, 14, v5                              // 0000002D2E44: 329E0A8E
	v_and_b32_e32 v78, 0x3fc, v78                              // 0000002D2E48: 369C9CFF 000003FC
	v_lshrrev_b32_e32 v5, 22, v5                               // 0000002D2E50: 320A0A96
	s_waitcnt vmcnt(16) lgkmcnt(7)                             // 0000002D2E54: BF894077
	v_dot2_f32_bf16 v7, v7, v0, 0                              // 0000002D2E58: CC1A4007 1A020107
	s_waitcnt vmcnt(15)                                        // 0000002D2E60: BF893FF7
	v_dot2_f32_bf16 v11, v11, v0, 0                            // 0000002D2E64: CC1A400B 1A02010B
	s_waitcnt vmcnt(14)                                        // 0000002D2E6C: BF893BF7
	v_dot2_f32_bf16 v15, v15, v0, 0                            // 0000002D2E70: CC1A400F 1A02010F
	s_waitcnt vmcnt(13)                                        // 0000002D2E78: BF8937F7
	v_dot2_f32_bf16 v0, v19, v0, 0                             // 0000002D2E7C: CC1A4000 1A020113
	v_and_b32_e32 v79, 0x3fc, v79                              // 0000002D2E84: 369E9EFF 000003FC
	s_waitcnt lgkmcnt(6)                                       // 0000002D2E8C: BF89FC67
	v_dot2_f32_bf16 v7, v8, v72, v7                            // 0000002D2E90: CC1A4007 1C1E9108
	v_dot2_f32_bf16 v8, v12, v72, v11                          // 0000002D2E98: CC1A4008 1C2E910C
	v_dot2_f32_bf16 v11, v16, v72, v15                         // 0000002D2EA0: CC1A400B 1C3E9110
	v_dot2_f32_bf16 v0, v20, v72, v0                           // 0000002D2EA8: CC1A4000 1C029114
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000002D2EB0: 360A0AFF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000002D2EB8: BF89FC57
	v_dot2_f32_bf16 v7, v9, v73, v7                            // 0000002D2EBC: CC1A4007 1C1E9309
	v_dot2_f32_bf16 v8, v13, v73, v8                           // 0000002D2EC4: CC1A4008 1C22930D
	v_dot2_f32_bf16 v9, v17, v73, v11                          // 0000002D2ECC: CC1A4009 1C2E9311
	v_dot2_f32_bf16 v0, v21, v73, v0                           // 0000002D2ED4: CC1A4000 1C029315
	v_lshlrev_b32_e32 v19, 2, v80                              // 0000002D2EDC: 3026A082
	s_waitcnt lgkmcnt(4)                                       // 0000002D2EE0: BF89FC47
	v_dot2_f32_bf16 v7, v10, v3, v7                            // 0000002D2EE4: CC1A4007 1C1E070A
	v_dot2_f32_bf16 v8, v14, v3, v8                            // 0000002D2EEC: CC1A4008 1C22070E
	v_dot2_f32_bf16 v9, v18, v3, v9                            // 0000002D2EF4: CC1A4009 1C260712
	v_dot2_f32_bf16 v0, v22, v3, v0                            // 0000002D2EFC: CC1A4000 1C020716
	v_and_b32_e32 v3, 0x3fc, v6                                // 0000002D2F04: 36060CFF 000003FC
	s_waitcnt vmcnt(12) lgkmcnt(3)                             // 0000002D2F0C: BF893037
	v_dot2_f32_bf16 v6, v23, v74, v7                           // 0000002D2F10: CC1A4006 1C1E9517
	s_waitcnt vmcnt(11)                                        // 0000002D2F18: BF892FF7
	v_dot2_f32_bf16 v7, v27, v74, v8                           // 0000002D2F1C: CC1A4007 1C22951B
	s_waitcnt vmcnt(10)                                        // 0000002D2F24: BF892BF7
	v_dot2_f32_bf16 v8, v31, v74, v9                           // 0000002D2F28: CC1A4008 1C26951F
	s_waitcnt vmcnt(9)                                         // 0000002D2F30: BF8927F7
	v_dot2_f32_bf16 v0, v35, v74, v0                           // 0000002D2F34: CC1A4000 1C029523
	ds_load_b32 v9, v77                                        // 0000002D2F3C: D8D80000 0900004D
	ds_load_b32 v10, v78                                       // 0000002D2F44: D8D80000 0A00004E
	ds_load_b32 v13, v79                                       // 0000002D2F4C: D8D80000 0D00004F
	s_waitcnt lgkmcnt(5)                                       // 0000002D2F54: BF89FC57
	v_dot2_f32_bf16 v6, v24, v75, v6                           // 0000002D2F58: CC1A4006 1C1A9718
	v_dot2_f32_bf16 v7, v28, v75, v7                           // 0000002D2F60: CC1A4007 1C1E971C
	v_dot2_f32_bf16 v8, v32, v75, v8                           // 0000002D2F68: CC1A4008 1C229720
	v_dot2_f32_bf16 v0, v36, v75, v0                           // 0000002D2F70: CC1A4000 1C029724
	v_and_b32_e32 v12, 0x3fc, v81                              // 0000002D2F78: 3618A2FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000002D2F80: BF89FC47
	v_dot2_f32_bf16 v6, v25, v76, v6                           // 0000002D2F84: CC1A4006 1C1A9919
	v_dot2_f32_bf16 v7, v29, v76, v7                           // 0000002D2F8C: CC1A4007 1C1E991D
	v_dot2_f32_bf16 v8, v33, v76, v8                           // 0000002D2F94: CC1A4008 1C229921
	v_dot2_f32_bf16 v0, v37, v76, v0                           // 0000002D2F9C: CC1A4000 1C029925
	v_and_b32_e32 v11, 0x3fc, v82                              // 0000002D2FA4: 3616A4FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000002D2FAC: BF89FC37
	v_dot2_f32_bf16 v6, v26, v4, v6                            // 0000002D2FB0: CC1A4006 1C1A091A
	v_dot2_f32_bf16 v7, v30, v4, v7                            // 0000002D2FB8: CC1A4007 1C1E091E
	v_dot2_f32_bf16 v8, v34, v4, v8                            // 0000002D2FC0: CC1A4008 1C220922
	v_dot2_f32_bf16 v0, v38, v4, v0                            // 0000002D2FC8: CC1A4000 1C020926
	ds_load_b32 v4, v5                                         // 0000002D2FD0: D8D80000 04000005
	ds_load_b32 v5, v19                                        // 0000002D2FD8: D8D80000 05000013
	ds_load_b32 v12, v12                                       // 0000002D2FE0: D8D80000 0C00000C
	ds_load_b32 v11, v11                                       // 0000002D2FE8: D8D80000 0B00000B
	ds_load_b32 v3, v3                                         // 0000002D2FF0: D8D80000 03000003
	s_waitcnt vmcnt(8) lgkmcnt(7)                              // 0000002D2FF8: BF892077
	v_dot2_f32_bf16 v6, v39, v9, v6                            // 0000002D2FFC: CC1A4006 1C1A1327
	s_waitcnt vmcnt(7)                                         // 0000002D3004: BF891FF7
	v_dot2_f32_bf16 v7, v43, v9, v7                            // 0000002D3008: CC1A4007 1C1E132B
	s_waitcnt vmcnt(6)                                         // 0000002D3010: BF891BF7
	v_dot2_f32_bf16 v8, v47, v9, v8                            // 0000002D3014: CC1A4008 1C22132F
	s_waitcnt vmcnt(5)                                         // 0000002D301C: BF8917F7
	v_dot2_f32_bf16 v0, v51, v9, v0                            // 0000002D3020: CC1A4000 1C021333
	s_waitcnt lgkmcnt(6)                                       // 0000002D3028: BF89FC67
	v_dot2_f32_bf16 v6, v40, v10, v6                           // 0000002D302C: CC1A4006 1C1A1528
	v_dot2_f32_bf16 v7, v44, v10, v7                           // 0000002D3034: CC1A4007 1C1E152C
	v_dot2_f32_bf16 v8, v48, v10, v8                           // 0000002D303C: CC1A4008 1C221530
	v_dot2_f32_bf16 v0, v52, v10, v0                           // 0000002D3044: CC1A4000 1C021534
	s_waitcnt lgkmcnt(5)                                       // 0000002D304C: BF89FC57
	v_dot2_f32_bf16 v6, v41, v13, v6                           // 0000002D3050: CC1A4006 1C1A1B29
	v_dot2_f32_bf16 v7, v45, v13, v7                           // 0000002D3058: CC1A4007 1C1E1B2D
	v_dot2_f32_bf16 v8, v49, v13, v8                           // 0000002D3060: CC1A4008 1C221B31
	v_dot2_f32_bf16 v0, v53, v13, v0                           // 0000002D3068: CC1A4000 1C021B35
	s_waitcnt lgkmcnt(4)                                       // 0000002D3070: BF89FC47
	v_dot2_f32_bf16 v6, v42, v4, v6                            // 0000002D3074: CC1A4006 1C1A092A
	v_dot2_f32_bf16 v7, v46, v4, v7                            // 0000002D307C: CC1A4007 1C1E092E
	v_dot2_f32_bf16 v8, v50, v4, v8                            // 0000002D3084: CC1A4008 1C220932
	v_dot2_f32_bf16 v0, v54, v4, v0                            // 0000002D308C: CC1A4000 1C020936
	s_waitcnt vmcnt(4) lgkmcnt(3)                              // 0000002D3094: BF891037
	v_dot2_f32_bf16 v4, v55, v5, v6                            // 0000002D3098: CC1A4004 1C1A0B37
	s_waitcnt vmcnt(3)                                         // 0000002D30A0: BF890FF7
	v_dot2_f32_bf16 v6, v59, v5, v7                            // 0000002D30A4: CC1A4006 1C1E0B3B
	s_waitcnt vmcnt(2)                                         // 0000002D30AC: BF890BF7
	v_dot2_f32_bf16 v7, v63, v5, v8                            // 0000002D30B0: CC1A4007 1C220B3F
	s_waitcnt vmcnt(1)                                         // 0000002D30B8: BF8907F7
	v_dot2_f32_bf16 v0, v67, v5, v0                            // 0000002D30BC: CC1A4000 1C020B43
	s_waitcnt lgkmcnt(2)                                       // 0000002D30C4: BF89FC27
	v_dot2_f32_bf16 v4, v56, v12, v4                           // 0000002D30C8: CC1A4004 1C121938
	v_dot2_f32_bf16 v5, v60, v12, v6                           // 0000002D30D0: CC1A4005 1C1A193C
	v_dot2_f32_bf16 v6, v64, v12, v7                           // 0000002D30D8: CC1A4006 1C1E1940
	v_dot2_f32_bf16 v0, v68, v12, v0                           // 0000002D30E0: CC1A4000 1C021944
	s_waitcnt lgkmcnt(1)                                       // 0000002D30E8: BF89FC17
	v_dot2_f32_bf16 v4, v57, v11, v4                           // 0000002D30EC: CC1A4004 1C121739
	v_dot2_f32_bf16 v5, v61, v11, v5                           // 0000002D30F4: CC1A4005 1C16173D
	v_dot2_f32_bf16 v6, v65, v11, v6                           // 0000002D30FC: CC1A4006 1C1A1741
	v_dot2_f32_bf16 v0, v69, v11, v0                           // 0000002D3104: CC1A4000 1C021745
	s_waitcnt lgkmcnt(0)                                       // 0000002D310C: BF89FC07
	v_dot2_f32_bf16 v4, v58, v3, v4                            // 0000002D3110: CC1A4004 1C12073A
	v_dot2_f32_bf16 v5, v62, v3, v5                            // 0000002D3118: CC1A4005 1C16073E
	v_dot2_f32_bf16 v6, v66, v3, v6                            // 0000002D3120: CC1A4006 1C1A0742
	v_dot2_f32_bf16 v7, v70, v3, v0                            // 0000002D3128: CC1A4007 1C020746
	s_waitcnt vmcnt(0)                                         // 0000002D3130: BF8903F7
	v_fma_mix_f32 v3, v71, v4, 0 op_sel_hi:[1,0,0]             // 0000002D3134: CC200003 0A020947
	v_fma_mix_f32 v0, v71, v5, 0 op_sel_hi:[1,0,0]             // 0000002D313C: CC200000 0A020B47
	v_fma_mix_f32 v4, v71, v6, 0 op_sel_hi:[1,0,0]             // 0000002D3144: CC200004 0A020D47
	v_fma_mix_f32 v5, v71, v7, 0 op_sel_hi:[1,0,0]             // 0000002D314C: CC200005 0A020F47
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002D3154: 8C7E037E
	.long 0xd71f0006                                           // 0000002D3158: D71F0006
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002D315C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002D3160: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D3164: BF870121
	v_xor_b32_e32 v7, 8, v6                                    // 0000002D3168: 3A0E0C88
	v_xor_b32_e32 v11, 4, v6                                   // 0000002D316C: 3A160C84
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000002D3170: 7C980EA0
	v_cndmask_b32_e32 v7, v6, v7, vcc_lo                       // 0000002D3174: 020E0F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D3178: BF870113
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 0000002D317C: 7C9816A0
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000002D3180: 300E0E82
	ds_bpermute_b32 v10, v7, v4                                // 0000002D3184: DACC0000 0A000407
	s_waitcnt lgkmcnt(0)                                       // 0000002D318C: BF89FC07
	v_add_f32_e32 v4, v4, v10                                  // 0000002D3190: 06081504
	ds_bpermute_b32 v9, v7, v0                                 // 0000002D3194: DACC0000 09000007
	ds_bpermute_b32 v8, v7, v3                                 // 0000002D319C: DACC0000 08000307
	ds_bpermute_b32 v7, v7, v5                                 // 0000002D31A4: DACC0000 07000507
	s_waitcnt lgkmcnt(2)                                       // 0000002D31AC: BF89FC27
	v_dual_add_f32 v0, v0, v9 :: v_dual_cndmask_b32 v11, v6, v11// 0000002D31B0: C9121300 000A1706
	s_waitcnt lgkmcnt(0)                                       // 0000002D31B8: BF89FC07
	v_add_f32_e32 v5, v5, v7                                   // 0000002D31BC: 060A0F05
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002D31C0: BF870002
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000002D31C4: 30161682
	ds_bpermute_b32 v9, v11, v4                                // 0000002D31C8: DACC0000 0900040B
	s_waitcnt lgkmcnt(0)                                       // 0000002D31D0: BF89FC07
	v_add_f32_e32 v4, v4, v9                                   // 0000002D31D4: 06081304
	ds_bpermute_b32 v10, v11, v5                               // 0000002D31D8: DACC0000 0A00050B
	s_waitcnt lgkmcnt(0)                                       // 0000002D31E0: BF89FC07
	v_add_f32_e32 v5, v5, v10                                  // 0000002D31E4: 060A1505
	v_xor_b32_e32 v10, 1, v6                                   // 0000002D31E8: 3A140C81
	v_add_f32_e32 v3, v3, v8                                   // 0000002D31EC: 06061103
	ds_bpermute_b32 v8, v11, v0                                // 0000002D31F0: DACC0000 0800000B
	ds_bpermute_b32 v7, v11, v3                                // 0000002D31F8: DACC0000 0700030B
	v_xor_b32_e32 v11, 2, v6                                   // 0000002D3200: 3A160C82
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000002D3204: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 0000002D3208: 7C9816A0
	s_waitcnt lgkmcnt(1)                                       // 0000002D320C: BF89FC17
	v_dual_add_f32 v0, v0, v8 :: v_dual_cndmask_b32 v11, v6, v11// 0000002D3210: C9121100 000A1706
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000002D3218: 7C9814A0
	v_dual_cndmask_b32 v6, v6, v10 :: v_dual_lshlrev_b32 v11, 2, v11// 0000002D321C: CA621506 060A1682
	s_waitcnt lgkmcnt(0)                                       // 0000002D3224: BF89FC07
	v_add_f32_e32 v3, v3, v7                                   // 0000002D3228: 06060F03
	ds_bpermute_b32 v8, v11, v0                                // 0000002D322C: DACC0000 0800000B
	ds_bpermute_b32 v9, v11, v4                                // 0000002D3234: DACC0000 0900040B
	v_lshlrev_b32_e32 v12, 2, v6                               // 0000002D323C: 30180C82
	s_waitcnt lgkmcnt(1)                                       // 0000002D3240: BF89FC17
	v_add_f32_e32 v10, v0, v8                                  // 0000002D3244: 06141100
	s_waitcnt lgkmcnt(0)                                       // 0000002D3248: BF89FC07
	v_add_f32_e32 v8, v4, v9                                   // 0000002D324C: 06101304
	ds_bpermute_b32 v7, v11, v3                                // 0000002D3250: DACC0000 0700030B
	ds_bpermute_b32 v11, v11, v5                               // 0000002D3258: DACC0000 0B00050B
	ds_bpermute_b32 v9, v12, v8                                // 0000002D3260: DACC0000 0900080C
	s_waitcnt lgkmcnt(2)                                       // 0000002D3268: BF89FC27
	v_add_f32_e32 v3, v3, v7                                   // 0000002D326C: 06060F03
	s_waitcnt lgkmcnt(1)                                       // 0000002D3270: BF89FC17
	v_add_f32_e32 v6, v5, v11                                  // 0000002D3274: 060C1705
	ds_bpermute_b32 v11, v12, v10                              // 0000002D3278: DACC0000 0B000A0C
	ds_bpermute_b32 v4, v12, v3                                // 0000002D3280: DACC0000 0400030C
	ds_bpermute_b32 v7, v12, v6                                // 0000002D3288: DACC0000 0700060C
	v_cmpx_eq_u32_e32 0, v2                                    // 0000002D3290: 7D940480
	s_cbranch_execz 540                                        // 0000002D3294: BFA5021C <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi4ELi1EEEvPKhlllPKtS5_PtPf+0xf08>
	s_waitcnt lgkmcnt(1)                                       // 0000002D3298: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_and_b32 v0, 14, v1     // 0000002D329C: C9240903 0300028E
	v_and_b32_e32 v1, 1, v1                                    // 0000002D32A4: 36020281
	s_lshl_b32 s0, s2, 4                                       // 0000002D32A8: 84008402
	s_cmp_lg_u64 s[10:11], 0                                   // 0000002D32AC: BF11800A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D32B0: BF870112
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002D32B4: D6100004 02052103
	v_or3_b32 v13, v0, s0, v1                                  // 0000002D32BC: D658000D 04040100
	s_cselect_b32 s0, -1, 0                                    // 0000002D32C4: 980080C1
	s_cmp_eq_u64 s[10:11], 0                                   // 0000002D32C8: BF10800A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D32CC: BF870112
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002D32D0: D6550003 03FE0903 00007FFF
	v_ashrrev_i32_e32 v14, 31, v13                             // 0000002D32DC: 341C1A9F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D32E0: BF870112
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000002D32E4: 360606FF FFFF0000
	.long 0xd73c000f                                           // 0000002D32EC: D73C000F
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000002D32F0: 02021A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D32F4: BF870091
	.long 0xd7006a00                                           // 0000002D32F8: D7006A00
	v_cndmask_b32_e32 v1, s6, v15, vcc_lo                      // 0000002D32FC: 02021E06
	v_add_co_ci_u32_e64 v1, null, s7, v16, vcc_lo              // 0000002D3300: D5207C01 01AA2007
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D3308: BF870092
	.long 0xd7006a11                                           // 0000002D330C: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v0, vcc_lo                   // 0000002D3310: 020200FF 00002000
	v_add_co_ci_u32_e64 v18, null, 0, v1, vcc_lo               // 0000002D3318: D5207C12 01AA0280
	.long 0xd7006a13                                           // 0000002D3320: D7006A13
	v_cndmask_b32_e32 v1, 0x3000, v0, vcc_lo                   // 0000002D3324: 020200FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D332C: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v1, vcc_lo               // 0000002D3330: D5207C14 01AA0280
	.long 0xd7006a15                                           // 0000002D3338: D7006A15
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000002D333C: 020200FF 00001000
	v_add_co_ci_u32_e64 v22, null, 0, v1, vcc_lo               // 0000002D3344: D5207C16 01AA0280
	s_clause 0x3                                               // 0000002D334C: BF850003
	global_load_u16 v2, v[17:18], off offset:2048              // 0000002D3350: DC4A0800 027C0011
	global_load_u16 v5, v[19:20], off offset:3072              // 0000002D3358: DC4A0C00 057C0013
	global_load_u16 v12, v[0:1], off                           // 0000002D3360: DC4A0000 0C7C0000
	global_load_u16 v17, v[21:22], off offset:1024             // 0000002D3368: DC4A0400 117C0015
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 0000002D3370: 100606FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002D3378: BF870291
	v_exp_f32_e32 v3, v3                                       // 0000002D337C: 7E064B03
	v_add_f32_e32 v3, 1.0, v3                                  // 0000002D3380: 060606F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D3384: BF870121
	v_div_scale_f32 v4, null, v3, v3, 1.0                      // 0000002D3388: D6FC7C04 03CA0703
	v_div_scale_f32 v20, vcc_lo, 1.0, v3, 1.0                  // 0000002D3390: D6FC6A14 03CA06F2
	v_rcp_f32_e32 v18, v4                                      // 0000002D3398: 7E245504
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D339C: BF870095
	v_fma_f32 v19, -v4, v18, 1.0                               // 0000002D33A0: D6130013 23CA2504
	v_fmac_f32_e32 v18, v19, v18                               // 0000002D33A8: 56242513
	s_waitcnt vmcnt(3)                                         // 0000002D33AC: BF890FF7
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000002D33B0: 30040490
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002D33B4: BF870132
	v_mul_f32_e32 v19, v20, v18                                // 0000002D33B8: 10262514
	s_waitcnt vmcnt(2)                                         // 0000002D33BC: BF890BF7
	v_lshlrev_b32_e32 v5, 16, v5                               // 0000002D33C0: 300A0A90
	v_fma_f32 v21, -v4, v19, v20                               // 0000002D33C4: D6130015 24522704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D33CC: BF870091
	v_fmac_f32_e32 v19, v21, v18                               // 0000002D33D0: 56262515
	v_fma_f32 v4, -v4, v19, v20                                // 0000002D33D4: D6130004 24522704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D33DC: BF870091
	v_div_fmas_f32 v4, v4, v18, v19                            // 0000002D33E0: D6370004 044E2504
	v_div_fixup_f32 v3, v4, v3, 1.0                            // 0000002D33E8: D6270003 03CA0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D33F0: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002D33F4: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002D33FC: D6550003 03FE0903 00007FFF
	s_waitcnt vmcnt(1)                                         // 0000002D3408: BF8907F7
	v_lshlrev_b32_e32 v4, 16, v12                              // 0000002D340C: 30081890
	s_waitcnt vmcnt(0)                                         // 0000002D3410: BF8903F7
	v_lshlrev_b32_e32 v12, 16, v17                             // 0000002D3414: 30182290
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000002D3418: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D3420: BF870091
	v_fma_f32 v4, v4, v3, 0                                    // 0000002D3424: D6130004 02020704
	v_fmac_f32_e32 v4, v12, v3                                 // 0000002D342C: 5608070C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D3430: BF870121
	v_fmac_f32_e32 v4, v2, v3                                  // 0000002D3434: 56080702
	.long 0xd7006a02                                           // 0000002D3438: D7006A02
	v_cndmask_b32_e32 v1, s8, v15, vcc_lo                      // 0000002D343C: 02021E08
	v_fmac_f32_e32 v4, v5, v3                                  // 0000002D3440: 56080705
	v_add_co_ci_u32_e64 v3, null, s9, v16, vcc_lo              // 0000002D3444: D5207C03 01AA2009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D344C: BF870092
	v_mul_f32_e32 v12, 0x3e800000, v4                          // 0000002D3450: 101808FF 3E800000
	v_bfe_u32 v4, v12, 16, 1                                   // 0000002D3458: D6100004 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D3460: BF870001
	v_add3_u32 v15, v12, v4, 0x7fff                            // 0000002D3464: D655000F 03FE090C 00007FFF
	.long 0xd73c0004                                           // 0000002D3470: D73C0004
	v_cndmask_b32_e32 v1, 2, v13, vcc_lo                       // 0000002D3474: 02021A82
	global_store_d16_hi_b16 v[2:3], v15, off                   // 0000002D3478: DC960000 007C0F02
	s_cbranch_scc1 7                                           // 0000002D3480: BFA20007 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi4ELi1EEEvPKhlllPKtS5_PtPf+0x8a0>
	.long 0xd7006a0d                                           // 0000002D3484: D7006A0D
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 0000002D3488: 0202080A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D348C: BF870001
	v_add_co_ci_u32_e64 v14, null, s11, v5, vcc_lo             // 0000002D3490: D5207C0E 01AA0A0B
	global_store_b32 v[13:14], v12, off                        // 0000002D3498: DC6A0000 007C0C0D
	.long 0xd7006a0c                                           // 0000002D34A0: D7006A0C
	v_cndmask_b32_e32 v1, 0x5000, v0, vcc_lo                   // 0000002D34A4: 020200FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D34AC: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v1, vcc_lo               // 0000002D34B0: D5207C0D 01AA0280
	.long 0xd7006a0e                                           // 0000002D34B8: D7006A0E
	v_cndmask_b32_e32 v1, 0x6000, v0, vcc_lo                   // 0000002D34BC: 020200FF 00006000
	v_add_co_ci_u32_e64 v15, null, 0, v1, vcc_lo               // 0000002D34C4: D5207C0F 01AA0280
	s_clause 0x1                                               // 0000002D34CC: BF850001
	global_load_u16 v16, v[12:13], off                         // 0000002D34D0: DC4A0000 107C000C
	global_load_u16 v17, v[14:15], off offset:1024             // 0000002D34D8: DC4A0400 117C000E
	.long 0xd7006a0c                                           // 0000002D34E0: D7006A0C
	v_cndmask_b32_e32 v1, 0x7000, v0, vcc_lo                   // 0000002D34E4: 020200FF 00007000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D34EC: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v1, vcc_lo               // 0000002D34F0: D5207C0D 01AA0280
	.long 0xd7006a0e                                           // 0000002D34F8: D7006A0E
	v_cndmask_b32_e32 v1, 0x8000, v0, vcc_lo                   // 0000002D34FC: 020200FF 00008000
	v_add_co_ci_u32_e64 v15, null, 0, v1, vcc_lo               // 0000002D3504: D5207C0F 01AA0280
	s_clause 0x1                                               // 0000002D350C: BF850001
	global_load_u16 v12, v[12:13], off offset:2048             // 0000002D3510: DC4A0800 0C7C000C
	global_load_u16 v13, v[14:15], off offset:3072             // 0000002D3518: DC4A0C00 0D7C000E
	v_add_f32_e32 v10, v10, v11                                // 0000002D3520: 0614170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D3524: BF870091
	v_bfe_u32 v11, v10, 16, 1                                  // 0000002D3528: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 0000002D3530: D655000A 03FE170A 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D353C: BF870091
	v_and_b32_e32 v10, 0xffff0000, v10                         // 0000002D3540: 361414FF FFFF0000
	v_mul_f32_e32 v10, 0xbfb8aa3b, v10                         // 0000002D3548: 101414FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000002D3550: BF8702A1
	v_exp_f32_e32 v10, v10                                     // 0000002D3554: 7E144B0A
	s_waitcnt vmcnt(0)                                         // 0000002D3558: BF8903F7
	v_dual_add_f32 v10, 1.0, v10 :: v_dual_lshlrev_b32 v13, 16, v13// 0000002D355C: C92214F2 0A0C1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D3564: BF870121
	v_div_scale_f32 v11, null, v10, v10, 1.0                   // 0000002D3568: D6FC7C0B 03CA150A
	v_div_scale_f32 v18, vcc_lo, 1.0, v10, 1.0                 // 0000002D3570: D6FC6A12 03CA14F2
	v_rcp_f32_e32 v14, v11                                     // 0000002D3578: 7E1C550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D357C: BF870095
	v_fma_f32 v15, -v11, v14, 1.0                              // 0000002D3580: D613000F 23CA1D0B
	v_fmac_f32_e32 v14, v15, v14                               // 0000002D3588: 561C1D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D358C: BF870091
	v_mul_f32_e32 v15, v18, v14                                // 0000002D3590: 101E1D12
	v_fma_f32 v19, -v11, v15, v18                              // 0000002D3594: D6130013 244A1F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D359C: BF870091
	v_fmac_f32_e32 v15, v19, v14                               // 0000002D35A0: 561E1D13
	v_fma_f32 v11, -v11, v15, v18                              // 0000002D35A4: D613000B 244A1F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D35AC: BF870121
	v_div_fmas_f32 v11, v11, v14, v15                          // 0000002D35B0: D637000B 043E1D0B
	v_lshlrev_b32_e32 v14, 16, v17                             // 0000002D35B8: 301C2290
	v_div_fixup_f32 v10, v11, v10, 1.0                         // 0000002D35BC: D627000A 03CA150B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D35C4: BF870091
	v_bfe_u32 v11, v10, 16, 1                                  // 0000002D35C8: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 0000002D35D0: D655000A 03FE170A 00007FFF
	v_lshlrev_b32_e32 v11, 16, v16                             // 0000002D35DC: 30162090
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D35E0: BF870092
	v_and_b32_e32 v10, 0xffff0000, v10                         // 0000002D35E4: 361414FF FFFF0000
	v_fma_f32 v11, v11, v10, 0                                 // 0000002D35EC: D613000B 0202150B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D35F4: BF870091
	v_dual_fmac_f32 v11, v14, v10 :: v_dual_lshlrev_b32 v12, 16, v12// 0000002D35F8: C822150E 0B0C1890
	v_fmac_f32_e32 v11, v12, v10                               // 0000002D3600: 5616150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D3604: BF870121
	v_fmac_f32_e32 v11, v13, v10                               // 0000002D3608: 5616150D
	v_cndmask_b32_e64 v10, 0, 1, s0                            // 0000002D360C: D501000A 00010280
	v_mul_f32_e32 v11, 0x3e800000, v11                         // 0000002D3614: 101616FF 3E800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D361C: BF870091
	v_bfe_u32 v12, v11, 16, 1                                  // 0000002D3620: D610000C 0205210B
	v_add3_u32 v14, v11, v12, 0x7fff                           // 0000002D3628: D655000E 03FE190B 00007FFF
	.long 0xd7006a0c                                           // 0000002D3634: D7006A0C
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 0000002D3638: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D3640: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v3, vcc_lo               // 0000002D3644: D5207C0D 01AA0680
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000002D364C: 916A007E
	global_store_d16_hi_b16 v[12:13], v14, off offset:1024     // 0000002D3650: DC960400 007C0E0C
	s_cbranch_vccnz 13                                         // 0000002D3658: BFA4000D <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi4ELi1EEEvPKhlllPKtS5_PtPf+0xa90>
	.long 0xd7006a0c                                           // 0000002D365C: D7006A0C
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 0000002D3660: 0202080A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D3664: BF870111
	v_add_co_ci_u32_e64 v13, null, s11, v5, vcc_lo             // 0000002D3668: D5207C0D 01AA0A0B
	.long 0xd7006a0c                                           // 0000002D3670: D7006A0C
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 0000002D3674: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D367C: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000002D3680: D5207C0D 01AA1A80
	global_store_b32 v[12:13], v11, off offset:2048            // 0000002D3688: DC6A0800 007C0B0C
	.long 0xd7006a0b                                           // 0000002D3690: D7006A0B
	v_cndmask_b32_e32 v1, 0xa000, v0, vcc_lo                   // 0000002D3694: 020200FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D369C: BF8700A1
	v_add_co_ci_u32_e64 v12, null, 0, v1, vcc_lo               // 0000002D36A0: D5207C0C 01AA0280
	.long 0xd7006a0d                                           // 0000002D36A8: D7006A0D
	v_cndmask_b32_e32 v1, 0xb000, v0, vcc_lo                   // 0000002D36AC: 020200FF 0000B000
	v_add_co_ci_u32_e64 v14, null, 0, v1, vcc_lo               // 0000002D36B4: D5207C0E 01AA0280
	s_clause 0x1                                               // 0000002D36BC: BF850001
	global_load_u16 v15, v[11:12], off                         // 0000002D36C0: DC4A0000 0F7C000B
	global_load_u16 v16, v[13:14], off offset:1024             // 0000002D36C8: DC4A0400 107C000D
	.long 0xd7006a0b                                           // 0000002D36D0: D7006A0B
	v_cndmask_b32_e32 v1, 0xc000, v0, vcc_lo                   // 0000002D36D4: 020200FF 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D36DC: BF8700A1
	v_add_co_ci_u32_e64 v12, null, 0, v1, vcc_lo               // 0000002D36E0: D5207C0C 01AA0280
	.long 0xd7006a0d                                           // 0000002D36E8: D7006A0D
	v_cndmask_b32_e32 v1, 0xd000, v0, vcc_lo                   // 0000002D36EC: 020200FF 0000D000
	v_add_co_ci_u32_e64 v14, null, 0, v1, vcc_lo               // 0000002D36F4: D5207C0E 01AA0280
	s_clause 0x1                                               // 0000002D36FC: BF850001
	global_load_u16 v11, v[11:12], off offset:2048             // 0000002D3700: DC4A0800 0B7C000B
	global_load_u16 v12, v[13:14], off offset:3072             // 0000002D3708: DC4A0C00 0C7C000D
	v_add_f32_e32 v8, v8, v9                                   // 0000002D3710: 06101308
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D3714: BF870091
	v_bfe_u32 v9, v8, 16, 1                                    // 0000002D3718: D6100009 02052108
	v_add3_u32 v8, v8, v9, 0x7fff                              // 0000002D3720: D6550008 03FE1308 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D372C: BF8700A1
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000002D3730: 361010FF FFFF0000
	s_waitcnt vmcnt(1)                                         // 0000002D3738: BF8907F7
	v_dual_mul_f32 v8, 0xbfb8aa3b, v8 :: v_dual_lshlrev_b32 v11, 16, v11// 0000002D373C: C8E210FF 080A1690 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002D3748: BF870291
	v_exp_f32_e32 v8, v8                                       // 0000002D374C: 7E104B08
	v_add_f32_e32 v8, 1.0, v8                                  // 0000002D3750: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D3754: BF870121
	v_div_scale_f32 v9, null, v8, v8, 1.0                      // 0000002D3758: D6FC7C09 03CA1108
	v_div_scale_f32 v17, vcc_lo, 1.0, v8, 1.0                  // 0000002D3760: D6FC6A11 03CA10F2
	v_rcp_f32_e32 v13, v9                                      // 0000002D3768: 7E1A5509
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D376C: BF870095
	v_fma_f32 v14, -v9, v13, 1.0                               // 0000002D3770: D613000E 23CA1B09
	v_fmac_f32_e32 v13, v14, v13                               // 0000002D3778: 561A1B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D377C: BF870091
	v_mul_f32_e32 v14, v17, v13                                // 0000002D3780: 101C1B11
	v_fma_f32 v18, -v9, v14, v17                               // 0000002D3784: D6130012 24461D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D378C: BF870091
	v_fmac_f32_e32 v14, v18, v13                               // 0000002D3790: 561C1B12
	v_fma_f32 v9, -v9, v14, v17                                // 0000002D3794: D6130009 24461D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000002D379C: BF870241
	v_div_fmas_f32 v17, v9, v13, v14                           // 0000002D37A0: D6370011 043A1B09
	v_div_fmas_f32 v18, v9, v13, v14                           // 0000002D37A8: D6370012 043A1B09
	v_div_fmas_f32 v9, v9, v13, v14                            // 0000002D37B0: D6370009 043A1B09
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 0000002D37B8: 7C9A1481
	v_div_fixup_f32 v17, v17, v8, 1.0                          // 0000002D37BC: D6270011 03CA1111
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D37C4: BF870214
	v_div_fixup_f32 v13, v18, v8, 1.0                          // 0000002D37C8: D627000D 03CA1112
	v_div_fixup_f32 v8, v9, v8, 1.0                            // 0000002D37D0: D6270008 03CA1109
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000002D37D8: 8B6A6A7E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D37DC: BF870193
	v_bfe_u32 v14, v17, 16, 1                                  // 0000002D37E0: D610000E 02052111
	v_bfe_u32 v9, v13, 16, 1                                   // 0000002D37E8: D6100009 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D37F0: BF870112
	v_add3_u32 v14, v17, v14, 0x7fff                           // 0000002D37F4: D655000E 03FE1D11 00007FFF
	v_add3_u32 v9, v13, v9, 0x7fff                             // 0000002D3800: D6550009 03FE130D 00007FFF
	v_bfe_u32 v17, v8, 16, 1                                   // 0000002D380C: D6100011 02052108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D3814: BF870193
	v_and_b32_e32 v13, 0xffff0000, v14                         // 0000002D3818: 361A1CFF FFFF0000
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002D3820: 361212FF FFFF0000
	v_lshlrev_b32_e32 v14, 16, v15                             // 0000002D3828: 301C1E90
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002D382C: BF8701A4
	v_add3_u32 v8, v8, v17, 0x7fff                             // 0000002D3830: D6550008 03FE2308 00007FFF
	v_lshlrev_b32_e32 v15, 16, v16                             // 0000002D383C: 301E2090
	v_fma_f32 v13, v14, v13, 0                                 // 0000002D3840: D613000D 02021B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002D3848: BF870131
	v_dual_fmac_f32 v13, v15, v9 :: v_dual_and_b32 v8, 0xffff0000, v8// 0000002D384C: C824130F 0D0810FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 0000002D3858: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v12                              // 0000002D385C: 30121890
	v_fmac_f32_e32 v13, v11, v8                                // 0000002D3860: 561A110B
	.long 0xd700000b                                           // 0000002D3864: D700000B
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000002D3868: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D3870: BF870191
	v_add_co_ci_u32_e64 v12, null, 0, v3, s0                   // 0000002D3874: D5207C0C 00020680
	v_fmac_f32_e32 v13, v9, v8                                 // 0000002D387C: 561A1109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D3880: BF870091
	v_mul_f32_e32 v8, 0x3e800000, v13                          // 0000002D3884: 10101AFF 3E800000
	v_bfe_u32 v9, v8, 16, 1                                    // 0000002D388C: D6100009 02052108
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D3894: BF870001
	v_add3_u32 v9, v8, v9, 0x7fff                              // 0000002D3898: D6550009 03FE1308 00007FFF
	global_store_d16_hi_b16 v[11:12], v9, off offset:2048      // 0000002D38A4: DC960800 007C090B
	s_cbranch_vccnz 13                                         // 0000002D38AC: BFA4000D <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi4ELi1EEEvPKhlllPKtS5_PtPf+0xce4>
	.long 0xd7006a09                                           // 0000002D38B0: D7006A09
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 0000002D38B4: 0202080A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D38B8: BF870111
	v_add_co_ci_u32_e64 v12, null, s11, v5, vcc_lo             // 0000002D38BC: D5207C0C 01AA0A0B
	.long 0xd7006a0b                                           // 0000002D38C4: D7006A0B
	v_cndmask_b32_e32 v1, 0x5000, v9, vcc_lo                   // 0000002D38C8: 020212FF 00005000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D38D0: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v12, vcc_lo              // 0000002D38D4: D5207C0C 01AA1880
	global_store_b32 v[11:12], v8, off                         // 0000002D38DC: DC6A0000 007C080B
	.long 0xd7006a08                                           // 0000002D38E4: D7006A08
	v_cndmask_b32_e32 v1, 0xf000, v0, vcc_lo                   // 0000002D38E8: 020200FF 0000F000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D38F0: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v1, vcc_lo                // 0000002D38F4: D5207C09 01AA0280
	.long 0xd7006a0b                                           // 0000002D38FC: D7006A0B
	v_cndmask_b32_e32 v1, 0x10000, v0, vcc_lo                  // 0000002D3900: 020200FF 00010000
	v_add_co_ci_u32_e64 v12, null, 0, v1, vcc_lo               // 0000002D3908: D5207C0C 01AA0280
	s_clause 0x1                                               // 0000002D3910: BF850001
	global_load_u16 v13, v[8:9], off                           // 0000002D3914: DC4A0000 0D7C0008
	global_load_u16 v11, v[11:12], off offset:1024             // 0000002D391C: DC4A0400 0B7C000B
	.long 0xd7006a08                                           // 0000002D3924: D7006A08
	v_cndmask_b32_e32 v1, 0x11000, v0, vcc_lo                  // 0000002D3928: 020200FF 00011000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D3930: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v1, vcc_lo                // 0000002D3934: D5207C09 01AA0280
	.long 0xd7006a00                                           // 0000002D393C: D7006A00
	v_cndmask_b32_e32 v1, 0x12000, v0, vcc_lo                  // 0000002D3940: 020200FF 00012000
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000002D3948: D5207C01 01AA0280
	s_clause 0x1                                               // 0000002D3950: BF850001
	global_load_u16 v8, v[8:9], off offset:2048                // 0000002D3954: DC4A0800 087C0008
	global_load_u16 v0, v[0:1], off offset:3072                // 0000002D395C: DC4A0C00 007C0000
	s_waitcnt lgkmcnt(0)                                       // 0000002D3964: BF89FC07
	v_add_f32_e32 v1, v6, v7                                   // 0000002D3968: 06020F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D396C: BF870091
	v_bfe_u32 v6, v1, 16, 1                                    // 0000002D3970: D6100006 02052101
	v_add3_u32 v1, v1, v6, 0x7fff                              // 0000002D3978: D6550001 03FE0D01 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D3984: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002D3988: 360202FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 0000002D3990: BF8903F7
	v_dual_mul_f32 v1, 0xbfb8aa3b, v1 :: v_dual_lshlrev_b32 v0, 16, v0// 0000002D3994: C8E202FF 01000090 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002D39A0: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002D39A4: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002D39A8: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D39AC: BF870121
	v_div_scale_f32 v6, null, v1, v1, 1.0                      // 0000002D39B0: D6FC7C06 03CA0301
	v_div_scale_f32 v12, vcc_lo, 1.0, v1, 1.0                  // 0000002D39B8: D6FC6A0C 03CA02F2
	v_rcp_f32_e32 v7, v6                                       // 0000002D39C0: 7E0E5506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D39C4: BF870095
	v_fma_f32 v9, -v6, v7, 1.0                                 // 0000002D39C8: D6130009 23CA0F06
	v_fmac_f32_e32 v7, v9, v7                                  // 0000002D39D0: 560E0F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D39D4: BF870091
	v_mul_f32_e32 v9, v12, v7                                  // 0000002D39D8: 10120F0C
	v_fma_f32 v14, -v6, v9, v12                                // 0000002D39DC: D613000E 24321306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D39E4: BF870091
	v_fmac_f32_e32 v9, v14, v7                                 // 0000002D39E8: 56120F0E
	v_fma_f32 v6, -v6, v9, v12                                 // 0000002D39EC: D6130006 24321306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002D39F4: BF8701B1
	v_div_fmas_f32 v12, v6, v7, v9                             // 0000002D39F8: D637000C 04260F06
	v_div_fmas_f32 v6, v6, v7, v9                              // 0000002D3A00: D6370006 04260F06
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 0000002D3A08: 7C9A1481
	v_div_fixup_f32 v7, v12, v1, 1.0                           // 0000002D3A0C: D6270007 03CA030C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D3A14: BF870123
	v_div_fixup_f32 v1, v6, v1, 1.0                            // 0000002D3A18: D6270001 03CA0306
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000002D3A20: 8B6A6A7E
	v_bfe_u32 v6, v7, 16, 1                                    // 0000002D3A24: D6100006 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D3A2C: BF870112
	v_bfe_u32 v9, v1, 16, 1                                    // 0000002D3A30: D6100009 02052101
	v_add3_u32 v6, v7, v6, 0x7fff                              // 0000002D3A38: D6550006 03FE0D07 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000002D3A44: BF870232
	v_add3_u32 v1, v1, v9, 0x7fff                              // 0000002D3A48: D6550001 03FE1301 00007FFF
	v_lshlrev_b32_e32 v7, 16, v13                              // 0000002D3A54: 300E1A90
	v_lshlrev_b32_e32 v9, 16, v11                              // 0000002D3A58: 30121690
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000002D3A5C: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D3A64: BF870114
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002D3A68: 360202FF FFFF0000
	v_fma_f32 v6, v7, v6, 0                                    // 0000002D3A70: D6130006 02020D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D3A78: BF870091
	v_dual_fmac_f32 v6, v9, v1 :: v_dual_lshlrev_b32 v7, 16, v8// 0000002D3A7C: C8220309 06061090
	v_fmac_f32_e32 v6, v7, v1                                  // 0000002D3A84: 560C0307
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D3A88: BF870091
	v_fmac_f32_e32 v6, v0, v1                                  // 0000002D3A8C: 560C0300
	v_mul_f32_e32 v0, 0x3e800000, v6                           // 0000002D3A90: 10000CFF 3E800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D3A98: BF870091
	v_bfe_u32 v1, v0, 16, 1                                    // 0000002D3A9C: D6100001 02052100
	v_add3_u32 v6, v0, v1, 0x7fff                              // 0000002D3AA4: D6550006 03FE0300 00007FFF
	.long 0xd7000001                                           // 0000002D3AB0: D7000001
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 0000002D3AB4: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D3ABC: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v3, s0                    // 0000002D3AC0: D5207C02 00020680
	global_store_d16_hi_b16 v[1:2], v6, off offset:3072        // 0000002D3AC8: DC960C00 007C0601
	s_cbranch_vccnz 13                                         // 0000002D3AD0: BFA4000D <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi4ELi1EEEvPKhlllPKtS5_PtPf+0xf08>
	.long 0xd7006a01                                           // 0000002D3AD4: D7006A01
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 0000002D3AD8: 0202080A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D3ADC: BF870111
	v_add_co_ci_u32_e64 v2, null, s11, v5, vcc_lo              // 0000002D3AE0: D5207C02 01AA0A0B
	.long 0xd7006a01                                           // 0000002D3AE8: D7006A01
	v_cndmask_b32_e32 v1, 0x7000, v1, vcc_lo                   // 0000002D3AEC: 020202FF 00007000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D3AF4: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000002D3AF8: D5207C02 01AA0480
	global_store_b32 v[1:2], v0, off offset:2048               // 0000002D3B00: DC6A0800 007C0001
	s_endpgm                                                   // 0000002D3B08: BFB00000
		...

