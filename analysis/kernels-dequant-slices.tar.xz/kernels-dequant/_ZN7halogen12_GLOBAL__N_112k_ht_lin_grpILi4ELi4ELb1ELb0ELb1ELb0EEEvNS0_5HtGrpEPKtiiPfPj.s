000000000042a700 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 00000042A700: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 00000042A704: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 00000042A70C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 00000042A714: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 00000042A718: BF108004
	s_cbranch_scc1 246                                         // 00000042A71C: BFA200F6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f8>
	s_load_b32 s6, s[0:1], 0x138                               // 00000042A720: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 00000042A728: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 00000042A72C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 00000042A730: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000042A734: BF030602
	s_cbranch_scc0 233                                         // 00000042A738: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000042A73C: 32020085
	s_sub_i32 s6, s2, s6                                       // 00000042A740: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000042A744: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 00000042A748: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 00000042A750: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000042A754: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 00000042A758: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 00000042A75C: BE86206A
	s_cbranch_execz 222                                        // 00000042A760: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 00000042A764: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 00000042A768: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 00000042A770: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 00000042A774: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 00000042A77C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042A784: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 00000042A788: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 00000042A78C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 00000042A790: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000042A794: BF870121
	.long 0xd72c0002                                           // 00000042A798: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 00000042A79C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 00000042A7A4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 00000042A7B0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A7B8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 00000042A7BC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000042A7C4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A7C8: BF870091
	.long 0xd73c0002                                           // 00000042A7CC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000042A7D0: 02020481
	.long 0xd7006a04                                           // 00000042A7D4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 00000042A7D8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000042A7DC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 00000042A7E0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 00000042A7E8: BF89FC07
	.long 0xd7006a02                                           // 00000042A7EC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 00000042A7F0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 00000042A7F4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 00000042A7FC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 00000042A804: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 00000042A80C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 00000042A814: BF8907F7
	.long 0x7e043904                                           // 00000042A818: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 00000042A81C: 360608FF FFFF0000
	.long 0x7e083905                                           // 00000042A824: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000042A828: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000042A830: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 00000042A834: 301C0490
	s_waitcnt vmcnt(0)                                         // 00000042A838: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000042A83C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000042A844: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000042A848: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000042A850: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000042A854: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 00000042A858: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 00000042A860: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 00000042A868: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 00000042A870: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 00000042A878: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000042A87C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 00000042A880: 361A0088
	.long 0xd73c0001                                           // 00000042A884: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000042A888: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 00000042A88C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 00000042A890: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000042A894: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042A898: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042A89C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042A8A4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000042A8AC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000042A8B4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 00000042A8B8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 00000042A8BC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 00000042A8C8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 00000042A8CC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 00000042A8D0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042A8D8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000042A8E0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000042A8E8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042A8EC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000042A8F4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 00000042A8FC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 00000042A900: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 00000042A908: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000042A90C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 00000042A910: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042A914: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000042A91C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042A924: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000042A92C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042A934: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000042A93C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 00000042A944: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042A948: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000042A950: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 00000042A958: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 00000042A95C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042A960: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 00000042A968: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 00000042A96C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042A970: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042A978: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000042A980: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 00000042A984: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000042A988: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000042A990: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000042A998: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 00000042A9A0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 00000042A9A4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 00000042A9A8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042A9AC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000042A9B4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 00000042A9BC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 00000042A9C0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042A9C4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042A9CC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 00000042A9D4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000042A9D8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042A9E0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000042A9E8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000042A9F0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042A9F8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000042AA00: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 00000042AA08: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 00000042AA0C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 00000042AA10: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042AA14: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 00000042AA18: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 00000042AA20: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000042AA24: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042AA2C: BF870214
	v_mov_b32_e32 v13, v5                                      // 00000042AA30: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 00000042AA34: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 00000042AA38: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 00000042AA40: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000042AA4C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000042AA54: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 00000042AA5C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 00000042AA68: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 00000042AA74: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 00000042AA80: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 00000042AA84: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000042AA88: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 00000042AA8C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 00000042AA94: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 00000042AA9C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 00000042AAA0: 060A1B05
	.long 0xd7006a01                                           // 00000042AAA4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 00000042AAA8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000042AAAC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 00000042AAB4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 00000042AABC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 00000042AAC4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 00000042AACC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 00000042AAD4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 00000042AADC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000042AAE0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000042AAE4: 8B6A037E
	s_cbranch_vccnz 4                                          // 00000042AAE8: BFA40004 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3fc>
	s_nop 0                                                    // 00000042AAEC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000042AAF0: BFB60003
	s_endpgm                                                   // 00000042AAF4: BFB00000
	s_cbranch_execz 65532                                      // 00000042AAF8: BFA5FFFC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 00000042AAFC: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 00000042AB00: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 00000042AB08: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 00000042AB10: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 00000042AB18: F4000180 F800010C
	v_lshrrev_b32_e32 v19, 5, v0                               // 00000042AB20: 32260085
	v_and_b32_e32 v20, 31, v0                                  // 00000042AB24: 3628009F
	s_mov_b32 s33, 0                                           // 00000042AB28: BEA10080
	s_mov_b32 s31, exec_lo                                     // 00000042AB2C: BE9F007E
	s_waitcnt lgkmcnt(0)                                       // 00000042AB30: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 00000042AB34: BF028103
	s_cselect_b32 s7, -1, 0                                    // 00000042AB38: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000042AB3C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 00000042AB40: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000042AB44: BF870009
	s_and_b32 s4, s7, s4                                       // 00000042AB48: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000042AB4C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 00000042AB50: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 00000042AB58: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000042AB5C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 00000042AB60: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000042AB64: BF870009
	s_and_b32 s4, s7, s5                                       // 00000042AB68: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000042AB6C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 00000042AB70: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 00000042AB74: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000042AB78: BF030602
	s_cselect_b32 s6, -1, 0                                    // 00000042AB7C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000042AB80: BF8704D9
	s_and_b32 s3, s3, s6                                       // 00000042AB84: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000042AB88: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000042AB8C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 00000042AB90: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000042AB94: 98030483
	s_mulk_i32 s3, 0x48                                        // 00000042AB98: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000042AB9C: BF870009
	s_add_u32 s4, s0, s3                                       // 00000042ABA0: 80040300
	s_addc_u32 s5, s1, 0                                       // 00000042ABA4: 82058001
	s_clause 0x3                                               // 00000042ABA8: BF850003
	s_load_b32 s30, s[4:5], 0x38                               // 00000042ABAC: F4000782 F8000038
	s_load_b64 s[28:29], s[4:5], 0x40                          // 00000042ABB4: F4040702 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 00000042ABBC: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 00000042ABC4: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 00000042ABCC: BF89FC07
	s_abs_i32 s3, s21                                          // 00000042ABD0: BE831515
	s_sub_i32 s34, s2, s23                                     // 00000042ABD4: 81A21702
	s_cvt_f32_u32 s6, s3                                       // 00000042ABD8: BE866503
	s_sub_i32 s7, 0, s3                                        // 00000042ABDC: 81870380
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000042ABE0: BF87029A
	v_rcp_iflag_f32_e32 v1, s6                                 // 00000042ABE4: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 00000042ABE8: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 00000042ABEC: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000042ABF4: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 00000042ABF8: BE866706
	s_mul_i32 s7, s7, s6                                       // 00000042ABFC: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000042AC00: BF8704B9
	s_mul_hi_u32 s2, s6, s7                                    // 00000042AC04: 96820706
	s_abs_i32 s7, s34                                          // 00000042AC08: BE871522
	s_add_i32 s6, s6, s2                                       // 00000042AC0C: 81060206
	s_mul_hi_u32 s2, s7, s6                                    // 00000042AC10: 96820607
	s_xor_b32 s6, s34, s21                                     // 00000042AC14: 8D061522
	s_mul_i32 s8, s2, s3                                       // 00000042AC18: 96080302
	s_ashr_i32 s6, s6, 31                                      // 00000042AC1C: 86069F06
	s_sub_i32 s7, s7, s8                                       // 00000042AC20: 81870807
	s_add_i32 s8, s2, 1                                        // 00000042AC24: 81088102
	s_sub_i32 s9, s7, s3                                       // 00000042AC28: 81890307
	s_cmp_ge_u32 s7, s3                                        // 00000042AC2C: BF090307
	s_cselect_b32 s2, s8, s2                                   // 00000042AC30: 98020208
	s_cselect_b32 s7, s9, s7                                   // 00000042AC34: 98070709
	s_add_i32 s8, s2, 1                                        // 00000042AC38: 81088102
	s_cmp_ge_u32 s7, s3                                        // 00000042AC3C: BF090307
	s_cselect_b32 s2, s8, s2                                   // 00000042AC40: 98020208
	s_load_b256 s[8:15], s[4:5], null                          // 00000042AC44: F40C0202 F8000000
	s_xor_b32 s2, s2, s6                                       // 00000042AC4C: 8D020602
	s_ashr_i32 s23, s19, 31                                    // 00000042AC50: 86179F13
	s_sub_i32 s26, s2, s6                                      // 00000042AC54: 819A0602
	s_lshr_b32 s2, s23, 25                                     // 00000042AC58: 85029917
	s_mul_i32 s36, s26, s21                                    // 00000042AC5C: 9624151A
	s_add_i32 s2, s19, s2                                      // 00000042AC60: 81020213
	s_sub_i32 s3, s34, s36                                     // 00000042AC64: 81832422
	s_ashr_i32 s2, s2, 7                                       // 00000042AC68: 86028702
	s_mul_i32 s27, s22, s3                                     // 00000042AC6C: 961B0316
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000042AC70: BF870499
	s_add_i32 s3, s27, s22                                     // 00000042AC74: 8103161B
	s_min_i32 s2, s2, s3                                       // 00000042AC78: 89020302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000042AC7C: BF870499
	s_sub_i32 s7, s2, s27                                      // 00000042AC80: 81871B02
	s_lshl_b32 s22, s7, 2                                      // 00000042AC84: 84168207
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000042AC88: BF870009
	.long 0xd4c4007e                                           // 00000042AC8C: D4C4007E
	v_cndmask_b32_e32 v1, s22, v19, vcc_lo                     // 00000042AC90: 02022616
	s_cbranch_execz 289                                        // 00000042AC94: BFA50121 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa1c>
	s_abs_i32 s35, s7                                          // 00000042AC98: BEA31507
	v_lshlrev_b32_e32 v7, 3, v20                               // 00000042AC9C: 300E2883
	s_cvt_f32_u32 s2, s35                                      // 00000042ACA0: BE826523
	v_lshlrev_b32_e32 v8, 7, v19                               // 00000042ACA4: 30102687
	v_and_b32_e32 v3, 2, v0                                    // 00000042ACA8: 36060082
	v_and_b32_e32 v5, 8, v0                                    // 00000042ACAC: 360A0088
	v_rcp_iflag_f32_e32 v1, s2                                 // 00000042ACB0: 7E025602
	s_sub_i32 s2, 0, s35                                       // 00000042ACB4: 81822380
	s_ashr_i32 s39, s7, 31                                     // 00000042ACB8: 86279F07
	.long 0xd44a0003                                           // 00000042ACBC: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 00000042ACC0: 02020680
	s_mul_i32 s41, s39, 0x1400                                 // 00000042ACC4: 9629FF27 00001400
	.long 0xd44a0005                                           // 00000042ACCC: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 00000042ACD0: 02020A80
	s_lshl_b32 s6, s7, 7                                       // 00000042ACD4: 84068707
	s_add_i32 s37, s18, -1                                     // 00000042ACD8: 8125C112
	s_mov_b32 s38, s19                                         // 00000042ACDC: BEA60013
	s_lshl_b32 s40, s7, 8                                      // 00000042ACE0: 84288807
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v2, 1, v0// 00000042ACE4: C8E402FF 01020081 4F7FFFFE
	s_mov_b32 s42, 0x76543210                                  // 00000042ACF0: BEAA00FF 76543210
	s_mov_b32 s43, 0x3db504f3                                  // 00000042ACF8: BEAB00FF 3DB504F3
	v_cmp_gt_u32_e32 vcc_lo, 16, v20                           // 00000042AD00: 7C982890
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000042AD04: BF870122
	v_cvt_u32_f32_e32 v4, v1                                   // 00000042AD08: 7E080F01
	v_and_b32_e32 v1, 4, v0                                    // 00000042AD0C: 36020084
	.long 0xd72c0006                                           // 00000042AD10: D72C0006
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 00000042AD14: 02020802
	.long 0xd44a0002                                           // 00000042AD18: D44A0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000042AD1C: 02020480
	v_lshl_or_b32 v2, v19, 8, v7                               // 00000042AD20: D6560002 041D1113
	v_lshl_add_u32 v7, s27, 7, v8                              // 00000042AD28: D6460007 04210E1B
	.long 0xd44a0004                                           // 00000042AD30: D44A0004
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000042AD34: 02020280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000042AD38: BF870223
	v_subrev_nc_u32_e32 v2, s41, v2                            // 00000042AD3C: 4E040429
	.long 0xd72d0006                                           // 00000042AD40: D72D0006
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000042AD44: 02020D04
	v_lshl_or_b32 v1, v20, 2, v7                               // 00000042AD48: D6560001 041D0514
	s_sub_i32 s41, 0, s6                                       // 00000042AD50: 81A90680
	s_delay_alu instid0(VALU_DEP_2)                            // 00000042AD54: BF870002
	v_dual_mov_b32 v4, v19 :: v_dual_add_nc_u32 v3, v4, v6     // 00000042AD58: CA200113 04020D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042AD60: BF870091
	.long 0xd72d0005                                           // 00000042AD64: D72D0005
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 00000042AD68: 02020704
	.long 0xd72c0006                                           // 00000042AD6C: D72C0006
	v_cndmask_b32_e32 v0, v5, v35, vcc_lo                      // 00000042AD70: 02004705
	v_add_nc_u32_e32 v7, 1, v5                                 // 00000042AD74: 4A0E0A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042AD78: BF870092
	v_sub_nc_u32_e32 v6, v4, v6                                // 00000042AD7C: 4C0C0D04
	v_subrev_nc_u32_e32 v8, s35, v6                            // 00000042AD80: 4E100C23
	.long 0xd44b0006                                           // 00000042AD84: D44B0006
	v_cndmask_b32_e32 v1, s35, v6, vcc_lo                      // 00000042AD88: 02020C23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042AD8C: BF870191
	v_cndmask_b32_e64 v5, v5, v7, s6                           // 00000042AD90: D5010005 001A0F05
	v_cndmask_b32_e64 v6, v6, v8, s6                           // 00000042AD98: D5010006 001A1106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042ADA0: BF870112
	v_add_nc_u32_e32 v7, 1, v5                                 // 00000042ADA4: 4A0E0A81
	.long 0xd44b0006                                           // 00000042ADA8: D44B0006
	v_cndmask_b32_e32 v1, s35, v6, vcc_lo                      // 00000042ADAC: 02020C23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042ADB0: BF870091
	v_cndmask_b32_e64 v5, v5, v7, s6                           // 00000042ADB4: D5010005 001A0F05
	v_xor_b32_e32 v9, s39, v5                                  // 00000042ADBC: 3A120A27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000042ADC0: BF870121
	v_subrev_nc_u32_e32 v10, s39, v9                           // 00000042ADC4: 4E141227
	.long 0xd72c0009                                           // 00000042ADC8: D72C0009
	v_cndmask_b32_e32 v1, 0x1400, v9, vcc_lo                   // 00000042ADCC: 020212FF 00001400
	v_min_i32_e32 v7, s37, v10                                 // 00000042ADD4: 220E1425
	v_mad_u64_u32 v[5:6], null, s41, v10, v[1:2]               // 00000042ADD8: D6FE7C05 04061429
	.long 0xd72c000a                                           // 00000042ADE0: D72C000A
	v_cndmask_b32_e32 v1, s40, v10, vcc_lo                     // 00000042ADE4: 02021428
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042ADE8: BF870193
	v_mad_i64_i32 v[7:8], null, v7, s38, 0                     // 00000042ADEC: D6FF7C07 02004D07
	v_ashrrev_i32_e32 v6, 31, v5                               // 00000042ADF4: 340C0A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042ADF8: BF870193
	v_sub_nc_u32_e32 v9, v9, v10                               // 00000042ADFC: 4C121509
	.long 0xd73c0007                                           // 00000042AE00: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000042AE04: 02020E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042AE08: BF870193
	.long 0xd73c0005                                           // 00000042AE0C: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000042AE10: 02020A81
	v_add_nc_u32_e32 v9, v2, v9                                // 00000042AE14: 4A121302
	v_add_nc_u32_e32 v2, 0x800, v2                             // 00000042AE18: 4A0404FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042AE20: BF870094
	.long 0xd700060b                                           // 00000042AE24: D700060B
	v_cndmask_b32_e32 v1, s16, v7, vcc_lo                      // 00000042AE28: 02020E10
	v_add_co_ci_u32_e64 v12, null, s17, v8, s6                 // 00000042AE2C: D5207C0C 001A1011
	s_waitcnt lgkmcnt(0)                                       // 00000042AE34: BF89FC07
	.long 0xd7000607                                           // 00000042AE38: D7000607
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000042AE3C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042AE40: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s11, v6, s6                  // 00000042AE44: D5207C08 001A0C0B
	.long 0xd7000605                                           // 00000042AE4C: D7000605
	v_cndmask_b32_e32 v1, v11, v5, vcc_lo                      // 00000042AE50: 02020B0B
	v_add_co_ci_u32_e64 v6, null, v12, v6, s6                  // 00000042AE54: D5207C06 001A0D0C
	global_load_b64 v[5:6], v[5:6], off                        // 00000042AE5C: DC560000 057C0005
	global_load_b64 v[7:8], v[7:8], off                        // 00000042AE64: DC560000 077C0007
	s_waitcnt vmcnt(1)                                         // 00000042AE6C: BF8907F7
	.long 0x7e163905                                           // 00000042AE70: 7E163905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000042AE74: 360A0AFF FFFF0000
	.long 0x7e183906                                           // 00000042AE7C: 7E183906
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042AE80: BF8701A3
	v_lshlrev_b32_e32 v11, 16, v11                             // 00000042AE84: 30161690
	s_waitcnt vmcnt(0)                                         // 00000042AE88: BF8903F7
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000042AE8C: CC200805 8A020B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000042AE94: BF8701C1
	v_fma_mix_f32 v14, v7, v11, v5 op_sel_hi:[1,0,0]           // 00000042AE98: CC20000E 0C161707
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000042AEA0: 360C0CFF FFFF0000
	v_fma_mix_f32 v5, v7, v11, -v5 op_sel_hi:[1,0,0]           // 00000042AEA8: CC200005 8C161707
	v_lshlrev_b32_e32 v12, 16, v12                             // 00000042AEB0: 30181890
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000042AEB4: CC200806 8A020D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000042AEBC: BF870121
	v_fma_mix_f32 v13, v8, v12, v6 op_sel_hi:[1,0,0]           // 00000042AEC0: CC20000D 0C1A1908
	v_fma_mix_f32 v6, v8, v12, -v6 op_sel_hi:[1,0,0]           // 00000042AEC8: CC200006 8C1A1908
	v_dual_add_f32 v7, v14, v13 :: v_dual_add_nc_u32 v4, 8, v4 // 00000042AED0: C9201B0E 07040888
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000042AED8: BF870232
	v_add_f32_e32 v8, v6, v5                                   // 00000042AEDC: 06100B06
	v_sub_f32_e32 v11, v14, v13                                // 00000042AEE0: 08161B0E
	v_sub_f32_e32 v5, v5, v6                                   // 00000042AEE4: 080A0D05
	.long 0xd4430006                                           // 00000042AEE8: D4430006
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 00000042AEEC: 02020816
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042AEF0: 7E0C02FA FF016107
	v_mov_b32_dpp v12, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042AEF8: 7E1802FA FF016108
	v_mov_b32_dpp v13, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042AF00: 7E1A02FA FF01610B
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 00000042AF08: D5010007 200A0F07
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 00000042AF10: D5010008 200A1108
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 00000042AF18: D501000B 200A170B
	v_add_nc_u32_e32 v1, 0x400, v1                             // 00000042AF20: 4A0202FF 00000400
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042AF28: 7E1C02FA FF016105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042AF30: BF870214
	v_dual_add_f32 v6, v7, v6 :: v_dual_add_f32 v7, v8, v12    // 00000042AF34: C9080D07 06061908
	v_add_f32_e32 v8, v11, v13                                 // 00000042AF3C: 06101B0B
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 00000042AF40: D5010005 200A0B05
	s_or_b32 s33, s6, s33                                      // 00000042AF48: 8C212106
	s_delay_alu instid0(VALU_DEP_3)                            // 00000042AF4C: BF870003
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042AF50: 7E1602FA FF016206
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042AF58: 7E1802FA FF016207
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042AF60: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 00000042AF68: D5010008 200E1108
	v_add_f32_e32 v5, v5, v14                                  // 00000042AF70: 060A1D05
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 00000042AF74: D5010007 200E0F07
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 00000042AF7C: D5010006 200E0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042AF84: BF870214
	v_add_f32_e32 v8, v8, v13                                  // 00000042AF88: 06101B08
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042AF8C: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000042AF94: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042AF9C: BF870214
	v_add_f32_e32 v6, v6, v11                                  // 00000042AFA0: 060C1706
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042AFA4: 7E1A02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 00000042AFAC: D5010008 20121108
	v_add_f32_e32 v7, v7, v12                                  // 00000042AFB4: 060E1907
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000042AFB8: BF870224
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042AFBC: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 00000042AFC4: D5010006 20120D06
	v_add_f32_e32 v8, v8, v13                                  // 00000042AFCC: 06101B08
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000042AFD0: BF870224
	v_mov_b32_dpp v12, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042AFD4: 7E1802FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 00000042AFDC: D5010007 20120F07
	v_add_f32_e32 v6, v6, v11                                  // 00000042AFE4: 060C1706
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000042AFE8: BF870234
	v_mov_b32_dpp v13, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042AFEC: 7E1A02FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 00000042AFF4: D5010008 20161108
	v_add_f32_e32 v5, v5, v14                                  // 00000042AFFC: 060A1D05
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042B000: 7E1602FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 00000042B008: D5010006 20160D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042B010: BF870214
	v_add_f32_e32 v8, v8, v13                                  // 00000042B014: 06101B08
	v_mov_b32_dpp v14, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042B018: 7E1C02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 00000042B020: D5010005 20120B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042B028: BF8701A3
	v_dual_add_f32 v6, v6, v11 :: v_dual_mov_b32 v13, v8       // 00000042B02C: C9101706 060C0108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000042B034: D5010008 21AA1108
	v_add_f32_e32 v5, v5, v14                                  // 00000042B03C: 060A1D05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042B040: BF870113
	v_permlanex16_b32 v13, v13, s42, 0xfedcba98                // 00000042B044: D65C000D 03FC550D FEDCBA98
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042B050: 7E1C02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 00000042B058: D5010005 20160B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042B060: BF870091
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v5, v5, v14   // 00000042B064: C9081B08 08041D05
	v_dual_add_f32 v7, v7, v12 :: v_dual_mov_b32 v14, v5       // 00000042B06C: C9101907 070E0105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000042B074: BF870231
	v_mov_b32_dpp v12, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042B078: 7E1802FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 00000042B080: D5010007 20160F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000042B088: D5010005 21AA0B05
	v_permlanex16_b32 v14, v14, s42, 0xfedcba98                // 00000042B090: D65C000E 03FC550E FEDCBA98
	v_mov_b32_e32 v11, v6                                      // 00000042B09C: 7E160306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000042B0A0: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042B0A8: BF870193
	v_add_f32_e32 v10, v5, v14                                 // 00000042B0AC: 06141D05
	v_permlanex16_b32 v11, v11, s42, 0xfedcba98                // 00000042B0B0: D65C000B 03FC550B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042B0BC: BF870091
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v6, v6, v11   // 00000042B0C0: C9081907 07061706
	v_mov_b32_e32 v12, v7                                      // 00000042B0C8: 7E180307
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000042B0CC: D5010007 21AA0F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042B0D4: BF870193
	v_fma_mixlo_f16 v5, v6, s43, 0                             // 00000042B0D8: CC210005 02005706
	v_permlanex16_b32 v12, v12, s42, 0xfedcba98                // 00000042B0E0: D65C000C 03FC550C FEDCBA98
	v_fma_mixhi_f16 v6, v10, s43, 0                            // 00000042B0EC: CC220006 0200570A
	v_fma_mixlo_f16 v6, v8, s43, 0                             // 00000042B0F4: CC210006 02005708
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042B0FC: BF870093
	v_add_f32_e32 v7, v7, v12                                  // 00000042B100: 060E1907
	v_fma_mixhi_f16 v5, v7, s43, 0                             // 00000042B104: CC220005 02005707
	ds_store_b64 v9, v[5:6]                                    // 00000042B10C: D9340000 00000509
	s_and_not1_b32 exec_lo, exec_lo, s33                       // 00000042B114: 917E217E
	s_cbranch_execnz 65297                                     // 00000042B118: BFA6FF11 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x660>
	s_or_b32 exec_lo, exec_lo, s31                             // 00000042B11C: 8C7E1F7E
	s_bfe_i32 s6, s7, 0x1001c                                  // 00000042B120: 9386FF07 0001001C
	s_lshl_b32 s4, s7, 3                                       // 00000042B128: 84048307
	s_lshr_b64 s[2:3], s[6:7], 29                              // 00000042B12C: 85829D06
	s_lshr_b32 s3, s23, 28                                     // 00000042B130: 85039C17
	s_add_i32 s2, s2, 7                                        // 00000042B134: 81028702
	s_add_i32 s3, s19, s3                                      // 00000042B138: 81030313
	s_ashr_i32 s2, s2, 3                                       // 00000042B13C: 86028302
	s_ashr_i32 s3, s3, 4                                       // 00000042B140: 86038403
	.long 0xd72c0001                                           // 00000042B144: D72C0001
	v_cndmask_b32_e32 v1, s2, v19, vcc_lo                      // 00000042B148: 02022602
	s_lshl_b32 s5, s27, 3                                      // 00000042B14C: 8405831B
	s_mul_hi_i32 s7, s26, s3                                   // 00000042B150: 9707031A
	s_ashr_i32 s6, s5, 31                                      // 00000042B154: 86069F05
	v_lshlrev_b32_e32 v21, 2, v20                              // 00000042B158: 302A2882
	s_waitcnt lgkmcnt(0)                                       // 00000042B15C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000042B160: BC7C0000
	s_barrier                                                  // 00000042B164: BFBD0000
	buffer_gl0_inv                                             // 00000042B168: E0AC0000 00000000
	v_add_nc_u32_e32 v3, s2, v1                                // 00000042B170: 4A060202
	s_mul_i32 s2, s26, s3                                      // 00000042B174: 9602031A
	v_add_nc_u32_e32 v2, 1, v1                                 // 00000042B178: 4A040281
	s_add_u32 s2, s2, s5                                       // 00000042B17C: 80020502
	s_addc_u32 s3, s7, s6                                      // 00000042B180: 82030607
	v_min_i32_e32 v22, s4, v3                                  // 00000042B184: 222C0604
	s_lshl_b64 s[4:5], s[2:3], 10                              // 00000042B188: 84848A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042B18C: BF8700A9
	s_add_u32 s3, s8, s4                                       // 00000042B190: 80030408
	s_addc_u32 s4, s9, s5                                      // 00000042B194: 82040509
	v_cmp_lt_i32_e32 vcc_lo, v2, v22                           // 00000042B198: 7C822D02
	s_and_saveexec_b32 s2, vcc_lo                              // 00000042B19C: BE82206A
	s_cbranch_execz 91                                         // 00000042B1A0: BFA5005B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xc10>
	.long 0xd7010503                                           // 00000042B1A4: D7010503
	v_cndmask_b32_e32 v0, v20, v129, vcc_lo                    // 00000042B1A8: 02010314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000042B1AC: BF870121
	v_cndmask_b32_e64 v4, v3, 31, s5                           // 00000042B1B0: D5010004 00153F03
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000042B1B8: 3406049F
	v_cmp_gt_u32_e32 vcc_lo, 31, v4                            // 00000042B1BC: 7C98089F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000042B1C0: BF8701B2
	.long 0xd73c0002                                           // 00000042B1C4: D73C0002
	v_cndmask_b32_e32 v1, 10, v2, vcc_lo                       // 00000042B1C8: 0202048A
	v_cndmask_b32_e64 v6, 0xe1, 1, vcc_lo                      // 00000042B1CC: D5010006 01A902FF 000000E1
	v_mov_b32_e32 v5, 0                                        // 00000042B1D8: 7E0A0280
	.long 0xd7006a08                                           // 00000042B1DC: D7006A08
	v_cndmask_b32_e32 v1, s3, v2, vcc_lo                       // 00000042B1E0: 02020403
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042B1E4: BF870211
	v_add_co_ci_u32_e64 v9, null, s4, v3, vcc_lo               // 00000042B1E8: D5207C09 01AA0604
	v_add_nc_u32_e32 v6, v6, v4                                // 00000042B1F0: 4A0C0906
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042B1F4: BF870114
	.long 0xd73c0004                                           // 00000042B1F8: D73C0004
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 00000042B1FC: 02020882
	v_lshlrev_b32_e32 v7, 24, v6                               // 00000042B200: 300E0C98
	v_bfe_i32 v6, v6, 7, 1                                     // 00000042B204: D6110006 02050F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042B20C: BF870093
	.long 0xd7006a02                                           // 00000042B210: D7006A02
	v_cndmask_b32_e32 v1, v8, v4, vcc_lo                       // 00000042B214: 02020908
	v_add_co_ci_u32_e64 v3, null, v9, v5, vcc_lo               // 00000042B218: D5207C03 01AA0B09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042B220: BF870094
	v_ashrrev_i32_e32 v7, 22, v7                               // 00000042B224: 340E0E96
	.long 0xd7006a04                                           // 00000042B228: D7006A04
	v_cndmask_b32_e32 v1, v8, v7, vcc_lo                       // 00000042B22C: 02020F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042B230: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v9, v6, vcc_lo               // 00000042B234: D5207C05 01AA0D09
	.long 0xd7006a06                                           // 00000042B23C: D7006A06
	v_cndmask_b32_e32 v1, v8, v21, vcc_lo                      // 00000042B240: 02022B08
	v_add_co_ci_u32_e64 v7, null, 0, v9, vcc_lo                // 00000042B244: D5207C07 01AA1280
	s_clause 0x17                                              // 00000042B24C: BF850017
	global_load_b32 v23, v[2:3], off                           // 00000042B250: DC520000 177C0002
	global_load_b32 v26, v[2:3], off offset:128                // 00000042B258: DC520080 1A7C0002
	global_load_b32 v25, v[2:3], off offset:256                // 00000042B260: DC520100 197C0002
	global_load_b32 v24, v[2:3], off offset:384                // 00000042B268: DC520180 187C0002
	global_load_b32 v18, v[2:3], off offset:512                // 00000042B270: DC520200 127C0002
	global_load_b32 v30, v[2:3], off offset:640                // 00000042B278: DC520280 1E7C0002
	global_load_b32 v31, v[2:3], off offset:768                // 00000042B280: DC520300 1F7C0002
	global_load_b32 v33, v[2:3], off offset:896                // 00000042B288: DC520380 217C0002
	global_load_b32 v32, v[4:5], off                           // 00000042B290: DC520000 207C0004
	global_load_b32 v29, v[4:5], off offset:128                // 00000042B298: DC520080 1D7C0004
	global_load_b32 v28, v[4:5], off offset:256                // 00000042B2A0: DC520100 1C7C0004
	global_load_b32 v27, v[4:5], off offset:384                // 00000042B2A8: DC520180 1B7C0004
	global_load_b32 v45, v[4:5], off offset:512                // 00000042B2B0: DC520200 2D7C0004
	global_load_b32 v44, v[4:5], off offset:640                // 00000042B2B8: DC520280 2C7C0004
	global_load_b32 v43, v[4:5], off offset:768                // 00000042B2C0: DC520300 2B7C0004
	global_load_b32 v42, v[4:5], off offset:896                // 00000042B2C8: DC520380 2A7C0004
	global_load_b32 v41, v[6:7], off                           // 00000042B2D0: DC520000 297C0006
	global_load_b32 v36, v[6:7], off offset:128                // 00000042B2D8: DC520080 247C0006
	global_load_b32 v35, v[6:7], off offset:256                // 00000042B2E0: DC520100 237C0006
	global_load_b32 v34, v[6:7], off offset:384                // 00000042B2E8: DC520180 227C0006
	global_load_b32 v40, v[6:7], off offset:512                // 00000042B2F0: DC520200 287C0006
	global_load_b32 v39, v[6:7], off offset:640                // 00000042B2F8: DC520280 277C0006
	global_load_b32 v38, v[6:7], off offset:768                // 00000042B300: DC520300 267C0006
	global_load_b32 v37, v[6:7], off offset:896                // 00000042B308: DC520380 257C0006
	s_or_b32 exec_lo, exec_lo, s2                              // 00000042B310: 8C7E027E
	v_cmp_lt_i32_e32 vcc_lo, v1, v22                           // 00000042B314: 7C822D01
	s_and_saveexec_b32 s5, vcc_lo                              // 00000042B318: BE85206A
	s_cbranch_execz 93                                         // 00000042B31C: BFA5005D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xd94>
	.long 0xd7010202                                           // 00000042B320: D7010202
	v_cndmask_b32_e32 v0, v20, v129, vcc_lo                    // 00000042B324: 02010314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000042B328: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s2                           // 00000042B32C: D5010003 00093F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000042B334: 3404029F
	.long 0xd44c0002                                           // 00000042B338: D44C0002
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 00000042B33C: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042B340: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s2                          // 00000042B344: D5010005 000902FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 00000042B350: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042B358: BF870114
	.long 0xd73c0005                                           // 00000042B35C: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000042B360: 0202028A
	.long 0xd73c0002                                           // 00000042B364: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000042B368: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000042B36C: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 00000042B370: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 00000042B374: D6110007 02050F07
	.long 0xd7000208                                           // 00000042B37C: D7000208
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 00000042B380: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042B384: BF870211
	v_add_co_ci_u32_e64 v9, null, s4, v6, s2                   // 00000042B388: D5207C09 000A0C04
	v_ashrrev_i32_e32 v6, 22, v4                               // 00000042B390: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042B394: BF870093
	.long 0xd7000204                                           // 00000042B398: D7000204
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 00000042B39C: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s2                   // 00000042B3A0: D5207C05 000A0709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042B3A8: BF870093
	.long 0xd7000206                                           // 00000042B3AC: D7000206
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 00000042B3B0: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s2                   // 00000042B3B4: D5207C07 000A0F09
	.long 0xd7000208                                           // 00000042B3BC: D7000208
	v_cndmask_b32_e32 v1, v8, v21, vcc_lo                      // 00000042B3C0: 02022B08
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042B3C4: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s2                    // 00000042B3C8: D5207C09 000A1280
	s_clause 0x17                                              // 00000042B3D0: BF850017
	global_load_b32 v2, v[4:5], off                            // 00000042B3D4: DC520000 027C0004
	global_load_b32 v121, v[4:5], off offset:128               // 00000042B3DC: DC520080 797C0004
	global_load_b32 v118, v[4:5], off offset:256               // 00000042B3E4: DC520100 767C0004
	global_load_b32 v115, v[4:5], off offset:384               // 00000042B3EC: DC520180 737C0004
	global_load_b32 v112, v[4:5], off offset:512               // 00000042B3F4: DC520200 707C0004
	global_load_b32 v109, v[4:5], off offset:640               // 00000042B3FC: DC520280 6D7C0004
	global_load_b32 v106, v[4:5], off offset:768               // 00000042B404: DC520300 6A7C0004
	global_load_b32 v83, v[4:5], off offset:896                // 00000042B40C: DC520380 537C0004
	global_load_b32 v3, v[6:7], off                            // 00000042B414: DC520000 037C0006
	global_load_b32 v122, v[6:7], off offset:128               // 00000042B41C: DC520080 7A7C0006
	global_load_b32 v119, v[6:7], off offset:256               // 00000042B424: DC520100 777C0006
	global_load_b32 v116, v[6:7], off offset:384               // 00000042B42C: DC520180 747C0006
	global_load_b32 v113, v[6:7], off offset:512               // 00000042B434: DC520200 717C0006
	global_load_b32 v110, v[6:7], off offset:640               // 00000042B43C: DC520280 6E7C0006
	global_load_b32 v107, v[6:7], off offset:768               // 00000042B444: DC520300 6B7C0006
	global_load_b32 v84, v[6:7], off offset:896                // 00000042B44C: DC520380 547C0006
	global_load_b32 v123, v[8:9], off                          // 00000042B454: DC520000 7B7C0008
	global_load_b32 v120, v[8:9], off offset:128               // 00000042B45C: DC520080 787C0008
	global_load_b32 v117, v[8:9], off offset:256               // 00000042B464: DC520100 757C0008
	global_load_b32 v114, v[8:9], off offset:384               // 00000042B46C: DC520180 727C0008
	global_load_b32 v111, v[8:9], off offset:512               // 00000042B474: DC520200 6F7C0008
	global_load_b32 v108, v[8:9], off offset:640               // 00000042B47C: DC520280 6C7C0008
	global_load_b32 v105, v[8:9], off offset:768               // 00000042B484: DC520300 697C0008
	global_load_b32 v82, v[8:9], off offset:896                // 00000042B48C: DC520380 527C0008
	s_or_b32 exec_lo, exec_lo, s5                              // 00000042B494: 8C7E057E
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0             // 00000042B498: CA100080 2E2E0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 00000042B4A0: CA100080 30300080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v51, 0             // 00000042B4A8: CA100080 32320080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v54, 0             // 00000042B4B0: CA100080 35360080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v56, 0             // 00000042B4B8: CA100080 37380080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v58, 0             // 00000042B4C0: CA100080 393A0080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v60, 0             // 00000042B4C8: CA100080 3B3C0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v62, 0             // 00000042B4D0: CA100080 3D3E0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v66, 0             // 00000042B4D8: CA100080 3F420080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v68, 0             // 00000042B4E0: CA100080 41440080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v52, 0             // 00000042B4E8: CA100080 43340080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v72, 0             // 00000042B4F0: CA100080 45480080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v76, 0             // 00000042B4F8: CA100080 474C0080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v70, 0             // 00000042B500: CA100080 4B460080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v73, 0             // 00000042B508: CA100080 40480080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v77, 0             // 00000042B510: CA100080 4A4C0080
	s_ashr_i32 s27, s26, 31                                    // 00000042B518: 861B9F1A
	s_and_saveexec_b32 s2, vcc_lo                              // 00000042B51C: BE82206A
	s_cbranch_execz 1108                                       // 00000042B520: BFA50454 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1f74>
	v_dual_mov_b32 v47, 0 :: v_dual_add_nc_u32 v4, -1, v0      // 00000042B524: CA200080 2F0400C1
	v_dual_mov_b32 v48, 0 :: v_dual_and_b32 v5, 16, v0         // 00000042B52C: CA240080 30040090
	v_dual_mov_b32 v46, 0 :: v_dual_add_nc_u32 v17, 2, v1      // 00000042B534: CA200080 2E100282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000042B53C: BF870243
	v_dual_mov_b32 v49, 0 :: v_dual_and_b32 v4, 31, v4         // 00000042B540: CA240080 3104089F
	v_sub_nc_u32_e32 v78, 0, v22                               // 00000042B548: 4C9C2C80
	v_dual_mov_b32 v50, 0 :: v_dual_lshlrev_b32 v79, 2, v20    // 00000042B54C: CA220080 324E2882
	v_lshl_or_b32 v80, v1, 5, v5                               // 00000042B554: D6560050 04150B01
	v_dual_mov_b32 v54, 0 :: v_dual_lshlrev_b32 v81, 2, v4     // 00000042B55C: CA220080 36500882
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v56, 0             // 00000042B564: CA100080 33380080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v58, 0             // 00000042B56C: CA100080 353A0080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v60, 0             // 00000042B574: CA100080 373C0080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v62, 0             // 00000042B57C: CA100080 393E0080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v66, 0             // 00000042B584: CA100080 3B420080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v68, 0             // 00000042B58C: CA100080 3D440080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v52, 0             // 00000042B594: CA100080 3F340080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v72, 0             // 00000042B59C: CA100080 41480080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v76, 0             // 00000042B5A4: CA100080 434C0080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v70, 0             // 00000042B5AC: CA100080 45460080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v64, 0             // 00000042B5B4: CA100080 47400080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v74, 0             // 00000042B5BC: CA100080 4B4A0080
	v_mov_b32_e32 v73, 0                                       // 00000042B5C4: 7E920280
	v_mov_b32_e32 v77, 0                                       // 00000042B5C8: 7E9A0280
	s_mov_b32 s5, 0                                            // 00000042B5CC: BE850080
	s_movk_i32 s6, 0x1eee                                      // 00000042B5D0: B0061EEE
	s_branch 982                                               // 00000042B5D4: BFA003D6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e30>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000042B5D8: 8C7E077E
	v_bfe_u32 v126, v123, 12, 16                               // 00000042B5DC: D610007E 0241197B
	v_alignbit_b32 v124, v2, v3, 16                            // 00000042B5E4: D616007C 02420702
	v_bfe_u32 v127, v123, 8, 16                                // 00000042B5EC: D610007F 0241117B
	ds_load_b128 v[13:16], v80                                 // 00000042B5F4: DBFC0000 0D000050
	ds_load_b128 v[1:4], v80 offset:5120                       // 00000042B5FC: DBFC1400 01000050
	ds_load_b128 v[5:8], v80 offset:10240                      // 00000042B604: DBFC2800 05000050
	ds_load_b128 v[9:12], v80 offset:15360                     // 00000042B60C: DBFC3C00 09000050
	v_bfe_u32 v130, v123, 4, 16                                // 00000042B614: D6100082 0241097B
	.long 0xd72c007e                                           // 00000042B61C: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 00000042B620: 0202FCFF 83DCD12D
	v_bfe_u32 v125, v124, 12, 16                               // 00000042B628: D610007D 0241197C
	.long 0xd72c007f                                           // 00000042B630: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 00000042B634: 0202FEFF 83DCD12D
	v_bfe_u32 v128, v124, 8, 16                                // 00000042B63C: D6100080 0241117C
	.long 0xd72c0082                                           // 00000042B644: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 00000042B648: 020304FF 83DCD12D
	v_alignbit_b32 v121, v121, v122, 16                        // 00000042B650: D6160079 0242F579
	.long 0xd72c007d                                           // 00000042B658: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 00000042B65C: 0202FAFF 83DCD12D
	v_alignbit_b32 v118, v118, v119, 16                        // 00000042B664: D6160076 0242EF76
	v_sad_u8 v126, v126, 0, 0x6400                             // 00000042B66C: D622007E 03FD017E 00006400
	.long 0xd72c0080                                           // 00000042B678: D72C0080
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 00000042B67C: 020300FF 83DCD12D
	v_sad_u8 v127, v127, 0, 0x6400                             // 00000042B684: D622007F 03FD017F 00006400
	v_alignbit_b32 v115, v115, v116, 16                        // 00000042B690: D6160073 0242E973
	v_bfe_u32 v119, v118, 12, 16                               // 00000042B698: D6100077 02411976
	v_and_b32_e32 v126, 0xffff, v126                           // 00000042B6A0: 36FCFCFF 0000FFFF
	v_sad_u8 v125, v125, 0, 0x6400                             // 00000042B6A8: D622007D 03FD017D 00006400
	v_alignbit_b32 v112, v112, v113, 16                        // 00000042B6B4: D6160070 0242E370
	v_bfe_u32 v116, v115, 12, 16                               // 00000042B6BC: D6100074 02411973
	v_sad_u8 v128, v128, 0, 0x6400                             // 00000042B6C4: D6220080 03FD0180 00006400
	v_lshl_or_b32 v126, v127, 16, v126                         // 00000042B6D0: D656007E 05F9217F
	v_bfe_u32 v127, v120, 12, 16                               // 00000042B6D8: D610007F 02411978
	.long 0xd72c0077                                           // 00000042B6E0: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 00000042B6E4: 0202EEFF 83DCD12D
	.long 0xd72c0074                                           // 00000042B6EC: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 00000042B6F0: 0202E8FF 83DCD12D
	v_bfe_u32 v113, v112, 12, 16                               // 00000042B6F8: D6100071 02411970
	v_pk_fma_f16 v126, v126, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042B700: CC0E007E 0BFC0D7E 0000C931
	v_and_b32_e32 v125, 0xffff, v125                           // 00000042B70C: 36FAFAFF 0000FFFF
	.long 0xd72c007f                                           // 00000042B714: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 00000042B718: 0202FEFF 83DCD12D
	v_alignbit_b32 v109, v109, v110, 16                        // 00000042B720: D616006D 0242DD6D
	.long 0xd72c0071                                           // 00000042B728: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 00000042B72C: 0202E2FF 83DCD12D
	v_sad_u8 v119, v119, 0, 0x6400                             // 00000042B734: D6220077 03FD0177 00006400
	v_lshl_or_b32 v125, v128, 16, v125                         // 00000042B740: D656007D 05F52180
	v_sad_u8 v128, v130, 0, 0x6400                             // 00000042B748: D6220080 03FD0182 00006400
	v_sad_u8 v116, v116, 0, 0x6400                             // 00000042B754: D6220074 03FD0174 00006400
	v_bfe_u32 v110, v109, 12, 16                               // 00000042B760: D610006E 0241196D
	v_sad_u8 v127, v127, 0, 0x6400                             // 00000042B768: D622007F 03FD017F 00006400
	v_pk_fma_f16 v125, v125, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042B774: CC0E007D 0BFC0D7D 0000C931
	v_and_b32_e32 v129, 0xffff, v124                           // 00000042B780: 3702F8FF 0000FFFF
	v_bfe_u32 v124, v124, 4, 16                                // 00000042B788: D610007C 0241097C
	v_sad_u8 v113, v113, 0, 0x6400                             // 00000042B790: D6220071 03FD0171 00006400
	.long 0xd72c006e                                           // 00000042B79C: D72C006E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v110, vcc_lo             // 00000042B7A0: 0202DCFF 83DCD12D
	s_waitcnt lgkmcnt(2)                                       // 00000042B7A8: BF89FC27
	v_dot2acc_f32_f16 v74, v125, v1                            // 00000042B7AC: 0494037D
	.long 0xd72c0081                                           // 00000042B7B0: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 00000042B7B4: 020302FF 83DCD12D
	.long 0xd72c007c                                           // 00000042B7BC: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 00000042B7C0: 0202F8FF 83DCD12D
	v_dot2acc_f32_f16 v77, v125, v13                           // 00000042B7C8: 049A1B7D
	v_alignbit_b32 v106, v106, v107, 16                        // 00000042B7CC: D616006A 0242D76A
	v_alignbit_b32 v83, v83, v84, 16                           // 00000042B7D4: D6160053 0242A953
	v_add_nc_u32_e32 v17, 1, v17                               // 00000042B7DC: 4A222281
	v_sad_u8 v110, v110, 0, 0x6400                             // 00000042B7E0: D622006E 03FD016E 00006400
	s_waitcnt lgkmcnt(0)                                       // 00000042B7EC: BF89FC07
	v_dot2acc_f32_f16 v64, v125, v9                            // 00000042B7F0: 0480137D
	v_sad_u8 v129, v129, 0, 0x6400                             // 00000042B7F4: D6220081 03FD0181 00006400
	v_sad_u8 v124, v124, 0, 0x6400                             // 00000042B800: D622007C 03FD017C 00006400
	v_bfe_u32 v107, v106, 12, 16                               // 00000042B80C: D610006B 0241196A
	v_bfe_u32 v84, v83, 12, 16                                 // 00000042B814: D6100054 02411953
	v_and_b32_e32 v116, 0xffff, v116                           // 00000042B81C: 36E8E8FF 0000FFFF
	v_lshlrev_b32_e32 v129, 16, v129                           // 00000042B824: 31030290
	v_and_b32_e32 v110, 0xffff, v110                           // 00000042B828: 36DCDCFF 0000FFFF
	.long 0xd72c006b                                           // 00000042B830: D72C006B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v107, vcc_lo             // 00000042B834: 0202D6FF 83DCD12D
	.long 0xd72c0054                                           // 00000042B83C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000042B840: 0202A8FF 83DCD12D
	v_add_nc_u32_e32 v80, 32, v80                              // 00000042B848: 4AA0A0A0
	v_and_or_b32 v124, 0xffff, v124, v129                      // 00000042B84C: D657007C 0606F8FF 0000FFFF
	v_bfe_u32 v129, v120, 4, 16                                // 00000042B858: D6100081 02410978
	s_delay_alu instid0(VALU_DEP_2)                            // 00000042B860: BF870002
	v_pk_fma_f16 v124, v124, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042B864: CC0E007C 0BFC0D7C 0000C931
	v_and_b32_e32 v123, 0xffff, v123                           // 00000042B870: 36F6F6FF 0000FFFF
	v_dot2acc_f32_f16 v73, v125, v5                            // 00000042B878: 04920B7D
	v_sad_u8 v107, v107, 0, 0x6400                             // 00000042B87C: D622006B 03FD016B 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 00000042B888: D6220054 03FD0154 00006400
	v_dot2acc_f32_f16 v74, v124, v2                            // 00000042B894: 0494057C
	.long 0xd72c007b                                           // 00000042B898: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 00000042B89C: 0202F6FF 83DCD12D
	v_dot2acc_f32_f16 v77, v124, v14                           // 00000042B8A4: 049A1D7C
	v_dot2acc_f32_f16 v64, v124, v10                           // 00000042B8A8: 0480157C
	v_dot2acc_f32_f16 v73, v124, v6                            // 00000042B8AC: 04920D7C
	v_bfe_u32 v124, v121, 8, 16                                // 00000042B8B0: D610007C 02411179
	v_dual_dot2acc_f32_f16 v74, v126, v3 :: v_dual_and_b32 v125, 0xffff, v121// 00000042B8B8: CB24077E 4A7CF2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000042B8C4: BF870224
	v_dot2acc_f32_f16 v64, v126, v11                           // 00000042B8C8: 0480177E
	v_sad_u8 v123, v123, 0, 0x6400                             // 00000042B8CC: D622007B 03FD017B 00006400
	.long 0xd72c007c                                           // 00000042B8D8: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 00000042B8DC: 0202F8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000042B8E4: BF870154
	.long 0xd72c007d                                           // 00000042B8E8: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 00000042B8EC: 0202FAFF 83DCD12D
	v_and_b32_e32 v107, 0xffff, v107                           // 00000042B8F4: 36D6D6FF 0000FFFF
	v_and_b32_e32 v84, 0xffff, v84                             // 00000042B8FC: 36A8A8FF 0000FFFF
	v_lshlrev_b32_e32 v123, 16, v123                           // 00000042B904: 30F6F690
	v_sad_u8 v124, v124, 0, 0x6400                             // 00000042B908: D622007C 03FD017C 00006400
	v_and_or_b32 v123, 0xffff, v128, v123                      // 00000042B914: D657007B 05EF00FF 0000FFFF
	v_bfe_u32 v128, v120, 8, 16                                // 00000042B920: D6100080 02411178
	v_and_b32_e32 v120, 0xffff, v120                           // 00000042B928: 36F0F0FF 0000FFFF
	v_sad_u8 v125, v125, 0, 0x6400                             // 00000042B930: D622007D 03FD017D 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000042B93C: BF870004
	v_pk_fma_f16 v122, v123, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042B940: CC0E007A 0BFC0D7B 0000C931
	v_bfe_u32 v123, v121, 12, 16                               // 00000042B94C: D610007B 02411979
	v_bfe_u32 v121, v121, 4, 16                                // 00000042B954: D6100079 02410979
	.long 0xd72c0078                                           // 00000042B95C: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 00000042B960: 0202F0FF 83DCD12D
	.long 0xd72c0080                                           // 00000042B968: D72C0080
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 00000042B96C: 020300FF 83DCD12D
	v_dot2acc_f32_f16 v64, v122, v12                           // 00000042B974: 0480197A
	.long 0xd72c007b                                           // 00000042B978: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 00000042B97C: 0202F6FF 83DCD12D
	.long 0xd72c0079                                           // 00000042B984: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 00000042B988: 0202F2FF 83DCD12D
	v_dot2acc_f32_f16 v74, v122, v4                            // 00000042B990: 0494097A
	v_sad_u8 v120, v120, 0, 0x6400                             // 00000042B994: D6220078 03FD0178 00006400
	v_dot2acc_f32_f16 v77, v126, v15                           // 00000042B9A0: 049A1F7E
	v_sad_u8 v128, v128, 0, 0x6400                             // 00000042B9A4: D6220080 03FD0180 00006400
	v_sad_u8 v123, v123, 0, 0x6400                             // 00000042B9B0: D622007B 03FD017B 00006400
	v_sad_u8 v121, v121, 0, 0x6400                             // 00000042B9BC: D6220079 03FD0179 00006400
	v_lshlrev_b32_e32 v120, 16, v120                           // 00000042B9C8: 30F0F090
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042B9CC: BF870093
	v_and_b32_e32 v123, 0xffff, v123                           // 00000042B9D0: 36F6F6FF 0000FFFF
	v_lshl_or_b32 v123, v124, 16, v123                         // 00000042B9D8: D656007B 05ED217C
	v_and_b32_e32 v124, 0xffff, v127                           // 00000042B9E0: 36F8FEFF 0000FFFF
	.long 0xd72c007f                                           // 00000042B9E8: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 00000042B9EC: 020302FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000042B9F4: BF870003
	v_pk_fma_f16 v123, v123, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042B9F8: CC0E007B 0BFC0D7B 0000C931
	v_dot2acc_f32_f16 v77, v122, v16                           // 00000042BA04: 049A217A
	v_dot2acc_f32_f16 v73, v126, v7                            // 00000042BA08: 04920F7E
	v_lshl_or_b32 v124, v128, 16, v124                         // 00000042BA0C: D656007C 05F12180
	v_bfe_u32 v126, v117, 4, 16                                // 00000042BA14: D610007E 02410975
	v_dot2acc_f32_f16 v76, v123, v1                            // 00000042BA1C: 0498037B
	v_lshlrev_b32_e32 v125, 16, v125                           // 00000042BA20: 30FAFA90
	v_dot2acc_f32_f16 v70, v123, v13                           // 00000042BA24: 048C1B7B
	v_pk_fma_f16 v124, v124, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BA28: CC0E007C 0BFC0D7C 0000C931
	v_dot2acc_f32_f16 v72, v123, v9                            // 00000042BA34: 0490137B
	.long 0xd72c007e                                           // 00000042BA38: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 00000042BA3C: 0202FCFF 83DCD12D
	v_and_or_b32 v121, 0xffff, v121, v125                      // 00000042BA44: D6570079 05F6F2FF 0000FFFF
	v_sad_u8 v125, v127, 0, 0x6400                             // 00000042BA50: D622007D 03FD017F 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042BA5C: BF8701A2
	v_pk_fma_f16 v121, v121, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BA60: CC0E0079 0BFC0D79 0000C931
	v_dot2acc_f32_f16 v73, v122, v8                            // 00000042BA6C: 0492117A
	v_and_or_b32 v120, 0xffff, v125, v120                      // 00000042BA70: D6570078 05E2FAFF 0000FFFF
	v_bfe_u32 v122, v118, 8, 16                                // 00000042BA7C: D610007A 02411176
	v_bfe_u32 v125, v117, 8, 16                                // 00000042BA84: D610007D 02411175
	v_dual_dot2acc_f32_f16 v70, v121, v14 :: v_dual_dot2acc_f32_f16 v75, v123, v5// 00000042BA8C: CB181D79 464A0B7B
	v_dot2acc_f32_f16 v76, v121, v2                            // 00000042BA94: 04980579
	v_pk_fma_f16 v120, v120, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BA98: CC0E0078 0BFC0D78 0000C931
	v_dot2acc_f32_f16 v72, v121, v10                           // 00000042BAA4: 04901579
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042BAA8: BF870214
	v_dual_dot2acc_f32_f16 v70, v124, v15 :: v_dual_dot2acc_f32_f16 v75, v121, v6// 00000042BAAC: CB181F7C 464A0D79
	v_dual_dot2acc_f32_f16 v76, v124, v3 :: v_dual_and_b32 v121, 0xffff, v118// 00000042BAB4: CB24077C 4C78ECFF 0000FFFF
	v_bfe_u32 v118, v118, 4, 16                                // 00000042BAC0: D6100076 02410976
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042BAC8: BF870213
	v_dot2acc_f32_f16 v70, v120, v16                           // 00000042BACC: 048C2178
	v_dot2acc_f32_f16 v75, v124, v7                            // 00000042BAD0: 04960F7C
	v_bfe_u32 v123, v117, 12, 16                               // 00000042BAD4: D610007B 02411975
	.long 0xd72c0079                                           // 00000042BADC: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 00000042BAE0: 0202F2FF 83DCD12D
	.long 0xd72c0076                                           // 00000042BAE8: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 00000042BAEC: 0202ECFF 83DCD12D
	.long 0xd72c007a                                           // 00000042BAF4: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 00000042BAF8: 0202F4FF 83DCD12D
	v_dot2acc_f32_f16 v75, v120, v8                            // 00000042BB00: 04961178
	v_dot2acc_f32_f16 v72, v124, v11                           // 00000042BB04: 0490177C
	.long 0xd72c007b                                           // 00000042BB08: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 00000042BB0C: 0202F6FF 83DCD12D
	v_dual_dot2acc_f32_f16 v76, v120, v4 :: v_dual_and_b32 v117, 0xffff, v117// 00000042BB14: CB240978 4C74EAFF 0000FFFF
	v_sad_u8 v121, v121, 0, 0x6400                             // 00000042BB20: D6220079 03FD0179 00006400
	v_sad_u8 v118, v118, 0, 0x6400                             // 00000042BB2C: D6220076 03FD0176 00006400
	v_sad_u8 v122, v122, 0, 0x6400                             // 00000042BB38: D622007A 03FD017A 00006400
	.long 0xd72c007d                                           // 00000042BB44: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 00000042BB48: 0202FAFF 83DCD12D
	.long 0xd72c0075                                           // 00000042BB50: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 00000042BB54: 0202EAFF 83DCD12D
	v_lshlrev_b32_e32 v121, 16, v121                           // 00000042BB5C: 30F2F290
	v_sad_u8 v123, v123, 0, 0x6400                             // 00000042BB60: D622007B 03FD017B 00006400
	v_dot2acc_f32_f16 v72, v120, v12                           // 00000042BB6C: 04901978
	v_and_b32_e32 v120, 0xffff, v115                           // 00000042BB70: 36F0E6FF 0000FFFF
	v_bfe_u32 v124, v114, 8, 16                                // 00000042BB78: D610007C 02411172
	v_and_or_b32 v118, 0xffff, v118, v121                      // 00000042BB80: D6570076 05E6ECFF 0000FFFF
	v_sad_u8 v117, v117, 0, 0x6400                             // 00000042BB8C: D6220075 03FD0175 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042BB98: BF870214
	.long 0xd72c0078                                           // 00000042BB9C: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 00000042BBA0: 0202F0FF 83DCD12D
	.long 0xd72c007c                                           // 00000042BBA8: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 00000042BBAC: 0202F8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042BBB4: BF8700A4
	v_pk_fma_f16 v118, v118, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BBB8: CC0E0076 0BFC0D76 0000C931
	v_and_b32_e32 v119, 0xffff, v119                           // 00000042BBC4: 36EEEEFF 0000FFFF
	v_lshl_or_b32 v119, v122, 16, v119                         // 00000042BBCC: D6560077 05DD217A
	v_sad_u8 v122, v125, 0, 0x6400                             // 00000042BBD4: D622007A 03FD017D 00006400
	v_bfe_u32 v125, v114, 4, 16                                // 00000042BBE0: D610007D 02410972
	v_sad_u8 v120, v120, 0, 0x6400                             // 00000042BBE8: D6220078 03FD0178 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000042BBF4: BF870234
	v_pk_fma_f16 v119, v119, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BBF8: CC0E0077 0BFC0D77 0000C931
	v_and_b32_e32 v121, 0xffff, v123                           // 00000042BC04: 36F2F6FF 0000FFFF
	v_sad_u8 v123, v126, 0, 0x6400                             // 00000042BC0C: D622007B 03FD017E 00006400
	v_lshlrev_b32_e32 v120, 16, v120                           // 00000042BC18: 30F0F090
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042BC1C: BF870214
	v_dot2acc_f32_f16 v52, v119, v13                           // 00000042BC20: 04681B77
	v_lshl_or_b32 v121, v122, 16, v121                         // 00000042BC24: D6560079 05E5217A
	v_dot2acc_f32_f16 v71, v119, v1                            // 00000042BC2C: 048E0377
	v_bfe_u32 v122, v115, 8, 16                                // 00000042BC30: D610007A 02411173
	v_bfe_u32 v115, v115, 4, 16                                // 00000042BC38: D6100073 02410973
	v_dot2acc_f32_f16 v52, v118, v14                           // 00000042BC40: 04681D76
	v_pk_fma_f16 v121, v121, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BC44: CC0E0079 0BFC0D79 0000C931
	v_lshlrev_b32_e32 v117, 16, v117                           // 00000042BC50: 30EAEA90
	v_dot2acc_f32_f16 v71, v118, v2                            // 00000042BC54: 048E0576
	.long 0xd72c007a                                           // 00000042BC58: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 00000042BC5C: 0202F4FF 83DCD12D
	.long 0xd72c0073                                           // 00000042BC64: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v115, vcc_lo             // 00000042BC68: 0202E6FF 83DCD12D
	v_dot2acc_f32_f16 v52, v121, v15                           // 00000042BC70: 04681F79
	v_and_or_b32 v117, 0xffff, v123, v117                      // 00000042BC74: D6570075 05D6F6FF 0000FFFF
	v_bfe_u32 v123, v114, 12, 16                               // 00000042BC80: D610007B 02411972
	v_dual_dot2acc_f32_f16 v71, v121, v3 :: v_dual_and_b32 v114, 0xffff, v114// 00000042BC88: CB240779 4772E4FF 0000FFFF
	v_dot2acc_f32_f16 v68, v119, v9                            // 00000042BC94: 04881377
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000042BC98: BF870254
	v_pk_fma_f16 v117, v117, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BC9C: CC0E0075 0BFC0D75 0000C931
	v_dot2acc_f32_f16 v69, v119, v5                            // 00000042BCA8: 048A0B77
	.long 0xd72c007b                                           // 00000042BCAC: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 00000042BCB0: 0202F6FF 83DCD12D
	v_sad_u8 v122, v122, 0, 0x6400                             // 00000042BCB8: D622007A 03FD017A 00006400
	.long 0xd72c0072                                           // 00000042BCC4: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 00000042BCC8: 0202E4FF 83DCD12D
	v_dual_dot2acc_f32_f16 v52, v117, v16 :: v_dual_dot2acc_f32_f16 v69, v118, v6// 00000042BCD0: CB182175 34440D76
	v_sad_u8 v115, v115, 0, 0x6400                             // 00000042BCD8: D6220073 03FD0173 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000042BCE4: BF870004
	v_lshl_or_b32 v116, v122, 16, v116                         // 00000042BCE8: D6560074 05D1217A
	v_dot2acc_f32_f16 v71, v117, v4                            // 00000042BCF0: 048E0975
	v_sad_u8 v123, v123, 0, 0x6400                             // 00000042BCF4: D622007B 03FD017B 00006400
	v_dot2acc_f32_f16 v69, v121, v7                            // 00000042BD00: 048A0F79
	.long 0xd72c0077                                           // 00000042BD04: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 00000042BD08: 0202FAFF 83DCD12D
	v_and_or_b32 v115, 0xffff, v115, v120                      // 00000042BD10: D6570073 05E2E6FF 0000FFFF
	v_sad_u8 v122, v124, 0, 0x6400                             // 00000042BD1C: D622007A 03FD017C 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000042BD28: BF870004
	v_dual_dot2acc_f32_f16 v69, v117, v8 :: v_dual_and_b32 v120, 0xffff, v123// 00000042BD2C: CB241175 4578F6FF 0000FFFF
	v_sad_u8 v114, v114, 0, 0x6400                             // 00000042BD38: D6220072 03FD0172 00006400
	v_pk_fma_f16 v116, v116, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BD44: CC0E0074 0BFC0D74 0000C931
	v_dot2acc_f32_f16 v68, v118, v10                           // 00000042BD50: 04881576
	v_pk_fma_f16 v115, v115, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BD54: CC0E0073 0BFC0D73 0000C931
	v_lshl_or_b32 v118, v122, 16, v120                         // 00000042BD60: D6560076 05E1217A
	v_sad_u8 v119, v119, 0, 0x6400                             // 00000042BD68: D6220077 03FD0177 00006400
	v_dual_dot2acc_f32_f16 v65, v116, v5 :: v_dual_lshlrev_b32 v114, 16, v114// 00000042BD74: CB220B74 4172E490
	v_dot2acc_f32_f16 v67, v116, v13                           // 00000042BD7C: 04861B74
	v_dot2acc_f32_f16 v66, v116, v1                            // 00000042BD80: 04840374
	v_pk_fma_f16 v118, v118, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BD84: CC0E0076 0BFC0D76 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000042BD90: BF870244
	v_and_or_b32 v114, 0xffff, v119, v114                      // 00000042BD94: D6570072 05CAEEFF 0000FFFF
	v_dual_dot2acc_f32_f16 v68, v121, v11 :: v_dual_dot2acc_f32_f16 v65, v115, v6// 00000042BDA0: CB181779 44400D73
	v_dot2acc_f32_f16 v67, v115, v14                           // 00000042BDA8: 04861D73
	v_dot2acc_f32_f16 v66, v115, v2                            // 00000042BDAC: 04840573
	v_pk_fma_f16 v114, v114, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BDB0: CC0E0072 0BFC0D72 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042BDBC: BF870214
	v_dual_dot2acc_f32_f16 v68, v117, v12 :: v_dual_dot2acc_f32_f16 v65, v118, v7// 00000042BDC0: CB181975 44400F76
	v_dot2acc_f32_f16 v67, v118, v15                           // 00000042BDC8: 04861F76
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000042BDCC: BF870244
	v_dual_dot2acc_f32_f16 v66, v118, v3 :: v_dual_and_b32 v117, 0xffff, v112// 00000042BDD0: CB240776 4274E0FF 0000FFFF
	v_dot2acc_f32_f16 v63, v116, v9                            // 00000042BDDC: 047E1374
	v_bfe_u32 v116, v112, 8, 16                                // 00000042BDE0: D6100074 02411170
	v_bfe_u32 v112, v112, 4, 16                                // 00000042BDE8: D6100070 02410970
	v_dot2acc_f32_f16 v66, v114, v4                            // 00000042BDF0: 04840972
	.long 0xd72c0075                                           // 00000042BDF4: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 00000042BDF8: 0202EAFF 83DCD12D
	v_dot2acc_f32_f16 v63, v115, v10                           // 00000042BE00: 047E1573
	v_bfe_u32 v115, v111, 12, 16                               // 00000042BE04: D6100073 0241196F
	.long 0xd72c0070                                           // 00000042BE0C: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 00000042BE10: 0202E0FF 83DCD12D
	.long 0xd72c0074                                           // 00000042BE18: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 00000042BE1C: 0202E8FF 83DCD12D
	v_bfe_u32 v119, v111, 8, 16                                // 00000042BE24: D6100077 0241116F
	v_bfe_u32 v120, v111, 4, 16                                // 00000042BE2C: D6100078 0241096F
	.long 0xd72c0073                                           // 00000042BE34: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v115, vcc_lo             // 00000042BE38: 0202E6FF 83DCD12D
	v_sad_u8 v117, v117, 0, 0x6400                             // 00000042BE40: D6220075 03FD0175 00006400
	v_mov_b32_e32 v122, v29                                    // 00000042BE4C: 7EF4031D
	.long 0xd72c0077                                           // 00000042BE50: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 00000042BE54: 0202EEFF 83DCD12D
	v_sad_u8 v112, v112, 0, 0x6400                             // 00000042BE5C: D6220070 03FD0170 00006400
	v_sad_u8 v116, v116, 0, 0x6400                             // 00000042BE68: D6220074 03FD0174 00006400
	v_lshlrev_b32_e32 v117, 16, v117                           // 00000042BE74: 30EAEA90
	v_mov_b32_e32 v121, v26                                    // 00000042BE78: 7EF2031A
	v_sad_u8 v115, v115, 0, 0x6400                             // 00000042BE7C: D6220073 03FD0173 00006400
	v_mov_b32_e32 v123, v41                                    // 00000042BE88: 7EF60329
	v_mov_b32_e32 v29, v87                                     // 00000042BE8C: 7E3A0357
	v_and_or_b32 v112, 0xffff, v112, v117                      // 00000042BE90: D6570070 05D6E0FF 0000FFFF
	s_waitcnt vmcnt(6)                                         // 00000042BE9C: BF891BF7
	v_dual_mov_b32 v26, v91 :: v_dual_and_b32 v115, 0xffff, v115// 00000042BEA0: CA24015B 1A72E6FF 0000FFFF
	v_mov_b32_e32 v41, v88                                     // 00000042BEAC: 7E520358
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042BEB0: BF8700A3
	v_pk_fma_f16 v112, v112, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BEB4: CC0E0070 0BFC0D70 0000C931
	v_and_b32_e32 v113, 0xffff, v113                           // 00000042BEC0: 36E2E2FF 0000FFFF
	v_lshl_or_b32 v113, v116, 16, v113                         // 00000042BEC8: D6560071 05C52174
	v_sad_u8 v116, v119, 0, 0x6400                             // 00000042BED0: D6220074 03FD0177 00006400
	v_dual_mov_b32 v119, v28 :: v_dual_mov_b32 v28, v86        // 00000042BEDC: CA10011C 771C0156
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000042BEE4: BF870223
	v_pk_fma_f16 v113, v113, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BEE8: CC0E0071 0BFC0D71 0000C931
	v_dot2acc_f32_f16 v65, v114, v8                            // 00000042BEF4: 04821172
	v_lshl_or_b32 v115, v116, 16, v115                         // 00000042BEF8: D6560073 05CD2174
	v_dot2acc_f32_f16 v67, v114, v16                           // 00000042BF00: 04862172
	v_bfe_u32 v116, v108, 12, 16                               // 00000042BF04: D6100074 0241196C
	v_dot2acc_f32_f16 v60, v113, v5                            // 00000042BF0C: 04780B71
	v_dot2acc_f32_f16 v62, v113, v13                           // 00000042BF10: 047C1B71
	v_pk_fma_f16 v115, v115, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BF14: CC0E0073 0BFC0D73 0000C931
	v_dot2acc_f32_f16 v59, v113, v9                            // 00000042BF20: 04761371
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000042BF24: BF870244
	v_dual_dot2acc_f32_f16 v60, v112, v6 :: v_dual_and_b32 v111, 0xffff, v111// 00000042BF28: CB240D70 3C6EDEFF 0000FFFF
	v_dot2acc_f32_f16 v61, v113, v1                            // 00000042BF34: 047A0371
	v_bfe_u32 v113, v109, 8, 16                                // 00000042BF38: D6100071 0241116D
	v_dot2acc_f32_f16 v62, v112, v14                           // 00000042BF40: 047C1D70
	.long 0xd72c006f                                           // 00000042BF44: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 00000042BF48: 0202DEFF 83DCD12D
	.long 0xd72c0074                                           // 00000042BF50: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 00000042BF54: 0202E8FF 83DCD12D
	v_dot2acc_f32_f16 v60, v115, v7                            // 00000042BF5C: 04780F73
	.long 0xd72c0071                                           // 00000042BF60: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 00000042BF64: 0202E2FF 83DCD12D
	v_dot2acc_f32_f16 v62, v115, v15                           // 00000042BF6C: 047C1F73
	v_dot2acc_f32_f16 v63, v118, v11                           // 00000042BF70: 047E1776
	.long 0xd72c0076                                           // 00000042BF74: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 00000042BF78: 0202F0FF 83DCD12D
	v_dot2acc_f32_f16 v61, v112, v2                            // 00000042BF80: 047A0570
	v_sad_u8 v111, v111, 0, 0x6400                             // 00000042BF84: D622006F 03FD016F 00006400
	v_sad_u8 v116, v116, 0, 0x6400                             // 00000042BF90: D6220074 03FD0174 00006400
	v_mov_b32_e32 v120, v36                                    // 00000042BF9C: 7EF00324
	v_sad_u8 v113, v113, 0, 0x6400                             // 00000042BFA0: D6220071 03FD0171 00006400
	v_mov_b32_e32 v36, v87                                     // 00000042BFAC: 7E480357
	v_sad_u8 v117, v118, 0, 0x6400                             // 00000042BFB0: D6220075 03FD0176 00006400
	v_bfe_u32 v118, v108, 4, 16                                // 00000042BFBC: D6100076 0241096C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000042BFC4: BF870124
	v_lshl_or_b32 v110, v113, 16, v110                         // 00000042BFC8: D656006E 05B92171
	v_and_b32_e32 v116, 0xffff, v116                           // 00000042BFD0: 36E8E8FF 0000FFFF
	v_pk_fma_f16 v110, v110, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042BFD8: CC0E006E 0BFC0D6E 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042BFE4: BF870091
	v_dual_dot2acc_f32_f16 v58, v110, v13 :: v_dual_lshlrev_b32 v111, 16, v111// 00000042BFE8: CB221B6E 3A6EDE90
	v_and_or_b32 v111, 0xffff, v117, v111                      // 00000042BFF0: D657006F 05BEEAFF 0000FFFF
	v_bfe_u32 v117, v108, 8, 16                                // 00000042BFFC: D6100075 0241116C
	v_dual_dot2acc_f32_f16 v61, v115, v3 :: v_dual_and_b32 v108, 0xffff, v108// 00000042C004: CB240773 3D6CD8FF 0000FFFF
	v_dot2acc_f32_f16 v56, v110, v5                            // 00000042C010: 04700B6E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042C014: BF870214
	v_pk_fma_f16 v111, v111, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042C018: CC0E006F 0BFC0D6F 0000C931
	.long 0xd72c0075                                           // 00000042C024: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 00000042C028: 0202EAFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042C030: BF870194
	.long 0xd72c006c                                           // 00000042C034: D72C006C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v108, vcc_lo             // 00000042C038: 0202D8FF 83DCD12D
	v_dot2acc_f32_f16 v62, v111, v16                           // 00000042C040: 047C216F
	v_dual_dot2acc_f32_f16 v63, v114, v12 :: v_dual_and_b32 v114, 0xffff, v109// 00000042C044: CB241972 3F72DAFF 0000FFFF
	v_bfe_u32 v109, v109, 4, 16                                // 00000042C050: D610006D 0241096D
	v_sad_u8 v117, v117, 0, 0x6400                             // 00000042C058: D6220075 03FD0175 00006400
	v_sad_u8 v108, v108, 0, 0x6400                             // 00000042C064: D622006C 03FD016C 00006400
	v_dot2acc_f32_f16 v59, v112, v10                           // 00000042C070: 04761570
	.long 0xd72c0072                                           // 00000042C074: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 00000042C078: 0202E4FF 83DCD12D
	.long 0xd72c006d                                           // 00000042C080: D72C006D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v109, vcc_lo             // 00000042C084: 0202DAFF 83DCD12D
	v_lshl_or_b32 v112, v117, 16, v116                         // 00000042C08C: D6560070 05D12175
	v_dot2acc_f32_f16 v61, v111, v4                            // 00000042C094: 047A096F
	v_lshlrev_b32_e32 v108, 16, v108                           // 00000042C098: 30D8D890
	v_dot2acc_f32_f16 v60, v111, v8                            // 00000042C09C: 0478116F
	v_mov_b32_e32 v116, v27                                    // 00000042C0A0: 7EE8031B
	v_pk_fma_f16 v112, v112, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042C0A4: CC0E0070 0BFC0D70 0000C931
	v_sad_u8 v114, v114, 0, 0x6400                             // 00000042C0B0: D6220072 03FD0172 00006400
	v_sad_u8 v109, v109, 0, 0x6400                             // 00000042C0BC: D622006D 03FD016D 00006400
	v_mov_b32_e32 v117, v35                                    // 00000042C0C8: 7EEA0323
	v_mov_b32_e32 v27, v85                                     // 00000042C0CC: 7E360355
	v_mov_b32_e32 v35, v86                                     // 00000042C0D0: 7E460356
	v_lshlrev_b32_e32 v113, 16, v114                           // 00000042C0D4: 30E2E490
	.long 0xd72c0072                                           // 00000042C0D8: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 00000042C0DC: 0202ECFF 83DCD12D
	s_waitcnt vmcnt(5)                                         // 00000042C0E4: BF8917F7
	v_dual_mov_b32 v118, v25 :: v_dual_mov_b32 v25, v90        // 00000042C0E8: CA100119 7618015A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042C0F0: BF870193
	v_and_or_b32 v109, 0xffff, v109, v113                      // 00000042C0F4: D657006D 05C6DAFF 0000FFFF
	v_sad_u8 v113, v114, 0, 0x6400                             // 00000042C100: D6220071 03FD0172 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 00000042C10C: BF870002
	v_pk_fma_f16 v109, v109, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042C110: CC0E006D 0BFC0D6D 0000C931
	v_dot2acc_f32_f16 v57, v110, v1                            // 00000042C11C: 0472036E
	v_mov_b32_e32 v114, v34                                    // 00000042C120: 7EE40322
	v_mov_b32_e32 v34, v85                                     // 00000042C124: 7E440355
	v_and_or_b32 v108, 0xffff, v113, v108                      // 00000042C128: D657006C 05B2E2FF 0000FFFF
	v_dot2acc_f32_f16 v58, v109, v14                           // 00000042C134: 04741D6D
	v_dot2acc_f32_f16 v56, v109, v6                            // 00000042C138: 04700D6D
	v_dot2acc_f32_f16 v57, v109, v2                            // 00000042C13C: 0472056D
	v_bfe_u32 v113, v105, 4, 16                                // 00000042C140: D6100071 02410969
	v_pk_fma_f16 v108, v108, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042C148: CC0E006C 0BFC0D6C 0000C931
	v_dot2acc_f32_f16 v58, v112, v15                           // 00000042C154: 04741F70
	v_dot2acc_f32_f16 v59, v115, v11                           // 00000042C158: 04761773
	v_dual_dot2acc_f32_f16 v56, v112, v7 :: v_dual_dot2acc_f32_f16 v55, v110, v9// 00000042C15C: CB180F70 3836136E
	v_and_b32_e32 v110, 0xffff, v106                           // 00000042C164: 36DCD4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042C16C: BF870214
	v_dot2acc_f32_f16 v58, v108, v16                           // 00000042C170: 0474216C
	v_dot2acc_f32_f16 v59, v111, v12                           // 00000042C174: 0476196F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000042C178: BF870004
	v_dual_dot2acc_f32_f16 v56, v108, v8 :: v_dual_dot2acc_f32_f16 v55, v109, v10// 00000042C17C: CB18116C 3836156D
	v_bfe_u32 v109, v106, 8, 16                                // 00000042C184: D610006D 0241116A
	v_bfe_u32 v106, v106, 4, 16                                // 00000042C18C: D610006A 0241096A
	.long 0xd72c006e                                           // 00000042C194: D72C006E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v110, vcc_lo             // 00000042C198: 0202DCFF 83DCD12D
	v_bfe_u32 v111, v105, 12, 16                               // 00000042C1A0: D610006F 02411969
	v_mov_b32_e32 v115, v24                                    // 00000042C1A8: 7EE60318
	.long 0xd72c006d                                           // 00000042C1AC: D72C006D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v109, vcc_lo             // 00000042C1B0: 0202DAFF 83DCD12D
	.long 0xd72c006a                                           // 00000042C1B8: D72C006A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v106, vcc_lo             // 00000042C1BC: 0202D4FF 83DCD12D
	s_waitcnt vmcnt(4)                                         // 00000042C1C4: BF8913F7
	v_mov_b32_e32 v24, v89                                     // 00000042C1C8: 7E300359
	.long 0xd72c006f                                           // 00000042C1CC: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 00000042C1D0: 0202DEFF 83DCD12D
	v_sad_u8 v110, v110, 0, 0x6400                             // 00000042C1D8: D622006E 03FD016E 00006400
	v_dot2acc_f32_f16 v57, v112, v3                            // 00000042C1E4: 04720770
	v_sad_u8 v109, v109, 0, 0x6400                             // 00000042C1E8: D622006D 03FD016D 00006400
	v_sad_u8 v106, v106, 0, 0x6400                             // 00000042C1F4: D622006A 03FD016A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000042C200: BF870224
	v_lshlrev_b32_e32 v110, 16, v110                           // 00000042C204: 30DCDC90
	v_sad_u8 v111, v111, 0, 0x6400                             // 00000042C208: D622006F 03FD016F 00006400
	v_lshl_or_b32 v107, v109, 16, v107                         // 00000042C214: D656006B 05AD216D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042C21C: BF870113
	v_and_or_b32 v106, 0xffff, v106, v110                      // 00000042C220: D657006A 05BAD4FF 0000FFFF
	v_pk_fma_f16 v107, v107, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042C22C: CC0E006B 0BFC0D6B 0000C931
	v_dot2acc_f32_f16 v57, v108, v4                            // 00000042C238: 0472096C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042C23C: BF870193
	v_pk_fma_f16 v106, v106, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042C240: CC0E006A 0BFC0D6A 0000C931
	v_dual_dot2acc_f32_f16 v54, v107, v13 :: v_dual_dot2acc_f32_f16 v55, v112, v11// 00000042C24C: CB181B6B 36361770
	v_bfe_u32 v112, v105, 8, 16                                // 00000042C254: D6100070 02411169
	v_dot2acc_f32_f16 v50, v107, v9                            // 00000042C25C: 0464136B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042C260: BF870213
	v_dual_dot2acc_f32_f16 v54, v106, v14 :: v_dual_and_b32 v105, 0xffff, v105// 00000042C264: CB241D6A 3668D2FF 0000FFFF
	v_dot2acc_f32_f16 v55, v108, v12                           // 00000042C270: 046E196C
	.long 0xd72c006c                                           // 00000042C274: D72C006C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 00000042C278: 0202E2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042C280: BF870214
	v_dot2acc_f32_f16 v50, v106, v10                           // 00000042C284: 0464156A
	.long 0xd72c0069                                           // 00000042C288: D72C0069
	v_cndmask_b32_e32 v1, 0x83dcd12d, v105, vcc_lo             // 00000042C28C: 0202D2FF 83DCD12D
	.long 0xd72c0070                                           // 00000042C294: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 00000042C298: 0202E0FF 83DCD12D
	v_dot2acc_f32_f16 v53, v107, v1                            // 00000042C2A0: 046A036B
	v_dot2acc_f32_f16 v51, v107, v5                            // 00000042C2A4: 04660B6B
	v_and_b32_e32 v107, 0xffff, v83                            // 00000042C2A8: 36D6A6FF 0000FFFF
	v_mov_b32_e32 v113, v103                                   // 00000042C2B0: 7EE20367
	v_sad_u8 v108, v108, 0, 0x6400                             // 00000042C2B4: D622006C 03FD016C 00006400
	v_sad_u8 v105, v105, 0, 0x6400                             // 00000042C2C0: D6220069 03FD0169 00006400
	v_sad_u8 v110, v112, 0, 0x6400                             // 00000042C2CC: D622006E 03FD0170 00006400
	.long 0xd72c006b                                           // 00000042C2D8: D72C006B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v107, vcc_lo             // 00000042C2DC: 0202D6FF 83DCD12D
	v_dual_dot2acc_f32_f16 v51, v106, v6 :: v_dual_mov_b32 v112, v104// 00000042C2E4: CB100D6A 33700168
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042C2EC: BF870094
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000042C2F0: 30D2D290
	v_and_or_b32 v105, 0xffff, v108, v105                      // 00000042C2F4: D6570069 05A6D8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042C300: BF870114
	v_sad_u8 v107, v107, 0, 0x6400                             // 00000042C304: D622006B 03FD016B 00006400
	v_pk_fma_f16 v105, v105, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042C310: CC0E0069 0BFC0D69 0000C931
	v_and_b32_e32 v109, 0xffff, v111                           // 00000042C31C: 36DADEFF 0000FFFF
	v_bfe_u32 v111, v82, 4, 16                                 // 00000042C324: D610006F 02410952
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000042C32C: BF870122
	v_lshl_or_b32 v109, v110, 16, v109                         // 00000042C330: D656006D 05B5216E
	v_bfe_u32 v110, v82, 8, 16                                 // 00000042C338: D610006E 02411152
	v_pk_fma_f16 v108, v109, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042C340: CC0E006C 0BFC0D6D 0000C931
	v_bfe_u32 v109, v82, 12, 16                                // 00000042C34C: D610006D 02411952
	v_and_b32_e32 v82, 0xffff, v82                             // 00000042C354: 36A4A4FF 0000FFFF
	v_dot2acc_f32_f16 v53, v106, v2                            // 00000042C35C: 046A056A
	v_bfe_u32 v106, v83, 8, 16                                 // 00000042C360: D610006A 02411153
	v_bfe_u32 v83, v83, 4, 16                                  // 00000042C368: D6100053 02410953
	.long 0xd72c006d                                           // 00000042C370: D72C006D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v109, vcc_lo             // 00000042C374: 0202DAFF 83DCD12D
	.long 0xd72c006e                                           // 00000042C37C: D72C006E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v110, vcc_lo             // 00000042C380: 0202DCFF 83DCD12D
	.long 0xd72c0052                                           // 00000042C388: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000042C38C: 0202A4FF 83DCD12D
	.long 0xd72c006a                                           // 00000042C394: D72C006A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v106, vcc_lo             // 00000042C398: 0202D4FF 83DCD12D
	.long 0xd72c0053                                           // 00000042C3A0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 00000042C3A4: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v54, v108, v15                           // 00000042C3AC: 046C1F6C
	v_dot2acc_f32_f16 v50, v108, v11                           // 00000042C3B0: 0464176C
	v_sad_u8 v109, v109, 0, 0x6400                             // 00000042C3B4: D622006D 03FD016D 00006400
	v_sad_u8 v110, v110, 0, 0x6400                             // 00000042C3C0: D622006E 03FD016E 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000042C3CC: D6220052 03FD0152 00006400
	v_sad_u8 v106, v106, 0, 0x6400                             // 00000042C3D8: D622006A 03FD016A 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 00000042C3E4: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v54, v105, v16                           // 00000042C3F0: 046C2169
	v_dot2acc_f32_f16 v50, v105, v12                           // 00000042C3F4: 04641969
	v_lshlrev_b32_e32 v82, 16, v82                             // 00000042C3F8: 30A4A490
	v_lshl_or_b32 v84, v106, 16, v84                           // 00000042C3FC: D6560054 0551216A
	v_lshlrev_b32_e32 v106, 16, v107                           // 00000042C404: 30D4D690
	.long 0xd72c006b                                           // 00000042C408: D72C006B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 00000042C40C: 0202DEFF 83DCD12D
	v_dot2acc_f32_f16 v53, v108, v3                            // 00000042C414: 046A076C
	v_mov_b32_e32 v111, v102                                   // 00000042C418: 7EDE0366
	v_pk_fma_f16 v84, v84, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000042C41C: CC0E0054 0BFC0D54 0000C931
	v_and_or_b32 v83, 0xffff, v83, v106                        // 00000042C428: D6570053 05AAA6FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042C434: BF870112
	v_dual_dot2acc_f32_f16 v53, v105, v4 :: v_dual_dot2acc_f32_f16 v46, v84, v9// 00000042C438: CB180969 352E1354
	v_pk_fma_f16 v83, v83, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000042C440: CC0E0053 0BFC0D53 0000C931
	v_dot2acc_f32_f16 v48, v84, v1                             // 00000042C44C: 04600354
	v_dot2acc_f32_f16 v51, v108, v7                            // 00000042C450: 04660F6C
	v_sad_u8 v107, v107, 0, 0x6400                             // 00000042C454: D622006B 03FD016B 00006400
	v_mov_b32_e32 v108, v99                                    // 00000042C460: 7ED80363
	v_dot2acc_f32_f16 v46, v83, v10                            // 00000042C464: 045C1553
	v_dual_dot2acc_f32_f16 v48, v83, v2 :: v_dual_and_b32 v109, 0xffff, v109// 00000042C468: CB240553 306CDAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v51, v105, v8 :: v_dual_add_nc_u32 v2, v78, v17// 00000042C474: CB201169 3302234E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042C47C: BF8701A2
	v_lshl_or_b32 v106, v110, 16, v109                         // 00000042C480: D656006A 05B5216E
	v_mov_b32_e32 v109, v101                                   // 00000042C488: 7EDA0365
	v_cmp_eq_u32_e32 vcc_lo, 2, v2                             // 00000042C48C: 7C940482
	v_dual_mov_b32 v2, v23 :: v_dual_mov_b32 v23, v92          // 00000042C490: CA100117 0216015C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000042C498: BF870254
	v_pk_fma_f16 v105, v106, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000042C49C: CC0E0069 0BFC0D6A 0000C931
	v_dot2acc_f32_f16 v49, v84, v13                            // 00000042C4A8: 04621B54
	v_and_or_b32 v13, 0xffff, v107, v82                        // 00000042C4AC: D657000D 054AD6FF 0000FFFF
	v_mov_b32_e32 v110, v100                                   // 00000042C4B8: 7EDC0364
	v_mov_b32_e32 v106, v98                                    // 00000042C4BC: 7ED40362
	v_dual_dot2acc_f32_f16 v46, v105, v11 :: v_dual_dot2acc_f32_f16 v49, v83, v14// 00000042C4C0: CB181769 2E301D53
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000042C4C8: BF870234
	v_pk_fma_f16 v1, v13, s6, 0xc931 op_sel_hi:[1,0,0]         // 00000042C4CC: CC0E0001 0BFC0D0D 0000C931
	v_dual_dot2acc_f32_f16 v47, v84, v5 :: v_dual_dot2acc_f32_f16 v48, v105, v3// 00000042C4D8: CB180B54 2F300769
	v_mov_b32_e32 v3, v32                                      // 00000042C4E0: 7E060320
	v_dot2acc_f32_f16 v49, v105, v15                           // 00000042C4E4: 04621F69
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042C4E8: BF870213
	v_dual_dot2acc_f32_f16 v46, v1, v12 :: v_dual_dot2acc_f32_f16 v47, v83, v6// 00000042C4EC: CB181901 2E2E0D53
	v_dot2acc_f32_f16 v48, v1, v4                              // 00000042C4F4: 04600901
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000042C4F8: BF870223
	v_dual_mov_b32 v32, v88 :: v_dual_dot2acc_f32_f16 v49, v1, v16// 00000042C4FC: CA180158 20302101
	v_mov_b32_e32 v107, v97                                    // 00000042C504: 7ED60361
	v_dot2acc_f32_f16 v47, v105, v7                            // 00000042C508: 045E0F69
	v_mov_b32_e32 v105, v96                                    // 00000042C50C: 7ED20360
	v_dual_mov_b32 v83, v95 :: v_dual_mov_b32 v84, v94         // 00000042C510: CA10015F 5354015E
	v_mov_b32_e32 v82, v93                                     // 00000042C518: 7EA4035D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000042C51C: BF8704A4
	v_dot2acc_f32_f16 v47, v1, v8                              // 00000042C520: 045E1101
	s_or_b32 s5, vcc_lo, s5                                    // 00000042C524: 8C05056A
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000042C528: 917E057E
	s_cbranch_execz 80                                         // 00000042C52C: BFA50050 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1f70>
	s_waitcnt vmcnt(3)                                         // 00000042C530: BF890FF7
	v_dual_mov_b32 v104, v18 :: v_dual_mov_b32 v103, v45       // 00000042C534: CA100112 6866012D
	s_waitcnt vmcnt(2)                                         // 00000042C53C: BF890BF7
	v_dual_mov_b32 v102, v40 :: v_dual_mov_b32 v101, v30       // 00000042C540: CA100128 6664011E
	s_waitcnt vmcnt(2)                                         // 00000042C548: BF890BF7
	v_dual_mov_b32 v100, v44 :: v_dual_mov_b32 v99, v39        // 00000042C54C: CA10012C 64620127
	s_waitcnt vmcnt(0)                                         // 00000042C554: BF8903F7
	v_dual_mov_b32 v98, v31 :: v_dual_mov_b32 v95, v33         // 00000042C558: CA10011F 625E0121
	s_waitcnt vmcnt(1)                                         // 00000042C560: BF8907F7
	v_dual_mov_b32 v97, v43 :: v_dual_mov_b32 v96, v38         // 00000042C564: CA10012B 61600126
	s_waitcnt vmcnt(0)                                         // 00000042C56C: BF8903F7
	v_dual_mov_b32 v94, v42 :: v_dual_mov_b32 v93, v37         // 00000042C570: CA10012A 5E5C0125
	s_mov_b32 s7, exec_lo                                      // 00000042C578: BE87007E
	.long 0xd4c1007e                                           // 00000042C57C: D4C1007E
	v_cndmask_b32_e32 v1, v17, v22, vcc_lo                     // 00000042C580: 02022D11
	s_cbranch_execz 64532                                      // 00000042C584: BFA5FC14 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xed8>
	v_ashrrev_i32_e32 v18, 31, v17                             // 00000042C588: 3424229F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042C58C: BF870091
	.long 0xd73c0004                                           // 00000042C590: D73C0004
	v_cndmask_b32_e32 v1, 10, v17, vcc_lo                      // 00000042C594: 0202228A
	.long 0xd7006a01                                           // 00000042C598: D7006A01
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 00000042C59C: 02020803
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042C5A0: BF870111
	v_add_co_ci_u32_e64 v7, null, s4, v5, vcc_lo               // 00000042C5A4: D5207C07 01AA0A04
	.long 0xd7006a04                                           // 00000042C5AC: D7006A04
	v_cndmask_b32_e32 v1, v1, v79, vcc_lo                      // 00000042C5B0: 02029F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042C5B4: BF8700A1
	v_add_co_ci_u32_e64 v5, null, 0, v7, vcc_lo                // 00000042C5B8: D5207C05 01AA0E80
	.long 0xd7006a06                                           // 00000042C5C0: D7006A06
	v_cndmask_b32_e32 v1, v1, v81, vcc_lo                      // 00000042C5C4: 0202A301
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 00000042C5C8: D5207C07 01AA0E80
	s_clause 0xf                                               // 00000042C5D0: BF85000F
	global_load_b32 v88, v[4:5], off                           // 00000042C5D4: DC520000 587C0004
	global_load_b32 v87, v[4:5], off offset:128                // 00000042C5DC: DC520080 577C0004
	global_load_b32 v86, v[4:5], off offset:256                // 00000042C5E4: DC520100 567C0004
	global_load_b32 v85, v[4:5], off offset:384                // 00000042C5EC: DC520180 557C0004
	global_load_b32 v40, v[4:5], off offset:512                // 00000042C5F4: DC520200 287C0004
	global_load_b32 v39, v[4:5], off offset:640                // 00000042C5FC: DC520280 277C0004
	global_load_b32 v38, v[4:5], off offset:768                // 00000042C604: DC520300 267C0004
	global_load_b32 v37, v[4:5], off offset:896                // 00000042C60C: DC520380 257C0004
	global_load_b32 v92, v[6:7], off                           // 00000042C614: DC520000 5C7C0006
	global_load_b32 v91, v[6:7], off offset:128                // 00000042C61C: DC520080 5B7C0006
	global_load_b32 v90, v[6:7], off offset:256                // 00000042C624: DC520100 5A7C0006
	global_load_b32 v89, v[6:7], off offset:384                // 00000042C62C: DC520180 597C0006
	global_load_b32 v18, v[6:7], off offset:512                // 00000042C634: DC520200 127C0006
	global_load_b32 v30, v[6:7], off offset:640                // 00000042C63C: DC520280 1E7C0006
	global_load_b32 v31, v[6:7], off offset:768                // 00000042C644: DC520300 1F7C0006
	global_load_b32 v33, v[6:7], off offset:896                // 00000042C64C: DC520380 217C0006
	s_waitcnt vmcnt(10)                                        // 00000042C654: BF892BF7
	v_dual_mov_b32 v45, v40 :: v_dual_mov_b32 v44, v39         // 00000042C658: CA100128 2D2C0127
	s_waitcnt vmcnt(8)                                         // 00000042C660: BF8923F7
	v_dual_mov_b32 v43, v38 :: v_dual_mov_b32 v42, v37         // 00000042C664: CA100126 2B2A0125
	s_branch 64474                                             // 00000042C66C: BFA0FBDA <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xed8>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000042C670: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000042C674: BF870009
	s_or_b32 exec_lo, exec_lo, s2                              // 00000042C678: 8C7E027E
	s_waitcnt vmcnt(23)                                        // 00000042C67C: BF895FF7
	v_dual_mov_b32 v1, v77 :: v_dual_mov_b32 v2, v74           // 00000042C680: CA10014D 0102014A
	s_waitcnt vmcnt(15)                                        // 00000042C688: BF893FF7
	v_dual_mov_b32 v4, v73 :: v_dual_mov_b32 v3, v64           // 00000042C68C: CA100149 04020140
	v_dual_mov_b32 v5, v70 :: v_dual_mov_b32 v8, v75           // 00000042C694: CA100146 0508014B
	v_dual_mov_b32 v7, v76 :: v_dual_mov_b32 v10, v71          // 00000042C69C: CA10014C 070A0147
	v_dual_mov_b32 v9, v72 :: v_dual_mov_b32 v14, v66          // 00000042C6A4: CA100148 090E0142
	v_dual_mov_b32 v6, v52 :: v_dual_mov_b32 v11, v69          // 00000042C6AC: CA100134 060A0145
	v_dual_mov_b32 v12, v68 :: v_dual_mov_b32 v13, v67         // 00000042C6B4: CA100144 0C0C0143
	v_dual_mov_b32 v15, v65 :: v_dual_mov_b32 v16, v63         // 00000042C6BC: CA100141 0F10013F
	s_waitcnt vmcnt(3)                                         // 00000042C6C4: BF890FF7
	v_dual_mov_b32 v17, v62 :: v_dual_mov_b32 v18, v61         // 00000042C6C8: CA10013E 1112013D
	v_dual_mov_b32 v22, v60 :: v_dual_mov_b32 v23, v59         // 00000042C6D0: CA10013C 1616013B
	v_dual_mov_b32 v24, v58 :: v_dual_mov_b32 v25, v57         // 00000042C6D8: CA10013A 18180139
	v_dual_mov_b32 v26, v56 :: v_dual_mov_b32 v27, v55         // 00000042C6E0: CA100138 1A1A0137
	v_dual_mov_b32 v28, v54 :: v_dual_mov_b32 v29, v53         // 00000042C6E8: CA100136 1C1C0135
	s_waitcnt vmcnt(1)                                         // 00000042C6F0: BF8907F7
	v_dual_mov_b32 v30, v51 :: v_dual_mov_b32 v31, v50         // 00000042C6F4: CA100133 1E1E0132
	s_waitcnt vmcnt(0)                                         // 00000042C6FC: BF8903F7
	v_dual_mov_b32 v32, v49 :: v_dual_mov_b32 v33, v48         // 00000042C700: CA100131 20200130
	v_dual_mov_b32 v34, v47 :: v_dual_mov_b32 v35, v46         // 00000042C708: CA10012F 2222012E
	s_mov_b32 s2, 0x76543210                                   // 00000042C710: BE8200FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000042C718: BF870009
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 00000042C71C: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 00000042C728: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 00000042C734: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 00000042C740: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v5, v5, s2, 0xfedcba98                   // 00000042C74C: D65C0005 03FC0505 FEDCBA98
	v_permlanex16_b32 v7, v7, s2, 0xfedcba98                   // 00000042C758: D65C0007 03FC0507 FEDCBA98
	v_permlanex16_b32 v8, v8, s2, 0xfedcba98                   // 00000042C764: D65C0008 03FC0508 FEDCBA98
	v_permlanex16_b32 v9, v9, s2, 0xfedcba98                   // 00000042C770: D65C0009 03FC0509 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 00000042C77C: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 00000042C788: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v11, v11, s2, 0xfedcba98                 // 00000042C794: D65C000B 03FC050B FEDCBA98
	v_permlanex16_b32 v12, v12, s2, 0xfedcba98                 // 00000042C7A0: D65C000C 03FC050C FEDCBA98
	v_permlanex16_b32 v13, v13, s2, 0xfedcba98                 // 00000042C7AC: D65C000D 03FC050D FEDCBA98
	v_permlanex16_b32 v14, v14, s2, 0xfedcba98                 // 00000042C7B8: D65C000E 03FC050E FEDCBA98
	v_permlanex16_b32 v15, v15, s2, 0xfedcba98                 // 00000042C7C4: D65C000F 03FC050F FEDCBA98
	v_permlanex16_b32 v16, v16, s2, 0xfedcba98                 // 00000042C7D0: D65C0010 03FC0510 FEDCBA98
	v_permlanex16_b32 v17, v17, s2, 0xfedcba98                 // 00000042C7DC: D65C0011 03FC0511 FEDCBA98
	v_permlanex16_b32 v18, v18, s2, 0xfedcba98                 // 00000042C7E8: D65C0012 03FC0512 FEDCBA98
	v_permlanex16_b32 v22, v22, s2, 0xfedcba98                 // 00000042C7F4: D65C0016 03FC0516 FEDCBA98
	v_permlanex16_b32 v23, v23, s2, 0xfedcba98                 // 00000042C800: D65C0017 03FC0517 FEDCBA98
	v_permlanex16_b32 v24, v24, s2, 0xfedcba98                 // 00000042C80C: D65C0018 03FC0518 FEDCBA98
	v_permlanex16_b32 v25, v25, s2, 0xfedcba98                 // 00000042C818: D65C0019 03FC0519 FEDCBA98
	v_permlanex16_b32 v26, v26, s2, 0xfedcba98                 // 00000042C824: D65C001A 03FC051A FEDCBA98
	v_permlanex16_b32 v27, v27, s2, 0xfedcba98                 // 00000042C830: D65C001B 03FC051B FEDCBA98
	v_permlanex16_b32 v28, v28, s2, 0xfedcba98                 // 00000042C83C: D65C001C 03FC051C FEDCBA98
	v_permlanex16_b32 v29, v29, s2, 0xfedcba98                 // 00000042C848: D65C001D 03FC051D FEDCBA98
	v_permlanex16_b32 v30, v30, s2, 0xfedcba98                 // 00000042C854: D65C001E 03FC051E FEDCBA98
	v_permlanex16_b32 v31, v31, s2, 0xfedcba98                 // 00000042C860: D65C001F 03FC051F FEDCBA98
	v_permlanex16_b32 v32, v32, s2, 0xfedcba98                 // 00000042C86C: D65C0020 03FC0520 FEDCBA98
	v_permlanex16_b32 v33, v33, s2, 0xfedcba98                 // 00000042C878: D65C0021 03FC0521 FEDCBA98
	v_permlanex16_b32 v34, v34, s2, 0xfedcba98                 // 00000042C884: D65C0022 03FC0522 FEDCBA98
	v_permlanex16_b32 v35, v35, s2, 0xfedcba98                 // 00000042C890: D65C0023 03FC0523 FEDCBA98
	.long 0xd44c0002                                           // 00000042C89C: D44C0002
	v_cndmask_b32_e32 v1, 16, v20, vcc_lo                      // 00000042C8A0: 02022890
	s_barrier                                                  // 00000042C8A4: BFBD0000
	buffer_gl0_inv                                             // 00000042C8A8: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 00000042C8B0: BE832002
	s_cbranch_execz 68                                         // 00000042C8B4: BFA50044 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x22c8>
	v_lshl_or_b32 v21, v19, 11, v21                            // 00000042C8B8: D6560015 04551713
	v_dual_add_f32 v12, v68, v12 :: v_dual_add_f32 v5, v70, v5 // 00000042C8C0: C9081944 0C040B46
	v_dual_add_f32 v8, v75, v8 :: v_dual_add_f32 v1, v77, v1   // 00000042C8C8: C908114B 0800034D
	v_dual_add_f32 v10, v71, v10 :: v_dual_add_f32 v7, v76, v7 // 00000042C8D0: C9081547 0A060F4C
	v_dual_add_f32 v2, v74, v2 :: v_dual_add_f32 v3, v64, v3   // 00000042C8D8: C908054A 02020740
	v_dual_add_f32 v20, v46, v35 :: v_dual_add_f32 v33, v48, v33// 00000042C8E0: C908472E 14204330
	v_dual_add_f32 v4, v73, v4 :: v_dual_add_nc_u32 v35, 0x400, v21// 00000042C8E8: C9200949 04222AFF 00000400
	v_dual_add_f32 v14, v66, v14 :: v_dual_add_f32 v9, v72, v9 // 00000042C8F4: C9081D42 0E081348
	v_dual_add_f32 v18, v61, v18 :: v_dual_add_f32 v13, v67, v13// 00000042C8FC: C908253D 120C1B43
	v_add_f32_e32 v6, v52, v6                                  // 00000042C904: 060C0D34
	v_dual_add_f32 v34, v47, v34 :: v_dual_add_f32 v31, v50, v31// 00000042C908: C908452F 221E3F32
	v_dual_add_f32 v32, v49, v32 :: v_dual_add_f32 v27, v55, v27// 00000042C910: C9084131 201A3737
	v_dual_add_f32 v30, v51, v30 :: v_dual_add_f32 v29, v53, v29// 00000042C918: C9083D33 1E1C3B35
	v_dual_add_f32 v28, v54, v28 :: v_dual_add_f32 v25, v57, v25// 00000042C920: C9083936 1C183339
	v_dual_add_f32 v26, v56, v26 :: v_dual_add_f32 v23, v59, v23// 00000042C928: C9083538 1A162F3B
	v_dual_add_f32 v24, v58, v24 :: v_dual_add_f32 v15, v65, v15// 00000042C930: C908313A 180E1F41
	v_dual_add_f32 v22, v60, v22 :: v_dual_add_f32 v17, v62, v17// 00000042C938: C9082D3C 1610233E
	v_dual_add_f32 v16, v63, v16 :: v_dual_add_f32 v11, v69, v11// 00000042C940: C908213F 100A1745
	ds_store_2addr_b32 v21, v1, v5 offset1:16                  // 00000042C948: D8381000 00050115
	ds_store_2addr_b32 v21, v2, v7 offset0:128 offset1:144     // 00000042C950: D8389080 00070215
	ds_store_2addr_b32 v35, v4, v8 offset1:16                  // 00000042C958: D8381000 00080423
	ds_store_2addr_b32 v35, v3, v9 offset0:128 offset1:144     // 00000042C960: D8389080 00090323
	ds_store_2addr_b32 v21, v6, v13 offset0:32 offset1:48      // 00000042C968: D8383020 000D0615
	ds_store_2addr_b32 v21, v10, v14 offset0:160 offset1:176   // 00000042C970: D838B0A0 000E0A15
	ds_store_2addr_b32 v35, v11, v15 offset0:32 offset1:48     // 00000042C978: D8383020 000F0B23
	ds_store_2addr_b32 v35, v12, v16 offset0:160 offset1:176   // 00000042C980: D838B0A0 00100C23
	ds_store_2addr_b32 v21, v17, v24 offset0:64 offset1:80     // 00000042C988: D8385040 00181115
	ds_store_2addr_b32 v21, v18, v25 offset0:192 offset1:208   // 00000042C990: D838D0C0 00191215
	ds_store_2addr_b32 v35, v22, v26 offset0:64 offset1:80     // 00000042C998: D8385040 001A1623
	ds_store_2addr_b32 v35, v23, v27 offset0:192 offset1:208   // 00000042C9A0: D838D0C0 001B1723
	ds_store_2addr_b32 v21, v28, v32 offset0:96 offset1:112    // 00000042C9A8: D8387060 00201C15
	ds_store_2addr_b32 v21, v29, v33 offset0:224 offset1:240   // 00000042C9B0: D838F0E0 00211D15
	ds_store_2addr_b32 v35, v30, v34 offset0:96 offset1:112    // 00000042C9B8: D8387060 00221E23
	ds_store_2addr_b32 v35, v31, v20 offset0:224 offset1:240   // 00000042C9C0: D838F0E0 00141F23
	s_or_b32 exec_lo, exec_lo, s3                              // 00000042C9C8: 8C7E037E
	.long 0xd44c0003                                           // 00000042C9CC: D44C0003
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 00000042C9D0: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 00000042C9D8: BF89FC07
	s_barrier                                                  // 00000042C9DC: BFBD0000
	buffer_gl0_inv                                             // 00000042C9E0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 00000042C9E8: BE842003
	s_cbranch_execz 39                                         // 00000042C9EC: BFA50027 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x238c>
	v_mov_b32_e32 v1, v0                                       // 00000042C9F0: 7E020300
	s_mov_b32 s5, 0                                            // 00000042C9F4: BE850080
	s_nop 0                                                    // 00000042C9F8: BF800000
	s_nop 0                                                    // 00000042C9FC: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042CA00: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 00000042CA04: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 00000042CA08: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 00000042CA10: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 00000042CA18: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 00000042CA20: D8E02820 06000008
	s_or_b32 s5, vcc_lo, s5                                    // 00000042CA28: 8C05056A
	s_waitcnt lgkmcnt(2)                                       // 00000042CA2C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 00000042CA30: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000042CA34: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 00000042CA38: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 00000042CA3C: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 00000042CA44: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 00000042CA48: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 00000042CA4C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 00000042CA50: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042CA54: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 00000042CA58: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 00000042CA5C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 00000042CA60: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042CA64: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 00000042CA68: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 00000042CA6C: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 00000042CA74: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 00000042CA7C: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000042CA84: 917E057E
	s_cbranch_execnz 65501                                     // 00000042CA88: BFA6FFDD <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2300>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000042CA8C: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 00000042CA90: BF048215
	s_mov_b32 s4, -1                                           // 00000042CA94: BE8400C1
	s_cbranch_scc1 243                                         // 00000042CA98: BFA200F3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2768>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 00000042CA9C: F4080100 F80001A8
	s_waitcnt lgkmcnt(0)                                       // 00000042CAA4: BF89FC07
	s_barrier                                                  // 00000042CAA8: BFBD0000
	buffer_gl0_inv                                             // 00000042CAAC: E0AC0000 00000000
	s_and_saveexec_b32 s8, s3                                  // 00000042CAB4: BE882003
	s_cbranch_execz 85                                         // 00000042CAB8: BFA50055 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2510>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000042CABC: 32020087
	s_ashr_i32 s35, s34, 31                                    // 00000042CAC0: 86239F22
	s_ashr_i32 s37, s36, 31                                    // 00000042CAC4: 86259F24
	s_lshl_b64 s[0:1], s[34:35], 2                             // 00000042CAC8: 84808222
	s_lshl_b32 s10, s26, 7                                     // 00000042CACC: 840A871A
	v_or_b32_e32 v1, s0, v1                                    // 00000042CAD0: 38020200
	v_mov_b32_e32 v2, s1                                       // 00000042CAD4: 7E040201
	s_lshl_b64 s[0:1], s[36:37], 2                             // 00000042CAD8: 84808224
	s_ashr_i32 s11, s10, 31                                    // 00000042CADC: 860B9F0A
	s_lshl_b64 s[16:17], s[28:29], 2                           // 00000042CAE0: 8490821C
	.long 0xd7016a01                                           // 00000042CAE4: D7016A01
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 00000042CAE8: 02000101
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042CAEC: BF870001
	v_subrev_co_ci_u32_e64 v2, null, s1, v2, vcc_lo            // 00000042CAF0: D5227C02 01AA0401
	s_ashr_i32 s1, s20, 31                                     // 00000042CAF8: 86019F14
	s_lshl_b64 s[10:11], s[10:11], 2                           // 00000042CAFC: 848A820A
	.long 0xd72c0004                                           // 00000042CB00: D72C0004
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 00000042CB04: 02000301
	.long 0xd72c0003                                           // 00000042CB08: D72C0003
	v_cndmask_b32_e32 v0, v2, v20, vcc_lo                      // 00000042CB0C: 02002902
	v_mad_u64_u32 v[1:2], null, v1, s20, 0                     // 00000042CB10: D6FE7C01 02002901
	s_add_u32 s9, s10, s16                                     // 00000042CB18: 8009100A
	s_addc_u32 s10, s11, s17                                   // 00000042CB1C: 820A110B
	s_mov_b32 s0, s20                                          // 00000042CB20: BE800014
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000042CB24: BF870139
	s_lshl_b64 s[0:1], s[0:1], 3                               // 00000042CB28: 84808300
	v_add3_u32 v2, v2, v4, v3                                  // 00000042CB2C: D6550002 040E0902
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000042CB34: 360600FF 0000007F
	.long 0xd73c0001                                           // 00000042CB3C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000042CB40: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042CB44: BF8701A2
	v_lshlrev_b32_e32 v4, 2, v3                                // 00000042CB48: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000042CB4C: 30060082
	.long 0xd7006a01                                           // 00000042CB50: D7006A01
	v_cndmask_b32_e32 v1, s9, v1, vcc_lo                       // 00000042CB54: 02020209
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000042CB58: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s10, v2, vcc_lo              // 00000042CB5C: D5207C02 01AA040A
	s_mov_b32 s9, 0                                            // 00000042CB64: BE890080
	.long 0xd7006a01                                           // 00000042CB68: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000042CB6C: 02020901
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000042CB70: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 00000042CB78: 380800FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042CB80: BF870093
	.long 0xd7006a01                                           // 00000042CB84: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000042CB88: 02020204
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000042CB8C: D5207C02 01AA0405
	s_nop 0                                                    // 00000042CB94: BF800000
	s_nop 0                                                    // 00000042CB98: BF800000
	s_nop 0                                                    // 00000042CB9C: BF800000
	s_nop 0                                                    // 00000042CBA0: BF800000
	s_nop 0                                                    // 00000042CBA4: BF800000
	s_nop 0                                                    // 00000042CBA8: BF800000
	s_nop 0                                                    // 00000042CBAC: BF800000
	s_nop 0                                                    // 00000042CBB0: BF800000
	s_nop 0                                                    // 00000042CBB4: BF800000
	s_nop 0                                                    // 00000042CBB8: BF800000
	s_nop 0                                                    // 00000042CBBC: BF800000
	ds_load_b32 v5, v3 offset:16384                            // 00000042CBC0: D8D84000 05000003
	.long 0xd7000a04                                           // 00000042CBC8: D7000A04
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 00000042CBCC: 020208FF 00000100
	s_xor_b32 s10, s10, -1                                     // 00000042CBD4: 8D0AC10A
	v_add_nc_u32_e32 v3, 0x400, v3                             // 00000042CBD8: 4A0606FF 00000400
	s_and_b32 s10, exec_lo, s10                                // 00000042CBE0: 8B0A0A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000042CBE4: BF8700C9
	s_or_b32 s9, s10, s9                                       // 00000042CBE8: 8C09090A
	s_waitcnt lgkmcnt(0)                                       // 00000042CBEC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 00000042CBF0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 00000042CBF8: D7006A01
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 00000042CBFC: 02000101
	v_add_co_ci_u32_e64 v2, null, s1, v2, vcc_lo               // 00000042CC00: D5207C02 01AA0401
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 00000042CC08: 917E097E
	s_cbranch_execnz 65516                                     // 00000042CC0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x24c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000042CC10: 8C7E087E
	s_ashr_i32 s31, s30, 31                                    // 00000042CC14: 861F9F1E
	.long 0xd44a0000                                           // 00000042CC18: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000042CC1C: 02020080
	s_lshl_b64 s[8:9], s[30:31], 2                             // 00000042CC20: 8488821E
	s_waitcnt_vscnt null, 0x0                                  // 00000042CC24: BC7C0000
	buffer_gl1_inv                                             // 00000042CC28: E0B00000 00000000
	buffer_gl0_inv                                             // 00000042CC30: E0AC0000 00000000
	s_add_u32 s8, s6, s8                                       // 00000042CC38: 80080806
	s_addc_u32 s9, s7, s9                                      // 00000042CC3C: 82090907
	s_barrier                                                  // 00000042CC40: BFBD0000
	buffer_gl0_inv                                             // 00000042CC44: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000042CC4C: BE812000
	s_cbranch_execz 29                                         // 00000042CC50: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x25c8>
	s_mov_b32 s7, exec_lo                                      // 00000042CC54: BE87007E
	s_mov_b32 s6, exec_lo                                      // 00000042CC58: BE86007E
	.long 0xd71f0001                                           // 00000042CC5C: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 00000042CC60: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042CC64: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000042CC68: 7D940280
	s_cbranch_execz 9                                          // 00000042CC6C: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2594>
	s_lshl_b64 s[10:11], s[26:27], 2                           // 00000042CC70: 848A821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000042CC74: BF8704B9
	s_add_u32 s10, s8, s10                                     // 00000042CC78: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000042CC7C: 820B0B09
	s_bcnt1_i32_b32 s7, s7                                     // 00000042CC80: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 00000042CC84: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[10:11] glc             // 00000042CC8C: DCD64000 020A0302
	s_or_b32 exec_lo, exec_lo, s6                              // 00000042CC94: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 00000042CC98: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 00000042CC9C: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042CCA0: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 00000042CCA4: CA200080 02000206
	s_add_i32 s6, s21, -1                                      // 00000042CCAC: 8106C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000042CCB0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 00000042CCB4: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000042CCB8: D5010001 01A90280
	ds_store_b32 v2, v1 offset:20480                           // 00000042CCC0: D8345000 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000042CCC8: 8C7E017E
	v_mov_b32_e32 v1, 0                                        // 00000042CCCC: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 00000042CCD0: BF89FC07
	s_barrier                                                  // 00000042CCD4: BFBD0000
	buffer_gl0_inv                                             // 00000042CCD8: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:20480                            // 00000042CCE0: D8D85000 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000042CCE8: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000042CCEC: 7C940280
	s_cbranch_vccnz 928                                        // 00000042CCF0: BFA403A0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3474>
	buffer_gl1_inv                                             // 00000042CCF4: E0B00000 00000000
	buffer_gl0_inv                                             // 00000042CCFC: E0AC0000 00000000
	s_and_saveexec_b32 s10, s3                                 // 00000042CD04: BE8A2003
	s_cbranch_execz 76                                         // 00000042CD08: BFA5004C <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x273c>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000042CD0C: 32020087
	s_lshl_b32 s16, s26, 7                                     // 00000042CD10: 8410871A
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000042CD14: 360600FF 0000007F
	s_ashr_i32 s17, s16, 31                                    // 00000042CD1C: 86119F10
	s_lshl_b64 s[22:23], s[28:29], 2                           // 00000042CD20: 8496821C
	v_mad_i64_i32 v[1:2], null, v1, s20, 0                     // 00000042CD24: D6FF7C01 02002901
	s_lshl_b64 s[16:17], s[16:17], 2                           // 00000042CD2C: 84908210
	s_ashr_i32 s7, s20, 31                                     // 00000042CD30: 86079F14
	s_add_u32 s1, s16, s22                                     // 00000042CD34: 80011610
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000042CD38: 30060682
	s_addc_u32 s3, s17, s23                                    // 00000042CD3C: 82031711
	v_mov_b32_e32 v5, v0                                       // 00000042CD40: 7E0A0300
	s_mov_b32 s6, s20                                          // 00000042CD44: BE860014
	.long 0xd73c0001                                           // 00000042CD48: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000042CD4C: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042CD50: BF870091
	.long 0xd7006a01                                           // 00000042CD54: D7006A01
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 00000042CD58: 02020201
	v_add_co_ci_u32_e64 v2, null, s3, v2, vcc_lo               // 00000042CD5C: D5207C02 01AA0403
	s_mov_b32 s3, 0                                            // 00000042CD64: BE830080
	.long 0xd7006a01                                           // 00000042CD68: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000042CD6C: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042CD70: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000042CD74: D5207C02 01AA0480
	.long 0xd7006a01                                           // 00000042CD7C: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000042CD80: 02020204
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042CD84: BF870001
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000042CD88: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[6:7], 3                               // 00000042CD90: 84848306
	s_lshl_b64 s[6:7], s[6:7], 4                               // 00000042CD94: 84868406
	s_nop 0                                                    // 00000042CD98: BF800000
	s_nop 0                                                    // 00000042CD9C: BF800000
	s_nop 0                                                    // 00000042CDA0: BF800000
	s_nop 0                                                    // 00000042CDA4: BF800000
	s_nop 0                                                    // 00000042CDA8: BF800000
	s_nop 0                                                    // 00000042CDAC: BF800000
	s_nop 0                                                    // 00000042CDB0: BF800000
	s_nop 0                                                    // 00000042CDB4: BF800000
	s_nop 0                                                    // 00000042CDB8: BF800000
	s_nop 0                                                    // 00000042CDBC: BF800000
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 00000042CDC0: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 00000042CDC8: 7E0C0280
	s_mov_b32 s1, s21                                          // 00000042CDCC: BE810015
	global_load_b32 v7, v[3:4], off glc                        // 00000042CDD0: DC524000 077C0003
	.long 0xd7006a03                                           // 00000042CDD8: D7006A03
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 00000042CDDC: 02000D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000042CDE0: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s7, v4, vcc_lo               // 00000042CDE4: D5207C04 01AA0807
	s_add_i32 s1, s1, -1                                       // 00000042CDEC: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 00000042CDF0: BF068001
	s_waitcnt vmcnt(0)                                         // 00000042CDF4: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 00000042CDF8: 060C0F06
	s_cbranch_scc0 65524                                       // 00000042CDFC: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x26d0>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 00000042CE00: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 00000042CE08: 7C920AFF 000000FF
	.long 0xd7000101                                           // 00000042CE10: D7000101
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000042CE14: 02000901
	v_lshlrev_b32_e32 v3, 2, v5                                // 00000042CE18: 30060A82
	v_add_co_ci_u32_e64 v2, null, s5, v2, s1                   // 00000042CE1C: D5207C02 00060405
	v_mov_b32_e32 v5, v4                                       // 00000042CE24: 7E0A0304
	s_or_b32 s3, vcc_lo, s3                                    // 00000042CE28: 8C03036A
	ds_store_b32 v3, v6 offset:16384                           // 00000042CE2C: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000042CE34: 917E037E
	s_cbranch_execnz 65505                                     // 00000042CE38: BFA6FFE1 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x26c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000042CE3C: 8C7E0A7E
	s_and_saveexec_b32 s1, s0                                  // 00000042CE40: BE812000
	s_cbranch_execz 6                                          // 00000042CE44: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2760>
	s_lshl_b64 s[4:5], s[26:27], 2                             // 00000042CE48: 8484821A
	v_mov_b32_e32 v1, 0                                        // 00000042CE4C: 7E020280
	s_add_u32 s4, s8, s4                                       // 00000042CE50: 80040408
	s_addc_u32 s5, s9, s5                                      // 00000042CE54: 82050509
	global_store_b32 v1, v1, s[4:5]                            // 00000042CE58: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000042CE60: 8C7E017E
	s_mov_b32 s4, -1                                           // 00000042CE64: BE8400C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000042CE68: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000042CE6C: 8B6A047E
	s_cbranch_vccz 63262                                       // 00000042CE70: BFA3F71E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_gt_i32_e32 vcc_lo, s18, v19                          // 00000042CE74: 7C882612
	.long 0xd44c0000                                           // 00000042CE78: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000042CE7C: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 00000042CE84: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000042CE88: BC7C0000
	s_barrier                                                  // 00000042CE8C: BFBD0000
	buffer_gl0_inv                                             // 00000042CE90: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 00000042CE98: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000042CE9C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000042CEA0: BE812000
	s_cbranch_execz 63249                                      // 00000042CEA4: BFA5F711 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 00000042CEA8: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042CEAC: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000042CEB0: 30040282
	v_lshl_or_b32 v2, v19, 9, v2                               // 00000042CEB4: D6560002 04091313
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042CEBC: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 00000042CEC0: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000042CEC8: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000042CED0: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000042CED8: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000042CEE0: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000042CEE8: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000042CEEC: 36160082
	s_waitcnt lgkmcnt(3)                                       // 00000042CEF0: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 00000042CEF4: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 00000042CEFC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000042CF00: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000042CF08: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000042CF0C: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000042CF14: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000042CF18: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 00000042CF20: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 00000042CF28: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000042CF2C: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 00000042CF30: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 00000042CF38: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000042CF40: 7C941480
	.long 0xd44a0000                                           // 00000042CF44: D44A0000
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 00000042CF48: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 00000042CF4C: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 00000042CF54: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 00000042CF58: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 00000042CF5C: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 00000042CF60: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 00000042CF64: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000042CF6C: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000042CF70: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 00000042CF74: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042CF78: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000042CF80: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042CF88: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000042CF90: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042CF98: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000042CFA0: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042CFA8: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000042CFB0: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042CFB8: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000042CFC0: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042CFC8: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000042CFD0: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042CFD8: 7E2402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000042CFE0: D5010003 21AA0703
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000042CFE8: 7E2802FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000042CFF0: D5010002 21AA0502
	v_dual_add_f32 v6, v7, v6 :: v_dual_add_f32 v5, v5, v15    // 00000042CFF8: C9080D07 06041F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 00000042D000: 7C941680
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v16   // 00000042D004: C9081509 07082108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000042D00C: BF870233
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042D010: 7E1402FA FF016206
	v_add_f32_e32 v4, v4, v17                                  // 00000042D018: 06082304
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000042D01C: D5010006 21AA0D06
	v_mov_b32_dpp v11, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042D024: 7E1602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000042D02C: D5010007 21AA0F07
	v_add_f32_e32 v2, v2, v20                                  // 00000042D034: 06042902
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D038: BF870092
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 00000042D03C: C9081506 06061707
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042D044: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 00000042D04C: D5010006 20020D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000042D054: BF8700D3
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042D058: 7E1602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 00000042D060: D5010007 20020F07
	v_add_f32_e32 v9, v13, v14                                 // 00000042D068: 06121D0D
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042D06C: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000042D074: D5010005 21AA0B05
	v_dual_add_f32 v15, v5, v14 :: v_dual_add_f32 v14, v7, v11 // 00000042D07C: C9081D05 0F0E1707
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042D084: BF8701A4
	v_mov_b32_dpp v13, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042D088: 7E1A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000042D090: D5010009 21AA1309
	v_mov_b32_dpp v7, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042D098: 7E0E02FA FF01640F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042D0A0: BF870194
	v_mov_b32_dpp v24, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042D0A4: 7E3002FA FF01680E
	v_add_f32_e32 v9, v9, v13                                  // 00000042D0AC: 06121B09
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042D0B0: 7E1A02FA FF016208
	s_delay_alu instid0(VALU_DEP_2)                            // 00000042D0B8: BF870002
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042D0BC: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 00000042D0C4: D5010009 20021309
	v_add_f32_e32 v5, v6, v10                                  // 00000042D0CC: 060A1506
	v_cndmask_b32_e64 v6, -v8, v8, vcc_lo                      // 00000042D0D0: D5010006 21AA1108
	v_add_f32_e32 v3, v3, v18                                  // 00000042D0D8: 06062503
	v_mov_b32_dpp v10, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042D0DC: 7E1402FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000042D0E4: D5010004 21AA0904
	v_add_f32_e32 v22, v9, v12                                 // 00000042D0EC: 062C1909
	v_add_f32_e32 v6, v6, v13                                  // 00000042D0F0: 060C1B06
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042D0F4: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000042D0FC: D5010003 21AA0703
	v_mov_b32_dpp v12, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042D104: 7E1802FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000042D10C: D5010002 21AA0502
	v_add_f32_e32 v4, v4, v10                                  // 00000042D114: 06081504
	v_cndmask_b32_e64 v9, -v15, v15, s0                        // 00000042D118: D5010009 20021F0F
	v_add_f32_e32 v3, v3, v11                                  // 00000042D120: 06061703
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042D124: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 00000042D12C: D5010006 20020D06
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042D134: 7E1602FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000042D13C: D5010004 20020904
	v_add_f32_e32 v2, v2, v12                                  // 00000042D144: 06041902
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042D148: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000042D150: D5010003 20020703
	v_dual_add_f32 v20, v9, v7 :: v_dual_add_f32 v17, v6, v10  // 00000042D158: C9080F09 14101506
	v_add_f32_e32 v15, v4, v11                                 // 00000042D160: 061E1704
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000042D164: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 00000042D16C: D5010002 20020502
	v_add_f32_e32 v12, v3, v12                                 // 00000042D174: 06181903
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042D178: 7E1002FA FF016805
	v_mov_b32_dpp v23, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042D180: 7E2E02FA FF016816
	v_mov_b32_dpp v21, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042D188: 7E2A02FA FF016814
	v_add_f32_e32 v9, v2, v13                                  // 00000042D190: 06121B02
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042D194: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042D19C: 7E2002FA FF01680F
	v_mov_b32_dpp v13, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042D1A4: 7E1A02FA FF01680C
	s_delay_alu instid0(VALU_DEP_4)                            // 00000042D1AC: BF870004
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000042D1B0: 7E1402FA FF016809
	s_and_b32 exec_lo, exec_lo, s2                             // 00000042D1B8: 8B7E027E
	s_cbranch_execz 63051                                      // 00000042D1BC: BFA5F64B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 00000042D1C0: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 00000042D1C8: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 00000042D1CC: BF118018
	s_cselect_b32 s1, -1, 0                                    // 00000042D1D0: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042D1D4: BF870112
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000042D1D8: 3408069F
	.long 0xd44a0000                                           // 00000042D1DC: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000042D1E0: 02020080
	s_lshr_b32 s2, s20, 31                                     // 00000042D1E4: 85029F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000042D1E8: BF870009
	s_add_i32 s2, s20, s2                                      // 00000042D1EC: 81020214
	.long 0xd73c0001                                           // 00000042D1F0: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000042D1F4: 02020681
	v_cndmask_b32_e64 v0, -v5, v5, s0                          // 00000042D1F8: D5010000 20020B05
	v_mad_i64_i32 v[4:5], null, s20, v19, 0                    // 00000042D200: D6FF7C04 02022614
	s_ashr_i32 s2, s2, 1                                       // 00000042D208: 86028102
	s_cmp_eq_u64 s[24:25], 0                                   // 00000042D20C: BF108018
	v_mad_i64_i32 v[25:26], null, s2, v19, 0                   // 00000042D210: D6FF7C19 02022602
	.long 0xd7006a06                                           // 00000042D218: D7006A06
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 00000042D21C: 0202020C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D220: BF870001
	v_add_co_ci_u32_e64 v7, null, s13, v2, vcc_lo              // 00000042D224: D5207C07 01AA040D
	v_add_f32_e32 v0, v0, v8                                   // 00000042D22C: 06001100
	.long 0xd73c0004                                           // 00000042D230: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000042D234: 02020881
	global_load_d16_b16 v11, v[6:7], off                       // 00000042D238: DC820000 0B7C0006
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 00000042D240: 100000FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042D248: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042D24C: BF8700A1
	v_fma_mix_f32 v27, v11, v0, neg(0) op_sel_hi:[1,0,0]       // 00000042D250: CC20001B 8A02010B
	.long 0xd7006a00                                           // 00000042D258: D7006A00
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 00000042D25C: 0202080E
	v_add_co_ci_u32_e64 v8, null, s15, v5, vcc_lo              // 00000042D260: D5207C08 01AA0A0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000042D268: BF8701B3
	v_bfe_u32 v19, v27, 16, 1                                  // 00000042D26C: D6100013 0205211B
	.long 0xd73c0004                                           // 00000042D274: D73C0004
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 00000042D278: 02023281
	v_ashrrev_i32_e32 v11, 31, v3                              // 00000042D27C: 3416069F
	v_add3_u32 v19, v27, v19, 0x7fff                           // 00000042D280: D6550013 03FE271B 00007FFF
	s_cbranch_scc1 570                                         // 00000042D28C: BFA2023A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3478>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000042D290: BF870122
	v_lshrrev_b32_e32 v25, 23, v11                             // 00000042D294: 32321697
	v_mov_b32_e32 v29, s14                                     // 00000042D298: 7E3A020E
	v_add_nc_u32_e32 v25, v3, v25                              // 00000042D29C: 4A323303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D2A0: BF870091
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 00000042D2A4: 363432FF FFFFFE00
	v_sub_nc_u32_e32 v27, v3, v26                              // 00000042D2AC: 4C363503
	v_mov_b32_e32 v26, s15                                     // 00000042D2B0: 7E34020F
	v_ashrrev_i32_e32 v25, 9, v25                              // 00000042D2B4: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042D2B8: BF8701A3
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v27                        // 00000042D2BC: 7C8836FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v27                      // 00000042D2C4: 4A3836FF FFFFFF00
	v_dual_cndmask_b32 v30, s25, v26 :: v_dual_lshlrev_b32 v25, 8, v25// 00000042D2CC: CA623419 1E183288
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042D2D4: BF870112
	v_cndmask_b32_e32 v27, v28, v27, vcc_lo                    // 00000042D2D8: 0236371C
	v_ashrrev_i32_e32 v26, 31, v25                             // 00000042D2DC: 3434329F
	v_cndmask_b32_e32 v29, s24, v29, vcc_lo                    // 00000042D2E0: 023A3A18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042D2E4: BF870193
	v_ashrrev_i32_e32 v28, 31, v27                             // 00000042D2E8: 3438369F
	.long 0xd73c0019                                           // 00000042D2EC: D73C0019
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 00000042D2F0: 02023281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D2F4: BF870093
	.long 0xd7006a1d                                           // 00000042D2F8: D7006A1D
	v_cndmask_b32_e32 v1, v29, v4, vcc_lo                      // 00000042D2FC: 0202091D
	v_add_co_ci_u32_e64 v30, null, v30, v5, vcc_lo             // 00000042D300: D5207C1E 01AA0B1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042D308: BF870194
	.long 0xd73c001b                                           // 00000042D30C: D73C001B
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 00000042D310: 02023681
	.long 0xd7006a19                                           // 00000042D314: D7006A19
	v_cndmask_b32_e32 v1, v29, v25, vcc_lo                     // 00000042D318: 0202331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042D31C: BF870111
	v_add_co_ci_u32_e64 v26, null, v30, v26, vcc_lo            // 00000042D320: D5207C1A 01AA351E
	.long 0xd7006a19                                           // 00000042D328: D7006A19
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 00000042D32C: 02023719
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D330: BF870001
	v_add_co_ci_u32_e64 v26, null, v26, v28, vcc_lo            // 00000042D334: D5207C1A 01AA391A
	global_store_d16_hi_b16 v[25:26], v19, off                 // 00000042D33C: DC960000 007C1319
	s_cbranch_execnz 7                                         // 00000042D344: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2c64>
	.long 0xd7006a19                                           // 00000042D348: D7006A19
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042D34C: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D350: BF870001
	v_add_co_ci_u32_e64 v26, null, v8, v2, vcc_lo              // 00000042D354: D5207C1A 01AA0508
	global_store_d16_hi_b16 v[25:26], v19, off                 // 00000042D35C: DC960000 007C1319
	global_load_d16_b16 v19, v[6:7], off offset:32             // 00000042D364: DC820020 137C0006
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 00000042D36C: D501000E 20021D0E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000042D374: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D378: BF870091
	v_add_f32_e32 v14, v14, v24                                // 00000042D37C: 061C310E
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 00000042D380: 101C1CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042D388: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000042D38C: BF870121
	v_fma_mix_f32 v19, v19, v14, neg(0) op_sel_hi:[1,0,0]      // 00000042D390: CC200013 8A021D13
	v_cndmask_b32_e64 v14, 0, 1, s1                            // 00000042D398: D501000E 00050280
	v_bfe_u32 v24, v19, 16, 1                                  // 00000042D3A0: D6100018 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D3A8: BF870001
	v_add3_u32 v19, v19, v24, 0x7fff                           // 00000042D3AC: D6550013 03FE3113 00007FFF
	s_cbranch_vccnz 496                                        // 00000042D3B8: BFA401F0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x347c>
	v_or_b32_e32 v24, 16, v3                                   // 00000042D3BC: 38300690
	v_lshrrev_b32_e32 v25, 23, v11                             // 00000042D3C0: 32321697
	v_mov_b32_e32 v27, s15                                     // 00000042D3C4: 7E36020F
	v_mov_b32_e32 v29, s14                                     // 00000042D3C8: 7E3A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D3CC: BF870093
	v_add_nc_u32_e32 v25, v24, v25                             // 00000042D3D0: 4A323318
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 00000042D3D4: 363432FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D3DC: BF870091
	v_sub_nc_u32_e32 v26, v24, v26                             // 00000042D3E0: 4C343518
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v26                        // 00000042D3E4: 7C8834FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v26                      // 00000042D3EC: 4A3834FF FFFFFF00
	v_cndmask_b32_e32 v30, s25, v27, vcc_lo                    // 00000042D3F4: 023C3619
	v_ashrrev_i32_e32 v25, 9, v25                              // 00000042D3F8: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042D3FC: BF8701A3
	v_cndmask_b32_e32 v26, v28, v26, vcc_lo                    // 00000042D400: 0234351C
	v_cndmask_b32_e32 v28, s24, v29, vcc_lo                    // 00000042D404: 02383A18
	v_lshlrev_b32_e32 v24, 8, v25                              // 00000042D408: 30303288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042D40C: BF870193
	v_ashrrev_i32_e32 v27, 31, v26                             // 00000042D410: 3436349F
	.long 0xd7006a1c                                           // 00000042D414: D7006A1C
	v_cndmask_b32_e32 v1, v28, v4, vcc_lo                      // 00000042D418: 0202091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042D41C: BF870211
	v_add_co_ci_u32_e64 v29, null, v30, v5, vcc_lo             // 00000042D420: D5207C1D 01AA0B1E
	v_ashrrev_i32_e32 v25, 31, v24                             // 00000042D428: 3432309F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042D42C: BF870114
	.long 0xd73c001a                                           // 00000042D430: D73C001A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000042D434: 02023481
	.long 0xd73c0018                                           // 00000042D438: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 00000042D43C: 02023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D440: BF870091
	.long 0xd7006a18                                           // 00000042D444: D7006A18
	v_cndmask_b32_e32 v1, v28, v24, vcc_lo                     // 00000042D448: 0202311C
	v_add_co_ci_u32_e64 v25, null, v29, v25, vcc_lo            // 00000042D44C: D5207C19 01AA331D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D454: BF870092
	.long 0xd7006a18                                           // 00000042D458: D7006A18
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 00000042D45C: 02023518
	v_add_co_ci_u32_e64 v25, null, v25, v27, vcc_lo            // 00000042D460: D5207C19 01AA3719
	global_store_d16_hi_b16 v[24:25], v19, off                 // 00000042D468: DC960000 007C1318
	s_cbranch_execnz 7                                         // 00000042D470: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2d90>
	.long 0xd7006a18                                           // 00000042D474: D7006A18
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042D478: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D47C: BF870001
	v_add_co_ci_u32_e64 v25, null, v8, v2, vcc_lo              // 00000042D480: D5207C19 01AA0508
	global_store_d16_hi_b16 v[24:25], v19, off offset:32       // 00000042D488: DC960020 007C1318
	global_load_d16_b16 v19, v[6:7], off offset:64             // 00000042D490: DC820040 137C0006
	v_cndmask_b32_e64 v22, -v22, v22, s0                       // 00000042D498: D5010016 20022D16
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 00000042D4A0: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042D4A4: BF8700A2
	v_add_f32_e32 v22, v22, v23                                // 00000042D4A8: 062C2F16
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000042D4AC: 8B6A6A7E
	v_mul_f32_e32 v22, 0x3db504f3, v22                         // 00000042D4B0: 102C2CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042D4B8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D4BC: BF870091
	v_fma_mix_f32 v19, v19, v22, neg(0) op_sel_hi:[1,0,0]      // 00000042D4C0: CC200013 8A022D13
	v_bfe_u32 v22, v19, 16, 1                                  // 00000042D4C8: D6100016 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D4D0: BF870001
	v_add3_u32 v19, v19, v22, 0x7fff                           // 00000042D4D4: D6550013 03FE2D13 00007FFF
	s_cbranch_vccnz 423                                        // 00000042D4E0: BFA401A7 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3480>
	v_or_b32_e32 v22, 32, v3                                   // 00000042D4E4: 382C06A0
	v_lshrrev_b32_e32 v23, 23, v11                             // 00000042D4E8: 322E1697
	v_mov_b32_e32 v25, s15                                     // 00000042D4EC: 7E32020F
	v_mov_b32_e32 v27, s14                                     // 00000042D4F0: 7E36020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D4F4: BF870093
	v_add_nc_u32_e32 v23, v22, v23                             // 00000042D4F8: 4A2E2F16
	v_and_b32_e32 v24, 0xfffffe00, v23                         // 00000042D4FC: 36302EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D504: BF870091
	v_sub_nc_u32_e32 v24, v22, v24                             // 00000042D508: 4C303116
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v24                        // 00000042D50C: 7C8830FF 00000100
	v_add_nc_u32_e32 v26, 0xffffff00, v24                      // 00000042D514: 4A3430FF FFFFFF00
	v_cndmask_b32_e32 v28, s25, v25, vcc_lo                    // 00000042D51C: 02383219
	v_ashrrev_i32_e32 v23, 9, v23                              // 00000042D520: 342E2E89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042D524: BF8701A3
	v_cndmask_b32_e32 v24, v26, v24, vcc_lo                    // 00000042D528: 0230311A
	v_cndmask_b32_e32 v26, s24, v27, vcc_lo                    // 00000042D52C: 02343618
	v_lshlrev_b32_e32 v22, 8, v23                              // 00000042D530: 302C2E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042D534: BF870193
	v_ashrrev_i32_e32 v25, 31, v24                             // 00000042D538: 3432309F
	.long 0xd7006a1a                                           // 00000042D53C: D7006A1A
	v_cndmask_b32_e32 v1, v26, v4, vcc_lo                      // 00000042D540: 0202091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042D544: BF870211
	v_add_co_ci_u32_e64 v27, null, v28, v5, vcc_lo             // 00000042D548: D5207C1B 01AA0B1C
	v_ashrrev_i32_e32 v23, 31, v22                             // 00000042D550: 342E2C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042D554: BF870114
	.long 0xd73c0018                                           // 00000042D558: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 00000042D55C: 02023081
	.long 0xd73c0016                                           // 00000042D560: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 00000042D564: 02022C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D568: BF870091
	.long 0xd7006a16                                           // 00000042D56C: D7006A16
	v_cndmask_b32_e32 v1, v26, v22, vcc_lo                     // 00000042D570: 02022D1A
	v_add_co_ci_u32_e64 v23, null, v27, v23, vcc_lo            // 00000042D574: D5207C17 01AA2F1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D57C: BF870092
	.long 0xd7006a16                                           // 00000042D580: D7006A16
	v_cndmask_b32_e32 v1, v22, v24, vcc_lo                     // 00000042D584: 02023116
	v_add_co_ci_u32_e64 v23, null, v23, v25, vcc_lo            // 00000042D588: D5207C17 01AA3317
	global_store_d16_hi_b16 v[22:23], v19, off                 // 00000042D590: DC960000 007C1316
	s_cbranch_execnz 7                                         // 00000042D598: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2eb8>
	.long 0xd7006a16                                           // 00000042D59C: D7006A16
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042D5A0: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D5A4: BF870001
	v_add_co_ci_u32_e64 v23, null, v8, v2, vcc_lo              // 00000042D5A8: D5207C17 01AA0508
	global_store_d16_hi_b16 v[22:23], v19, off offset:64       // 00000042D5B0: DC960040 007C1316
	global_load_d16_b16 v19, v[6:7], off offset:96             // 00000042D5B8: DC820060 137C0006
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 00000042D5C0: D5010014 20022914
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 00000042D5C8: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042D5CC: BF8700A2
	v_add_f32_e32 v20, v20, v21                                // 00000042D5D0: 06282B14
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000042D5D4: 8B6A6A7E
	v_mul_f32_e32 v20, 0x3db504f3, v20                         // 00000042D5D8: 102828FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042D5E0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D5E4: BF870091
	v_fma_mix_f32 v19, v19, v20, neg(0) op_sel_hi:[1,0,0]      // 00000042D5E8: CC200013 8A022913
	v_bfe_u32 v20, v19, 16, 1                                  // 00000042D5F0: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D5F8: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000042D5FC: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 350                                        // 00000042D608: BFA4015E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3484>
	v_or_b32_e32 v20, 48, v3                                   // 00000042D60C: 382806B0
	v_lshrrev_b32_e32 v21, 23, v11                             // 00000042D610: 322A1697
	v_mov_b32_e32 v23, s15                                     // 00000042D614: 7E2E020F
	v_mov_b32_e32 v25, s14                                     // 00000042D618: 7E32020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D61C: BF870093
	v_add_nc_u32_e32 v21, v20, v21                             // 00000042D620: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 00000042D624: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D62C: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 00000042D630: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 00000042D634: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 00000042D63C: 4A302CFF FFFFFF00
	v_cndmask_b32_e32 v26, s25, v23, vcc_lo                    // 00000042D644: 02342E19
	v_ashrrev_i32_e32 v21, 9, v21                              // 00000042D648: 342A2A89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042D64C: BF8701A3
	v_cndmask_b32_e32 v22, v24, v22, vcc_lo                    // 00000042D650: 022C2D18
	v_cndmask_b32_e32 v24, s24, v25, vcc_lo                    // 00000042D654: 02303218
	v_lshlrev_b32_e32 v20, 8, v21                              // 00000042D658: 30282A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042D65C: BF870193
	v_ashrrev_i32_e32 v23, 31, v22                             // 00000042D660: 342E2C9F
	.long 0xd7006a18                                           // 00000042D664: D7006A18
	v_cndmask_b32_e32 v1, v24, v4, vcc_lo                      // 00000042D668: 02020918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042D66C: BF870211
	v_add_co_ci_u32_e64 v25, null, v26, v5, vcc_lo             // 00000042D670: D5207C19 01AA0B1A
	v_ashrrev_i32_e32 v21, 31, v20                             // 00000042D678: 342A289F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042D67C: BF870114
	.long 0xd73c0016                                           // 00000042D680: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 00000042D684: 02022C81
	.long 0xd73c0014                                           // 00000042D688: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000042D68C: 02022881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D690: BF870091
	.long 0xd7006a14                                           // 00000042D694: D7006A14
	v_cndmask_b32_e32 v1, v24, v20, vcc_lo                     // 00000042D698: 02022918
	v_add_co_ci_u32_e64 v21, null, v25, v21, vcc_lo            // 00000042D69C: D5207C15 01AA2B19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D6A4: BF870092
	.long 0xd7006a14                                           // 00000042D6A8: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 00000042D6AC: 02022D14
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 00000042D6B0: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 00000042D6B8: DC960000 007C1314
	s_cbranch_execnz 7                                         // 00000042D6C0: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2fe0>
	.long 0xd7006a14                                           // 00000042D6C4: D7006A14
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042D6C8: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D6CC: BF870001
	v_add_co_ci_u32_e64 v21, null, v8, v2, vcc_lo              // 00000042D6D0: D5207C15 01AA0508
	global_store_d16_hi_b16 v[20:21], v19, off offset:96       // 00000042D6D8: DC960060 007C1314
	global_load_d16_b16 v19, v[6:7], off offset:128            // 00000042D6E0: DC820080 137C0006
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 00000042D6E8: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 00000042D6F0: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042D6F4: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 00000042D6F8: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000042D6FC: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 00000042D700: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042D708: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D70C: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 00000042D710: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 00000042D718: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D720: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 00000042D724: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 277                                        // 00000042D730: BFA40115 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3488>
	v_or_b32_e32 v18, 64, v3                                   // 00000042D734: 382406C0
	v_lshrrev_b32_e32 v19, 23, v11                             // 00000042D738: 32261697
	v_mov_b32_e32 v21, s15                                     // 00000042D73C: 7E2A020F
	v_mov_b32_e32 v23, s14                                     // 00000042D740: 7E2E020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D744: BF870093
	v_add_nc_u32_e32 v19, v18, v19                             // 00000042D748: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 00000042D74C: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D754: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 00000042D758: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 00000042D75C: 7C8828FF 00000100
	v_add_nc_u32_e32 v22, 0xffffff00, v20                      // 00000042D764: 4A2C28FF FFFFFF00
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 00000042D76C: 02302A19
	v_ashrrev_i32_e32 v19, 9, v19                              // 00000042D770: 34262689
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042D774: BF8701A3
	v_cndmask_b32_e32 v20, v22, v20, vcc_lo                    // 00000042D778: 02282916
	v_cndmask_b32_e32 v22, s24, v23, vcc_lo                    // 00000042D77C: 022C2E18
	v_lshlrev_b32_e32 v18, 8, v19                              // 00000042D780: 30242688
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042D784: BF870193
	v_ashrrev_i32_e32 v21, 31, v20                             // 00000042D788: 342A289F
	.long 0xd7006a16                                           // 00000042D78C: D7006A16
	v_cndmask_b32_e32 v1, v22, v4, vcc_lo                      // 00000042D790: 02020916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042D794: BF870211
	v_add_co_ci_u32_e64 v23, null, v24, v5, vcc_lo             // 00000042D798: D5207C17 01AA0B18
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000042D7A0: 3426249F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042D7A4: BF870114
	.long 0xd73c0014                                           // 00000042D7A8: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000042D7AC: 02022881
	.long 0xd73c0012                                           // 00000042D7B0: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000042D7B4: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D7B8: BF870091
	.long 0xd7006a12                                           // 00000042D7BC: D7006A12
	v_cndmask_b32_e32 v1, v22, v18, vcc_lo                     // 00000042D7C0: 02022516
	v_add_co_ci_u32_e64 v19, null, v23, v19, vcc_lo            // 00000042D7C4: D5207C13 01AA2717
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D7CC: BF870092
	.long 0xd7006a12                                           // 00000042D7D0: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 00000042D7D4: 02022912
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 00000042D7D8: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 00000042D7E0: DC960000 007C1112
	s_cbranch_execnz 7                                         // 00000042D7E8: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3108>
	.long 0xd7006a12                                           // 00000042D7EC: D7006A12
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042D7F0: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D7F4: BF870001
	v_add_co_ci_u32_e64 v19, null, v8, v2, vcc_lo              // 00000042D7F8: D5207C13 01AA0508
	global_store_d16_hi_b16 v[18:19], v17, off offset:128      // 00000042D800: DC960080 007C1112
	global_load_d16_b16 v17, v[6:7], off offset:160            // 00000042D808: DC8200A0 117C0006
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 00000042D810: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 00000042D818: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042D81C: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 00000042D820: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000042D824: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 00000042D828: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042D830: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D834: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 00000042D838: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 00000042D840: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D848: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 00000042D84C: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 204                                        // 00000042D858: BFA400CC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x348c>
	v_or_b32_e32 v16, 0x50, v3                                 // 00000042D85C: 382006FF 00000050
	v_lshrrev_b32_e32 v17, 23, v11                             // 00000042D864: 32221697
	v_mov_b32_e32 v19, s15                                     // 00000042D868: 7E26020F
	v_mov_b32_e32 v21, s14                                     // 00000042D86C: 7E2A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D870: BF870093
	v_add_nc_u32_e32 v17, v16, v17                             // 00000042D874: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 00000042D878: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D880: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 00000042D884: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 00000042D888: 7C8824FF 00000100
	v_add_nc_u32_e32 v20, 0xffffff00, v18                      // 00000042D890: 4A2824FF FFFFFF00
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 00000042D898: 022C2619
	v_ashrrev_i32_e32 v17, 9, v17                              // 00000042D89C: 34222289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042D8A0: BF8701A3
	v_cndmask_b32_e32 v18, v20, v18, vcc_lo                    // 00000042D8A4: 02242514
	v_cndmask_b32_e32 v20, s24, v21, vcc_lo                    // 00000042D8A8: 02282A18
	v_lshlrev_b32_e32 v16, 8, v17                              // 00000042D8AC: 30202288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042D8B0: BF870193
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000042D8B4: 3426249F
	.long 0xd7006a14                                           // 00000042D8B8: D7006A14
	v_cndmask_b32_e32 v1, v20, v4, vcc_lo                      // 00000042D8BC: 02020914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042D8C0: BF870211
	v_add_co_ci_u32_e64 v21, null, v22, v5, vcc_lo             // 00000042D8C4: D5207C15 01AA0B16
	v_ashrrev_i32_e32 v17, 31, v16                             // 00000042D8CC: 3422209F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042D8D0: BF870114
	.long 0xd73c0012                                           // 00000042D8D4: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000042D8D8: 02022481
	.long 0xd73c0010                                           // 00000042D8DC: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000042D8E0: 02022081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D8E4: BF870091
	.long 0xd7006a10                                           // 00000042D8E8: D7006A10
	v_cndmask_b32_e32 v1, v20, v16, vcc_lo                     // 00000042D8EC: 02022114
	v_add_co_ci_u32_e64 v17, null, v21, v17, vcc_lo            // 00000042D8F0: D5207C11 01AA2315
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D8F8: BF870092
	.long 0xd7006a10                                           // 00000042D8FC: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 00000042D900: 02022510
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 00000042D904: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 00000042D90C: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 00000042D914: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3234>
	.long 0xd7006a10                                           // 00000042D918: D7006A10
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042D91C: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D920: BF870001
	v_add_co_ci_u32_e64 v17, null, v8, v2, vcc_lo              // 00000042D924: D5207C11 01AA0508
	global_store_d16_hi_b16 v[16:17], v15, off offset:160      // 00000042D92C: DC9600A0 007C0F10
	global_load_d16_b16 v15, v[6:7], off offset:192            // 00000042D934: DC8200C0 0F7C0006
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 00000042D93C: D501000C 2002190C
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 00000042D944: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042D948: BF8700A2
	v_add_f32_e32 v12, v12, v13                                // 00000042D94C: 06181B0C
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000042D950: 8B6A6A7E
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 00000042D954: 101818FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042D95C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D960: BF870091
	v_fma_mix_f32 v12, v15, v12, neg(0) op_sel_hi:[1,0,0]      // 00000042D964: CC20000C 8A02190F
	v_bfe_u32 v13, v12, 16, 1                                  // 00000042D96C: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042D974: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 00000042D978: D655000C 03FE1B0C 00007FFF
	s_cbranch_vccnz 130                                        // 00000042D984: BFA40082 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3490>
	v_or_b32_e32 v13, 0x60, v3                                 // 00000042D988: 381A06FF 00000060
	v_lshrrev_b32_e32 v15, 23, v11                             // 00000042D990: 321E1697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042D994: BF870091
	v_dual_mov_b32 v18, s14 :: v_dual_add_nc_u32 v15, v13, v15 // 00000042D998: CA20000E 120E1F0D
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 00000042D9A0: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000042D9A8: BF8701B1
	v_sub_nc_u32_e32 v13, v13, v16                             // 00000042D9AC: 4C1A210D
	v_mov_b32_e32 v16, s15                                     // 00000042D9B0: 7E20020F
	v_ashrrev_i32_e32 v15, 9, v15                              // 00000042D9B4: 341E1E89
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v13                        // 00000042D9B8: 7C881AFF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v13                      // 00000042D9C0: 4A221AFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042D9C8: BF8701A3
	v_lshlrev_b32_e32 v15, 8, v15                              // 00000042D9CC: 301E1E88
	v_cndmask_b32_e32 v19, s25, v16, vcc_lo                    // 00000042D9D0: 02262019
	v_cndmask_b32_e32 v17, v17, v13, vcc_lo                    // 00000042D9D4: 02221B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042D9D8: BF8701A3
	v_ashrrev_i32_e32 v16, 31, v15                             // 00000042D9DC: 34201E9F
	v_cndmask_b32_e32 v13, s24, v18, vcc_lo                    // 00000042D9E0: 021A2418
	v_ashrrev_i32_e32 v18, 31, v17                             // 00000042D9E4: 3424229F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042D9E8: BF870193
	.long 0xd73c000f                                           // 00000042D9EC: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 00000042D9F0: 02021E81
	.long 0xd7006a0d                                           // 00000042D9F4: D7006A0D
	v_cndmask_b32_e32 v1, v13, v4, vcc_lo                      // 00000042D9F8: 0202090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042D9FC: BF870211
	v_add_co_ci_u32_e64 v19, null, v19, v5, vcc_lo             // 00000042DA00: D5207C13 01AA0B13
	.long 0xd73c0011                                           // 00000042DA08: D73C0011
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 00000042DA0C: 02022281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042DA10: BF870093
	.long 0xd7006a0d                                           // 00000042DA14: D7006A0D
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 00000042DA18: 02021F0D
	v_add_co_ci_u32_e64 v16, null, v19, v16, vcc_lo            // 00000042DA1C: D5207C10 01AA2113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042DA24: BF870092
	.long 0xd7006a0f                                           // 00000042DA28: D7006A0F
	v_cndmask_b32_e32 v1, v13, v17, vcc_lo                     // 00000042DA2C: 0202230D
	v_add_co_ci_u32_e64 v16, null, v16, v18, vcc_lo            // 00000042DA30: D5207C10 01AA2510
	global_store_d16_hi_b16 v[15:16], v12, off                 // 00000042DA38: DC960000 007C0C0F
	s_cbranch_execnz 7                                         // 00000042DA40: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3360>
	.long 0xd7006a0f                                           // 00000042DA44: D7006A0F
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042DA48: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042DA4C: BF870001
	v_add_co_ci_u32_e64 v16, null, v8, v2, vcc_lo              // 00000042DA50: D5207C10 01AA0508
	global_store_d16_hi_b16 v[15:16], v12, off offset:192      // 00000042DA58: DC9600C0 007C0C0F
	global_load_d16_b16 v6, v[6:7], off offset:224             // 00000042DA60: DC8200E0 067C0006
	v_cndmask_b32_e64 v7, -v9, v9, s0                          // 00000042DA68: D5010007 20021309
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 00000042DA70: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042DA74: BF8700A2
	v_add_f32_e32 v7, v7, v10                                  // 00000042DA78: 060E1507
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000042DA7C: 8B6A6A7E
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 00000042DA80: 100E0EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042DA88: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042DA8C: BF870091
	v_fma_mix_f32 v6, v6, v7, neg(0) op_sel_hi:[1,0,0]         // 00000042DA90: CC200006 8A020F06
	v_bfe_u32 v7, v6, 16, 1                                    // 00000042DA98: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042DAA0: BF870001
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000042DAA4: D6550006 03FE0F06 00007FFF
	s_cbranch_vccnz 56                                         // 00000042DAB0: BFA40038 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3494>
	v_or_b32_e32 v3, 0x70, v3                                  // 00000042DAB4: 380606FF 00000070
	v_lshrrev_b32_e32 v7, 23, v11                              // 00000042DABC: 320E1697
	v_mov_b32_e32 v10, s15                                     // 00000042DAC0: 7E14020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042DAC4: BF870092
	v_dual_mov_b32 v12, s14 :: v_dual_add_nc_u32 v7, v3, v7    // 00000042DAC8: CA20000E 0C060F03
	v_and_b32_e32 v9, 0xfffffe00, v7                           // 00000042DAD0: 36120EFF FFFFFE00
	v_ashrrev_i32_e32 v7, 9, v7                                // 00000042DAD8: 340E0E89
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042DADC: BF870112
	v_sub_nc_u32_e32 v3, v3, v9                                // 00000042DAE0: 4C061303
	v_lshlrev_b32_e32 v9, 8, v7                                // 00000042DAE4: 30120E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000042DAE8: BF870232
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 00000042DAEC: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 00000042DAF4: 4A0E06FF FFFFFF00
	v_cndmask_b32_e32 v13, s25, v10, vcc_lo                    // 00000042DAFC: 021A1419
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000042DB00: 3414129F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042DB04: BF8701A3
	v_cndmask_b32_e32 v11, v7, v3, vcc_lo                      // 00000042DB08: 02160707
	v_cndmask_b32_e32 v3, s24, v12, vcc_lo                     // 00000042DB0C: 02061818
	.long 0xd73c0009                                           // 00000042DB10: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000042DB14: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042DB18: BF870193
	v_ashrrev_i32_e32 v12, 31, v11                             // 00000042DB1C: 3418169F
	.long 0xd7006a07                                           // 00000042DB20: D7006A07
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 00000042DB24: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042DB28: BF870191
	v_add_co_ci_u32_e64 v5, null, v13, v5, vcc_lo              // 00000042DB2C: D5207C05 01AA0B0D
	.long 0xd73c0003                                           // 00000042DB34: D73C0003
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000042DB38: 02021681
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042DB3C: BF870093
	.long 0xd7006a07                                           // 00000042DB40: D7006A07
	v_cndmask_b32_e32 v1, v7, v9, vcc_lo                       // 00000042DB44: 02021307
	v_add_co_ci_u32_e64 v5, null, v5, v10, vcc_lo              // 00000042DB48: D5207C05 01AA1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042DB50: BF870092
	.long 0xd7006a03                                           // 00000042DB54: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 00000042DB58: 02020707
	v_add_co_ci_u32_e64 v4, null, v5, v4, vcc_lo               // 00000042DB5C: D5207C04 01AA0905
	global_store_d16_hi_b16 v[3:4], v6, off                    // 00000042DB64: DC960000 007C0603
	s_cbranch_execnz 62431                                     // 00000042DB6C: BFA6F3DF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 8                                                 // 00000042DB70: BFA00008 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3494>
	s_branch 62429                                             // 00000042DB74: BFA0F3DD <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 65011                                             // 00000042DB78: BFA0FDF3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2c48>
	s_branch 65085                                             // 00000042DB7C: BFA0FE3D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2d74>
	s_branch 65158                                             // 00000042DB80: BFA0FE86 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2e9c>
	s_branch 65231                                             // 00000042DB84: BFA0FECF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2fc4>
	s_branch 65304                                             // 00000042DB88: BFA0FF18 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x30ec>
	s_branch 65378                                             // 00000042DB8C: BFA0FF62 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3218>
	s_branch 65452                                             // 00000042DB90: BFA0FFAC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3344>
	.long 0xd7006a00                                           // 00000042DB94: D7006A00
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042DB98: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042DB9C: BF870001
	v_add_co_ci_u32_e64 v1, null, v8, v2, vcc_lo               // 00000042DBA0: D5207C01 01AA0508
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 00000042DBA8: DC9600E0 007C0600
	s_nop 0                                                    // 00000042DBB0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000042DBB4: BFB60003
	s_endpgm                                                   // 00000042DBB8: BFB00000
		...

