0000000000344300 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi32ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi32ELi1EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000344300: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000344308: BE830080
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000034430C: 32020085
	s_lshl_b64 s[12:13], s[2:3], 3                             // 000000344310: 848C8302
	s_load_b64 s[2:3], s[0:1], 0x20                            // 000000344314: F4040080 F8000020
	v_mov_b32_e32 v9, s13                                      // 00000034431C: 7E12020D
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v17, 31, v0         // 000000344320: CA240080 0610009F
	v_or_b32_e32 v8, s12, v1                                   // 000000344328: 3810020C
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000034432C: CA100080 04040080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v16, 0              // 000000344334: CA100080 07100080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000034433C: BF8704D3
	.long 0xd73c0001                                           // 000000344340: D73C0001
	v_cndmask_b32_e32 v1, 4, v8, vcc_lo                        // 000000344344: 02021084
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v44, 0             // 000000344348: CA100080 0F2C0080
	v_mov_b32_e32 v18, 0                                       // 000000344350: 7E240280
	s_waitcnt lgkmcnt(0)                                       // 000000344354: BF89FC07
	s_ashr_i32 s16, s11, 31                                    // 000000344358: 86109F0B
	s_lshr_b32 s0, s16, 27                                     // 00000034435C: 85009B10
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000344360: BF870009
	s_add_u32 s0, s10, s0                                      // 000000344364: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000344368: 8201800B
	s_lshr_b32 s14, s11, 31                                    // 00000034436C: 850E9F0B
	s_lshr_b64 s[12:13], s[0:1], 5                             // 000000344370: 858C8500
	s_add_u32 s0, s10, s14                                     // 000000344374: 80000E0A
	s_addc_u32 s1, s11, 0                                      // 000000344378: 8201800B
	s_lshr_b32 s13, s16, 30                                    // 00000034437C: 850D9E10
	s_ashr_i64 s[14:15], s[0:1], 1                             // 000000344380: 868E8100
	s_add_u32 s0, s10, s13                                     // 000000344384: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 000000344388: 8201800B
	s_lshr_b32 s13, s16, 28                                    // 00000034438C: 850D9C10
	s_ashr_i64 s[16:17], s[0:1], 2                             // 000000344390: 86908200
	s_add_u32 s0, s10, s13                                     // 000000344394: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 000000344398: 8201800B
	v_cmp_gt_i64_e32 vcc_lo, s[2:3], v[8:9]                    // 00000034439C: 7CA81002
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003443A0: 86808400
	s_add_u32 s13, s16, s14                                    // 0000003443A4: 800D0E10
	s_addc_u32 s18, s17, s15                                   // 0000003443A8: 82120F11
	s_add_u32 s0, s13, s0                                      // 0000003443AC: 8000000D
	s_addc_u32 s1, s18, s1                                     // 0000003443B0: 82010112
	s_add_u32 s0, s0, 15                                       // 0000003443B4: 80008F00
	s_addc_u32 s1, s1, 0                                       // 0000003443B8: 82018001
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 0000003443BC: 02040480
	s_ashr_i32 s13, s1, 31                                     // 0000003443C0: 860D9F01
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000003443C4: 02020280
	s_lshr_b32 s13, s13, 28                                    // 0000003443C8: 850D9C0D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003443CC: BF8704A9
	s_add_u32 s0, s0, s13                                      // 0000003443D0: 80000D00
	s_addc_u32 s1, s1, 0                                       // 0000003443D4: 82018001
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003443D8: 86808400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000003443DC: BF870149
	.long 0xd72c0003                                           // 0000003443E0: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 0000003443E4: 02000301
	.long 0xd72c0002                                           // 0000003443E8: D72C0002
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000003443EC: 02000102
	v_mad_u64_u32 v[10:11], null, v1, s0, s[4:5]               // 0000003443F0: D6FE7C0A 00100101
	.long 0xd4440000                                           // 0000003443F8: D4440000
	v_cndmask_b32_e32 v1, s12, v17, vcc_lo                     // 0000003443FC: 0202220C
	v_add3_u32 v19, v2, v11, v3                                // 000000344400: D6550013 040E1702
	s_and_saveexec_b32 s4, s0                                  // 000000344408: BE842000
	s_cbranch_execz 35                                         // 00000034440C: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi32ELi1EEEvPKhPKtPtll+0x19c>
	v_lshlrev_b32_e32 v1, 4, v17                               // 000000344410: 30022284
	v_lshlrev_b32_e32 v0, 1, v0                                // 000000344414: 30000081
	v_lshlrev_b32_e32 v5, 3, v17                               // 000000344418: 300A2283
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034441C: BF870093
	.long 0xd7000101                                           // 000000344420: D7000101
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000344424: 0202030A
	v_add_co_ci_u32_e64 v2, null, 0, v19, s1                   // 000000344428: D5207C02 00062680
	.long 0xd7000103                                           // 000000344430: D7000103
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 000000344434: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000344438: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s15, v19, s1                 // 00000034443C: D5207C04 0006260F
	v_and_b32_e32 v0, 60, v0                                   // 000000344444: 360000BC
	.long 0xd7000106                                           // 000000344448: D7000106
	v_cndmask_b32_e32 v0, v3, v16, vcc_lo                      // 00000034444C: 02002103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000344450: BF8700A1
	v_add_co_ci_u32_e64 v7, null, s17, v4, s1                  // 000000344454: D5207C07 00060811
	.long 0xd700010b                                           // 00000034445C: D700010B
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000344460: 02020B03
	v_add_co_ci_u32_e64 v12, null, 0, v4, s1                   // 000000344464: D5207C0C 00060880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034446C: BF870094
	.long 0xd700010d                                           // 000000344470: D700010D
	v_cndmask_b32_e32 v1, v6, v0, vcc_lo                       // 000000344474: 02020106
	v_add_co_ci_u32_e64 v14, null, 0, v7, s1                   // 000000344478: D5207C0E 00060E80
	s_clause 0x2                                               // 000000344480: BF850002
	global_load_b128 v[4:7], v[1:2], off                       // 000000344484: DC5E0000 047C0001
	global_load_b64 v[15:16], v[11:12], off                    // 00000034448C: DC560000 0F7C000B
	global_load_b32 v44, v[13:14], off                         // 000000344494: DC520000 2C7C000D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000034449C: 8C7E047E
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000003444A0: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000003444A8: CA100080 16160080
	s_and_saveexec_b32 s13, s0                                 // 0000003444B0: BE8D2000
	s_cbranch_execz 954                                        // 0000003444B4: BFA503BA <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi32ELi1EEEvPKhPKtPtll+0x10a0>
	.long 0xd7000018                                           // 0000003444B8: D7000018
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 0000003444BC: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003444C0: BF8701A1
	v_add_co_ci_u32_e64 v25, null, s15, v19, s0                // 0000003444C4: D5207C19 0002260F
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v17    // 0000003444CC: CA220080 0C0A2285
	.long 0xd700001a                                           // 0000003444D4: D700001A
	v_cndmask_b32_e32 v0, v24, v16, vcc_lo                     // 0000003444D8: 02002118
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003444DC: BF870001
	v_add_co_ci_u32_e64 v27, null, s17, v25, s0                // 0000003444E0: D5207C1B 00023211
	v_lshl_or_b32 v28, v17, 4, 0x200                           // 0000003444E8: D656001C 03FD0911 00000200
	v_lshl_or_b32 v29, v17, 3, 0x100                           // 0000003444F4: D656001D 03FD0711 00000100
	v_lshl_or_b32 v30, v17, 1, 64                              // 000000344500: D656001E 03010311
	v_dual_mov_b32 v18, v12 :: v_dual_mov_b32 v31, v17         // 000000344508: CA10010C 121E0111
	v_mov_b32_e32 v20, v12                                     // 000000344510: 7E28030C
	v_mov_b32_e32 v21, v12                                     // 000000344514: 7E2A030C
	v_mov_b32_e32 v22, v12                                     // 000000344518: 7E2C030C
	v_mov_b32_e32 v23, v12                                     // 00000034451C: 7E2E030C
	s_waitcnt vmcnt(0)                                         // 000000344520: BF8903F7
	v_mov_b32_e32 v32, v44                                     // 000000344524: 7E40032C
	s_mul_i32 s0, s11, 6                                       // 000000344528: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 00000034452C: 9681860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000344530: 8484820A
	s_add_i32 s14, s1, s0                                      // 000000344534: 810E0001
	s_mul_i32 s16, s10, 6                                      // 000000344538: 9610860A
	s_mov_b32 s15, 0                                           // 00000034453C: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000344540: 848A810A
	s_branch 879                                               // 000000344544: BFA0036F <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi32ELi1EEEvPKhPKtPtll+0x1004>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000344548: 8C7E117E
	v_lshlrev_b32_e32 v33, 4, v15                              // 00000034454C: 30421E84
	v_lshlrev_b32_e32 v35, 2, v15                              // 000000344550: 30461E82
	v_lshrrev_b32_e32 v34, 4, v4                               // 000000344554: 32440884
	v_lshrrev_b32_e32 v36, 2, v15                              // 000000344558: 32481E82
	.long 0x7f5a3880                                           // 00000034455C: 7F5A3880
	v_and_b32_e32 v33, 48, v33                                 // 000000344560: 364242B0
	v_and_b32_e32 v35, 48, v35                                 // 000000344564: 364646B0
	v_lshrrev_b32_e32 v38, 6, v15                              // 000000344568: 324C1E86
	v_and_b32_e32 v36, 48, v36                                 // 00000034456C: 364848B0
	v_lshrrev_b32_e32 v37, 20, v4                              // 000000344570: 324A0894
	v_and_or_b32 v33, v4, 15, v33                              // 000000344574: D6570021 04851F04
	v_and_or_b32 v34, v34, 15, v35                             // 00000034457C: D6570022 048D1F22
	v_and_b32_e32 v38, 48, v38                                 // 000000344584: 364C4CB0
	v_lshrrev_b32_e32 v40, 18, v15                             // 000000344588: 32501E92
	v_lshrrev_b32_e32 v41, 22, v15                             // 00000034458C: 32521E96
	v_cvt_f32_ubyte0_e32 v33, v33                              // 000000344590: 7E422321
	v_lshrrev_b32_e32 v43, 6, v16                              // 000000344594: 32562086
	v_and_or_b32 v37, v37, 15, v38                             // 000000344598: D6570025 04991F25
	v_and_b32_e32 v40, 48, v40                                 // 0000003445A0: 365050B0
	v_and_b32_e32 v41, 48, v41                                 // 0000003445A4: 365252B0
	v_fma_mix_f32 v33, v33, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003445A8: CC206021 14B25921
	v_lshrrev_b32_e32 v42, 20, v6                              // 0000003445B0: 32540C94
	v_and_b32_e32 v43, 48, v43                                 // 0000003445B4: 365656B0
	v_lshrrev_b32_e32 v47, 18, v16                             // 0000003445B8: 325E2092
	v_lshrrev_b32_e32 v48, 22, v16                             // 0000003445BC: 32602096
	v_bfe_u32 v35, v33, 16, 1                                  // 0000003445C0: D6100023 02052121
	s_and_b32 s0, exec_lo, s0                                  // 0000003445C8: 8B00007E
	v_and_or_b32 v42, v42, 15, v43                             // 0000003445CC: D657002A 04AD1F2A
	v_and_b32_e32 v47, 48, v47                                 // 0000003445D4: 365E5EB0
	v_and_b32_e32 v48, 48, v48                                 // 0000003445D8: 366060B0
	v_add3_u32 v33, v33, v35, 0x7fff                           // 0000003445DC: D6550021 03FE4721 00007FFF
	v_and_b32_e32 v35, 48, v15                                 // 0000003445E8: 36461EB0
	s_or_b32 s15, s0, s15                                      // 0000003445EC: 8C0F0F00
	v_add_nc_u32_e32 v28, 0x200, v28                           // 0000003445F0: 4A3838FF 00000200
	v_add_nc_u32_e32 v29, 0x100, v29                           // 0000003445F8: 4A3A3AFF 00000100
	.long 0x7e5a39a1                                           // 000000344600: 7E5A39A1
	v_cvt_f32_ubyte0_e32 v33, v34                              // 000000344604: 7E422322
	v_add_nc_u32_e32 v30, 64, v30                              // 000000344608: 4A3C3CC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034460C: BF870092
	v_fma_mix_f32 v33, v33, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344610: CC206021 14B25921
	v_bfe_u32 v34, v33, 16, 1                                  // 000000344618: D6100022 02052121
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000344620: BF870121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 000000344624: D6550021 03FE4521 00007FFF
	v_lshrrev_b32_e32 v34, 8, v4                               // 000000344630: 32440888
	v_and_or_b32 v33, 0xffff0000, v33, v45                     // 000000344634: D6570021 04B642FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000344640: BF870122
	v_and_or_b32 v34, v34, 15, v35                             // 000000344644: D6570022 048D1F22
	v_lshrrev_b32_e32 v35, 12, v4                              // 00000034464C: 3246088C
	v_cvt_f32_ubyte0_e32 v34, v34                              // 000000344650: 7E442322
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344654: BF870112
	v_and_or_b32 v35, v35, 15, v36                             // 000000344658: D6570023 04911F23
	v_fma_mix_f32 v34, v34, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344660: CC206022 14B25922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344668: BF870091
	v_bfe_u32 v36, v34, 16, 1                                  // 00000034466C: D6100024 02052122
	v_add3_u32 v34, v34, v36, 0x7fff                           // 000000344674: D6550022 03FE4922 00007FFF
	v_lshrrev_b32_e32 v36, 8, v15                              // 000000344680: 32481E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000344684: BF8701A2
	.long 0x7e5a39a2                                           // 000000344688: 7E5A39A2
	v_cvt_f32_ubyte0_e32 v34, v35                              // 00000034468C: 7E442323
	v_and_b32_e32 v36, 48, v36                                 // 000000344690: 364848B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344694: BF870092
	v_fma_mix_f32 v34, v34, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344698: CC206022 14B25922
	v_bfe_u32 v35, v34, 16, 1                                  // 0000003446A0: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003446A8: BF870121
	v_add3_u32 v34, v34, v35, 0x7fff                           // 0000003446AC: D6550022 03FE4722 00007FFF
	v_lshrrev_b32_e32 v35, 4, v15                              // 0000003446B8: 32461E84
	v_and_or_b32 v34, 0xffff0000, v34, v45                     // 0000003446BC: D6570022 04B644FF FFFF0000
	.long 0x7e5a3984                                           // 0000003446C8: 7E5A3984
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003446CC: BF870093
	v_and_b32_e32 v35, 48, v35                                 // 0000003446D0: 364646B0
	v_and_or_b32 v35, v45, 15, v35                             // 0000003446D4: D6570023 048D1F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003446DC: BF870091
	v_cvt_f32_ubyte0_e32 v35, v35                              // 0000003446E0: 7E462323
	v_fma_mix_f32 v35, v35, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003446E4: CC206023 14B25923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003446EC: BF870091
	v_bfe_u32 v38, v35, 16, 1                                  // 0000003446F0: D6100026 02052123
	v_add3_u32 v35, v35, v38, 0x7fff                           // 0000003446F8: D6550023 03FE4D23 00007FFF
	v_lshrrev_b32_e32 v38, 12, v15                             // 000000344704: 324C1E8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000344708: BF8700A2
	.long 0x7e5a39a3                                           // 00000034470C: 7E5A39A3
	v_cvt_f32_ubyte0_e32 v35, v37                              // 000000344710: 7E462325
	v_fma_mix_f32 v35, v35, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344714: CC206023 14B25923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034471C: BF870091
	v_bfe_u32 v37, v35, 16, 1                                  // 000000344720: D6100025 02052123
	v_add3_u32 v35, v35, v37, 0x7fff                           // 000000344728: D6550023 03FE4B23 00007FFF
	v_lshrrev_b32_e32 v37, 24, v4                              // 000000344734: 324A0898
	v_lshrrev_b32_e32 v4, 28, v4                               // 000000344738: 3208089C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034473C: BF870193
	v_and_or_b32 v35, 0xffff0000, v35, v45                     // 000000344740: D6570023 04B646FF FFFF0000
	v_and_or_b32 v36, v37, 15, v36                             // 00000034474C: D6570024 04911F25
	v_lshrrev_b32_e32 v37, 10, v15                             // 000000344754: 324A1E8A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344758: BF870112
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000034475C: 7E482324
	v_and_or_b32 v4, v37, 48, v4                               // 000000344760: D6570004 04116125
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344768: BF870112
	v_fma_mix_f32 v36, v36, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034476C: CC206024 14B25924
	v_cvt_f32_ubyte0_e32 v4, v4                                // 000000344774: 7E082304
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344778: BF870112
	v_bfe_u32 v37, v36, 16, 1                                  // 00000034477C: D6100025 02052124
	v_fma_mix_f32 v4, v4, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344784: CC206004 14B25904
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034478C: BF870122
	v_add3_u32 v36, v36, v37, 0x7fff                           // 000000344790: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 4, v5                               // 00000034479C: 324A0A84
	.long 0x7e5a39a4                                           // 0000003447A0: 7E5A39A4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003447A4: BF870094
	v_bfe_u32 v36, v4, 16, 1                                   // 0000003447A8: D6100024 02052104
	v_add3_u32 v4, v4, v36, 0x7fff                             // 0000003447B0: D6550004 03FE4904 00007FFF
	v_and_b32_e32 v36, 48, v38                                 // 0000003447BC: 36484CB0
	v_lshrrev_b32_e32 v38, 14, v15                             // 0000003447C0: 324C1E8E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003447C4: BF870193
	v_and_or_b32 v4, 0xffff0000, v4, v45                       // 0000003447C8: D6570004 04B608FF FFFF0000
	v_and_or_b32 v36, v5, 15, v36                              // 0000003447D4: D6570024 04911F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003447DC: BF8701A3
	v_and_b32_e32 v38, 48, v38                                 // 0000003447E0: 364C4CB0
	.long 0x7e5a398f                                           // 0000003447E4: 7E5A398F
	v_cvt_f32_ubyte0_e32 v36, v36                              // 0000003447E8: 7E482324
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003447EC: BF870193
	v_and_or_b32 v37, v37, 15, v38                             // 0000003447F0: D6570025 04991F25
	v_and_b32_e32 v39, 48, v45                                 // 0000003447F8: 364E5AB0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003447FC: BF870193
	v_fma_mix_f32 v36, v36, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344800: CC206024 14B25924
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000344808: 7E4A2325
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034480C: BF870112
	v_bfe_u32 v38, v36, 16, 1                                  // 000000344810: D6100026 02052124
	v_fma_mix_f32 v37, v37, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344818: CC206025 14B25925
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344820: BF870112
	v_add3_u32 v36, v36, v38, 0x7fff                           // 000000344824: D6550024 03FE4D24 00007FFF
	v_bfe_u32 v38, v37, 16, 1                                  // 000000344830: D6100026 02052125
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000344838: BF8701A2
	.long 0x7e4839a4                                           // 00000034483C: 7E4839A4
	.long 0x7f4839ad                                           // 000000344840: 7F4839AD
	v_add3_u32 v37, v37, v38, 0x7fff                           // 000000344844: D6550025 03FE4D25 00007FFF
	v_lshrrev_b32_e32 v38, 20, v15                             // 000000344850: 324C1E94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000344854: BF8701A2
	v_and_or_b32 v36, 0xffff0000, v37, v36                     // 000000344858: D6570024 04924AFF FFFF0000
	v_lshrrev_b32_e32 v37, 8, v5                               // 000000344864: 324A0A88
	v_and_b32_e32 v38, 48, v38                                 // 000000344868: 364C4CB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034486C: BF870122
	v_and_or_b32 v37, v37, 15, v39                             // 000000344870: D6570025 049D1F25
	v_lshrrev_b32_e32 v39, 12, v5                              // 000000344878: 324E0A8C
	v_cvt_f32_ubyte0_e32 v37, v37                              // 00000034487C: 7E4A2325
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344880: BF870112
	v_and_or_b32 v39, v39, 15, v40                             // 000000344884: D6570027 04A11F27
	v_fma_mix_f32 v37, v37, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034488C: CC206025 14B25925
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344894: BF870091
	v_bfe_u32 v40, v37, 16, 1                                  // 000000344898: D6100028 02052125
	v_add3_u32 v37, v37, v40, 0x7fff                           // 0000003448A0: D6550025 03FE5125 00007FFF
	v_lshrrev_b32_e32 v40, 20, v5                              // 0000003448AC: 32500A94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003448B0: BF8701A2
	.long 0x7e5a39a5                                           // 0000003448B4: 7E5A39A5
	v_cvt_f32_ubyte0_e32 v37, v39                              // 0000003448B8: 7E4A2327
	v_and_or_b32 v40, v40, 15, v41                             // 0000003448BC: D6570028 04A51F28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003448C4: BF870092
	v_fma_mix_f32 v37, v37, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003448C8: CC206025 14B25925
	v_bfe_u32 v39, v37, 16, 1                                  // 0000003448D0: D6100027 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003448D8: BF8701B1
	v_add3_u32 v37, v37, v39, 0x7fff                           // 0000003448DC: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 24, v15                             // 0000003448E8: 324E1E98
	v_lshrrev_b32_e32 v15, 26, v15                             // 0000003448EC: 321E1E9A
	v_and_or_b32 v37, 0xffff0000, v37, v45                     // 0000003448F0: D6570025 04B64AFF FFFF0000
	.long 0x7e5a3985                                           // 0000003448FC: 7E5A3985
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344900: BF870114
	v_and_b32_e32 v39, 48, v39                                 // 000000344904: 364E4EB0
	v_and_or_b32 v38, v45, 15, v38                             // 000000344908: D6570026 04991F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344910: BF870091
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000344914: 7E4C2326
	v_fma_mix_f32 v38, v38, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344918: CC206026 14B25926
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344920: BF870091
	v_bfe_u32 v41, v38, 16, 1                                  // 000000344924: D6100029 02052126
	v_add3_u32 v38, v38, v41, 0x7fff                           // 00000034492C: D6550026 03FE5326 00007FFF
	v_lshrrev_b32_e32 v41, 2, v16                              // 000000344938: 32522082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034493C: BF8701A2
	.long 0x7e5a39a6                                           // 000000344940: 7E5A39A6
	v_cvt_f32_ubyte0_e32 v38, v40                              // 000000344944: 7E4C2328
	v_and_b32_e32 v41, 48, v41                                 // 000000344948: 365252B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034494C: BF870092
	v_fma_mix_f32 v38, v38, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344950: CC206026 14B25926
	v_bfe_u32 v40, v38, 16, 1                                  // 000000344958: D6100028 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000344960: BF8701B1
	v_add3_u32 v38, v38, v40, 0x7fff                           // 000000344964: D6550026 03FE5126 00007FFF
	v_lshrrev_b32_e32 v40, 24, v5                              // 000000344970: 32500A98
	v_lshrrev_b32_e32 v5, 28, v5                               // 000000344974: 320A0A9C
	v_and_or_b32 v38, 0xffff0000, v38, v45                     // 000000344978: D6570026 04B64CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000344984: BF870193
	v_and_or_b32 v39, v40, 15, v39                             // 000000344988: D6570027 049D1F28
	v_and_or_b32 v5, v15, 48, v5                               // 000000344990: D6570005 0415610F
	v_lshlrev_b32_e32 v40, 2, v16                              // 000000344998: 30502082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034499C: BF870193
	v_cvt_f32_ubyte0_e32 v15, v39                              // 0000003449A0: 7E1E2327
	v_cvt_f32_ubyte0_e32 v5, v5                                // 0000003449A4: 7E0A2305
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003449A8: BF870193
	v_and_b32_e32 v40, 48, v40                                 // 0000003449AC: 365050B0
	v_fma_mix_f32 v15, v15, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003449B0: CC20600F 14B2590F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003449B8: BF870113
	v_fma_mix_f32 v5, v5, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003449BC: CC206005 14B25905
	v_bfe_u32 v39, v15, 16, 1                                  // 0000003449C4: D6100027 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003449CC: BF870121
	v_add3_u32 v15, v15, v39, 0x7fff                           // 0000003449D0: D655000F 03FE4F0F 00007FFF
	v_lshrrev_b32_e32 v39, 4, v6                               // 0000003449DC: 324E0C84
	.long 0x7e5a398f                                           // 0000003449E0: 7E5A398F
	v_bfe_u32 v15, v5, 16, 1                                   // 0000003449E4: D610000F 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003449EC: BF870113
	v_and_or_b32 v39, v39, 15, v40                             // 0000003449F0: D6570027 04A11F27
	v_add3_u32 v5, v5, v15, 0x7fff                             // 0000003449F8: D6550005 03FE1F05 00007FFF
	v_lshlrev_b32_e32 v15, 4, v16                              // 000000344A04: 301E2084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344A08: BF870112
	v_and_or_b32 v5, 0xffff0000, v5, v45                       // 000000344A0C: D6570005 04B60AFF FFFF0000
	v_and_b32_e32 v15, 48, v15                                 // 000000344A18: 361E1EB0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344A1C: BF870091
	v_and_or_b32 v15, v6, 15, v15                              // 000000344A20: D657000F 043D1F06
	v_cvt_f32_ubyte0_e32 v15, v15                              // 000000344A28: 7E1E230F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344A2C: BF870091
	v_fma_mix_f32 v15, v15, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344A30: CC20600F 14B2590F
	v_bfe_u32 v40, v15, 16, 1                                  // 000000344A38: D6100028 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000344A40: BF870121
	v_add3_u32 v15, v15, v40, 0x7fff                           // 000000344A44: D655000F 03FE510F 00007FFF
	v_and_b32_e32 v40, 48, v16                                 // 000000344A50: 365020B0
	.long 0x7e5a398f                                           // 000000344A54: 7E5A398F
	v_cvt_f32_ubyte0_e32 v15, v39                              // 000000344A58: 7E1E2327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344A5C: BF870091
	v_fma_mix_f32 v15, v15, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344A60: CC20600F 14B2590F
	v_bfe_u32 v39, v15, 16, 1                                  // 000000344A68: D6100027 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000344A70: BF870121
	v_add3_u32 v15, v15, v39, 0x7fff                           // 000000344A74: D655000F 03FE4F0F 00007FFF
	v_lshrrev_b32_e32 v39, 8, v6                               // 000000344A80: 324E0C88
	v_and_or_b32 v15, 0xffff0000, v15, v45                     // 000000344A84: D657000F 04B61EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000344A90: BF870122
	v_and_or_b32 v39, v39, 15, v40                             // 000000344A94: D6570027 04A11F27
	v_lshrrev_b32_e32 v40, 12, v6                              // 000000344A9C: 32500C8C
	v_cvt_f32_ubyte0_e32 v39, v39                              // 000000344AA0: 7E4E2327
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344AA4: BF870112
	v_and_or_b32 v40, v40, 15, v41                             // 000000344AA8: D6570028 04A51F28
	v_fma_mix_f32 v39, v39, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344AB0: CC206027 14B25927
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344AB8: BF870091
	v_bfe_u32 v41, v39, 16, 1                                  // 000000344ABC: D6100029 02052127
	v_add3_u32 v39, v39, v41, 0x7fff                           // 000000344AC4: D6550027 03FE5327 00007FFF
	v_lshrrev_b32_e32 v41, 8, v16                              // 000000344AD0: 32522088
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000344AD4: BF8701A2
	.long 0x7e5a39a7                                           // 000000344AD8: 7E5A39A7
	v_cvt_f32_ubyte0_e32 v39, v40                              // 000000344ADC: 7E4E2328
	v_and_b32_e32 v41, 48, v41                                 // 000000344AE0: 365252B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344AE4: BF870092
	v_fma_mix_f32 v39, v39, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344AE8: CC206027 14B25927
	v_bfe_u32 v40, v39, 16, 1                                  // 000000344AF0: D6100028 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000344AF8: BF870121
	v_add3_u32 v39, v39, v40, 0x7fff                           // 000000344AFC: D6550027 03FE5127 00007FFF
	v_lshrrev_b32_e32 v40, 4, v16                              // 000000344B08: 32502084
	v_and_or_b32 v39, 0xffff0000, v39, v45                     // 000000344B0C: D6570027 04B64EFF FFFF0000
	.long 0x7e5a3986                                           // 000000344B18: 7E5A3986
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344B1C: BF870093
	v_and_b32_e32 v40, 48, v40                                 // 000000344B20: 365050B0
	v_and_or_b32 v40, v45, 15, v40                             // 000000344B24: D6570028 04A11F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344B2C: BF870091
	v_cvt_f32_ubyte0_e32 v40, v40                              // 000000344B30: 7E502328
	v_fma_mix_f32 v40, v40, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344B34: CC206028 14B25928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344B3C: BF870091
	v_bfe_u32 v43, v40, 16, 1                                  // 000000344B40: D610002B 02052128
	v_add3_u32 v40, v40, v43, 0x7fff                           // 000000344B48: D6550028 03FE5728 00007FFF
	v_lshrrev_b32_e32 v43, 12, v16                             // 000000344B54: 3256208C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000344B58: BF8700A2
	.long 0x7e5a39a8                                           // 000000344B5C: 7E5A39A8
	v_cvt_f32_ubyte0_e32 v40, v42                              // 000000344B60: 7E50232A
	v_fma_mix_f32 v40, v40, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344B64: CC206028 14B25928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344B6C: BF870091
	v_bfe_u32 v42, v40, 16, 1                                  // 000000344B70: D610002A 02052128
	v_add3_u32 v40, v40, v42, 0x7fff                           // 000000344B78: D6550028 03FE5528 00007FFF
	v_lshrrev_b32_e32 v42, 24, v6                              // 000000344B84: 32540C98
	v_lshrrev_b32_e32 v6, 28, v6                               // 000000344B88: 320C0C9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000344B8C: BF870193
	v_and_or_b32 v40, 0xffff0000, v40, v45                     // 000000344B90: D6570028 04B650FF FFFF0000
	v_and_or_b32 v41, v42, 15, v41                             // 000000344B9C: D6570029 04A51F2A
	v_lshrrev_b32_e32 v42, 10, v16                             // 000000344BA4: 3254208A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344BA8: BF870112
	v_cvt_f32_ubyte0_e32 v41, v41                              // 000000344BAC: 7E522329
	v_and_or_b32 v6, v42, 48, v6                               // 000000344BB0: D6570006 0419612A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344BB8: BF870112
	v_fma_mix_f32 v41, v41, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344BBC: CC206029 14B25929
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000344BC4: 7E0C2306
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344BC8: BF870112
	v_bfe_u32 v42, v41, 16, 1                                  // 000000344BCC: D610002A 02052129
	v_fma_mix_f32 v6, v6, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344BD4: CC206006 14B25906
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000344BDC: BF870122
	v_add3_u32 v41, v41, v42, 0x7fff                           // 000000344BE0: D6550029 03FE5529 00007FFF
	v_lshrrev_b32_e32 v42, 4, v7                               // 000000344BEC: 32540E84
	.long 0x7e5a39a9                                           // 000000344BF0: 7E5A39A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344BF4: BF870094
	v_bfe_u32 v41, v6, 16, 1                                   // 000000344BF8: D6100029 02052106
	v_add3_u32 v6, v6, v41, 0x7fff                             // 000000344C00: D6550006 03FE5306 00007FFF
	v_and_b32_e32 v41, 15, v7                                  // 000000344C0C: 36520E8F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344C10: BF870112
	v_and_or_b32 v6, 0xffff0000, v6, v45                       // 000000344C14: D6570006 04B60CFF FFFF0000
	v_and_or_b32 v41, v43, 48, v41                             // 000000344C20: D6570029 04A5612B
	v_lshrrev_b32_e32 v43, 14, v16                             // 000000344C28: 3256208E
	.long 0x7e5a3990                                           // 000000344C2C: 7E5A3990
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000344C30: BF870193
	v_cvt_f32_ubyte0_e32 v41, v41                              // 000000344C34: 7E522329
	v_and_b32_e32 v43, 48, v43                                 // 000000344C38: 365656B0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000344C3C: BF870193
	v_and_b32_e32 v46, 48, v45                                 // 000000344C40: 365C5AB0
	v_fma_mix_f32 v41, v41, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344C44: CC206029 14B25929
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344C4C: BF870113
	v_and_or_b32 v42, v42, 15, v43                             // 000000344C50: D657002A 04AD1F2A
	v_bfe_u32 v43, v41, 16, 1                                  // 000000344C58: D610002B 02052129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344C60: BF870112
	v_cvt_f32_ubyte0_e32 v42, v42                              // 000000344C64: 7E54232A
	v_add3_u32 v41, v41, v43, 0x7fff                           // 000000344C68: D6550029 03FE5729 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344C74: BF870112
	v_fma_mix_f32 v42, v42, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344C78: CC20602A 14B2592A
	.long 0x7e5239a9                                           // 000000344C80: 7E5239A9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000344C84: BF870122
	v_bfe_u32 v43, v42, 16, 1                                  // 000000344C88: D610002B 0205212A
	.long 0x7f5239ad                                           // 000000344C90: 7F5239AD
	v_add3_u32 v42, v42, v43, 0x7fff                           // 000000344C94: D655002A 03FE572A 00007FFF
	v_lshrrev_b32_e32 v43, 20, v16                             // 000000344CA0: 32562094
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000344CA4: BF8701A2
	v_and_or_b32 v41, 0xffff0000, v42, v41                     // 000000344CA8: D6570029 04A654FF FFFF0000
	v_lshrrev_b32_e32 v42, 8, v7                               // 000000344CB4: 32540E88
	v_and_b32_e32 v43, 48, v43                                 // 000000344CB8: 365656B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000344CBC: BF870122
	v_and_or_b32 v42, v42, 15, v46                             // 000000344CC0: D657002A 04B91F2A
	v_lshrrev_b32_e32 v46, 12, v7                              // 000000344CC8: 325C0E8C
	v_cvt_f32_ubyte0_e32 v42, v42                              // 000000344CCC: 7E54232A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344CD0: BF870112
	v_and_or_b32 v46, v46, 15, v47                             // 000000344CD4: D657002E 04BD1F2E
	v_fma_mix_f32 v42, v42, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344CDC: CC20602A 14B2592A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344CE4: BF870091
	v_bfe_u32 v47, v42, 16, 1                                  // 000000344CE8: D610002F 0205212A
	v_add3_u32 v42, v42, v47, 0x7fff                           // 000000344CF0: D655002A 03FE5F2A 00007FFF
	v_lshrrev_b32_e32 v47, 20, v7                              // 000000344CFC: 325E0E94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000344D00: BF8701A2
	.long 0x7e5a39aa                                           // 000000344D04: 7E5A39AA
	v_cvt_f32_ubyte0_e32 v42, v46                              // 000000344D08: 7E54232E
	v_and_or_b32 v47, v47, 15, v48                             // 000000344D0C: D657002F 04C11F2F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344D14: BF870092
	v_fma_mix_f32 v42, v42, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344D18: CC20602A 14B2592A
	v_bfe_u32 v46, v42, 16, 1                                  // 000000344D20: D610002E 0205212A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000344D28: BF8701B1
	v_add3_u32 v42, v42, v46, 0x7fff                           // 000000344D2C: D655002A 03FE5D2A 00007FFF
	v_lshrrev_b32_e32 v46, 24, v16                             // 000000344D38: 325C2098
	v_lshrrev_b32_e32 v16, 26, v16                             // 000000344D3C: 3220209A
	v_and_or_b32 v42, 0xffff0000, v42, v45                     // 000000344D40: D657002A 04B654FF FFFF0000
	.long 0x7e5a3987                                           // 000000344D4C: 7E5A3987
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344D50: BF870114
	v_and_b32_e32 v46, 48, v46                                 // 000000344D54: 365C5CB0
	v_and_or_b32 v43, v45, 15, v43                             // 000000344D58: D657002B 04AD1F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344D60: BF870091
	v_cvt_f32_ubyte0_e32 v43, v43                              // 000000344D64: 7E56232B
	v_fma_mix_f32 v43, v43, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344D68: CC20602B 14B2592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344D70: BF870091
	v_bfe_u32 v48, v43, 16, 1                                  // 000000344D74: D6100030 0205212B
	v_add3_u32 v43, v43, v48, 0x7fff                           // 000000344D7C: D655002B 03FE612B 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000344D88: BF8700A1
	.long 0x7e5a39ab                                           // 000000344D8C: 7E5A39AB
	v_cvt_f32_ubyte0_e32 v43, v47                              // 000000344D90: 7E56232F
	v_fma_mix_f32 v43, v43, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344D94: CC20602B 14B2592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344D9C: BF870091
	v_bfe_u32 v47, v43, 16, 1                                  // 000000344DA0: D610002F 0205212B
	v_add3_u32 v43, v43, v47, 0x7fff                           // 000000344DA8: D655002B 03FE5F2B 00007FFF
	v_lshrrev_b32_e32 v47, 24, v7                              // 000000344DB4: 325E0E98
	v_lshrrev_b32_e32 v7, 28, v7                               // 000000344DB8: 320E0E9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000344DBC: BF870193
	v_and_or_b32 v43, 0xffff0000, v43, v45                     // 000000344DC0: D657002B 04B656FF FFFF0000
	v_and_or_b32 v46, v47, 15, v46                             // 000000344DCC: D657002E 04B91F2F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344DD4: BF870113
	v_and_or_b32 v7, v16, 48, v7                               // 000000344DD8: D6570007 041D6110
	v_cvt_f32_ubyte0_e32 v16, v46                              // 000000344DE0: 7E20232E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344DE4: BF870112
	v_cvt_f32_ubyte0_e32 v7, v7                                // 000000344DE8: 7E0E2307
	v_fma_mix_f32 v16, v16, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344DEC: CC206010 14B25910
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000344DF4: BF870112
	v_fma_mix_f32 v7, v7, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000344DF8: CC206007 14B25907
	v_bfe_u32 v46, v16, 16, 1                                  // 000000344E00: D610002E 02052110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344E08: BF870091
	v_add3_u32 v16, v16, v46, 0x7fff                           // 000000344E0C: D6550010 03FE5D10 00007FFF
	.long 0x7e5a3990                                           // 000000344E18: 7E5A3990
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344E1C: BF870094
	v_bfe_u32 v16, v7, 16, 1                                   // 000000344E20: D6100010 02052107
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000344E28: D6550007 03FE2107 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000344E34: BF870131
	v_and_or_b32 v7, 0xffff0000, v7, v45                       // 000000344E38: D6570007 04B60EFF FFFF0000
	.long 0xd73c002c                                           // 000000344E44: D73C002C
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000344E48: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 000000344E4C: 4A1616FF 00000400
	.long 0xd700003c                                           // 000000344E54: D700003C
	v_cndmask_b32_e32 v1, s6, v44, vcc_lo                      // 000000344E58: 02025806
	s_delay_alu instid0(VALU_DEP_1)                            // 000000344E5C: BF870001
	v_add_co_ci_u32_e64 v61, null, s7, v45, s0                 // 000000344E60: D5207C3D 00025A07
	s_clause 0x3                                               // 000000344E68: BF850003
	global_load_b128 v[44:47], v[60:61], off                   // 000000344E6C: DC5E0000 2C7C003C
	global_load_b128 v[48:51], v[60:61], off offset:16         // 000000344E74: DC5E0010 307C003C
	global_load_b128 v[52:55], v[60:61], off offset:32         // 000000344E7C: DC5E0020 347C003C
	global_load_b128 v[56:59], v[60:61], off offset:48         // 000000344E84: DC5E0030 387C003C
	s_waitcnt vmcnt(3)                                         // 000000344E8C: BF890FF7
	v_dot2_f32_bf16 v16, v44, v33, 0                           // 000000344E90: CC1A4010 1A02432C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344E98: BF870091
	v_dot2_f32_bf16 v16, v45, v34, v16                         // 000000344E9C: CC1A4010 1C42452D
	v_dot2_f32_bf16 v16, v46, v35, v16                         // 000000344EA4: CC1A4010 1C42472E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000344EAC: BF8700A1
	v_dot2_f32_bf16 v16, v47, v4, v16                          // 000000344EB0: CC1A4010 1C42092F
	s_waitcnt vmcnt(2)                                         // 000000344EB8: BF890BF7
	v_dot2_f32_bf16 v16, v48, v36, v16                         // 000000344EBC: CC1A4010 1C424930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344EC4: BF870091
	v_dot2_f32_bf16 v16, v49, v37, v16                         // 000000344EC8: CC1A4010 1C424B31
	v_dot2_f32_bf16 v16, v50, v38, v16                         // 000000344ED0: CC1A4010 1C424D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000344ED8: BF8700A1
	v_dot2_f32_bf16 v16, v51, v5, v16                          // 000000344EDC: CC1A4010 1C420B33
	s_waitcnt vmcnt(1)                                         // 000000344EE4: BF8907F7
	v_dot2_f32_bf16 v16, v52, v15, v16                         // 000000344EE8: CC1A4010 1C421F34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344EF0: BF870091
	v_dot2_f32_bf16 v16, v53, v39, v16                         // 000000344EF4: CC1A4010 1C424F35
	v_dot2_f32_bf16 v16, v54, v40, v16                         // 000000344EFC: CC1A4010 1C425136
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000344F04: BF8700A1
	v_dot2_f32_bf16 v16, v55, v6, v16                          // 000000344F08: CC1A4010 1C420D37
	s_waitcnt vmcnt(0)                                         // 000000344F10: BF8903F7
	v_dot2_f32_bf16 v16, v56, v41, v16                         // 000000344F14: CC1A4010 1C425338
	.long 0xd7000038                                           // 000000344F1C: D7000038
	v_cndmask_b32_e32 v0, v60, v10, vcc_lo                     // 000000344F20: 0200153C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000344F24: BF8701B2
	v_dot2_f32_bf16 v16, v57, v42, v16                         // 000000344F28: CC1A4010 1C425539
	v_add_co_ci_u32_e64 v57, null, s11, v61, s0                // 000000344F30: D5207C39 00027A0B
	.long 0xd700003e                                           // 000000344F38: D700003E
	v_cndmask_b32_e32 v0, v60, v4, vcc_lo                      // 000000344F3C: 0200093C
	v_dot2_f32_bf16 v16, v58, v43, v16                         // 000000344F40: CC1A4010 1C42573A
	v_add_co_ci_u32_e64 v63, null, s5, v61, s0                 // 000000344F48: D5207C3F 00027A05
	s_delay_alu instid0(VALU_DEP_2)                            // 000000344F50: BF870002
	v_dot2_f32_bf16 v16, v59, v7, v16                          // 000000344F54: CC1A4010 1C420F3B
	s_clause 0x3                                               // 000000344F5C: BF850003
	global_load_b128 v[44:47], v[56:57], off                   // 000000344F60: DC5E0000 2C7C0038
	global_load_b128 v[48:51], v[56:57], off offset:16         // 000000344F68: DC5E0010 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:32         // 000000344F70: DC5E0020 347C0038
	global_load_b128 v[56:59], v[56:57], off offset:48         // 000000344F78: DC5E0030 387C0038
	v_add_f32_e32 v23, v23, v16                                // 000000344F80: 062E2117
	s_waitcnt vmcnt(3)                                         // 000000344F84: BF890FF7
	v_dot2_f32_bf16 v16, v44, v33, 0                           // 000000344F88: CC1A4010 1A02432C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344F90: BF870091
	v_dot2_f32_bf16 v16, v45, v34, v16                         // 000000344F94: CC1A4010 1C42452D
	v_dot2_f32_bf16 v16, v46, v35, v16                         // 000000344F9C: CC1A4010 1C42472E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000344FA4: BF8700A1
	v_dot2_f32_bf16 v16, v47, v4, v16                          // 000000344FA8: CC1A4010 1C42092F
	s_waitcnt vmcnt(2)                                         // 000000344FB0: BF890BF7
	v_dot2_f32_bf16 v16, v48, v36, v16                         // 000000344FB4: CC1A4010 1C424930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344FBC: BF870091
	v_dot2_f32_bf16 v16, v49, v37, v16                         // 000000344FC0: CC1A4010 1C424B31
	v_dot2_f32_bf16 v16, v50, v38, v16                         // 000000344FC8: CC1A4010 1C424D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000344FD0: BF8700A1
	v_dot2_f32_bf16 v16, v51, v5, v16                          // 000000344FD4: CC1A4010 1C420B33
	s_waitcnt vmcnt(1)                                         // 000000344FDC: BF8907F7
	v_dot2_f32_bf16 v16, v52, v15, v16                         // 000000344FE0: CC1A4010 1C421F34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000344FE8: BF870091
	v_dot2_f32_bf16 v16, v53, v39, v16                         // 000000344FEC: CC1A4010 1C424F35
	v_dot2_f32_bf16 v16, v54, v40, v16                         // 000000344FF4: CC1A4010 1C425136
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000344FFC: BF8700A1
	v_dot2_f32_bf16 v16, v55, v6, v16                          // 000000345000: CC1A4010 1C420D37
	s_waitcnt vmcnt(0)                                         // 000000345008: BF8903F7
	v_dot2_f32_bf16 v16, v56, v41, v16                         // 00000034500C: CC1A4010 1C425338
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000345014: BF870091
	v_dot2_f32_bf16 v16, v57, v42, v16                         // 000000345018: CC1A4010 1C425539
	v_dot2_f32_bf16 v16, v58, v43, v16                         // 000000345020: CC1A4010 1C42573A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000345028: BF870001
	v_dot2_f32_bf16 v16, v59, v7, v16                          // 00000034502C: CC1A4010 1C420F3B
	s_clause 0x3                                               // 000000345034: BF850003
	global_load_b128 v[44:47], v[62:63], off                   // 000000345038: DC5E0000 2C7C003E
	global_load_b128 v[48:51], v[62:63], off offset:16         // 000000345040: DC5E0010 307C003E
	global_load_b128 v[52:55], v[62:63], off offset:32         // 000000345048: DC5E0020 347C003E
	global_load_b128 v[56:59], v[62:63], off offset:48         // 000000345050: DC5E0030 387C003E
	v_add_f32_e32 v22, v22, v16                                // 000000345058: 062C2116
	s_waitcnt vmcnt(3)                                         // 00000034505C: BF890FF7
	v_dot2_f32_bf16 v16, v44, v33, 0                           // 000000345060: CC1A4010 1A02432C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000345068: BF870091
	v_dot2_f32_bf16 v16, v45, v34, v16                         // 00000034506C: CC1A4010 1C42452D
	v_dot2_f32_bf16 v16, v46, v35, v16                         // 000000345074: CC1A4010 1C42472E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034507C: BF8700A1
	v_dot2_f32_bf16 v16, v47, v4, v16                          // 000000345080: CC1A4010 1C42092F
	s_waitcnt vmcnt(2)                                         // 000000345088: BF890BF7
	v_dot2_f32_bf16 v16, v48, v36, v16                         // 00000034508C: CC1A4010 1C424930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000345094: BF870091
	v_dot2_f32_bf16 v16, v49, v37, v16                         // 000000345098: CC1A4010 1C424B31
	v_dot2_f32_bf16 v16, v50, v38, v16                         // 0000003450A0: CC1A4010 1C424D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003450A8: BF8700A1
	v_dot2_f32_bf16 v16, v51, v5, v16                          // 0000003450AC: CC1A4010 1C420B33
	s_waitcnt vmcnt(1)                                         // 0000003450B4: BF8907F7
	v_dot2_f32_bf16 v16, v52, v15, v16                         // 0000003450B8: CC1A4010 1C421F34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003450C0: BF870091
	v_dot2_f32_bf16 v16, v53, v39, v16                         // 0000003450C4: CC1A4010 1C424F35
	v_dot2_f32_bf16 v16, v54, v40, v16                         // 0000003450CC: CC1A4010 1C425136
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003450D4: BF8700A1
	v_dot2_f32_bf16 v16, v55, v6, v16                          // 0000003450D8: CC1A4010 1C420D37
	s_waitcnt vmcnt(0)                                         // 0000003450E0: BF8903F7
	v_dot2_f32_bf16 v16, v56, v41, v16                         // 0000003450E4: CC1A4010 1C425338
	.long 0xd7000038                                           // 0000003450EC: D7000038
	v_cndmask_b32_e32 v0, v60, v16, vcc_lo                     // 0000003450F0: 0200213C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003450F4: BF870122
	v_dot2_f32_bf16 v16, v57, v42, v16                         // 0000003450F8: CC1A4010 1C425539
	v_add_co_ci_u32_e64 v57, null, s14, v61, s0                // 000000345100: D5207C39 00027A0E
	v_dot2_f32_bf16 v16, v58, v43, v16                         // 000000345108: CC1A4010 1C42573A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000345110: BF870001
	v_dot2_f32_bf16 v16, v59, v7, v16                          // 000000345114: CC1A4010 1C420F3B
	s_clause 0x3                                               // 00000034511C: BF850003
	global_load_b128 v[44:47], v[56:57], off                   // 000000345120: DC5E0000 2C7C0038
	global_load_b128 v[48:51], v[56:57], off offset:16         // 000000345128: DC5E0010 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:32         // 000000345130: DC5E0020 347C0038
	global_load_b128 v[56:59], v[56:57], off offset:48         // 000000345138: DC5E0030 387C0038
	v_add_f32_e32 v21, v21, v16                                // 000000345140: 062A2115
	s_waitcnt vmcnt(3)                                         // 000000345144: BF890FF7
	v_dot2_f32_bf16 v16, v44, v33, 0                           // 000000345148: CC1A4010 1A02432C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000345150: BF870091
	v_dot2_f32_bf16 v16, v45, v34, v16                         // 000000345154: CC1A4010 1C42452D
	v_dot2_f32_bf16 v16, v46, v35, v16                         // 00000034515C: CC1A4010 1C42472E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000345164: BF8700A1
	v_dot2_f32_bf16 v16, v47, v4, v16                          // 000000345168: CC1A4010 1C42092F
	s_waitcnt vmcnt(2)                                         // 000000345170: BF890BF7
	v_dot2_f32_bf16 v16, v48, v36, v16                         // 000000345174: CC1A4010 1C424930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034517C: BF870091
	v_dot2_f32_bf16 v16, v49, v37, v16                         // 000000345180: CC1A4010 1C424B31
	v_dot2_f32_bf16 v16, v50, v38, v16                         // 000000345188: CC1A4010 1C424D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000345190: BF8700A1
	v_dot2_f32_bf16 v16, v51, v5, v16                          // 000000345194: CC1A4010 1C420B33
	s_waitcnt vmcnt(1)                                         // 00000034519C: BF8907F7
	v_dot2_f32_bf16 v16, v52, v15, v16                         // 0000003451A0: CC1A4010 1C421F34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003451A8: BF870091
	v_dot2_f32_bf16 v16, v53, v39, v16                         // 0000003451AC: CC1A4010 1C424F35
	v_dot2_f32_bf16 v16, v54, v40, v16                         // 0000003451B4: CC1A4010 1C425136
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003451BC: BF8700A1
	v_dot2_f32_bf16 v16, v55, v6, v16                          // 0000003451C0: CC1A4010 1C420D37
	s_waitcnt vmcnt(0)                                         // 0000003451C8: BF8903F7
	v_dot2_f32_bf16 v16, v56, v41, v16                         // 0000003451CC: CC1A4010 1C425338
	.long 0xd7000038                                           // 0000003451D4: D7000038
	v_cndmask_b32_e32 v0, v62, v4, vcc_lo                      // 0000003451D8: 0200093E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003451DC: BF870122
	v_dot2_f32_bf16 v16, v57, v42, v16                         // 0000003451E0: CC1A4010 1C425539
	v_add_co_ci_u32_e64 v57, null, s5, v63, s0                 // 0000003451E8: D5207C39 00027E05
	v_dot2_f32_bf16 v16, v58, v43, v16                         // 0000003451F0: CC1A4010 1C42573A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003451F8: BF870001
	v_dot2_f32_bf16 v16, v59, v7, v16                          // 0000003451FC: CC1A4010 1C420F3B
	s_clause 0x3                                               // 000000345204: BF850003
	global_load_b128 v[44:47], v[56:57], off                   // 000000345208: DC5E0000 2C7C0038
	global_load_b128 v[48:51], v[56:57], off offset:16         // 000000345210: DC5E0010 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:32         // 000000345218: DC5E0020 347C0038
	global_load_b128 v[56:59], v[56:57], off offset:48         // 000000345220: DC5E0030 387C0038
	v_add_f32_e32 v20, v20, v16                                // 000000345228: 06282114
	s_waitcnt vmcnt(3)                                         // 00000034522C: BF890FF7
	v_dot2_f32_bf16 v16, v44, v33, 0                           // 000000345230: CC1A4010 1A02432C
	v_mov_b32_e32 v44, v32                                     // 000000345238: 7E580320
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034523C: BF870092
	v_dot2_f32_bf16 v16, v45, v34, v16                         // 000000345240: CC1A4010 1C42452D
	v_dot2_f32_bf16 v16, v46, v35, v16                         // 000000345248: CC1A4010 1C42472E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000345250: BF870131
	v_dot2_f32_bf16 v4, v47, v4, v16                           // 000000345254: CC1A4004 1C42092F
	v_mov_b32_e32 v16, v14                                     // 00000034525C: 7E20030E
	s_waitcnt vmcnt(2)                                         // 000000345260: BF890BF7
	v_dot2_f32_bf16 v4, v48, v36, v4                           // 000000345264: CC1A4004 1C124930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034526C: BF870091
	v_dot2_f32_bf16 v4, v49, v37, v4                           // 000000345270: CC1A4004 1C124B31
	v_dot2_f32_bf16 v4, v50, v38, v4                           // 000000345278: CC1A4004 1C124D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000345280: BF870131
	v_dot2_f32_bf16 v4, v51, v5, v4                            // 000000345284: CC1A4004 1C120B33
	v_mov_b32_e32 v5, v1                                       // 00000034528C: 7E0A0301
	s_waitcnt vmcnt(1)                                         // 000000345290: BF8907F7
	v_dot2_f32_bf16 v4, v52, v15, v4                           // 000000345294: CC1A4004 1C121F34
	v_mov_b32_e32 v15, v13                                     // 00000034529C: 7E1E030D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003452A0: BF870092
	v_dot2_f32_bf16 v4, v53, v39, v4                           // 0000003452A4: CC1A4004 1C124F35
	v_dot2_f32_bf16 v4, v54, v40, v4                           // 0000003452AC: CC1A4004 1C125136
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003452B4: BF870131
	v_dot2_f32_bf16 v4, v55, v6, v4                            // 0000003452B8: CC1A4004 1C120D37
	v_mov_b32_e32 v6, v2                                       // 0000003452C0: 7E0C0302
	s_waitcnt vmcnt(0)                                         // 0000003452C4: BF8903F7
	v_dot2_f32_bf16 v4, v56, v41, v4                           // 0000003452C8: CC1A4004 1C125338
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003452D0: BF870091
	v_dot2_f32_bf16 v4, v57, v42, v4                           // 0000003452D4: CC1A4004 1C125539
	v_dot2_f32_bf16 v4, v58, v43, v4                           // 0000003452DC: CC1A4004 1C12573A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003452E4: BF870091
	v_dot2_f32_bf16 v4, v59, v7, v4                            // 0000003452E8: CC1A4004 1C120F3B
	v_dual_mov_b32 v7, v3 :: v_dual_add_f32 v18, v18, v4       // 0000003452F0: CA080103 07120912
	v_mov_b32_e32 v4, v0                                       // 0000003452F8: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000003452FC: 917E0F7E
	s_cbranch_execz 38                                         // 000000345300: BFA50026 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi32ELi1EEEvPKhPKtPtll+0x109c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000345304: BF8701B1
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v31, 32, v31    // 000000345308: CA200104 001E3EA0
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 000000345310: CA100105 01020106
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v14, v16           // 000000345318: CA100107 030E0110
	.long 0xd4430000                                           // 000000345320: D4430000
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 000000345324: 02023E0C
	v_mov_b32_e32 v13, v15                                     // 000000345328: 7E1A030F
	s_mov_b32 s17, exec_lo                                     // 00000034532C: BE91007E
	.long 0xd4c4007e                                           // 000000345330: D4C4007E
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 000000345334: 02023E0C
	s_cbranch_execz 64643                                      // 000000345338: BFA5FC83 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi32ELi1EEEvPKhPKtPtll+0x248>
	v_and_b32_e32 v2, 0x7ffffffc, v30                          // 00000034533C: 36043CFF 7FFFFFFC
	.long 0xd7000100                                           // 000000345344: D7000100
	v_cndmask_b32_e32 v1, v10, v28, vcc_lo                     // 000000345348: 0202390A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034534C: BF8700A1
	v_add_co_ci_u32_e64 v1, null, 0, v19, s1                   // 000000345350: D5207C01 00062680
	.long 0xd700010d                                           // 000000345358: D700010D
	v_cndmask_b32_e32 v1, v24, v29, vcc_lo                     // 00000034535C: 02023B18
	v_add_co_ci_u32_e64 v14, null, 0, v25, s1                  // 000000345360: D5207C0E 00063280
	.long 0xd7000120                                           // 000000345368: D7000120
	v_cndmask_b32_e32 v1, v26, v2, vcc_lo                      // 00000034536C: 0202051A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000345370: BF870001
	v_add_co_ci_u32_e64 v33, null, 0, v27, s1                  // 000000345374: D5207C21 00063680
	s_clause 0x2                                               // 00000034537C: BF850002
	global_load_b128 v[0:3], v[0:1], off                       // 000000345380: DC5E0000 007C0000
	global_load_b64 v[13:14], v[13:14], off                    // 000000345388: DC560000 0D7C000D
	global_load_b32 v32, v[32:33], off                         // 000000345390: DC520000 207C0020
	s_branch 64619                                             // 000000345398: BFA0FC6B <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi32ELi1EEEvPKhPKtPtll+0x248>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000034539C: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003453A0: BF8700A9
	s_or_b32 exec_lo, exec_lo, s13                             // 0000003453A4: 8C7E0D7E
	.long 0xd71f0000                                           // 0000003453A8: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003453AC: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000003453B0: 3A020090
	s_waitcnt vmcnt(2)                                         // 0000003453B4: BF890BF7
	v_xor_b32_e32 v6, 8, v0                                    // 0000003453B8: 3A0C0088
	v_xor_b32_e32 v13, 4, v0                                   // 0000003453BC: 3A1A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003453C0: BF870093
	.long 0xd44c0000                                           // 0000003453C4: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000003453C8: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000003453CC: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003453D4: BF870114
	.long 0xd44c0000                                           // 0000003453D8: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 0000003453DC: 02020CA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000003453E0: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003453E4: BF870002
	v_cndmask_b32_e64 v6, v0, v6, s0                           // 0000003453E8: D5010006 00020D00
	.long 0xd44c0000                                           // 0000003453F0: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 0000003453F4: 02021AA0
	ds_bpermute_b32 v2, v1, v23                                // 0000003453F8: DACC0000 02001701
	v_cndmask_b32_e64 v13, v0, v13, s0                         // 000000345400: D501000D 00021B00
	s_waitcnt lgkmcnt(0)                                       // 000000345408: BF89FC07
	v_add_f32_e32 v2, v23, v2                                  // 00000034540C: 06040517
	ds_bpermute_b32 v4, v1, v21                                // 000000345410: DACC0000 04001501
	ds_bpermute_b32 v3, v1, v22                                // 000000345418: DACC0000 03001601
	ds_bpermute_b32 v5, v1, v20                                // 000000345420: DACC0000 05001401
	ds_bpermute_b32 v1, v1, v18                                // 000000345428: DACC0000 01001201
	v_lshlrev_b32_e32 v6, 2, v6                                // 000000345430: 300C0C82
	s_waitcnt lgkmcnt(2)                                       // 000000345434: BF89FC27
	v_dual_add_f32 v4, v21, v4 :: v_dual_add_f32 v3, v22, v3   // 000000345438: C9080915 04020716
	s_waitcnt lgkmcnt(1)                                       // 000000345440: BF89FC17
	v_add_f32_e32 v5, v20, v5                                  // 000000345444: 060A0B14
	ds_bpermute_b32 v7, v6, v2                                 // 000000345448: DACC0000 07000206
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000345450: 301A1A82
	ds_bpermute_b32 v11, v6, v4                                // 000000345454: DACC0000 0B000406
	s_waitcnt lgkmcnt(2)                                       // 00000034545C: BF89FC27
	v_add_f32_e32 v1, v18, v1                                  // 000000345460: 06020312
	ds_bpermute_b32 v10, v6, v3                                // 000000345464: DACC0000 0A000306
	ds_bpermute_b32 v12, v6, v5                                // 00000034546C: DACC0000 0C000506
	s_waitcnt lgkmcnt(3)                                       // 000000345474: BF89FC37
	v_add_f32_e32 v2, v2, v7                                   // 000000345478: 06040F02
	s_waitcnt lgkmcnt(2)                                       // 00000034547C: BF89FC27
	v_add_f32_e32 v4, v4, v11                                  // 000000345480: 06081704
	ds_bpermute_b32 v6, v6, v1                                 // 000000345484: DACC0000 06000106
	s_waitcnt lgkmcnt(0)                                       // 00000034548C: BF89FC07
	v_add_f32_e32 v1, v1, v6                                   // 000000345490: 06020D01
	ds_bpermute_b32 v6, v13, v2                                // 000000345494: DACC0000 0600020D
	v_add_f32_e32 v5, v5, v12                                  // 00000034549C: 060A1905
	ds_bpermute_b32 v12, v13, v1                               // 0000003454A0: DACC0000 0C00010D
	v_add_f32_e32 v3, v3, v10                                  // 0000003454A8: 06061503
	ds_bpermute_b32 v10, v13, v4                               // 0000003454AC: DACC0000 0A00040D
	s_waitcnt lgkmcnt(2)                                       // 0000003454B4: BF89FC27
	v_add_f32_e32 v2, v2, v6                                   // 0000003454B8: 06040D02
	ds_bpermute_b32 v11, v13, v5                               // 0000003454BC: DACC0000 0B00050D
	v_xor_b32_e32 v6, 1, v0                                    // 0000003454C4: 3A0C0081
	s_waitcnt lgkmcnt(1)                                       // 0000003454C8: BF89FC17
	v_add_f32_e32 v4, v4, v10                                  // 0000003454CC: 06081504
	v_add_f32_e32 v10, v1, v12                                 // 0000003454D0: 06141901
	ds_bpermute_b32 v7, v13, v3                                // 0000003454D4: DACC0000 0700030D
	v_xor_b32_e32 v13, 2, v0                                   // 0000003454DC: 3A1A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003454E0: BF870091
	.long 0xd44c0000                                           // 0000003454E4: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 0000003454E8: 02021AA0
	v_cndmask_b32_e64 v13, v0, v13, s0                         // 0000003454EC: D501000D 00021B00
	.long 0xd44c0000                                           // 0000003454F4: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 0000003454F8: 02020CA0
	s_waitcnt lgkmcnt(1)                                       // 0000003454FC: BF89FC17
	v_add_f32_e32 v5, v5, v11                                  // 000000345500: 060A1705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000345504: BF870193
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000345508: 301A1A82
	v_cndmask_b32_e64 v0, v0, v6, s0                           // 00000034550C: D5010000 00020D00
	.long 0xd44a0000                                           // 000000345514: D44A0000
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000345518: 02022280
	ds_bpermute_b32 v11, v13, v4                               // 00000034551C: DACC0000 0B00040D
	v_lshlrev_b32_e32 v14, 2, v0                               // 000000345524: 301C0082
	s_and_b32 s0, s0, vcc_lo                                   // 000000345528: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 00000034552C: BF89FC07
	v_add_f32_e32 v0, v4, v11                                  // 000000345530: 06001704
	ds_bpermute_b32 v1, v13, v2                                // 000000345534: DACC0000 0100020D
	v_add_f32_e32 v3, v3, v7                                   // 00000034553C: 06060F03
	ds_bpermute_b32 v12, v13, v5                               // 000000345540: DACC0000 0C00050D
	s_waitcnt lgkmcnt(1)                                       // 000000345548: BF89FC17
	v_add_f32_e32 v6, v2, v1                                   // 00000034554C: 060C0302
	ds_bpermute_b32 v7, v13, v3                                // 000000345550: DACC0000 0700030D
	ds_bpermute_b32 v13, v13, v10                              // 000000345558: DACC0000 0D000A0D
	s_waitcnt lgkmcnt(2)                                       // 000000345560: BF89FC27
	v_add_f32_e32 v1, v5, v12                                  // 000000345564: 06021905
	ds_bpermute_b32 v2, v14, v0                                // 000000345568: DACC0000 0200000E
	s_waitcnt lgkmcnt(1)                                       // 000000345570: BF89FC17
	v_dual_add_f32 v7, v3, v7 :: v_dual_add_f32 v4, v10, v13   // 000000345574: C9080F03 07041B0A
	ds_bpermute_b32 v10, v14, v6                               // 00000034557C: DACC0000 0A00060E
	ds_bpermute_b32 v3, v14, v1                                // 000000345584: DACC0000 0300010E
	ds_bpermute_b32 v11, v14, v7                               // 00000034558C: DACC0000 0B00070E
	ds_bpermute_b32 v5, v14, v4                                // 000000345594: DACC0000 0500040E
	s_and_saveexec_b32 s1, s0                                  // 00000034559C: BE812000
	s_cbranch_execz 72                                         // 0000003455A0: BFA50048 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi32ELi1EEEvPKhPKtPtll+0x13c4>
	s_waitcnt lgkmcnt(1)                                       // 0000003455A4: BF89FC17
	v_dual_add_f32 v11, v7, v11 :: v_dual_add_f32 v10, v6, v10 // 0000003455A8: C9081707 0B0A1506
	.long 0x7f183880                                           // 0000003455B0: 7F183880
	.long 0xd73c0006                                           // 0000003455B4: D73C0006
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000003455B8: 02021081
	s_waitcnt lgkmcnt(0)                                       // 0000003455BC: BF89FC07
	v_dual_add_f32 v14, v4, v5 :: v_dual_add_f32 v3, v1, v3    // 0000003455C0: C9080B04 0E020701
	.long 0x7e1a398a                                           // 0000003455C8: 7E1A398A
	.long 0x7f1a398c                                           // 0000003455CC: 7F1A398C
	.long 0x7e18398b                                           // 0000003455D0: 7E18398B
	.long 0xd7006a04                                           // 0000003455D4: D7006A04
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 0000003455D8: 02020C08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003455DC: BF8701B3
	v_dual_add_f32 v2, v0, v2 :: v_dual_and_b32 v9, 1, v13     // 0000003455E0: C9240500 02081A81
	v_add_co_ci_u32_e64 v5, null, s9, v7, vcc_lo               // 0000003455E8: D5207C05 01AA0E09
	.long 0x7f00398c                                           // 0000003455F0: 7F00398C
	.long 0x7e003982                                           // 0000003455F4: 7E003982
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000003455F8: 84808102
	v_and_b32_e32 v8, 1, v12                                   // 0000003455FC: 36101881
	.long 0x7e183983                                           // 000000345600: 7E183983
	.long 0xd7006a06                                           // 000000345604: D7006A06
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 000000345608: 02000104
	v_and_b32_e32 v13, 1, v0                                   // 00000034560C: 361A0081
	v_mad_u64_u32 v[0:1], null, s2, 6, v[4:5]                  // 000000345610: D6FE7C00 04110C02
	v_add_co_ci_u32_e64 v7, null, s1, v5, vcc_lo               // 000000345618: D5207C07 01AA0A01
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000345620: 84808202
	v_add3_u32 v11, v11, v8, 0x7fff                            // 000000345624: D655000B 03FE110B 00007FFF
	.long 0xd7006a08                                           // 000000345630: D7006A08
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 000000345634: 02000104
	v_and_b32_e32 v12, 1, v12                                  // 000000345638: 36181881
	v_add3_u32 v10, v10, v9, 0x7fff                            // 00000034563C: D655000A 03FE130A 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000345648: BF8907F7
	v_bfe_u32 v15, v14, 16, 1                                  // 00000034564C: D610000F 0205210E
	v_add_co_ci_u32_e64 v9, null, s1, v5, vcc_lo               // 000000345654: D5207C09 01AA0A01
	v_add3_u32 v13, v2, v13, 0x7fff                            // 00000034565C: D655000D 03FE1B02 00007FFF
	v_mad_u64_u32 v[1:2], null, s3, 6, v[1:2]                  // 000000345668: D6FE7C01 04050C03
	.long 0xd7006a02                                           // 000000345670: D7006A02
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 000000345674: 02000108
	v_add3_u32 v12, v3, v12, 0x7fff                            // 000000345678: D655000C 03FE1903 00007FFF
	v_add3_u32 v14, v14, v15, 0x7fff                           // 000000345684: D655000E 03FE1F0E 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v9, vcc_lo               // 000000345690: D5207C03 01AA1201
	s_clause 0x4                                               // 000000345698: BF850004
	global_store_d16_hi_b16 v[4:5], v10, off                   // 00000034569C: DC960000 007C0A04
	global_store_d16_hi_b16 v[6:7], v11, off                   // 0000003456A4: DC960000 007C0B06
	global_store_d16_hi_b16 v[8:9], v13, off                   // 0000003456AC: DC960000 007C0D08
	global_store_d16_hi_b16 v[0:1], v12, off                   // 0000003456B4: DC960000 007C0C00
	global_store_d16_hi_b16 v[2:3], v14, off                   // 0000003456BC: DC960000 007C0E02
	s_endpgm                                                   // 0000003456C4: BFB00000
		...

