0000000000721b00 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi1ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi1ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000721B00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000721B04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000721B0C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 000000721B14: BE830080
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000721B18: 32020085
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000721B1C: 84808302
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 000000721B20: CA100080 08080080
	v_dual_mov_b32 v2, s1 :: v_dual_and_b32 v7, 31, v0         // 000000721B28: CA240001 0206009F
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 000000721B30: CA100080 0A0A0080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 000000721B38: CA100080 0C0C0080
	v_or_b32_e32 v1, s0, v1                                    // 000000721B40: 38020200
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v15, 0             // 000000721B44: CA100080 0E0E0080
	s_waitcnt lgkmcnt(0)                                       // 000000721B4C: BF89FC07
	s_ashr_i32 s1, s11, 31                                     // 000000721B50: 86019F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000721B54: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000721B58: 7CA8020C
	s_lshr_b32 s1, s1, 28                                      // 000000721B5C: 85019C01
	s_add_u32 s0, s10, s1                                      // 000000721B60: 8000010A
	s_addc_u32 s1, s11, 0                                      // 000000721B64: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000721B68: BF870009
	s_lshr_b64 s[14:15], s[0:1], 4                             // 000000721B6C: 858E8400
	s_mov_b32 s1, exec_lo                                      // 000000721B70: BE81007E
	.long 0xd4c4007e                                           // 000000721B74: D4C4007E
	v_cndmask_b32_e32 v1, s14, v7, vcc_lo                      // 000000721B78: 02020E0E
	s_cbranch_execz 664                                        // 000000721B7C: BFA50298 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi1ELb1EEEvPKhPKtPvll+0xae0>
	s_ashr_i32 s0, s11, 31                                     // 000000721B80: 86009F0B
	v_dual_cndmask_b32 v3, 0, v2 :: v_dual_and_b32 v16, 6, v0  // 000000721B84: CA640480 03100086
	s_lshr_b32 s0, s0, 24                                      // 000000721B8C: 85009800
	v_cndmask_b32_e32 v5, 0, v1, vcc_lo                        // 000000721B90: 020A0280
	s_add_u32 s16, s10, s0                                     // 000000721B94: 8010000A
	s_addc_u32 s17, s11, 0                                     // 000000721B98: 8211800B
	v_bfe_u32 v9, v0, 3, 1                                     // 000000721B9C: D6100009 02050700
	s_ashr_i64 s[16:17], s[16:17], 8                           // 000000721BA4: 86908810
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v17, 4, v0          // 000000721BA8: CA240080 06100084
	s_mul_i32 s0, s17, 0xd2                                    // 000000721BB0: 9600FF11 000000D2
	s_mul_hi_u32 s2, s16, 0xd2                                 // 000000721BB8: 9682FF10 000000D2
	s_mul_i32 s15, s16, 0xd2                                   // 000000721BC0: 960FFF10 000000D2
	s_add_i32 s2, s2, s0                                       // 000000721BC8: 81020002
	.long 0xd72c0008                                           // 000000721BCC: D72C0008
	v_cndmask_b32_e32 v1, s15, v3, vcc_lo                      // 000000721BD0: 0202060F
	v_and_b32_e32 v0, 15, v0                                   // 000000721BD4: 3600008F
	v_mad_u64_u32 v[3:4], null, s15, v5, s[4:5]                // 000000721BD8: D6FE7C03 00120A0F
	.long 0xd72c0005                                           // 000000721BE0: D72C0005
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 000000721BE4: 02020A02
	v_dual_mov_b32 v27, v7 :: v_dual_lshlrev_b32 v18, 6, v9    // 000000721BE8: CA220107 1B121286
	v_dual_mov_b32 v14, v6 :: v_dual_lshlrev_b32 v19, 5, v9    // 000000721BF0: CA220106 0E121285
	v_or_b32_e32 v20, 8, v17                                   // 000000721BF8: 38282288
	v_or_b32_e32 v21, 8, v16                                   // 000000721BFC: 382A2088
	v_or_b32_e32 v22, 16, v17                                  // 000000721C00: 382C2290
	v_add3_u32 v4, v5, v4, v8                                  // 000000721C04: D6550004 04220905
	v_lshrrev_b32_e32 v8, 4, v7                                // 000000721C0C: 32100E84
	v_or_b32_e32 v23, 16, v16                                  // 000000721C10: 382E2090
	v_or_b32_e32 v24, 24, v17                                  // 000000721C14: 38302298
	v_or_b32_e32 v25, 24, v16                                  // 000000721C18: 38322098
	v_dual_mov_b32 v12, v6 :: v_dual_lshlrev_b32 v5, 4, v7     // 000000721C1C: CA220106 0C040E84
	v_mul_u32_u24_e32 v26, 0xd2, v8                            // 000000721C24: 163410FF 000000D2
	v_mov_b32_e32 v15, v6                                      // 000000721C2C: 7E1E0306
	v_mov_b32_e32 v13, v6                                      // 000000721C30: 7E1A0306
	v_mov_b32_e32 v11, v6                                      // 000000721C34: 7E160306
	v_mov_b32_e32 v10, v6                                      // 000000721C38: 7E140306
	v_mov_b32_e32 v9, v6                                       // 000000721C3C: 7E120306
	v_mov_b32_e32 v8, v6                                       // 000000721C40: 7E100306
	s_mul_i32 s0, s11, 6                                       // 000000721C44: 9600860B
	s_mul_hi_u32 s2, s10, 6                                    // 000000721C48: 9682860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000721C4C: 8484820A
	s_add_i32 s2, s2, s0                                       // 000000721C50: 81020002
	s_mul_i32 s15, s10, 6                                      // 000000721C54: 960F860A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000721C58: 848A810A
	.long 0xd700001c                                           // 000000721C5C: D700001C
	v_cndmask_b32_e32 v1, v3, v26, vcc_lo                      // 000000721C60: 02023503
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000721C64: BF8701A1
	v_add_co_ci_u32_e64 v29, null, 0, v4, s0                   // 000000721C68: D5207C1D 00020880
	v_and_b32_e32 v32, 32, v5                                  // 000000721C70: 36400AA0
	.long 0xd700001e                                           // 000000721C74: D700001E
	v_cndmask_b32_e32 v1, v28, v18, vcc_lo                     // 000000721C78: 0202251C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000721C7C: BF8701A1
	v_add_co_ci_u32_e64 v31, null, 0, v29, s0                  // 000000721C80: D5207C1F 00023A80
	v_and_b32_e32 v36, 16, v5                                  // 000000721C88: 36480A90
	.long 0xd700001e                                           // 000000721C8C: D700001E
	v_cndmask_b32_e32 v1, v30, v32, vcc_lo                     // 000000721C90: 0202411E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000721C94: BF8701A1
	v_add_co_ci_u32_e64 v31, null, 0, v31, s0                  // 000000721C98: D5207C1F 00023E80
	v_add_nc_u32_e32 v26, 0x1a4, v26                           // 000000721CA0: 4A3434FF 000001A4
	.long 0xd700001e                                           // 000000721CA8: D700001E
	v_cndmask_b32_e32 v1, v30, v36, vcc_lo                     // 000000721CAC: 0202491E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000721CB0: BF8700C1
	v_add_co_ci_u32_e64 v31, null, 0, v31, s0                  // 000000721CB4: D5207C1F 00023E80
	v_add_nc_u32_e32 v27, 32, v27                              // 000000721CBC: 4A3636A0
	global_load_b128 v[32:35], v[30:31], off                   // 000000721CC0: DC5E0000 207C001E
	.long 0xd700001e                                           // 000000721CC8: D700001E
	v_cndmask_b32_e32 v1, v28, v19, vcc_lo                     // 000000721CCC: 0202271C
	v_add_co_ci_u32_e64 v31, null, 0, v29, s0                  // 000000721CD0: D5207C1F 00023A80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721CD8: BF870092
	.long 0xd700001e                                           // 000000721CDC: D700001E
	v_cndmask_b32_e32 v1, v30, v36, vcc_lo                     // 000000721CE0: 0202491E
	v_add_co_ci_u32_e64 v31, null, 0, v31, s0                  // 000000721CE4: D5207C1F 00023E80
	global_load_b128 v[36:39], v[30:31], off offset:128        // 000000721CEC: DC5E0080 247C001E
	.long 0xd700001e                                           // 000000721CF4: D700001E
	v_cndmask_b32_e32 v1, v28, v0, vcc_lo                      // 000000721CF8: 0202011C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000721CFC: BF870001
	v_add_co_ci_u32_e64 v31, null, 0, v29, s0                  // 000000721D00: D5207C1F 00023A80
	s_clause 0x1                                               // 000000721D08: BF850001
	global_load_d16_b16 v28, v[28:29], off offset:208          // 000000721D0C: DC8200D0 1C7C001C
	global_load_i8 v30, v[30:31], off offset:192               // 000000721D14: DC4600C0 1E7C001E
	s_waitcnt vmcnt(2)                                         // 000000721D1C: BF890BF7
	v_lshrrev_b32_e32 v29, v16, v36                            // 000000721D20: 323A4910
	v_lshrrev_b32_e32 v31, v23, v36                            // 000000721D24: 323E4917
	s_waitcnt vmcnt(0)                                         // 000000721D28: BF8903F7
	v_cvt_f32_i32_e32 v30, v30                                 // 000000721D2C: 7E3C0B1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000721D30: BF870141
	v_fma_mix_f32 v40, v28, v30, neg(0) op_sel_hi:[1,0,0]      // 000000721D34: CC200028 8A023D1C
	v_bfe_u32 v28, v32, v17, 4                                 // 000000721D3C: D610001C 02122320
	v_lshlrev_b32_e32 v29, 4, v29                              // 000000721D44: 303A3A84
	v_lshlrev_b32_e32 v31, 4, v31                              // 000000721D48: 303E3E84
	v_and_or_b32 v28, v29, 48, v28                             // 000000721D4C: D657001C 0471611D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721D54: BF870091
	v_subrev_nc_u32_e32 v28, 32, v28                           // 000000721D58: 4E3838A0
	v_cvt_f32_i32_e32 v28, v28                                 // 000000721D5C: 7E380B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721D60: BF870091
	v_mul_f32_e32 v28, v40, v28                                // 000000721D64: 10383928
	v_bfe_u32 v29, v28, 16, 1                                  // 000000721D68: D610001D 0205211C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000721D70: BF870131
	v_add3_u32 v30, v28, v29, 0x7fff                           // 000000721D74: D655001E 03FE3B1C 00007FFF
	v_lshrrev_b32_e32 v29, v21, v36                            // 000000721D80: 323A4915
	v_bfe_u32 v28, v32, v20, 4                                 // 000000721D84: D610001C 02122920
	v_lshlrev_b32_e32 v29, 4, v29                              // 000000721D8C: 303A3A84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721D90: BF870091
	v_and_or_b32 v28, v29, 48, v28                             // 000000721D94: D657001C 0471611D
	v_subrev_nc_u32_e32 v28, 32, v28                           // 000000721D9C: 4E3838A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721DA0: BF870091
	v_cvt_f32_i32_e32 v28, v28                                 // 000000721DA4: 7E380B1C
	v_mul_f32_e32 v28, v40, v28                                // 000000721DA8: 10383928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721DAC: BF870091
	v_bfe_u32 v29, v28, 16, 1                                  // 000000721DB0: D610001D 0205211C
	v_add3_u32 v28, v28, v29, 0x7fff                           // 000000721DB8: D655001C 03FE3B1C 00007FFF
	v_bfe_u32 v29, v32, v22, 4                                 // 000000721DC4: D610001D 02122D20
	.long 0x7e38399e                                           // 000000721DCC: 7E38399E
	v_bfe_u32 v30, v33, v17, 4                                 // 000000721DD0: D610001E 02122321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721DD8: BF870093
	v_and_or_b32 v29, v31, 48, v29                             // 000000721DDC: D657001D 0475611F
	v_subrev_nc_u32_e32 v29, 32, v29                           // 000000721DE4: 4E3A3AA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721DE8: BF870091
	v_cvt_f32_i32_e32 v29, v29                                 // 000000721DEC: 7E3A0B1D
	v_mul_f32_e32 v29, v40, v29                                // 000000721DF0: 103A3B28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721DF4: BF870091
	v_bfe_u32 v31, v29, 16, 1                                  // 000000721DF8: D610001F 0205211D
	v_add3_u32 v31, v29, v31, 0x7fff                           // 000000721E00: D655001F 03FE3F1D 00007FFF
	v_bfe_u32 v29, v32, v24, 4                                 // 000000721E0C: D610001D 02123120
	v_lshrrev_b32_e32 v32, v25, v36                            // 000000721E14: 32404919
	v_lshrrev_b32_e32 v36, v23, v37                            // 000000721E18: 32484B17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000721E1C: BF870112
	v_lshlrev_b32_e32 v32, 4, v32                              // 000000721E20: 30404084
	v_lshlrev_b32_e32 v36, 4, v36                              // 000000721E24: 30484884
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721E28: BF870092
	v_and_or_b32 v29, v32, 48, v29                             // 000000721E2C: D657001D 04756120
	v_subrev_nc_u32_e32 v29, 32, v29                           // 000000721E34: 4E3A3AA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721E38: BF870091
	v_cvt_f32_i32_e32 v29, v29                                 // 000000721E3C: 7E3A0B1D
	v_mul_f32_e32 v29, v40, v29                                // 000000721E40: 103A3B28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721E44: BF870091
	v_bfe_u32 v32, v29, 16, 1                                  // 000000721E48: D6100020 0205211D
	v_add3_u32 v29, v29, v32, 0x7fff                           // 000000721E50: D655001D 03FE411D 00007FFF
	.long 0x7e3a399f                                           // 000000721E5C: 7E3A399F
	v_lshrrev_b32_e32 v31, v16, v37                            // 000000721E60: 323E4B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721E64: BF870091
	v_lshlrev_b32_e32 v31, 4, v31                              // 000000721E68: 303E3E84
	v_and_or_b32 v30, v31, 48, v30                             // 000000721E6C: D657001E 0479611F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721E74: BF870091
	v_subrev_nc_u32_e32 v30, 32, v30                           // 000000721E78: 4E3C3CA0
	v_cvt_f32_i32_e32 v30, v30                                 // 000000721E7C: 7E3C0B1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721E80: BF870091
	v_mul_f32_e32 v30, v40, v30                                // 000000721E84: 103C3D28
	v_bfe_u32 v31, v30, 16, 1                                  // 000000721E88: D610001F 0205211E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000721E90: BF870131
	v_add3_u32 v32, v30, v31, 0x7fff                           // 000000721E94: D6550020 03FE3F1E 00007FFF
	v_lshrrev_b32_e32 v31, v21, v37                            // 000000721EA0: 323E4B15
	v_bfe_u32 v30, v33, v20, 4                                 // 000000721EA4: D610001E 02122921
	v_lshlrev_b32_e32 v31, 4, v31                              // 000000721EAC: 303E3E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721EB0: BF870091
	v_and_or_b32 v30, v31, 48, v30                             // 000000721EB4: D657001E 0479611F
	v_subrev_nc_u32_e32 v30, 32, v30                           // 000000721EBC: 4E3C3CA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721EC0: BF870091
	v_cvt_f32_i32_e32 v30, v30                                 // 000000721EC4: 7E3C0B1E
	v_mul_f32_e32 v30, v40, v30                                // 000000721EC8: 103C3D28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721ECC: BF870091
	v_bfe_u32 v31, v30, 16, 1                                  // 000000721ED0: D610001F 0205211E
	v_add3_u32 v30, v30, v31, 0x7fff                           // 000000721ED8: D655001E 03FE3F1E 00007FFF
	v_bfe_u32 v31, v33, v22, 4                                 // 000000721EE4: D610001F 02122D21
	.long 0x7e3c39a0                                           // 000000721EEC: 7E3C39A0
	v_bfe_u32 v32, v34, v17, 4                                 // 000000721EF0: D6100020 02122322
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721EF8: BF870093
	v_and_or_b32 v31, v36, 48, v31                             // 000000721EFC: D657001F 047D6124
	v_subrev_nc_u32_e32 v31, 32, v31                           // 000000721F04: 4E3E3EA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721F08: BF870091
	v_cvt_f32_i32_e32 v31, v31                                 // 000000721F0C: 7E3E0B1F
	v_mul_f32_e32 v31, v40, v31                                // 000000721F10: 103E3F28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721F14: BF870091
	v_bfe_u32 v36, v31, 16, 1                                  // 000000721F18: D6100024 0205211F
	v_add3_u32 v36, v31, v36, 0x7fff                           // 000000721F20: D6550024 03FE491F 00007FFF
	v_bfe_u32 v31, v33, v24, 4                                 // 000000721F2C: D610001F 02123121
	v_lshrrev_b32_e32 v33, v25, v37                            // 000000721F34: 32424B19
	v_lshrrev_b32_e32 v37, v23, v38                            // 000000721F38: 324A4D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000721F3C: BF870112
	v_lshlrev_b32_e32 v33, 4, v33                              // 000000721F40: 30424284
	v_lshlrev_b32_e32 v37, 4, v37                              // 000000721F44: 304A4A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721F48: BF870092
	v_and_or_b32 v31, v33, 48, v31                             // 000000721F4C: D657001F 047D6121
	v_subrev_nc_u32_e32 v31, 32, v31                           // 000000721F54: 4E3E3EA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721F58: BF870091
	v_cvt_f32_i32_e32 v31, v31                                 // 000000721F5C: 7E3E0B1F
	v_mul_f32_e32 v31, v40, v31                                // 000000721F60: 103E3F28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721F64: BF870091
	v_bfe_u32 v33, v31, 16, 1                                  // 000000721F68: D6100021 0205211F
	v_add3_u32 v31, v31, v33, 0x7fff                           // 000000721F70: D655001F 03FE431F 00007FFF
	v_lshrrev_b32_e32 v33, v16, v38                            // 000000721F7C: 32424D10
	.long 0x7e3e39a4                                           // 000000721F80: 7E3E39A4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721F84: BF870092
	v_lshlrev_b32_e32 v33, 4, v33                              // 000000721F88: 30424284
	v_and_or_b32 v32, v33, 48, v32                             // 000000721F8C: D6570020 04816121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721F94: BF870091
	v_subrev_nc_u32_e32 v32, 32, v32                           // 000000721F98: 4E4040A0
	v_cvt_f32_i32_e32 v32, v32                                 // 000000721F9C: 7E400B20
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721FA0: BF870091
	v_mul_f32_e32 v32, v40, v32                                // 000000721FA4: 10404128
	v_bfe_u32 v33, v32, 16, 1                                  // 000000721FA8: D6100021 02052120
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000721FB0: BF870131
	v_add3_u32 v36, v32, v33, 0x7fff                           // 000000721FB4: D6550024 03FE4320 00007FFF
	v_lshrrev_b32_e32 v33, v21, v38                            // 000000721FC0: 32424D15
	v_bfe_u32 v32, v34, v20, 4                                 // 000000721FC4: D6100020 02122922
	v_lshlrev_b32_e32 v33, 4, v33                              // 000000721FCC: 30424284
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721FD0: BF870091
	v_and_or_b32 v32, v33, 48, v32                             // 000000721FD4: D6570020 04816121
	v_subrev_nc_u32_e32 v32, 32, v32                           // 000000721FDC: 4E4040A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721FE0: BF870091
	v_cvt_f32_i32_e32 v32, v32                                 // 000000721FE4: 7E400B20
	v_mul_f32_e32 v32, v40, v32                                // 000000721FE8: 10404128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000721FEC: BF870091
	v_bfe_u32 v33, v32, 16, 1                                  // 000000721FF0: D6100021 02052120
	v_add3_u32 v32, v32, v33, 0x7fff                           // 000000721FF8: D6550020 03FE4320 00007FFF
	v_bfe_u32 v33, v34, v22, 4                                 // 000000722004: D6100021 02122D22
	.long 0x7e4039a4                                           // 00000072200C: 7E4039A4
	v_lshrrev_b32_e32 v36, v16, v39                            // 000000722010: 32484F10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000722014: BF870113
	v_and_or_b32 v33, v37, 48, v33                             // 000000722018: D6570021 04856125
	v_lshlrev_b32_e32 v36, 4, v36                              // 000000722020: 30484884
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722024: BF870092
	v_subrev_nc_u32_e32 v33, 32, v33                           // 000000722028: 4E4242A0
	v_cvt_f32_i32_e32 v33, v33                                 // 00000072202C: 7E420B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722030: BF870091
	v_mul_f32_e32 v33, v40, v33                                // 000000722034: 10424328
	v_bfe_u32 v37, v33, 16, 1                                  // 000000722038: D6100025 02052121
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000722040: BF870141
	v_add3_u32 v37, v33, v37, 0x7fff                           // 000000722044: D6550025 03FE4B21 00007FFF
	v_bfe_u32 v33, v34, v24, 4                                 // 000000722050: D6100021 02123122
	v_lshrrev_b32_e32 v34, v25, v38                            // 000000722058: 32444D19
	v_lshrrev_b32_e32 v38, v23, v39                            // 00000072205C: 324C4F17
	v_lshlrev_b32_e32 v34, 4, v34                              // 000000722060: 30444484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000722064: BF870112
	v_lshlrev_b32_e32 v38, 4, v38                              // 000000722068: 304C4C84
	v_and_or_b32 v33, v34, 48, v33                             // 00000072206C: D6570021 04856122
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722074: BF870091
	v_subrev_nc_u32_e32 v33, 32, v33                           // 000000722078: 4E4242A0
	v_cvt_f32_i32_e32 v33, v33                                 // 00000072207C: 7E420B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722080: BF870091
	v_mul_f32_e32 v33, v40, v33                                // 000000722084: 10424328
	v_bfe_u32 v34, v33, 16, 1                                  // 000000722088: D6100022 02052121
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000722090: BF8701C1
	v_add3_u32 v33, v33, v34, 0x7fff                           // 000000722094: D6550021 03FE4521 00007FFF
	v_bfe_u32 v34, v35, v17, 4                                 // 0000007220A0: D6100022 02122323
	.long 0x7e4239a5                                           // 0000007220A8: 7E4239A5
	v_lshrrev_b32_e32 v37, v21, v39                            // 0000007220AC: 324A4F15
	v_and_or_b32 v34, v36, 48, v34                             // 0000007220B0: D6570022 04896124
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007220B8: BF870112
	v_lshlrev_b32_e32 v37, 4, v37                              // 0000007220BC: 304A4A84
	v_subrev_nc_u32_e32 v34, 32, v34                           // 0000007220C0: 4E4444A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007220C4: BF870091
	v_cvt_f32_i32_e32 v34, v34                                 // 0000007220C8: 7E440B22
	v_mul_f32_e32 v34, v40, v34                                // 0000007220CC: 10444528
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007220D0: BF870091
	v_bfe_u32 v36, v34, 16, 1                                  // 0000007220D4: D6100024 02052122
	v_add3_u32 v36, v34, v36, 0x7fff                           // 0000007220DC: D6550024 03FE4922 00007FFF
	v_bfe_u32 v34, v35, v20, 4                                 // 0000007220E8: D6100022 02122923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007220F0: BF870091
	v_and_or_b32 v34, v37, 48, v34                             // 0000007220F4: D6570022 04896125
	v_subrev_nc_u32_e32 v34, 32, v34                           // 0000007220FC: 4E4444A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722100: BF870091
	v_cvt_f32_i32_e32 v34, v34                                 // 000000722104: 7E440B22
	v_mul_f32_e32 v34, v40, v34                                // 000000722108: 10444528
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072210C: BF870091
	v_bfe_u32 v37, v34, 16, 1                                  // 000000722110: D6100025 02052122
	v_add3_u32 v34, v34, v37, 0x7fff                           // 000000722118: D6550022 03FE4B22 00007FFF
	v_bfe_u32 v37, v35, v22, 4                                 // 000000722124: D6100025 02122D23
	v_bfe_u32 v35, v35, v24, 4                                 // 00000072212C: D6100023 02123123
	.long 0x7e4439a4                                           // 000000722134: 7E4439A4
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722138: BF870093
	v_and_or_b32 v37, v38, 48, v37                             // 00000072213C: D6570025 04956126
	v_subrev_nc_u32_e32 v37, 32, v37                           // 000000722144: 4E4A4AA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722148: BF870091
	v_cvt_f32_i32_e32 v37, v37                                 // 00000072214C: 7E4A0B25
	v_mul_f32_e32 v37, v40, v37                                // 000000722150: 104A4B28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722154: BF870091
	v_bfe_u32 v38, v37, 16, 1                                  // 000000722158: D6100026 02052125
	v_add3_u32 v37, v37, v38, 0x7fff                           // 000000722160: D6550025 03FE4D25 00007FFF
	v_lshrrev_b32_e32 v38, v25, v39                            // 00000072216C: 324C4F19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722170: BF870091
	v_lshlrev_b32_e32 v38, 4, v38                              // 000000722174: 304C4C84
	v_and_or_b32 v35, v38, 48, v35                             // 000000722178: D6570023 048D6126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722180: BF870091
	v_subrev_nc_u32_e32 v35, 32, v35                           // 000000722184: 4E4646A0
	v_cvt_f32_i32_e32 v35, v35                                 // 000000722188: 7E460B23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072218C: BF870091
	v_mul_f32_e32 v35, v40, v35                                // 000000722190: 10464728
	v_bfe_u32 v38, v35, 16, 1                                  // 000000722194: D6100026 02052123
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000072219C: BF870141
	v_add3_u32 v35, v35, v38, 0x7fff                           // 0000007221A0: D6550023 03FE4D23 00007FFF
	.long 0x7e4639a5                                           // 0000007221AC: 7E4639A5
	.long 0xd73c0024                                           // 0000007221B0: D73C0024
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000007221B4: 02020A81
	v_add_nc_u32_e32 v5, 0x200, v5                             // 0000007221B8: 4A0A0AFF 00000200
	.long 0xd700002c                                           // 0000007221C0: D700002C
	v_cndmask_b32_e32 v1, s6, v36, vcc_lo                      // 0000007221C4: 02024806
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007221C8: BF870001
	v_add_co_ci_u32_e64 v45, null, s7, v37, s0                 // 0000007221CC: D5207C2D 00024A07
	s_clause 0x1                                               // 0000007221D4: BF850001
	global_load_b128 v[36:39], v[44:45], off                   // 0000007221D8: DC5E0000 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:16         // 0000007221E0: DC5E0010 287C002C
	s_waitcnt vmcnt(1)                                         // 0000007221E8: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 0000007221EC: CC1A4024 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007221F4: BF870091
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 0000007221F8: CC1A4024 1C923B25
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 000000722200: CC1A4024 1C923D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000722208: BF8700A1
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 00000072220C: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 000000722214: BF8903F7
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 000000722218: CC1A4024 1C924128
	.long 0xd7000028                                           // 000000722220: D7000028
	v_cndmask_b32_e32 v0, v44, v10, vcc_lo                     // 000000722224: 0200152C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000722228: BF8701B2
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 00000072222C: CC1A4024 1C924329
	v_add_co_ci_u32_e64 v41, null, s11, v45, s0                // 000000722234: D5207C29 00025A0B
	.long 0xd700002e                                           // 00000072223C: D700002E
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 000000722240: 0200092C
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 000000722244: CC1A4024 1C92452A
	v_add_co_ci_u32_e64 v47, null, s5, v45, s0                 // 00000072224C: D5207C2F 00025A05
	.long 0xd700002c                                           // 000000722254: D700002C
	v_cndmask_b32_e32 v0, v44, v15, vcc_lo                     // 000000722258: 02001F2C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000072225C: BF870123
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 000000722260: CC1A4024 1C92472B
	v_add_co_ci_u32_e64 v45, null, s2, v45, s0                 // 000000722268: D5207C2D 00025A02
	v_add_f32_e32 v15, v15, v36                                // 000000722270: 061E490F
	s_clause 0x1                                               // 000000722274: BF850001
	global_load_b128 v[36:39], v[40:41], off                   // 000000722278: DC5E0000 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:16         // 000000722280: DC5E0010 287C0028
	s_waitcnt vmcnt(1)                                         // 000000722288: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 00000072228C: CC1A4024 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722294: BF870091
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 000000722298: CC1A4024 1C923B25
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 0000007222A0: CC1A4024 1C923D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007222A8: BF8700A1
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 0000007222AC: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 0000007222B4: BF8903F7
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 0000007222B8: CC1A4024 1C924128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007222C0: BF870091
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 0000007222C4: CC1A4024 1C924329
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 0000007222CC: CC1A4024 1C92452A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007222D4: BF870091
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 0000007222D8: CC1A4024 1C92472B
	v_add_f32_e32 v14, v14, v36                                // 0000007222E0: 061C490E
	s_clause 0x1                                               // 0000007222E4: BF850001
	global_load_b128 v[36:39], v[46:47], off                   // 0000007222E8: DC5E0000 247C002E
	global_load_b128 v[40:43], v[46:47], off offset:16         // 0000007222F0: DC5E0010 287C002E
	.long 0xd700002e                                           // 0000007222F8: D700002E
	v_cndmask_b32_e32 v0, v46, v4, vcc_lo                      // 0000007222FC: 0200092E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000722300: BF8700B1
	v_add_co_ci_u32_e64 v47, null, s5, v47, s0                 // 000000722304: D5207C2F 00025E05
	s_waitcnt vmcnt(1)                                         // 00000072230C: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 000000722310: CC1A4024 1A023924
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 000000722318: CC1A4024 1C923B25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722320: BF870091
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 000000722324: CC1A4024 1C923D26
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 00000072232C: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 000000722334: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722338: BF870091
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 00000072233C: CC1A4024 1C924128
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 000000722344: CC1A4024 1C924329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072234C: BF870091
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 000000722350: CC1A4024 1C92452A
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 000000722358: CC1A4024 1C92472B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000722360: BF8700D1
	v_add_f32_e32 v13, v13, v36                                // 000000722364: 061A490D
	s_clause 0x1                                               // 000000722368: BF850001
	global_load_b128 v[36:39], v[44:45], off                   // 00000072236C: DC5E0000 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:16         // 000000722374: DC5E0010 287C002C
	.long 0xd700002c                                           // 00000072237C: D700002C
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 000000722380: 0200092C
	v_add_co_ci_u32_e64 v45, null, s5, v45, s0                 // 000000722384: D5207C2D 00025A05
	s_waitcnt vmcnt(1)                                         // 00000072238C: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 000000722390: CC1A4024 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722398: BF870091
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 00000072239C: CC1A4024 1C923B25
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 0000007223A4: CC1A4024 1C923D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007223AC: BF8700A1
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 0000007223B0: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 0000007223B8: BF8903F7
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 0000007223BC: CC1A4024 1C924128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007223C4: BF870091
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 0000007223C8: CC1A4024 1C924329
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 0000007223D0: CC1A4024 1C92452A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007223D8: BF870091
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 0000007223DC: CC1A4024 1C92472B
	v_add_f32_e32 v12, v12, v36                                // 0000007223E4: 0618490C
	s_clause 0x1                                               // 0000007223E8: BF850001
	global_load_b128 v[36:39], v[46:47], off                   // 0000007223EC: DC5E0000 247C002E
	global_load_b128 v[40:43], v[46:47], off offset:16         // 0000007223F4: DC5E0010 287C002E
	s_waitcnt vmcnt(1)                                         // 0000007223FC: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 000000722400: CC1A4024 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722408: BF870091
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 00000072240C: CC1A4024 1C923B25
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 000000722414: CC1A4024 1C923D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000072241C: BF8700A1
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 000000722420: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 000000722428: BF8903F7
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 00000072242C: CC1A4024 1C924128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722434: BF870091
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 000000722438: CC1A4024 1C924329
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 000000722440: CC1A4024 1C92452A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722448: BF870091
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 00000072244C: CC1A4024 1C92472B
	v_add_f32_e32 v11, v11, v36                                // 000000722454: 0616490B
	s_clause 0x1                                               // 000000722458: BF850001
	global_load_b128 v[36:39], v[44:45], off                   // 00000072245C: DC5E0000 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:16         // 000000722464: DC5E0010 287C002C
	s_waitcnt vmcnt(1)                                         // 00000072246C: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 000000722470: CC1A4024 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722478: BF870091
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 00000072247C: CC1A4024 1C923B25
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 000000722484: CC1A4024 1C923D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000072248C: BF8700A1
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 000000722490: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 000000722498: BF8903F7
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 00000072249C: CC1A4024 1C924128
	.long 0xd7000028                                           // 0000007224A4: D7000028
	v_cndmask_b32_e32 v0, v46, v4, vcc_lo                      // 0000007224A8: 0200092E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007224AC: BF870122
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 0000007224B0: CC1A4024 1C924329
	v_add_co_ci_u32_e64 v41, null, s5, v47, s0                 // 0000007224B8: D5207C29 00025E05
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 0000007224C0: CC1A4024 1C92452A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007224C8: BF870091
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 0000007224CC: CC1A4024 1C92472B
	v_add_f32_e32 v10, v10, v36                                // 0000007224D4: 0614490A
	s_clause 0x1                                               // 0000007224D8: BF850001
	global_load_b128 v[36:39], v[40:41], off                   // 0000007224DC: DC5E0000 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:16         // 0000007224E4: DC5E0010 287C0028
	s_waitcnt vmcnt(1)                                         // 0000007224EC: BF8907F7
	v_dot2_f32_bf16 v36, v36, v28, 0                           // 0000007224F0: CC1A4024 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007224F8: BF870091
	v_dot2_f32_bf16 v36, v37, v29, v36                         // 0000007224FC: CC1A4024 1C923B25
	v_dot2_f32_bf16 v36, v38, v30, v36                         // 000000722504: CC1A4024 1C923D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000072250C: BF8700A1
	v_dot2_f32_bf16 v36, v39, v31, v36                         // 000000722510: CC1A4024 1C923F27
	s_waitcnt vmcnt(0)                                         // 000000722518: BF8903F7
	v_dot2_f32_bf16 v36, v40, v32, v36                         // 00000072251C: CC1A4024 1C924128
	.long 0xd7000028                                           // 000000722524: D7000028
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 000000722528: 0200092C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000072252C: BF8701B2
	v_dot2_f32_bf16 v36, v41, v33, v36                         // 000000722530: CC1A4024 1C924329
	v_add_co_ci_u32_e64 v41, null, s5, v45, s0                 // 000000722538: D5207C29 00025A05
	.long 0xd4430000                                           // 000000722540: D4430000
	v_cndmask_b32_e32 v1, s14, v27, vcc_lo                     // 000000722544: 0202360E
	v_dot2_f32_bf16 v36, v42, v34, v36                         // 000000722548: CC1A4024 1C92452A
	s_or_b32 s3, s0, s3                                        // 000000722550: 8C030300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722554: BF870091
	v_dot2_f32_bf16 v36, v43, v35, v36                         // 000000722558: CC1A4024 1C92472B
	v_add_f32_e32 v9, v9, v36                                  // 000000722560: 06124909
	s_clause 0x1                                               // 000000722564: BF850001
	global_load_b128 v[36:39], v[40:41], off                   // 000000722568: DC5E0000 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:16         // 000000722570: DC5E0010 287C0028
	s_waitcnt vmcnt(1)                                         // 000000722578: BF8907F7
	v_dot2_f32_bf16 v28, v36, v28, 0                           // 00000072257C: CC1A401C 1A023924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000722584: BF870091
	v_dot2_f32_bf16 v28, v37, v29, v28                         // 000000722588: CC1A401C 1C723B25
	v_dot2_f32_bf16 v28, v38, v30, v28                         // 000000722590: CC1A401C 1C723D26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000722598: BF8700A1
	v_dot2_f32_bf16 v28, v39, v31, v28                         // 00000072259C: CC1A401C 1C723F27
	s_waitcnt vmcnt(0)                                         // 0000007225A4: BF8903F7
	v_dot2_f32_bf16 v28, v40, v32, v28                         // 0000007225A8: CC1A401C 1C724128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007225B0: BF870091
	v_dot2_f32_bf16 v28, v41, v33, v28                         // 0000007225B4: CC1A401C 1C724329
	v_dot2_f32_bf16 v28, v42, v34, v28                         // 0000007225BC: CC1A401C 1C72452A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007225C4: BF870091
	v_dot2_f32_bf16 v28, v43, v35, v28                         // 0000007225C8: CC1A401C 1C72472B
	v_add_f32_e32 v8, v8, v28                                  // 0000007225D0: 06103908
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000007225D4: 917E037E
	s_cbranch_execnz 64928                                     // 0000007225D8: BFA6FDA0 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi1ELb1EEEvPKhPKtPvll+0x15c>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007225DC: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007225E0: BF8700A9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007225E4: 8C7E017E
	.long 0xd71f0000                                           // 0000007225E8: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007225EC: 020100C1
	v_xor_b32_e32 v3, 16, v0                                   // 0000007225F0: 3A060090
	v_xor_b32_e32 v20, 8, v0                                   // 0000007225F4: 3A280088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007225F8: BF870092
	.long 0xd44c0000                                           // 0000007225FC: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 000000722600: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 000000722604: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000072260C: BF870113
	.long 0xd44c0000                                           // 000000722610: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 000000722614: 020228A0
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000722618: 30060682
	s_delay_alu instid0(VALU_DEP_2)                            // 00000072261C: BF870002
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 000000722620: D5010014 00022900
	ds_bpermute_b32 v4, v3, v15                                // 000000722628: DACC0000 04000F03
	s_waitcnt lgkmcnt(0)                                       // 000000722630: BF89FC07
	v_add_f32_e32 v4, v15, v4                                  // 000000722634: 0608090F
	ds_bpermute_b32 v5, v3, v14                                // 000000722638: DACC0000 05000E03
	ds_bpermute_b32 v6, v3, v13                                // 000000722640: DACC0000 06000D03
	ds_bpermute_b32 v16, v3, v12                               // 000000722648: DACC0000 10000C03
	ds_bpermute_b32 v17, v3, v11                               // 000000722650: DACC0000 11000B03
	ds_bpermute_b32 v18, v3, v10                               // 000000722658: DACC0000 12000A03
	ds_bpermute_b32 v19, v3, v9                                // 000000722660: DACC0000 13000903
	ds_bpermute_b32 v3, v3, v8                                 // 000000722668: DACC0000 03000803
	s_waitcnt lgkmcnt(6)                                       // 000000722670: BF89FC67
	v_dual_add_f32 v5, v14, v5 :: v_dual_lshlrev_b32 v20, 2, v20// 000000722674: C9220B0E 05142882
	s_waitcnt lgkmcnt(5)                                       // 00000072267C: BF89FC57
	v_add_f32_e32 v6, v13, v6                                  // 000000722680: 060C0D0D
	s_waitcnt lgkmcnt(3)                                       // 000000722684: BF89FC37
	v_dual_add_f32 v12, v12, v16 :: v_dual_add_f32 v11, v11, v17// 000000722688: C908210C 0C0A230B
	s_waitcnt lgkmcnt(1)                                       // 000000722690: BF89FC17
	v_dual_add_f32 v10, v10, v18 :: v_dual_add_f32 v9, v9, v19 // 000000722694: C908250A 0A082709
	s_waitcnt lgkmcnt(0)                                       // 00000072269C: BF89FC07
	v_add_f32_e32 v3, v8, v3                                   // 0000007226A0: 06060708
	ds_bpermute_b32 v13, v20, v5                               // 0000007226A4: DACC0000 0D000514
	ds_bpermute_b32 v8, v20, v4                                // 0000007226AC: DACC0000 08000414
	ds_bpermute_b32 v14, v20, v6                               // 0000007226B4: DACC0000 0E000614
	ds_bpermute_b32 v15, v20, v12                              // 0000007226BC: DACC0000 0F000C14
	ds_bpermute_b32 v16, v20, v11                              // 0000007226C4: DACC0000 10000B14
	ds_bpermute_b32 v17, v20, v10                              // 0000007226CC: DACC0000 11000A14
	ds_bpermute_b32 v18, v20, v9                               // 0000007226D4: DACC0000 12000914
	ds_bpermute_b32 v19, v20, v3                               // 0000007226DC: DACC0000 13000314
	v_xor_b32_e32 v20, 4, v0                                   // 0000007226E4: 3A280084
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007226E8: BF870091
	.long 0xd44c0000                                           // 0000007226EC: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 0000007226F0: 020228A0
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 0000007226F4: D5010014 00022900
	s_waitcnt lgkmcnt(6)                                       // 0000007226FC: BF89FC67
	v_dual_add_f32 v5, v5, v13 :: v_dual_add_f32 v4, v4, v8    // 000000722700: C9081B05 05041104
	s_waitcnt lgkmcnt(5)                                       // 000000722708: BF89FC57
	v_add_f32_e32 v6, v6, v14                                  // 00000072270C: 060C1D06
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000722710: 30282882
	s_waitcnt lgkmcnt(2)                                       // 000000722714: BF89FC27
	v_dual_add_f32 v11, v11, v16 :: v_dual_add_f32 v10, v10, v17// 000000722718: C908210B 0B0A230A
	s_waitcnt lgkmcnt(1)                                       // 000000722720: BF89FC17
	v_add_f32_e32 v9, v9, v18                                  // 000000722724: 06122509
	s_waitcnt lgkmcnt(0)                                       // 000000722728: BF89FC07
	v_add_f32_e32 v3, v3, v19                                  // 00000072272C: 06062703
	ds_bpermute_b32 v13, v20, v5                               // 000000722730: DACC0000 0D000514
	v_add_f32_e32 v8, v12, v15                                 // 000000722738: 06101F0C
	ds_bpermute_b32 v16, v20, v11                              // 00000072273C: DACC0000 10000B14
	ds_bpermute_b32 v12, v20, v4                               // 000000722744: DACC0000 0C000414
	ds_bpermute_b32 v14, v20, v6                               // 00000072274C: DACC0000 0E000614
	ds_bpermute_b32 v17, v20, v10                              // 000000722754: DACC0000 11000A14
	ds_bpermute_b32 v18, v20, v9                               // 00000072275C: DACC0000 12000914
	ds_bpermute_b32 v19, v20, v3                               // 000000722764: DACC0000 13000314
	s_waitcnt lgkmcnt(6)                                       // 00000072276C: BF89FC67
	v_add_f32_e32 v5, v5, v13                                  // 000000722770: 060A1B05
	ds_bpermute_b32 v15, v20, v8                               // 000000722774: DACC0000 0F000814
	v_xor_b32_e32 v20, 2, v0                                   // 00000072277C: 3A280082
	s_waitcnt lgkmcnt(3)                                       // 000000722780: BF89FC37
	v_dual_add_f32 v11, v11, v16 :: v_dual_add_f32 v10, v10, v17// 000000722784: C908210B 0B0A230A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000072278C: BF870132
	.long 0xd44c0000                                           // 000000722790: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 000000722794: 020228A0
	s_waitcnt lgkmcnt(1)                                       // 000000722798: BF89FC17
	v_add_f32_e32 v16, v3, v19                                 // 00000072279C: 06202703
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 0000007227A0: D5010014 00022900
	s_waitcnt lgkmcnt(0)                                       // 0000007227A8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007227AC: BF870001
	v_dual_add_f32 v13, v8, v15 :: v_dual_lshlrev_b32 v20, 2, v20// 0000007227B0: C9221F08 0D142882
	ds_bpermute_b32 v17, v20, v11                              // 0000007227B8: DACC0000 11000B14
	v_add_f32_e32 v4, v4, v12                                  // 0000007227C0: 06081904
	v_add_f32_e32 v12, v6, v14                                 // 0000007227C4: 06181D06
	v_xor_b32_e32 v6, 1, v0                                    // 0000007227C8: 3A0C0081
	ds_bpermute_b32 v8, v20, v5                                // 0000007227CC: DACC0000 08000514
	ds_bpermute_b32 v15, v20, v13                              // 0000007227D4: DACC0000 0F000D14
	ds_bpermute_b32 v3, v20, v4                                // 0000007227DC: DACC0000 03000414
	.long 0xd44c0000                                           // 0000007227E4: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 0000007227E8: 02020CA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007227EC: BF870121
	v_cndmask_b32_e64 v0, v0, v6, s0                           // 0000007227F0: D5010000 00020D00
	.long 0xd44a0000                                           // 0000007227F8: D44A0000
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                        // 0000007227FC: 02020E80
	v_dual_add_f32 v14, v9, v18 :: v_dual_lshlrev_b32 v21, 2, v0// 000000722800: C9222509 0E140082
	ds_bpermute_b32 v9, v20, v12                               // 000000722808: DACC0000 09000C14
	ds_bpermute_b32 v18, v20, v10                              // 000000722810: DACC0000 12000A14
	s_and_b32 s0, s0, vcc_lo                                   // 000000722818: 8B006A00
	s_waitcnt lgkmcnt(3)                                       // 00000072281C: BF89FC37
	v_add_f32_e32 v0, v13, v15                                 // 000000722820: 06001F0D
	s_waitcnt lgkmcnt(2)                                       // 000000722824: BF89FC27
	v_dual_add_f32 v6, v4, v3 :: v_dual_add_f32 v3, v11, v17   // 000000722828: C9080704 0602230B
	ds_bpermute_b32 v4, v21, v0                                // 000000722830: DACC0000 04000015
	ds_bpermute_b32 v11, v21, v6                               // 000000722838: DACC0000 0B000615
	s_waitcnt lgkmcnt(3)                                       // 000000722840: BF89FC37
	v_add_f32_e32 v9, v12, v9                                  // 000000722844: 0612130C
	ds_bpermute_b32 v19, v20, v14                              // 000000722848: DACC0000 13000E14
	ds_bpermute_b32 v20, v20, v16                              // 000000722850: DACC0000 14001014
	v_add_f32_e32 v8, v5, v8                                   // 000000722858: 06101105
	s_waitcnt lgkmcnt(4)                                       // 00000072285C: BF89FC47
	v_add_f32_e32 v10, v10, v18                                // 000000722860: 0614250A
	ds_bpermute_b32 v13, v21, v9                               // 000000722864: DACC0000 0D000915
	ds_bpermute_b32 v5, v21, v3                                // 00000072286C: DACC0000 05000315
	s_waitcnt lgkmcnt(2)                                       // 000000722874: BF89FC27
	v_dual_add_f32 v15, v14, v19 :: v_dual_add_f32 v16, v16, v20// 000000722878: C908270E 0F102910
	ds_bpermute_b32 v12, v21, v8                               // 000000722880: DACC0000 0C000815
	ds_bpermute_b32 v14, v21, v10                              // 000000722888: DACC0000 0E000A15
	ds_bpermute_b32 v17, v21, v15                              // 000000722890: DACC0000 11000F15
	ds_bpermute_b32 v18, v21, v16                              // 000000722898: DACC0000 12001015
	s_and_saveexec_b32 s1, s0                                  // 0000007228A0: BE812000
	s_cbranch_execz 68                                         // 0000007228A4: BFA50044 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi1ELb1EEEvPKhPKtPvll+0xeb8>
	.long 0xd73c0001                                           // 0000007228A8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000007228AC: 02020282
	s_waitcnt lgkmcnt(0)                                       // 0000007228B0: BF89FC07
	v_dual_add_f32 v16, v16, v18 :: v_dual_add_f32 v15, v15, v17// 0000007228B4: C9082510 100E230F
	v_dual_add_f32 v12, v8, v12 :: v_dual_add_f32 v17, v6, v11 // 0000007228BC: C9081908 0C101706
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000007228C4: 8480820C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007228C8: BF870093
	.long 0xd7006a06                                           // 0000007228CC: D7006A06
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000007228D0: 02020208
	v_add_co_ci_u32_e64 v7, null, s9, v2, vcc_lo               // 0000007228D4: D5207C07 01AA0409
	v_dual_add_f32 v14, v10, v14 :: v_dual_add_f32 v13, v9, v13// 0000007228DC: C9081D0A 0E0C1B09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007228E4: BF870193
	.long 0xd7006a08                                           // 0000007228E8: D7006A08
	v_cndmask_b32_e32 v0, v6, v0, vcc_lo                       // 0000007228EC: 02000106
	v_mad_u64_u32 v[1:2], null, s12, 12, v[6:7]                // 0000007228F0: D6FE7C01 0419180C
	v_add_co_ci_u32_e64 v9, null, s1, v7, vcc_lo               // 0000007228F8: D5207C09 01AA0E01
	s_lshl_b64 s[0:1], s[12:13], 3                             // 000000722900: 8480830C
	v_add_f32_e32 v18, v3, v5                                  // 000000722904: 06240B03
	.long 0xd7006a0a                                           // 000000722908: D7006A0A
	v_cndmask_b32_e32 v0, v6, v0, vcc_lo                       // 00000072290C: 02000106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000722910: BF8701A1
	v_add_co_ci_u32_e64 v11, null, s1, v7, vcc_lo              // 000000722914: D5207C0B 01AA0E01
	v_mad_u64_u32 v[2:3], null, s13, 12, v[2:3]                // 00000072291C: D6FE7C02 0409180D
	.long 0xd7006a03                                           // 000000722924: D7006A03
	v_cndmask_b32_e32 v0, v10, v0, vcc_lo                      // 000000722928: 0200010A
	v_add_f32_e32 v0, v0, v4                                   // 00000072292C: 06000900
	s_delay_alu instid0(VALU_DEP_4)                            // 000000722930: BF870004
	v_add_co_ci_u32_e64 v4, null, s1, v11, vcc_lo              // 000000722934: D5207C04 01AA1601
	.long 0xd7006a05                                           // 00000072293C: D7006A05
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 000000722940: 02000101
	s_clause 0x2                                               // 000000722944: BF850002
	global_store_b32 v[6:7], v17, off                          // 000000722948: DC6A0000 007C1106
	global_store_b32 v[8:9], v12, off                          // 000000722950: DC6A0000 007C0C08
	global_store_b32 v[10:11], v13, off                        // 000000722958: DC6A0000 007C0D0A
	v_add_co_ci_u32_e64 v6, null, s1, v2, vcc_lo               // 000000722960: D5207C06 01AA0401
	.long 0xd7006a07                                           // 000000722968: D7006A07
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 00000072296C: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000722970: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s1, v4, vcc_lo               // 000000722974: D5207C08 01AA0801
	.long 0xd7006a09                                           // 00000072297C: D7006A09
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 000000722980: 02000105
	v_add_co_ci_u32_e64 v10, null, s1, v6, vcc_lo              // 000000722984: D5207C0A 01AA0C01
	s_clause 0x4                                               // 00000072298C: BF850004
	global_store_b32 v[1:2], v0, off                           // 000000722990: DC6A0000 007C0001
	global_store_b32 v[3:4], v18, off                          // 000000722998: DC6A0000 007C1203
	global_store_b32 v[5:6], v14, off                          // 0000007229A0: DC6A0000 007C0E05
	global_store_b32 v[7:8], v15, off                          // 0000007229A8: DC6A0000 007C0F07
	global_store_b32 v[9:10], v16, off                         // 0000007229B0: DC6A0000 007C1009
	s_endpgm                                                   // 0000007229B8: BFB00000
		...

