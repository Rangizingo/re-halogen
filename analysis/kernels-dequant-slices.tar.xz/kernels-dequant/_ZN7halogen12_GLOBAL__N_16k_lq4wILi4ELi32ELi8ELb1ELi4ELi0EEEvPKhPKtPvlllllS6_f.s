0000000000f90200 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000F90200: F4100100 F8000000
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v1, 15, v0          // 000000F90208: CA240080 0600008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000F90210: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000F90214: 86039F02
	v_mov_b32_e32 v5, 0                                        // 000000F90218: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F9021C: BF870193
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000F90220: CA220080 08000282
	v_and_b32_e32 v2, 60, v2                                   // 000000F90228: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 000000F9022C: 321E0085
	v_dual_mov_b32 v21, 0 :: v_dual_and_b32 v16, 31, v0        // 000000F90230: CA240080 1510009F
	.long 0x7f263880                                           // 000000F90238: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v14, 2, v0     // 000000F9023C: CA220080 110E0082
	s_waitcnt lgkmcnt(0)                                       // 000000F90244: BF89FC07
	s_clause 0x1                                               // 000000F90248: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 000000F9024C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 000000F90254: DC520000 0D040002
	.long 0xd4510000                                           // 000000F9025C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000F90260: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000F90264: 8B007E00
	s_cselect_b32 s22, s3, 0                                   // 000000F90268: 98168003
	s_cselect_b32 s23, s2, 0                                   // 000000F9026C: 98178002
	s_add_u32 s0, s4, s14                                      // 000000F90270: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000F90274: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 000000F90278: 850E9F0B
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v2, s1              // 000000F9027C: CA100080 07020001
	s_add_u32 s14, s10, s14                                    // 000000F90284: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000F90288: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000F9028C: 86149F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000F90290: 868E810E
	s_lshr_b32 s20, s20, 27                                    // 000000F90294: 85149B14
	v_mov_b32_e32 v1, s0                                       // 000000F90298: 7E020200
	s_add_u32 s20, s10, s20                                    // 000000F9029C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 000000F902A0: 8215800B
	s_mul_i32 s19, s19, s23                                    // 000000F902A4: 96131713
	s_lshr_b64 s[20:21], s[20:21], 5                           // 000000F902A8: 85948514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000F902AC: BF870499
	s_add_i32 s21, s20, 7                                      // 000000F902B0: 81158714
	s_ashr_i32 s24, s21, 31                                    // 000000F902B4: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000F902B8: BF870499
	s_lshr_b32 s24, s24, 29                                    // 000000F902BC: 85189D18
	s_add_i32 s21, s21, s24                                    // 000000F902C0: 81151815
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F902C4: BF870009
	s_ashr_i32 s21, s21, 3                                     // 000000F902C8: 86158315
	s_add_u32 s0, s4, s16                                      // 000000F902CC: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000F902D0: 82011105
	.long 0xd72c0012                                           // 000000F902D4: D72C0012
	v_cndmask_b32_e32 v1, s21, v15, vcc_lo                     // 000000F902D8: 02021E15
	v_mov_b32_e32 v4, s1                                       // 000000F902DC: 7E080201
	v_mad_u64_u32 v[9:10], null, s23, s14, v[1:2]              // 000000F902E0: D6FE7C09 04041C17
	v_mov_b32_e32 v3, s0                                       // 000000F902E8: 7E060200
	s_mul_i32 s0, s22, s14                                     // 000000F902EC: 96000E16
	s_waitcnt vmcnt(1)                                         // 000000F902F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 000000F902F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 000000F902FC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 000000F90300: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F90308: BF870112
	v_add3_u32 v2, v11, v12, 0x7fff                            // 000000F9030C: D6550002 03FE190B 00007FFF
	v_add3_u32 v1, v13, v1, 0x7fff                             // 000000F90318: D6550001 03FE030D 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F90324: BF870002
	.long 0x7e263982                                           // 000000F90328: 7E263982
	v_add_nc_u32_e32 v2, s0, v10                               // 000000F9032C: 4A041400
	v_mad_u64_u32 v[11:12], null, s18, s23, v[3:4]             // 000000F90330: D6FE7C0B 040C2E12
	v_add_nc_u32_e32 v3, s21, v18                              // 000000F90338: 4A062415
	v_add_nc_u32_e32 v10, v18, v16                             // 000000F9033C: 4A142112
	s_mul_i32 s23, s23, s15                                    // 000000F90340: 96170F17
	s_mul_i32 s0, s18, s22                                     // 000000F90344: 96001612
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 000000F90348: D6570001 044E02FF FFFF0000
	v_min_i32_e32 v18, s20, v3                                 // 000000F90354: 22240614
	v_add_nc_u32_e32 v19, s23, v2                              // 000000F90358: 4A260417
	v_add_nc_u32_e32 v3, s19, v12                              // 000000F9035C: 4A061813
	ds_store_b32 v14, v1                                       // 000000F90360: D8340000 0000010E
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 000000F90368: 7C82250A
	v_add_nc_u32_e32 v20, s0, v3                               // 000000F9036C: 4A280600
	s_waitcnt lgkmcnt(0)                                       // 000000F90370: BF89FC07
	s_barrier                                                  // 000000F90374: BFBD0000
	buffer_gl0_inv                                             // 000000F90378: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000F90380: BE81206A
	s_cbranch_execz 21                                         // 000000F90384: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v1, 1, v10                               // 000000F90388: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 000000F9038C: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F90390: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000F90394: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000F90398: 3408069F
	.long 0xd7000001                                           // 000000F9039C: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000F903A0: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F903A4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000F903A8: D5207C02 00020514
	.long 0xd7000003                                           // 000000F903B0: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 000000F903B4: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 000000F903B8: D5207C04 00020913
	s_clause 0x1                                               // 000000F903C0: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 000000F903C4: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 000000F903CC: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 000000F903D4: BF8907F7
	v_cvt_f32_f16_e32 v21, v1                                  // 000000F903D8: 7E2A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F903DC: 8C7E017E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 000000F903E0: CA100080 17180080
	v_mov_b32_e32 v22, 0                                       // 000000F903E8: 7E2C0280
	s_and_saveexec_b32 s1, vcc_lo                              // 000000F903EC: BE81206A
	s_cbranch_execz 401                                        // 000000F903F0: BFA50191 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x838>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 000000F903F4: CA200080 160014A0
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 000000F903FC: CA220080 170C1485
	v_mov_b32_e32 v27, v21                                     // 000000F90404: 7E360315
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F90408: BF870003
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v25, 4, v1     // 000000F9040C: CA220080 18180284
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v26, 1, v1     // 000000F90414: CA220080 111A0281
	s_mul_i32 s0, s11, 6                                       // 000000F9041C: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000F90420: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000F90424: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000F90428: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000F9042C: 9610860A
	s_mov_b32 s15, 0                                           // 000000F90430: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000F90434: 848A810A
	s_branch 351                                               // 000000F90438: BFA0015F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x7b8>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000F9043C: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 000000F90440: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000F90448: 8B006A7E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 000000F9044C: 4A3232FF 00000200
	s_or_b32 s15, s0, s15                                      // 000000F90454: 8C0F0F00
	v_add_nc_u32_e32 v26, 64, v26                              // 000000F90458: 4A3434C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000F9045C: 301A1A82
	ds_load_b32 v42, v13                                       // 000000F90460: D8D80000 2A00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000F90468: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F9046C: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000F90470: 361A1AFF 000003FC
	ds_load_b32 v43, v13                                       // 000000F90478: D8D80000 2B00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 000000F90480: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000F90484: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000F90488: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F90490: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F90494: 360A0AFF 000003FC
	ds_load_b32 v44, v13                                       // 000000F9049C: D8D80000 2C00000D
	ds_load_b32 v45, v5                                        // 000000F904A4: D8D80000 2D000005
	v_and_b32_e32 v5, 0xff, v6                                 // 000000F904AC: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000F904B4: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000F904B8: 300A0A82
	ds_load_b32 v46, v5                                        // 000000F904BC: D8D80000 2E000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 000000F904C4: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F904C8: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F904CC: 360A0AFF 000003FC
	ds_load_b32 v47, v5                                        // 000000F904D4: D8D80000 2F000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 000000F904DC: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F904E0: 360A0AFF 000003FC
	ds_load_b32 v48, v5                                        // 000000F904E8: D8D80000 30000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 000000F904F0: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F904F4: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F904F8: 360A0AFF 000003FC
	ds_load_b32 v49, v5                                        // 000000F90500: D8D80000 31000005
	v_and_b32_e32 v5, 0xff, v7                                 // 000000F90508: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000F90510: 300A0A82
	ds_load_b32 v50, v5                                        // 000000F90514: D8D80000 32000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 000000F9051C: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F90520: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F90524: 360A0AFF 000003FC
	ds_load_b32 v51, v5                                        // 000000F9052C: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000F90534: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F90538: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 000000F90540: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 000000F90548: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F9054C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F90550: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 000000F90558: D8D80000 35000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000F90560: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000F90568: 300A0A82
	ds_load_b32 v54, v5                                        // 000000F9056C: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000F90574: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F90578: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F9057C: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 000000F90584: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 000000F9058C: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F90590: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 000000F90598: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 000000F905A0: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F905A4: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F905A8: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 000000F905B0: D8D80000 39000005
	.long 0xd73c0005                                           // 000000F905B8: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000F905BC: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000F905C0: 4A1818FF 00000400
	.long 0xd7006a28                                           // 000000F905C8: D7006A28
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000F905CC: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F905D0: BF870001
	v_add_co_ci_u32_e64 v41, null, s7, v6, vcc_lo              // 000000F905D4: D5207C29 01AA0C07
	s_clause 0x3                                               // 000000F905DC: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 000000F905E0: DC5E0000 057C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 000000F905E8: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 000000F905F0: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 000000F905F8: DC5E0030 247C0028
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000F90600: BF890CF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000F90604: CC1A4005 1A025505
	s_waitcnt lgkmcnt(14)                                      // 000000F9060C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F90610: BF8700A1
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000F90614: CC1A4005 1C165706
	s_waitcnt lgkmcnt(13)                                      // 000000F9061C: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000F90620: CC1A4005 1C165907
	s_waitcnt lgkmcnt(12)                                      // 000000F90628: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9062C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000F90630: CC1A4005 1C165B08
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000F90638: BF8908B7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000F9063C: CC1A4005 1C165D1C
	s_waitcnt lgkmcnt(10)                                      // 000000F90644: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F90648: BF8700A1
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000F9064C: CC1A4005 1C165F1D
	s_waitcnt lgkmcnt(9)                                       // 000000F90654: BF89FC97
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000F90658: CC1A4005 1C16611E
	s_waitcnt lgkmcnt(8)                                       // 000000F90660: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F90664: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000F90668: CC1A4005 1C16631F
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000F90670: BF890477
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000F90674: CC1A4005 1C166520
	s_waitcnt lgkmcnt(6)                                       // 000000F9067C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F90680: BF8700A1
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000F90684: CC1A4005 1C166721
	s_waitcnt lgkmcnt(5)                                       // 000000F9068C: BF89FC57
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000F90690: CC1A4005 1C166922
	s_waitcnt lgkmcnt(4)                                       // 000000F90698: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9069C: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000F906A0: CC1A4005 1C166B23
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000F906A8: BF890037
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000F906AC: CC1A4005 1C166D24
	.long 0xd7006a24                                           // 000000F906B4: D7006A24
	v_cndmask_b32_e32 v0, v40, v10, vcc_lo                     // 000000F906B8: 02001528
	s_waitcnt lgkmcnt(2)                                       // 000000F906BC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000F906C0: BF870132
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000F906C4: CC1A4005 1C166F25
	v_add_co_ci_u32_e64 v37, null, s11, v41, vcc_lo            // 000000F906CC: D5207C25 01AA520B
	s_waitcnt lgkmcnt(1)                                       // 000000F906D4: BF89FC17
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000F906D8: CC1A4005 1C167126
	s_waitcnt lgkmcnt(0)                                       // 000000F906E0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F906E4: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 000000F906E8: CC1A4005 1C167327
	v_fmac_f32_e32 v22, v21, v5                                // 000000F906F0: 562C0B15
	s_clause 0x3                                               // 000000F906F4: BF850003
	global_load_b128 v[5:8], v[36:37], off                     // 000000F906F8: DC5E0000 057C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000F90700: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000F90708: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000F90710: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000F90718: BF890FF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000F9071C: CC1A4005 1A025505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90724: BF870091
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000F90728: CC1A4005 1C165706
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000F90730: CC1A4005 1C165907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F90738: BF8700A1
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000F9073C: CC1A4005 1C165B08
	s_waitcnt vmcnt(2)                                         // 000000F90744: BF890BF7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000F90748: CC1A4005 1C165D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90750: BF870091
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000F90754: CC1A4005 1C165F1D
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000F9075C: CC1A4005 1C16611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F90764: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000F90768: CC1A4005 1C16631F
	s_waitcnt vmcnt(1)                                         // 000000F90770: BF8907F7
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000F90774: CC1A4005 1C166520
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9077C: BF870091
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000F90780: CC1A4005 1C166721
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000F90788: CC1A4005 1C166922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F90790: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000F90794: CC1A4005 1C166B23
	s_waitcnt vmcnt(0)                                         // 000000F9079C: BF8903F7
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000F907A0: CC1A4005 1C166D24
	.long 0xd7006a24                                           // 000000F907A8: D7006A24
	v_cndmask_b32_e32 v0, v40, v4, vcc_lo                      // 000000F907AC: 02000928
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F907B0: BF870122
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000F907B4: CC1A4005 1C166F25
	v_add_co_ci_u32_e64 v37, null, s5, v41, vcc_lo             // 000000F907BC: D5207C25 01AA5205
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000F907C4: CC1A4005 1C167126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F907CC: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 000000F907D0: CC1A4005 1C167327
	v_fmac_f32_e32 v24, v21, v5                                // 000000F907D8: 56300B15
	s_clause 0x3                                               // 000000F907DC: BF850003
	global_load_b128 v[5:8], v[36:37], off                     // 000000F907E0: DC5E0000 057C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000F907E8: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000F907F0: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000F907F8: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000F90800: BF890FF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000F90804: CC1A4005 1A025505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9080C: BF870091
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000F90810: CC1A4005 1C165706
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000F90818: CC1A4005 1C165907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F90820: BF8700A1
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000F90824: CC1A4005 1C165B08
	s_waitcnt vmcnt(2)                                         // 000000F9082C: BF890BF7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000F90830: CC1A4005 1C165D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90838: BF870091
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000F9083C: CC1A4005 1C165F1D
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000F90844: CC1A4005 1C16611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9084C: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000F90850: CC1A4005 1C16631F
	s_waitcnt vmcnt(1)                                         // 000000F90858: BF8907F7
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000F9085C: CC1A4005 1C166520
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90864: BF870091
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000F90868: CC1A4005 1C166721
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000F90870: CC1A4005 1C166922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F90878: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000F9087C: CC1A4005 1C166B23
	s_waitcnt vmcnt(0)                                         // 000000F90884: BF8903F7
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000F90888: CC1A4005 1C166D24
	.long 0xd7006a24                                           // 000000F90890: D7006A24
	v_cndmask_b32_e32 v0, v40, v16, vcc_lo                     // 000000F90894: 02002128
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F90898: BF870122
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000F9089C: CC1A4005 1C166F25
	v_add_co_ci_u32_e64 v37, null, s14, v41, vcc_lo            // 000000F908A4: D5207C25 01AA520E
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000F908AC: CC1A4005 1C167126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F908B4: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 000000F908B8: CC1A4005 1C167327
	v_fmac_f32_e32 v23, v21, v5                                // 000000F908C0: 562E0B15
	s_clause 0x3                                               // 000000F908C4: BF850003
	global_load_b128 v[5:8], v[36:37], off                     // 000000F908C8: DC5E0000 057C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000F908D0: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000F908D8: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000F908E0: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000F908E8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000F908EC: CC1A4005 1A025505
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F908F4: BF870121
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000F908F8: CC1A4005 1C165706
	v_mov_b32_e32 v6, v2                                       // 000000F90900: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000F90904: CC1A4005 1C165907
	v_mov_b32_e32 v7, v3                                       // 000000F9090C: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000F90910: BF870132
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000F90914: CC1A4005 1C165B08
	v_mov_b32_e32 v8, v4                                       // 000000F9091C: 7E100304
	s_waitcnt vmcnt(2)                                         // 000000F90920: BF890BF7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000F90924: CC1A4005 1C165D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9092C: BF870091
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000F90930: CC1A4005 1C165F1D
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000F90938: CC1A4005 1C16611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F90940: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000F90944: CC1A4005 1C16631F
	s_waitcnt vmcnt(1)                                         // 000000F9094C: BF8907F7
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000F90950: CC1A4005 1C166520
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90958: BF870091
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000F9095C: CC1A4005 1C166721
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000F90964: CC1A4005 1C166922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9096C: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000F90970: CC1A4005 1C166B23
	s_waitcnt vmcnt(0)                                         // 000000F90978: BF8903F7
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000F9097C: CC1A4005 1C166D24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90984: BF870091
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000F90988: CC1A4005 1C166F25
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000F90990: CC1A4005 1C167126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90998: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 000000F9099C: CC1A4005 1C167327
	v_fmac_f32_e32 v17, v21, v5                                // 000000F909A4: 56220B15
	v_mov_b32_e32 v5, v1                                       // 000000F909A8: 7E0A0301
	v_mov_b32_e32 v21, v27                                     // 000000F909AC: 7E2A031B
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000F909B0: 917E0F7E
	s_cbranch_execz 31                                         // 000000F909B4: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x834>
	s_waitcnt vmcnt(0)                                         // 000000F909B8: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 000000F909BC: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000F909C4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 000000F909CC: 7E080308
	s_mov_b32 s17, exec_lo                                     // 000000F909D0: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F909D4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 000000F909D8: 7C8C250A
	.long 0xd4c1007e                                           // 000000F909DC: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 000000F909E0: 0202250A
	s_cbranch_execz 65173                                      // 000000F909E4: BFA5FE95 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x23c>
	v_ashrrev_i32_e32 v2, 31, v26                              // 000000F909E8: 3404349F
	v_ashrrev_i32_e32 v4, 31, v25                              // 000000F909EC: 3408329F
	.long 0xd7000001                                           // 000000F909F0: D7000001
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 000000F909F4: 0202350B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F909F8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000F909FC: D5207C02 00020514
	.long 0xd7000003                                           // 000000F90A04: D7000003
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000F90A08: 02023309
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 000000F90A0C: D5207C04 00020913
	s_clause 0x1                                               // 000000F90A14: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 000000F90A18: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000F90A20: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000F90A28: BF8907F7
	v_cvt_f32_f16_e32 v27, v13                                 // 000000F90A2C: 7E36170D
	s_branch 65154                                             // 000000F90A30: BFA0FE82 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x23c>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000F90A34: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F90A38: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F90A3C: 8C7E017E
	.long 0xd71f0001                                           // 000000F90A40: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000F90A44: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000F90A48: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000F90A4C: 3A040290
	s_waitcnt vmcnt(0)                                         // 000000F90A50: BF8903F7
	v_xor_b32_e32 v6, 8, v1                                    // 000000F90A54: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 000000F90A58: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F90A5C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000F90A60: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000F90A64: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000F90A68: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F90A6C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000F90A70: 30040482
	ds_bpermute_b32 v5, v2, v23                                // 000000F90A74: DACC0000 05001702
	s_waitcnt lgkmcnt(0)                                       // 000000F90A7C: BF89FC07
	v_add_f32_e32 v5, v23, v5                                  // 000000F90A80: 060A0B17
	ds_bpermute_b32 v3, v2, v22                                // 000000F90A84: DACC0000 03001602
	ds_bpermute_b32 v4, v2, v24                                // 000000F90A8C: DACC0000 04001802
	ds_bpermute_b32 v2, v2, v17                                // 000000F90A94: DACC0000 02001102
	s_waitcnt lgkmcnt(2)                                       // 000000F90A9C: BF89FC27
	v_dual_add_f32 v3, v22, v3 :: v_dual_cndmask_b32 v6, v1, v6// 000000F90AA0: C9120716 03060D01
	s_waitcnt lgkmcnt(0)                                       // 000000F90AA8: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 000000F90AAC: 06040511
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000F90AB0: 7C9814A0
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F90AB4: BF870003
	v_lshlrev_b32_e32 v6, 2, v6                                // 000000F90AB8: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000F90ABC: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 000000F90AC0: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 000000F90AC8: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 000000F90ACC: 060A1305
	ds_bpermute_b32 v7, v6, v3                                 // 000000F90AD0: DACC0000 07000306
	s_waitcnt lgkmcnt(0)                                       // 000000F90AD8: BF89FC07
	v_dual_add_f32 v3, v3, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 000000F90ADC: C9220F03 030A1482
	v_add_f32_e32 v4, v24, v4                                  // 000000F90AE4: 06080918
	ds_bpermute_b32 v8, v6, v4                                 // 000000F90AE8: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 000000F90AF0: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 000000F90AF8: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 000000F90AFC: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 000000F90B00: DACC0000 0600030A
	s_waitcnt lgkmcnt(0)                                       // 000000F90B08: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 000000F90B0C: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 000000F90B14: DACC0000 0800050A
	s_waitcnt lgkmcnt(0)                                       // 000000F90B1C: BF89FC07
	v_add_f32_e32 v5, v5, v8                                   // 000000F90B20: 060A1105
	ds_bpermute_b32 v7, v10, v4                                // 000000F90B24: DACC0000 0700040A
	ds_bpermute_b32 v9, v10, v2                                // 000000F90B2C: DACC0000 0900020A
	v_xor_b32_e32 v10, 2, v1                                   // 000000F90B34: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F90B38: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000F90B3C: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000F90B40: 02141501
	v_lshlrev_b32_e32 v10, 2, v10                              // 000000F90B44: 30141482
	s_waitcnt lgkmcnt(0)                                       // 000000F90B48: BF89FC07
	v_add_f32_e32 v6, v2, v9                                   // 000000F90B4C: 060C1302
	ds_bpermute_b32 v2, v10, v3                                // 000000F90B50: DACC0000 0200030A
	v_add_f32_e32 v4, v4, v7                                   // 000000F90B58: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 000000F90B5C: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 000000F90B64: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 000000F90B6C: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 000000F90B74: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F90B78: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000F90B7C: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 000000F90B80: 02021501
	s_waitcnt lgkmcnt(3)                                       // 000000F90B84: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 000000F90B88: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 000000F90B90: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 000000F90B94: 06061105
	s_waitcnt lgkmcnt(0)                                       // 000000F90B98: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 000000F90B9C: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 000000F90BA4: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 000000F90BAC: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 000000F90BB4: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 000000F90BBC: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v16                                   // 000000F90BC4: 7D942080
	s_cbranch_execz 9                                          // 000000F90BC8: BFA50009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x9f0>
	s_waitcnt lgkmcnt(1)                                       // 000000F90BCC: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_add_f32 v7, v3, v7     // 000000F90BD0: C9081105 08060F03
	s_waitcnt lgkmcnt(0)                                       // 000000F90BD8: BF89FC07
	v_dual_add_f32 v6, v2, v6 :: v_dual_add_f32 v5, v1, v4     // 000000F90BDC: C9080D02 06040901
	v_lshlrev_b32_e32 v1, 4, v15                               // 000000F90BE4: 30021E84
	ds_store_b128 v1, v[5:8] offset:1024                       // 000000F90BE8: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s0                              // 000000F90BF0: 8C7E007E
	.long 0xd4510000                                           // 000000F90BF4: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000F90BF8: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 4, v0                             // 000000F90BFC: 7C980084
	s_waitcnt lgkmcnt(0)                                       // 000000F90C00: BF89FC07
	s_barrier                                                  // 000000F90C04: BFBD0000
	buffer_gl0_inv                                             // 000000F90C08: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000F90C10: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F90C14: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000F90C18: BE812000
	s_cbranch_execz 74                                         // 000000F90C1C: BFA5004A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xb48>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 000000F90C20: 4A0E1CFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000F90C28: 84808202
	ds_load_2addr_b32 v[1:2], v7 offset1:4                     // 000000F90C2C: D8DC0400 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:8 offset1:12          // 000000F90C34: D8DC0C08 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:16 offset1:20         // 000000F90C3C: D8DC1410 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000F90C44: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000F90C48: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000F90C4C: BF8700C1
	v_add_f32_e32 v8, v1, v2                                   // 000000F90C50: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:24 offset1:28         // 000000F90C54: D8DC1C18 01000007
	s_waitcnt lgkmcnt(2)                                       // 000000F90C5C: BF89FC27
	v_add_f32_e32 v3, v8, v3                                   // 000000F90C60: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 000000F90C64: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000F90C68: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90C6C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000F90C70: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000F90C74: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000F90C78: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90C7C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000F90C80: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000F90C84: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90C88: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000F90C8C: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 000000F90C94: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90C98: BF870095
	v_add_f32_e32 v4, 1.0, v1                                  // 000000F90C9C: 060802F2
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 000000F90CA0: D6FC7C05 03CA0904
	v_div_scale_f32 v7, vcc_lo, 1.0, v4, 1.0                   // 000000F90CA8: D6FC6A07 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000F90CB0: BF870292
	v_rcp_f32_e32 v6, v5                                       // 000000F90CB4: 7E0C5505
	v_fma_f32 v1, -v5, v6, 1.0                                 // 000000F90CB8: D6130001 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F90CC0: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 000000F90CC4: 560C0D01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000F90CC8: D6FE7C01 0202000C
	v_mul_f32_e32 v8, v7, v6                                   // 000000F90CD0: 10100D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F90CD4: BF870112
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000F90CD8: D6FE7C02 040A000D
	v_fma_f32 v9, -v5, v8, v7                                  // 000000F90CE0: D6130009 241E1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F90CE8: BF870191
	v_fmac_f32_e32 v8, v9, v6                                  // 000000F90CEC: 56100D09
	.long 0xd73c0000                                           // 000000F90CF0: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000F90CF4: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90CF8: BF870092
	v_fma_f32 v3, -v5, v8, v7                                  // 000000F90CFC: D6130003 241E1105
	v_div_fmas_f32 v2, v3, v6, v8                              // 000000F90D04: D6370002 04220D03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90D0C: BF870093
	.long 0xd7006a00                                           // 000000F90D10: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000F90D14: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000F90D18: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F90D20: BF870193
	v_div_fixup_f32 v2, v2, v4, 1.0                            // 000000F90D24: D6270002 03CA0902
	.long 0xd7006a00                                           // 000000F90D2C: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000F90D30: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F90D34: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000F90D38: D5207C01 01AA0201
	global_store_b32 v[0:1], v2, off                           // 000000F90D40: DC6A0000 007C0200
	s_endpgm                                                   // 000000F90D48: BFB00000
		...

