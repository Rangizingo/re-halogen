0000000000712b00 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi8ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi8ELb1EEEvPKhPKtPvll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000712B00: F40C0100 F8000000
	v_lshrrev_b32_e32 v5, 5, v0                                // 000000712B08: 320A0085
	v_dual_mov_b32 v11, 0 :: v_dual_and_b32 v6, 31, v0         // 000000712B0C: CA240080 0B06009F
	v_mov_b32_e32 v10, 0                                       // 000000712B14: 7E140280
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v9, 0              // 000000712B18: CA100080 0C080080
	s_waitcnt lgkmcnt(0)                                       // 000000712B20: BF89FC07
	s_ashr_i32 s3, s11, 31                                     // 000000712B24: 86039F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000712B28: BF870499
	s_lshr_b32 s3, s3, 28                                      // 000000712B2C: 85039C03
	s_add_u32 s12, s10, s3                                     // 000000712B30: 800C030A
	s_addc_u32 s13, s11, 0                                     // 000000712B34: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000712B38: BF870499
	s_lshr_b64 s[14:15], s[12:13], 4                           // 000000712B3C: 858E840C
	s_add_i32 s3, s14, 7                                       // 000000712B40: 8103870E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000712B44: BF870499
	s_ashr_i32 s12, s3, 31                                     // 000000712B48: 860C9F03
	s_lshr_b32 s12, s12, 29                                    // 000000712B4C: 850C9D0C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000712B50: BF8704B9
	s_add_i32 s3, s3, s12                                      // 000000712B54: 81030C03
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000712B58: F4040300 F8000020
	s_ashr_i32 s3, s3, 3                                       // 000000712B60: 86038303
	.long 0xd72c0001                                           // 000000712B64: D72C0001
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 000000712B68: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000712B6C: BF870131
	v_add_nc_u32_e32 v2, s3, v1                                // 000000712B70: 4A040203
	v_add_nc_u32_e32 v7, v1, v6                                // 000000712B74: 4A0E0D01
	s_mov_b32 s3, 0                                            // 000000712B78: BE830080
	v_min_i32_e32 v8, s14, v2                                  // 000000712B7C: 2210040E
	s_mov_b32 s14, exec_lo                                     // 000000712B80: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000712B84: BF870001
	.long 0xd4c1007e                                           // 000000712B88: D4C1007E
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                       // 000000712B8C: 02021107
	s_cbranch_execz 465                                        // 000000712B90: BFA501D1 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi8ELb1EEEvPKhPKtPvll+0x7d8>
	s_waitcnt lgkmcnt(0)                                       // 000000712B94: BF89FC07
	.long 0xd4510000                                           // 000000712B98: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000712B9C: 02001802
	v_dual_mov_b32 v10, 0 :: v_dual_lshlrev_b32 v1, 4, v7      // 000000712BA0: CA220080 0A000E84
	v_mov_b32_e32 v11, 0                                       // 000000712BA8: 7E160280
	s_mul_i32 s15, s11, 6                                      // 000000712BAC: 960F860B
	s_mul_hi_u32 s18, s10, 6                                   // 000000712BB0: 9692860A
	s_and_b32 s0, s0, exec_lo                                  // 000000712BB4: 8B007E00
	s_cselect_b32 s16, s2, 0                                   // 000000712BB8: 98108002
	s_cselect_b32 s17, 0, 0                                    // 000000712BBC: 98118080
	s_ashr_i32 s0, s11, 31                                     // 000000712BC0: 86009F0B
	v_mov_b32_e32 v12, 0                                       // 000000712BC4: 7E180280
	s_lshr_b32 s0, s0, 24                                      // 000000712BC8: 85009800
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000712BCC: BF8704A9
	s_add_u32 s0, s10, s0                                      // 000000712BD0: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000712BD4: 8201800B
	s_ashr_i64 s[0:1], s[0:1], 8                               // 000000712BD8: 86808800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000712BDC: BF870009
	s_mul_i32 s17, s0, s17                                     // 000000712BE0: 96111100
	s_mul_hi_u32 s19, s0, s16                                  // 000000712BE4: 96931000
	s_mul_i32 s1, s1, s16                                      // 000000712BE8: 96011001
	s_add_i32 s17, s19, s17                                    // 000000712BEC: 81111113
	s_mul_i32 s0, s0, s16                                      // 000000712BF0: 96001000
	s_add_i32 s1, s17, s1                                      // 000000712BF4: 81010111
	s_mul_hi_u32 s16, s0, 0xd2                                 // 000000712BF8: 9690FF00 000000D2
	s_mulk_i32 s1, 0xd2                                        // 000000712C00: B80100D2
	s_mulk_i32 s0, 0xd2                                        // 000000712C04: B80000D2
	s_add_i32 s16, s16, s1                                     // 000000712C08: 81100110
	s_add_u32 s0, s4, s0                                       // 000000712C0C: 80000004
	s_addc_u32 s1, s5, s16                                     // 000000712C10: 82011005
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000712C14: BF870009
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v4, s1              // 000000712C18: CA100080 09040001
	v_mov_b32_e32 v3, s0                                       // 000000712C20: 7E060200
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000712C24: 8484820A
	s_add_i32 s15, s18, s15                                    // 000000712C28: 810F0F12
	s_mul_i32 s16, s10, 6                                      // 000000712C2C: 9610860A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000712C30: 848A810A
	s_mov_b32 s17, s3                                          // 000000712C34: BE910003
	v_ashrrev_i32_e32 v13, 4, v7                               // 000000712C38: 341A0E84
	v_bfe_u32 v15, v7, 3, 1                                    // 000000712C3C: D610000F 02050707
	v_and_b32_e32 v16, 32, v1                                  // 000000712C44: 362002A0
	v_and_b32_e32 v14, 15, v7                                  // 000000712C48: 361C0E8F
	v_and_b32_e32 v17, 16, v1                                  // 000000712C4C: 36220290
	.long 0xd72c000d                                           // 000000712C50: D72C000D
	v_cndmask_b32_e32 v1, 0xd2, v13, vcc_lo                    // 000000712C54: 02021AFF 000000D2
	v_lshlrev_b32_e32 v18, 6, v15                              // 000000712C5C: 30241E86
	v_lshlrev_b32_e32 v15, 5, v15                              // 000000712C60: 301E1E85
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000712C64: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000712C68: BF8700A4
	v_ashrrev_i32_e32 v19, 31, v13                             // 000000712C6C: 34261A9F
	.long 0xd7006a15                                           // 000000712C70: D7006A15
	v_cndmask_b32_e32 v1, v3, v13, vcc_lo                      // 000000712C74: 02021B03
	v_add_co_ci_u32_e64 v22, null, v4, v19, vcc_lo             // 000000712C78: D5207C16 01AA2704
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000712C80: BF8701A2
	.long 0xd7006a12                                           // 000000712C84: D7006A12
	v_cndmask_b32_e32 v1, v21, v18, vcc_lo                     // 000000712C88: 02022515
	.long 0xd700000f                                           // 000000712C8C: D700000F
	v_cndmask_b32_e32 v1, v21, v15, vcc_lo                     // 000000712C90: 02021F15
	v_add_co_ci_u32_e64 v19, null, 0, v22, vcc_lo              // 000000712C94: D5207C13 01AA2C80
	s_delay_alu instid0(VALU_DEP_3)                            // 000000712C9C: BF870003
	.long 0xd7006a12                                           // 000000712CA0: D7006A12
	v_cndmask_b32_e32 v1, v18, v16, vcc_lo                     // 000000712CA4: 02022112
	v_add_co_ci_u32_e64 v16, null, 0, v22, s0                  // 000000712CA8: D5207C10 00022C80
	.long 0xd700010d                                           // 000000712CB0: D700010D
	v_cndmask_b32_e32 v1, v21, v14, vcc_lo                     // 000000712CB4: 02021D15
	.long 0xd700000f                                           // 000000712CB8: D700000F
	v_cndmask_b32_e32 v1, v15, v17, vcc_lo                     // 000000712CBC: 0202230F
	v_add_co_ci_u32_e64 v19, null, 0, v19, vcc_lo              // 000000712CC0: D5207C13 01AA2680
	v_add_co_ci_u32_e64 v14, null, 0, v22, s1                  // 000000712CC8: D5207C0E 00062C80
	v_add_co_ci_u32_e64 v16, null, 0, v16, s0                  // 000000712CD0: D5207C10 00022080
	.long 0xd7006a11                                           // 000000712CD8: D7006A11
	v_cndmask_b32_e32 v1, v18, v17, vcc_lo                     // 000000712CDC: 02022312
	s_delay_alu instid0(VALU_DEP_1)                            // 000000712CE0: BF870001
	v_add_co_ci_u32_e64 v18, null, 0, v19, vcc_lo              // 000000712CE4: D5207C12 01AA2680
	s_clause 0x3                                               // 000000712CEC: BF850003
	global_load_i8 v53, v[13:14], off offset:192               // 000000712CF0: DC4600C0 357C000D
	global_load_b128 v[13:16], v[15:16], off offset:128        // 000000712CF8: DC5E0080 0D7C000F
	global_load_b128 v[17:20], v[17:18], off                   // 000000712D00: DC5E0000 117C0011
	global_load_d16_b16 v54, v[21:22], off offset:208          // 000000712D08: DC8200D0 367C0015
	.long 0xd73c0015                                           // 000000712D10: D73C0015
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000712D14: 02020281
	v_add_nc_u32_e32 v1, 0x200, v1                             // 000000712D18: 4A0202FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000712D20: BF870092
	.long 0xd7006a25                                           // 000000712D24: D7006A25
	v_cndmask_b32_e32 v1, s6, v21, vcc_lo                      // 000000712D28: 02022A06
	v_add_co_ci_u32_e64 v38, null, s7, v22, vcc_lo             // 000000712D2C: D5207C26 01AA2C07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000712D34: BF870092
	.long 0xd7006a29                                           // 000000712D38: D7006A29
	v_cndmask_b32_e32 v0, v37, v10, vcc_lo                     // 000000712D3C: 02001525
	v_add_co_ci_u32_e64 v42, null, s11, v38, vcc_lo            // 000000712D40: D5207C2A 01AA4C0B
	.long 0xd7006a2d                                           // 000000712D48: D7006A2D
	v_cndmask_b32_e32 v0, v37, v4, vcc_lo                      // 000000712D4C: 02000925
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000712D50: BF8700A1
	v_add_co_ci_u32_e64 v46, null, s5, v38, vcc_lo             // 000000712D54: D5207C2E 01AA4C05
	.long 0xd7006a31                                           // 000000712D5C: D7006A31
	v_cndmask_b32_e32 v0, v37, v16, vcc_lo                     // 000000712D60: 02002125
	v_add_co_ci_u32_e64 v50, null, s15, v38, vcc_lo            // 000000712D64: D5207C32 01AA4C0F
	s_clause 0x7                                               // 000000712D6C: BF850007
	global_load_b128 v[21:24], v[37:38], off                   // 000000712D70: DC5E0000 157C0025
	global_load_b128 v[25:28], v[41:42], off                   // 000000712D78: DC5E0000 197C0029
	global_load_b128 v[29:32], v[45:46], off                   // 000000712D80: DC5E0000 1D7C002D
	global_load_b128 v[33:36], v[49:50], off                   // 000000712D88: DC5E0000 217C0031
	global_load_b128 v[37:40], v[37:38], off offset:16         // 000000712D90: DC5E0010 257C0025
	global_load_b128 v[41:44], v[41:42], off offset:16         // 000000712D98: DC5E0010 297C0029
	global_load_b128 v[45:48], v[45:46], off offset:16         // 000000712DA0: DC5E0010 2D7C002D
	global_load_b128 v[49:52], v[49:50], off offset:16         // 000000712DA8: DC5E0010 317C0031
	s_waitcnt vmcnt(11)                                        // 000000712DB0: BF892FF7
	v_cvt_f32_i32_e32 v53, v53                                 // 000000712DB4: 7E6A0B35
	s_waitcnt vmcnt(8)                                         // 000000712DB8: BF8923F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000712DBC: BF870131
	v_fma_mix_f32 v53, v54, v53, neg(0) op_sel_hi:[1,0,0]      // 000000712DC0: CC200035 8A026B36
	v_and_b32_e32 v55, 6, v7                                   // 000000712DC8: 366E0E86
	v_and_b32_e32 v2, 4, v7                                    // 000000712DCC: 36040E84
	v_or_b32_e32 v59, 16, v55                                  // 000000712DD0: 38766E90
	v_or_b32_e32 v57, 8, v55                                   // 000000712DD4: 38726E88
	s_delay_alu instid0(VALU_DEP_3)                            // 000000712DD8: BF870003
	v_or_b32_e32 v58, 16, v2                                   // 000000712DDC: 38740490
	v_or_b32_e32 v61, 24, v55                                  // 000000712DE0: 387A6E98
	v_lshrrev_b32_e32 v62, v55, v13                            // 000000712DE4: 327C1B37
	v_lshrrev_b32_e32 v64, v59, v13                            // 000000712DE8: 32801B3B
	v_lshrrev_b32_e32 v65, v55, v14                            // 000000712DEC: 32821D37
	v_lshrrev_b32_e32 v67, v59, v14                            // 000000712DF0: 32861D3B
	v_lshrrev_b32_e32 v68, v55, v15                            // 000000712DF4: 32881F37
	v_lshrrev_b32_e32 v70, v59, v15                            // 000000712DF8: 328C1F3B
	v_lshrrev_b32_e32 v55, v55, v16                            // 000000712DFC: 326E2137
	v_lshrrev_b32_e32 v59, v59, v16                            // 000000712E00: 3276213B
	v_or_b32_e32 v56, 8, v2                                    // 000000712E04: 38700488
	v_or_b32_e32 v60, 24, v2                                   // 000000712E08: 38780498
	v_bfe_u32 v54, v17, v2, 4                                  // 000000712E0C: D6100036 02120511
	v_bfe_u32 v71, v17, v58, 4                                 // 000000712E14: D6100047 02127511
	v_bfe_u32 v72, v18, v2, 4                                  // 000000712E1C: D6100048 02120512
	v_bfe_u32 v74, v18, v58, 4                                 // 000000712E24: D610004A 02127512
	v_bfe_u32 v75, v19, v2, 4                                  // 000000712E2C: D610004B 02120513
	v_bfe_u32 v77, v19, v58, 4                                 // 000000712E34: D610004D 02127513
	v_bfe_u32 v2, v20, v2, 4                                   // 000000712E3C: D6100002 02120514
	v_lshlrev_b32_e32 v55, 4, v55                              // 000000712E44: 306E6E84
	v_bfe_u32 v58, v20, v58, 4                                 // 000000712E48: D610003A 02127514
	v_lshlrev_b32_e32 v59, 4, v59                              // 000000712E50: 30767684
	v_lshrrev_b32_e32 v66, v57, v14                            // 000000712E54: 32841D39
	v_lshrrev_b32_e32 v14, v61, v14                            // 000000712E58: 321C1D3D
	v_and_or_b32 v2, v55, 48, v2                               // 000000712E5C: D6570002 04096137
	v_lshrrev_b32_e32 v63, v57, v13                            // 000000712E64: 327E1B39
	v_and_or_b32 v55, v59, 48, v58                             // 000000712E68: D6570037 04E9613B
	v_lshrrev_b32_e32 v69, v57, v15                            // 000000712E70: 328A1F39
	v_lshrrev_b32_e32 v15, v61, v15                            // 000000712E74: 321E1F3D
	v_lshrrev_b32_e32 v57, v57, v16                            // 000000712E78: 32722139
	v_lshrrev_b32_e32 v16, v61, v16                            // 000000712E7C: 3220213D
	v_subrev_nc_u32_e32 v55, 32, v55                           // 000000712E80: 4E6E6EA0
	v_bfe_u32 v73, v18, v56, 4                                 // 000000712E84: D6100049 02127112
	v_bfe_u32 v18, v18, v60, 4                                 // 000000712E8C: D6100012 02127912
	v_lshrrev_b32_e32 v13, v61, v13                            // 000000712E94: 321A1B3D
	v_lshlrev_b32_e32 v61, 4, v62                              // 000000712E98: 307A7C84
	v_cvt_f32_i32_e32 v55, v55                                 // 000000712E9C: 7E6E0B37
	v_lshlrev_b32_e32 v14, 4, v14                              // 000000712EA0: 301C1C84
	v_bfe_u32 v62, v17, v56, 4                                 // 000000712EA4: D610003E 02127111
	v_lshlrev_b32_e32 v68, 4, v68                              // 000000712EAC: 30888884
	v_bfe_u32 v76, v19, v56, 4                                 // 000000712EB0: D610004C 02127113
	v_bfe_u32 v19, v19, v60, 4                                 // 000000712EB8: D6100013 02127913
	v_lshlrev_b32_e32 v15, 4, v15                              // 000000712EC0: 301E1E84
	v_bfe_u32 v56, v20, v56, 4                                 // 000000712EC4: D6100038 02127114
	v_lshlrev_b32_e32 v57, 4, v57                              // 000000712ECC: 30727284
	v_bfe_u32 v20, v20, v60, 4                                 // 000000712ED0: D6100014 02127914
	v_dual_mul_f32 v55, v53, v55 :: v_dual_lshlrev_b32 v16, 4, v16// 000000712ED8: C8E26F35 37102084
	v_and_or_b32 v14, v14, 48, v18                             // 000000712EE0: D657000E 0449610E
	v_and_or_b32 v18, v68, 48, v75                             // 000000712EE8: D6570012 052D6144
	v_and_or_b32 v15, v15, 48, v19                             // 000000712EF0: D657000F 044D610F
	v_and_or_b32 v19, v57, 48, v56                             // 000000712EF8: D6570013 04E16139
	v_and_or_b32 v16, v16, 48, v20                             // 000000712F00: D6570010 04516110
	v_subrev_nc_u32_e32 v14, 32, v14                           // 000000712F08: 4E1C1CA0
	v_subrev_nc_u32_e32 v18, 32, v18                           // 000000712F0C: 4E2424A0
	v_subrev_nc_u32_e32 v15, 32, v15                           // 000000712F10: 4E1E1EA0
	v_subrev_nc_u32_e32 v2, 32, v2                             // 000000712F14: 4E0404A0
	v_subrev_nc_u32_e32 v19, 32, v19                           // 000000712F18: 4E2626A0
	v_subrev_nc_u32_e32 v16, 32, v16                           // 000000712F1C: 4E2020A0
	v_cvt_f32_i32_e32 v14, v14                                 // 000000712F20: 7E1C0B0E
	v_lshlrev_b32_e32 v63, 4, v63                              // 000000712F24: 307E7E84
	v_bfe_u32 v17, v17, v60, 4                                 // 000000712F28: D6100011 02127911
	v_lshlrev_b32_e32 v69, 4, v69                              // 000000712F30: 308A8A84
	v_lshlrev_b32_e32 v70, 4, v70                              // 000000712F34: 308C8C84
	v_and_or_b32 v54, v61, 48, v54                             // 000000712F38: D6570036 04D9613D
	v_cvt_f32_i32_e32 v18, v18                                 // 000000712F40: 7E240B12
	v_lshlrev_b32_e32 v13, 4, v13                              // 000000712F44: 301A1A84
	v_cvt_f32_i32_e32 v15, v15                                 // 000000712F48: 7E1E0B0F
	v_lshlrev_b32_e32 v64, 4, v64                              // 000000712F4C: 30808084
	v_cvt_f32_i32_e32 v2, v2                                   // 000000712F50: 7E040B02
	v_lshlrev_b32_e32 v65, 4, v65                              // 000000712F54: 30828284
	v_cvt_f32_i32_e32 v19, v19                                 // 000000712F58: 7E260B13
	v_lshlrev_b32_e32 v66, 4, v66                              // 000000712F5C: 30848484
	v_cvt_f32_i32_e32 v16, v16                                 // 000000712F60: 7E200B10
	v_dual_mul_f32 v14, v53, v14 :: v_dual_lshlrev_b32 v67, 4, v67// 000000712F64: C8E21D35 0E428684
	v_and_or_b32 v60, v63, 48, v62                             // 000000712F6C: D657003C 04F9613F
	v_subrev_nc_u32_e32 v20, 32, v54                           // 000000712F74: 4E286CA0
	v_mul_f32_e32 v18, v53, v18                                // 000000712F78: 10242535
	v_and_or_b32 v13, v13, 48, v17                             // 000000712F7C: D657000D 0445610D
	v_mul_f32_e32 v15, v53, v15                                // 000000712F84: 101E1F35
	v_and_or_b32 v61, v64, 48, v71                             // 000000712F88: D657003D 051D6140
	v_and_or_b32 v64, v69, 48, v76                             // 000000712F90: D6570040 05316145
	v_mul_f32_e32 v2, v53, v2                                  // 000000712F98: 10040535
	v_and_or_b32 v17, v65, 48, v72                             // 000000712F9C: D6570011 05216141
	v_and_or_b32 v65, v70, 48, v77                             // 000000712FA4: D6570041 05356146
	v_mul_f32_e32 v19, v53, v19                                // 000000712FAC: 10262735
	v_and_or_b32 v62, v66, 48, v73                             // 000000712FB0: D657003E 05256142
	v_mul_f32_e32 v16, v53, v16                                // 000000712FB8: 10202135
	v_and_or_b32 v63, v67, 48, v74                             // 000000712FBC: D657003F 05296143
	v_subrev_nc_u32_e32 v54, 32, v60                           // 000000712FC4: 4E6C78A0
	v_subrev_nc_u32_e32 v56, 32, v61                           // 000000712FC8: 4E707AA0
	v_subrev_nc_u32_e32 v13, 32, v13                           // 000000712FCC: 4E1A1AA0
	v_subrev_nc_u32_e32 v17, 32, v17                           // 000000712FD0: 4E2222A0
	v_subrev_nc_u32_e32 v57, 32, v62                           // 000000712FD4: 4E727CA0
	v_subrev_nc_u32_e32 v58, 32, v63                           // 000000712FD8: 4E747EA0
	v_subrev_nc_u32_e32 v59, 32, v64                           // 000000712FDC: 4E7680A0
	v_subrev_nc_u32_e32 v60, 32, v65                           // 000000712FE0: 4E7882A0
	v_cvt_f32_i32_e32 v20, v20                                 // 000000712FE4: 7E280B14
	v_cvt_f32_i32_e32 v54, v54                                 // 000000712FE8: 7E6C0B36
	v_cvt_f32_i32_e32 v56, v56                                 // 000000712FEC: 7E700B38
	v_cvt_f32_i32_e32 v13, v13                                 // 000000712FF0: 7E1A0B0D
	v_cvt_f32_i32_e32 v17, v17                                 // 000000712FF4: 7E220B11
	v_cvt_f32_i32_e32 v57, v57                                 // 000000712FF8: 7E720B39
	v_cvt_f32_i32_e32 v58, v58                                 // 000000712FFC: 7E740B3A
	v_cvt_f32_i32_e32 v59, v59                                 // 000000713000: 7E760B3B
	v_cvt_f32_i32_e32 v60, v60                                 // 000000713004: 7E780B3C
	v_mul_f32_e32 v20, v53, v20                                // 000000713008: 10282935
	v_dual_mul_f32 v54, v53, v54 :: v_dual_add_nc_u32 v7, 32, v7// 00000071300C: C8E06D35 36060EA0
	v_mul_f32_e32 v58, v53, v58                                // 000000713014: 10747535
	v_mul_f32_e32 v56, v53, v56                                // 000000713018: 10707135
	v_mul_f32_e32 v13, v53, v13                                // 00000071301C: 101A1B35
	v_mul_f32_e32 v17, v53, v17                                // 000000713020: 10222335
	v_mul_f32_e32 v57, v53, v57                                // 000000713024: 10727335
	v_mul_f32_e32 v59, v53, v59                                // 000000713028: 10767735
	v_mul_f32_e32 v60, v53, v60                                // 00000071302C: 10787935
	v_bfe_u32 v53, v20, 16, 1                                  // 000000713030: D6100035 02052114
	v_bfe_u32 v61, v54, 16, 1                                  // 000000713038: D610003D 02052136
	v_bfe_u32 v62, v56, 16, 1                                  // 000000713040: D610003E 02052138
	v_bfe_u32 v63, v13, 16, 1                                  // 000000713048: D610003F 0205210D
	v_bfe_u32 v64, v17, 16, 1                                  // 000000713050: D6100040 02052111
	v_add3_u32 v20, v20, v53, 0x7fff                           // 000000713058: D6550014 03FE6B14 00007FFF
	v_add3_u32 v53, v54, v61, 0x7fff                           // 000000713064: D6550035 03FE7B36 00007FFF
	v_add3_u32 v54, v56, v62, 0x7fff                           // 000000713070: D6550036 03FE7D38 00007FFF
	v_bfe_u32 v65, v57, 16, 1                                  // 00000071307C: D6100041 02052139
	v_add3_u32 v13, v13, v63, 0x7fff                           // 000000713084: D655000D 03FE7F0D 00007FFF
	.long 0x7e6a3994                                           // 000000713090: 7E6A3994
	v_bfe_u32 v66, v58, 16, 1                                  // 000000713094: D6100042 0205213A
	v_add3_u32 v17, v17, v64, 0x7fff                           // 00000071309C: D6550011 03FE8111 00007FFF
	.long 0x7e1a39b6                                           // 0000007130A8: 7E1A39B6
	v_bfe_u32 v67, v14, 16, 1                                  // 0000007130AC: D6100043 0205210E
	s_waitcnt vmcnt(7)                                         // 0000007130B4: BF891FF7
	v_dot2_f32_bf16 v20, v21, v53, 0                           // 0000007130B8: CC1A4014 1A026B15
	s_waitcnt vmcnt(6)                                         // 0000007130C0: BF891BF7
	v_dot2_f32_bf16 v21, v25, v53, 0                           // 0000007130C4: CC1A4015 1A026B19
	s_waitcnt vmcnt(5)                                         // 0000007130CC: BF8917F7
	v_dot2_f32_bf16 v25, v29, v53, 0                           // 0000007130D0: CC1A4019 1A026B1D
	s_waitcnt vmcnt(4)                                         // 0000007130D8: BF8913F7
	v_dot2_f32_bf16 v29, v33, v53, 0                           // 0000007130DC: CC1A401D 1A026B21
	v_add3_u32 v56, v57, v65, 0x7fff                           // 0000007130E4: D6550038 03FE8339 00007FFF
	v_bfe_u32 v68, v18, 16, 1                                  // 0000007130F0: D6100044 02052112
	v_add3_u32 v57, v58, v66, 0x7fff                           // 0000007130F8: D6550039 03FE853A 00007FFF
	.long 0x7e703991                                           // 000000713104: 7E703991
	v_dot2_f32_bf16 v17, v22, v13, v20                         // 000000713108: CC1A4011 1C521B16
	v_dot2_f32_bf16 v20, v26, v13, v21                         // 000000713110: CC1A4014 1C561B1A
	v_dot2_f32_bf16 v21, v30, v13, v25                         // 000000713118: CC1A4015 1C661B1E
	v_dot2_f32_bf16 v13, v34, v13, v29                         // 000000713120: CC1A400D 1C761B22
	v_bfe_u32 v69, v59, 16, 1                                  // 000000713128: D6100045 0205213B
	v_add3_u32 v14, v14, v67, 0x7fff                           // 000000713130: D655000E 03FE870E 00007FFF
	v_bfe_u32 v70, v60, 16, 1                                  // 00000071313C: D6100046 0205213C
	v_add3_u32 v18, v18, v68, 0x7fff                           // 000000713144: D6550012 03FE8912 00007FFF
	.long 0x7e1c39b9                                           // 000000713150: 7E1C39B9
	v_dot2_f32_bf16 v17, v23, v56, v17                         // 000000713154: CC1A4011 1C467117
	v_dot2_f32_bf16 v20, v27, v56, v20                         // 00000071315C: CC1A4014 1C52711B
	v_dot2_f32_bf16 v21, v31, v56, v21                         // 000000713164: CC1A4015 1C56711F
	v_dot2_f32_bf16 v13, v35, v56, v13                         // 00000071316C: CC1A400D 1C367123
	v_bfe_u32 v71, v15, 16, 1                                  // 000000713174: D6100047 0205210F
	v_add3_u32 v58, v59, v69, 0x7fff                           // 00000071317C: D655003A 03FE8B3B 00007FFF
	v_bfe_u32 v72, v2, 16, 1                                   // 000000713188: D6100048 02052102
	v_add3_u32 v59, v60, v70, 0x7fff                           // 000000713190: D655003B 03FE8D3C 00007FFF
	.long 0x7e743992                                           // 00000071319C: 7E743992
	v_dot2_f32_bf16 v17, v24, v14, v17                         // 0000007131A0: CC1A4011 1C461D18
	v_dot2_f32_bf16 v18, v28, v14, v20                         // 0000007131A8: CC1A4012 1C521D1C
	v_dot2_f32_bf16 v20, v32, v14, v21                         // 0000007131B0: CC1A4014 1C561D20
	v_dot2_f32_bf16 v13, v36, v14, v13                         // 0000007131B8: CC1A400D 1C361D24
	v_bfe_u32 v73, v19, 16, 1                                  // 0000007131C0: D6100049 02052113
	v_add3_u32 v15, v15, v71, 0x7fff                           // 0000007131C8: D655000F 03FE8F0F 00007FFF
	v_bfe_u32 v74, v55, 16, 1                                  // 0000007131D4: D610004A 02052137
	v_add3_u32 v2, v2, v72, 0x7fff                             // 0000007131DC: D6550002 03FE9102 00007FFF
	.long 0x7e1e39bb                                           // 0000007131E8: 7E1E39BB
	s_waitcnt vmcnt(3)                                         // 0000007131EC: BF890FF7
	v_dot2_f32_bf16 v14, v37, v58, v17                         // 0000007131F0: CC1A400E 1C467525
	s_waitcnt vmcnt(2)                                         // 0000007131F8: BF890BF7
	v_dot2_f32_bf16 v17, v41, v58, v18                         // 0000007131FC: CC1A4011 1C4A7529
	s_waitcnt vmcnt(1)                                         // 000000713204: BF8907F7
	v_dot2_f32_bf16 v18, v45, v58, v20                         // 000000713208: CC1A4012 1C52752D
	s_waitcnt vmcnt(0)                                         // 000000713210: BF8903F7
	v_dot2_f32_bf16 v13, v49, v58, v13                         // 000000713214: CC1A400D 1C367531
	v_bfe_u32 v75, v16, 16, 1                                  // 00000071321C: D610004B 02052110
	v_add3_u32 v19, v19, v73, 0x7fff                           // 000000713224: D6550013 03FE9313 00007FFF
	v_add3_u32 v55, v55, v74, 0x7fff                           // 000000713230: D6550037 03FE9537 00007FFF
	.long 0x7e263982                                           // 00000071323C: 7E263982
	v_dot2_f32_bf16 v2, v38, v15, v14                          // 000000713240: CC1A4002 1C3A1F26
	v_dot2_f32_bf16 v14, v42, v15, v17                         // 000000713248: CC1A400E 1C461F2A
	v_dot2_f32_bf16 v17, v46, v15, v18                         // 000000713250: CC1A4011 1C4A1F2E
	v_dot2_f32_bf16 v13, v50, v15, v13                         // 000000713258: CC1A400D 1C361F32
	v_add3_u32 v16, v16, v75, 0x7fff                           // 000000713260: D6550010 03FE9710 00007FFF
	.long 0x7e2039b7                                           // 00000071326C: 7E2039B7
	v_dot2_f32_bf16 v2, v39, v19, v2                           // 000000713270: CC1A4002 1C0A2727
	v_dot2_f32_bf16 v14, v43, v19, v14                         // 000000713278: CC1A400E 1C3A272B
	v_dot2_f32_bf16 v15, v47, v19, v17                         // 000000713280: CC1A400F 1C46272F
	v_dot2_f32_bf16 v13, v51, v19, v13                         // 000000713288: CC1A400D 1C362733
	v_cmp_ge_i32_e32 vcc_lo, v7, v8                            // 000000713290: 7C8C1107
	v_dot2_f32_bf16 v2, v40, v16, v2                           // 000000713294: CC1A4002 1C0A2128
	v_dot2_f32_bf16 v14, v44, v16, v14                         // 00000071329C: CC1A400E 1C3A212C
	v_dot2_f32_bf16 v15, v48, v16, v15                         // 0000007132A4: CC1A400F 1C3E2130
	v_dot2_f32_bf16 v13, v52, v16, v13                         // 0000007132AC: CC1A400D 1C362134
	s_or_b32 s17, vcc_lo, s17                                  // 0000007132B4: 8C11116A
	v_add_f32_e32 v9, v9, v2                                   // 0000007132B8: 06120509
	v_add_f32_e32 v10, v10, v14                                // 0000007132BC: 06141D0A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007132C0: BF870003
	v_dual_add_f32 v12, v12, v15 :: v_dual_add_f32 v11, v11, v13// 0000007132C4: C9081F0C 0C0A1B0B
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000007132CC: 917E117E
	s_cbranch_execnz 65113                                     // 0000007132D0: BFA6FE59 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi8ELb1EEEvPKhPKtPvll+0x138>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000007132D4: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007132D8: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007132DC: 8C7E0E7E
	.long 0xd71f0001                                           // 0000007132E0: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007132E4: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000007132E8: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007132EC: 3A040290
	v_xor_b32_e32 v8, 8, v1                                    // 0000007132F0: 3A100288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007132F4: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007132F8: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007132FC: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000713300: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000713304: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000713308: 30040482
	ds_bpermute_b32 v3, v2, v9                                 // 00000071330C: DACC0000 03000902
	s_waitcnt lgkmcnt(0)                                       // 000000713314: BF89FC07
	v_add_f32_e32 v3, v9, v3                                   // 000000713318: 06060709
	ds_bpermute_b32 v7, v2, v12                                // 00000071331C: DACC0000 07000C02
	ds_bpermute_b32 v4, v2, v10                                // 000000713324: DACC0000 04000A02
	ds_bpermute_b32 v2, v2, v11                                // 00000071332C: DACC0000 02000B02
	s_waitcnt lgkmcnt(2)                                       // 000000713334: BF89FC27
	v_dual_cndmask_b32 v8, v1, v8 :: v_dual_add_f32 v7, v12, v7// 000000713338: CA481101 08060F0C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000713340: BF870001
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000713344: 30101082
	s_waitcnt lgkmcnt(0)                                       // 000000713348: BF89FC07
	v_add_f32_e32 v2, v11, v2                                  // 00000071334C: 0604050B
	v_xor_b32_e32 v12, 4, v1                                   // 000000713350: 3A180284
	ds_bpermute_b32 v11, v8, v7                                // 000000713354: DACC0000 0B000708
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 00000071335C: 7C9818A0
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 000000713360: 02181901
	s_waitcnt lgkmcnt(0)                                       // 000000713364: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000713368: BF870001
	v_dual_add_f32 v7, v7, v11 :: v_dual_lshlrev_b32 v12, 2, v12// 00000071336C: C9221707 070C1882
	v_add_f32_e32 v4, v10, v4                                  // 000000713374: 0608090A
	ds_bpermute_b32 v9, v8, v3                                 // 000000713378: DACC0000 09000308
	ds_bpermute_b32 v10, v8, v4                                // 000000713380: DACC0000 0A000408
	ds_bpermute_b32 v8, v8, v2                                 // 000000713388: DACC0000 08000208
	s_waitcnt lgkmcnt(0)                                       // 000000713390: BF89FC07
	v_dual_add_f32 v3, v3, v9 :: v_dual_add_f32 v2, v2, v8     // 000000713394: C9081303 03021102
	ds_bpermute_b32 v8, v12, v3                                // 00000071339C: DACC0000 0800030C
	v_add_f32_e32 v4, v4, v10                                  // 0000007133A4: 06081504
	ds_bpermute_b32 v10, v12, v7                               // 0000007133A8: DACC0000 0A00070C
	ds_bpermute_b32 v11, v12, v2                               // 0000007133B0: DACC0000 0B00020C
	s_waitcnt lgkmcnt(2)                                       // 0000007133B8: BF89FC27
	v_add_f32_e32 v3, v3, v8                                   // 0000007133BC: 06061103
	ds_bpermute_b32 v9, v12, v4                                // 0000007133C0: DACC0000 0900040C
	v_xor_b32_e32 v12, 2, v1                                   // 0000007133C8: 3A180282
	s_waitcnt lgkmcnt(1)                                       // 0000007133CC: BF89FC17
	v_dual_add_f32 v7, v7, v10 :: v_dual_add_f32 v8, v2, v11   // 0000007133D0: C9081507 07081702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007133D8: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000007133DC: 7C9818A0
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 0000007133E0: 02181901
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000007133E4: 30181882
	s_waitcnt lgkmcnt(0)                                       // 0000007133E8: BF89FC07
	v_add_f32_e32 v4, v4, v9                                   // 0000007133EC: 06081304
	ds_bpermute_b32 v2, v12, v3                                // 0000007133F0: DACC0000 0200030C
	ds_bpermute_b32 v10, v12, v7                               // 0000007133F8: DACC0000 0A00070C
	ds_bpermute_b32 v11, v12, v8                               // 000000713400: DACC0000 0B00080C
	ds_bpermute_b32 v9, v12, v4                                // 000000713408: DACC0000 0900040C
	v_xor_b32_e32 v12, 1, v1                                   // 000000713410: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000713414: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000713418: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 00000071341C: 02021901
	s_waitcnt lgkmcnt(3)                                       // 000000713420: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v12, 2, v1 // 000000713424: C9220503 010C0282
	s_waitcnt lgkmcnt(2)                                       // 00000071342C: BF89FC27
	v_add_f32_e32 v3, v7, v10                                  // 000000713430: 06061507
	s_waitcnt lgkmcnt(1)                                       // 000000713434: BF89FC17
	v_add_f32_e32 v7, v8, v11                                  // 000000713438: 060E1708
	s_waitcnt lgkmcnt(0)                                       // 00000071343C: BF89FC07
	v_add_f32_e32 v2, v4, v9                                   // 000000713440: 06041304
	ds_bpermute_b32 v4, v12, v1                                // 000000713444: DACC0000 0400010C
	ds_bpermute_b32 v9, v12, v3                                // 00000071344C: DACC0000 0900030C
	ds_bpermute_b32 v10, v12, v7                               // 000000713454: DACC0000 0A00070C
	ds_bpermute_b32 v8, v12, v2                                // 00000071345C: DACC0000 0800020C
	v_cmpx_eq_u32_e32 0, v6                                    // 000000713464: 7D940C80
	s_cbranch_execz 9                                          // 000000713468: BFA50009 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi8ELb1EEEvPKhPKtPvll+0x990>
	s_waitcnt lgkmcnt(1)                                       // 00000071346C: BF89FC17
	v_dual_add_f32 v10, v7, v10 :: v_dual_add_f32 v7, v1, v4   // 000000713470: C9081507 0A060901
	s_waitcnt lgkmcnt(0)                                       // 000000713478: BF89FC07
	v_dual_add_f32 v9, v3, v9 :: v_dual_add_f32 v8, v2, v8     // 00000071347C: C9081303 09081102
	v_lshlrev_b32_e32 v1, 4, v5                                // 000000713484: 30020A84
	ds_store_b128 v1, v[7:10]                                  // 000000713488: DB7C0000 00000701
	s_or_b32 exec_lo, exec_lo, s0                              // 000000713490: 8C7E007E
	.long 0xd4540000                                           // 000000713494: D4540000
	v_cndmask_b32_e32 v0, s12, v2, vcc_lo                      // 000000713498: 0200040C
	v_cmp_gt_u32_e32 vcc_lo, 4, v0                             // 00000071349C: 7C980084
	s_waitcnt lgkmcnt(0)                                       // 0000007134A0: BF89FC07
	s_barrier                                                  // 0000007134A4: BFBD0000
	buffer_gl0_inv                                             // 0000007134A8: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000007134B0: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007134B4: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000007134B8: BE812000
	s_cbranch_execz 43                                         // 0000007134BC: BFA5002B <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi8ELb1EEEvPKhPKtPvll+0xa6c>
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000007134C0: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000007134C4: 84808202
	ds_load_2addr_b32 v[1:2], v7 offset1:4                     // 0000007134C8: D8DC0400 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:8 offset1:12          // 0000007134D0: D8DC0C08 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:16 offset1:20         // 0000007134D8: D8DC1410 05000007
	s_waitcnt lgkmcnt(2)                                       // 0000007134E0: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 0000007134E4: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007134E8: BF870131
	v_add_f32_e32 v9, v1, v2                                   // 0000007134EC: 06120501
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 0000007134F0: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(1)                                       // 0000007134F8: BF89FC17
	v_add_f32_e32 v3, v9, v3                                   // 0000007134FC: 06060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000713500: BF870191
	v_add_f32_e32 v4, v3, v4                                   // 000000713504: 06080903
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000713508: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 000000713510: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000713514: BF8700C2
	v_add_f32_e32 v0, v4, v5                                   // 000000713518: 06000B04
	ds_load_2addr_b32 v[7:8], v7 offset0:24 offset1:28         // 00000071351C: D8DC1C18 07000007
	v_add_f32_e32 v3, v0, v6                                   // 000000713524: 06060D00
	.long 0xd73c0000                                           // 000000713528: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000071352C: 02020282
	.long 0xd7006a00                                           // 000000713530: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000713534: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000713538: BF870111
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000071353C: D5207C01 01AA0209
	.long 0xd7006a00                                           // 000000713544: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000713548: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000071354C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000713550: D5207C01 01AA0201
	s_waitcnt lgkmcnt(0)                                       // 000000713558: BF89FC07
	v_add_f32_e32 v2, v3, v7                                   // 00000071355C: 06040F03
	v_add_f32_e32 v2, v2, v8                                   // 000000713560: 06041102
	global_store_b32 v[0:1], v2, off                           // 000000713564: DC6A0000 007C0200
	s_endpgm                                                   // 00000071356C: BFB00000
		...

